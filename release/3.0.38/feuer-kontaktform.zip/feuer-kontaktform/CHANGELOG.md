# Changelog




## [3.0.38] - 2026-06-29

- Kritischer PHP-Startfehler behoben: UTF-8-BOM vor `<?php` wurde aus PHP-Dateien entfernt.
- Versions-Sync schreibt Dateien jetzt explizit als UTF-8 ohne BOM, damit `declare(strict_types=1)` nicht blockiert wird.
- `uninstall.php` laedt den Inbound-Support jetzt vollstaendig, bevor die Plugin-Uninstall-Routine gestartet wird.
- Production-ZIP neu gebaut und auf sichere Pfade, Server-Entpackbarkeit und BOM-freie PHP-Dateien geprueft.

## [3.0.37] - 2026-06-29

- Hotfix gegen kritische Fehler nach 3.0.36.
- Riskante typed callbacks in den neuen IMAP-Postfach-Einstellungen entfernt.
- Fallback-Ketten in Empfaenger-Ausgabe und Dashboard-Widget vereinfacht.
- Sichere Fallbacks fuer String-Pruefungen und IV-Erzeugung bei Secret-Verschluesselung ergaenzt.
- Production-ZIP mit Strukturpruefung neu gebaut.
## [3.0.36] - 2026-06-29

- Mehrere zusätzliche IMAP-Postfächer können für den Ticket-Mailabruf konfiguriert werden.
- SMTP-, IMAP- und externe Antispam-Secrets werden verschlüsselt in den WordPress-Optionen gespeichert.
- Frontend-Spamschutz erweitert: Honeypot, optional Cloudflare Turnstile und optional Google reCAPTCHA v2.
- WordPress-Dashboard-Widget für berechtigte Benutzer mit den letzten Anfragen.
- Privacy-Erase entfernt jetzt zusätzlich hochgeladene Dateien aus Ticket-Feldern.
- Release-Build prüft ZIP-Einträge auf serverfreundliche Pfade und saubere Attribute.
- Composer-Konfiguration für PHPCS/WPCS und PHPStan ergänzt.

## 3.0.35 - 2026-06-22

- Die Г¶ffentliche `index.php` wurde als professionelle Plugin-PrГ¤sentationsseite neu aufgebaut.
- Angaben zu Dateianzahl, Codezeilen und Zeichen wurden entfernt.
- Die Seite beschreibt jetzt Zweck, Kernfunktionen, Vorteile fГјr freiwillige Feuerwehren, Datenschutzanforderungen in Deutschland, E-Mail-Betrieb, WordPress-Einbindung, Autor und Projektseite.
- Der Statistik-Scanner in `index.php` wurde entfernt, damit die Г¶ffentliche Seite statisch, schneller und einfacher zu betreiben ist.

## 3.0.34 - 2026-06-21

- WP-Cron fГјr das Ticket-Postfach wird bei Aktivierung, Update und nach dem Speichern der Einstellungen zuverlГ¤ssig geplant.
- Im Tab `Ticket-Postfach` wird angezeigt, ob die nГ¤chste automatische PostfachprГјfung geplant ist.
- Bei aktivem `DISABLE_WP_CRON` zeigt die Administration einen Hinweis, dass der Server WordPress-Cron extern aufrufen muss.
- GeschГјtzte Anfrage-Links nutzen jetzt kurze nicht erratbare Zugriffscodes statt langer Token.
- Der Zugriffscode wird zusГ¤tzlich als Cookie-Sitzung gesetzt, aber nicht mehr aus der URL entfernt, damit berechtigte Personen den Link weitergeben und Г¶ffnen kГ¶nnen.
- Das Г„ndern der Anfrage-ID in der URL reicht weiterhin nicht aus, weil jede Anfrage einen eigenen geheimen Code benГ¶tigt.
- Alte bereits versendete Links mit langem `token` bleiben bis zum Ablauf kompatibel.
- Wenn ein angemeldeter WordPress-Benutzer die geschГјtzte Anfrage Г¶ffnet, wird sein vollstГ¤ndiger Name im Antwortformular automatisch eingetragen.

## 3.0.33 - 2026-06-14

- Neue E-Mails ohne Anfrage Nr. kГ¶nnen direkt am Ticket-Postfach als eigenstГ¤ndige Anfrage angenommen werden.
- Jede direkte E-Mail erhГ¤lt automatisch eine 8-stellige Anfrage Nr. und wird vollstГ¤ndig im Anfrageverlauf gespeichert.
- Direkte E-Mail-Anfragen werden an einen frei konfigurierbaren Standard-EmpfГ¤nger weitergeleitet.
- Der Standard-EmpfГ¤nger erhГ¤lt den geschГјtzten Browserdialog mit Anfrageansicht, Verlauf, EmpfangsbestГ¤tigung und Antwortformular.
- Optional erhГ¤lt der ursprГјngliche Absender eine automatische EmpfangsbestГ¤tigung mit Anfrage Nr.
- Antworten werden auch dann Гјber die sichere Plus-Adresse zugeordnet, wenn die Anfrage Nr. aus dem Betreff entfernt wurde.
- Automatische Antworten, Zustellberichte und interne Absenderadressen werden zum Schutz vor E-Mail-Schleifen abgewiesen.
- Direkte E-Mail-Anfragen werden in der Administration, im Datenschutzexport und in der JSON-Sicherung als eigener Eingangsweg gefГјhrt.

## 3.0.32 - 2026-06-14

- Abteilungen kГ¶nnen eine Anfrage Гјber einen zeitlich begrenzten, signierten Zugriff sicher Г¶ffnen.
- Die geschГјtzte Seite zeigt Anfrage, Felder und vollstГ¤ndigen Verlauf und erlaubt EmpfangsbestГ¤tigung sowie direkte Antworten.
- Zugriffstoken werden nur als Hash gespeichert, nach dem ersten Г–ffnen aus der URL entfernt und in eine `HttpOnly`-Cookie Гјbernommen.
- Administratoren sehen GГјltigkeit und letzte Nutzung und kГ¶nnen einen Zugriff sofort widerrufen.
- Neues bidirektionales Ticket-Postfach, zum Beispiel `anfrage@domain.de`, mit IMAP-Import alle fГјnf Minuten.
- Antworten von Besuchern werden gespeichert und lГ¶sen eine neue Benachrichtigung mit frischem Zugriffslink an die Abteilung aus.
- Antworten der Abteilung aus dem E-Mail-Programm werden gespeichert und Гјber den Plugin-Mailer an den Besucher weitergeleitet.
- Sichere Plus-Adressen wie `anfrage+fkt-12345678-securecode@domain.de` schГјtzen den Import zusГ¤tzlich zu Anfrage Nr. und AbsenderprГјfung.
- Benutzerdefinierte Autoantwort-Betreffzeilen erhalten automatisch die Anfrage Nr., wenn sie dort fehlt.
- Der WordPress-Datenschutzexport enthГ¤lt jetzt auch den vollstГ¤ndigen Nachrichtenverlauf.
- Voraussetzung fГјr den E-Mail-Import: PHP-IMAP und Plus-Adressierung oder Catch-all beim Mailanbieter.

## 3.0.31 - 2026-06-14

- Abteilungs-E-Mails enthalten jetzt eine signierte EmpfangsbestГ¤tigung.
- Die BestГ¤tigung erfolgt erst nach einem bewussten Klick auf der BestГ¤tigungsseite, damit automatische Link-PrГјfungen von Mailservern keinen falschen Empfang melden.
- Anfragen speichern und zeigen Versandstatus, EmpfГ¤nger, Anzahl der Versuche, Versandzeit, BestГ¤tigungszeit und den letzten technischen Fehler.
- Fehlgeschlagene oder unbestГ¤tigte Abteilungs-E-Mails kГ¶nnen direkt aus der Anfrage erneut gesendet werden, ohne die Autoantwort an den Besucher zu wiederholen.
- Fehler aus `wp_mail()` und PHPMailer werden jetzt fГјr Testmails, Abteilungs-E-Mails, Autoantworten und Antworten aus dem Plugin protokolliert.
- Eine aktivierte, aber unvollstГ¤ndige SMTP-Konfiguration wird nicht mehr still Гјber den Standardversand umgangen.

## 3.0.30 - 2026-05-14

- Version 3.0.29 wurde als stabiler Zugriffs-Release dokumentiert.
- README, PrГ¤sentationsseite und Update-Metadaten beschreiben die Rollen- und Rechteverwaltung jetzt explizit als eigenstГ¤ndigen stabilen Release-Schritt.

## 3.0.29 - 2026-05-14

- Neue Zugriffssteuerung fГјr das Plugin nach WordPress-Rollen.
- Administratoren behalten immer Vollzugriff.
- FГјr Redakteur und andere Rollen kann jetzt pro Bereich festgelegt werden, ob sie Anfragen sehen, antworten, Abteilungen verwalten, Einstellungen Г¶ffnen oder Protokolle sehen dГјrfen.
- Die Zugriffs-Matrix selbst kann nur vom Administrator geГ¤ndert werden.

## 3.0.28 - 2026-05-04

- Interne Benachrichtigungen zeigen bei `Direkte Antwort an` jetzt nur noch die reine E-Mail-Adresse.
- Der echte `Reply-To` Header fГјr interne Benachrichtigungen wird jetzt ebenfalls nur noch als reine E-Mail-Adresse gesetzt, um Probleme mit einzelnen Mailprogrammen und gespeicherten Antwortadressen zu vermeiden.

## 3.0.27 - 2026-05-04

- Bitte Texte in der AdminoberflГ¤che wurden auf korrekte UTF-8-Umlaute bereinigt.
- Sichtbare Begriffe wie `EmpfГ¤nger`, `PrГјfung`, `DatenschutzerklГ¤rung`, `zurГјck`, `Гјber`, `GrГ¶Гџe`, `AktivitГ¤ten` und die neue SicherungsoberflГ¤che zeigen jetzt wieder normale deutsche Zeichen.

## 3.0.26 - 2026-05-04

- Neue Sicherungsfunktion im Adminbereich fГјr Export und Wiederherstellung aller Plugin-Daten als JSON-Datei.
- Gesichert werden jetzt Einstellungen, EmpfГ¤nger-E-Mails, Abteilungen, Themen, Anfragen, NachrichtenverlГ¤ufe und Protokolle.
- Wiederherstellungen ersetzen den kompletten aktuellen Plugin-Bestand und protokollieren den Import im Plugin-Log.

## 3.0.25 - 2026-05-01

- Der Updater liest nach der Installation die tatsГ¤chlich installierte Plugin-Version direkt aus der Plugin-Datei.
- WordPress- und Plugin-Update-Caches werden nach der Installation konsequenter geleert.
- Wenn nach einem Update weiterhin die alte Version installiert ist, meldet der Updater jetzt einen klaren Fehler statt erneut still eine neue Version anzuzeigen.

## 3.0.24 - 2026-05-01

- Der Plugin-Name in der WordPress-Pluginliste und in den Plugin-Infos lautet wieder `Feuer-Kontaktform`.
- Das Admin-MenГј bleibt weiterhin verkГјrzt bei `Kontaktform`.

## 3.0.23 - 2026-05-01

- Interne Benachrichtigungen setzen den `Reply-To` jetzt mit Name und E-Mail des eigentlichen Antwortziels.
- Benachrichtigungs-E-Mails zeigen sichtbar an, an wen eine direkte Antwort aus dem Mailprogramm gesendet wird.
- Die Einstellung `Reply-To fГјr interne Benachrichtigung` markiert den Absender der Anfrage jetzt als empfohlene Option.

## 3.0.22 - 2026-04-30

- Sichtbarer Plugin-Name in der WordPress-AdminoberflГ¤che wurde auf `Kontaktform` verkГјrzt.
- MenГјeintrГ¤ge, Гњberschriften, Plugin-Infos und Privacy-Labels verwenden jetzt ebenfalls `Kontaktform`.

## 3.0.21 - 2026-04-29

- Standard-Autoantworten verwenden wieder durchgehend `Anfrage Nr.`.
- Der alte Hinweistext zum FortfГјhren des Dialogs im Betreff wurde aus Text- und HTML-Autoantwort entfernt.
- Bestehende Themen werden beim Update auf die neue Standard-EingangsbestГ¤tigung migriert.

## 3.0.20 - 2026-04-23

- Direkte Beispiel-Links werden jetzt auch direkt in der Abteilungs-Konfiguration angezeigt.
- Direkte Beispiel-Links werden jetzt auch direkt in der Themen-Konfiguration angezeigt.
- Der `Shortcodes`-Tab jeder Abteilung zeigt jetzt zusГ¤tzlich direkte URL-Beispiele fГјr Abteilung und Thema.

## 3.0.19 - 2026-04-23

- Seiten mit eingebautem Formular unterstГјtzen jetzt direkte Sprung-Links Гјber URL-Parameter.
- UnterstГјtzt werden `?feuer_department=slug` und `?feuer_department=slug&feuer_topic=slug`.
- ZusГ¤tzlich werden die deutschen Aliase `?abteilung=slug` und `?thema=slug` verstanden.
- Im Bereich `Einstellungen -> Shortcodes` werden jetzt konkrete Beispiel-Links angezeigt.

## 3.0.18 - 2026-04-23

- Admin-OberflГ¤che erzeugt den Slug fГјr Abteilungen und Themen jetzt live aus `Name` oder `Thema`.
- Umlaute wie `Г„`, `Г–`, `Гњ`, `Г¤`, `Г¶`, `Гј` und `Гџ` werden fГјr den Slug sauber in `ae`, `oe`, `ue` und `ss` umgesetzt.
- Manuell geГ¤nderte Slugs bleiben erhalten und werden nicht automatisch Гјberschrieben.
- Asset-Version erhГ¶ht, damit WordPress den neuen Admin-JavaScript-Stand direkt lГ¤dt.

## 3.0.17 - 2026-04-23

- Speichern von Abteilungen zeigt jetzt konkrete Fehlermeldungen bei leerem Namen, ungГјltiger EmpfГ¤nger-E-Mail, leerem Slug, doppeltem Slug und Datenbankfehlern.
- Leerer Abteilungs-Slug wird aus dem Namen erzeugt und leere Sortierung automatisch sauber fortgefГјhrt.
- Themen speichern jetzt dieselbe Validierungslogik: klare Meldungen bei ungГјltiger Abteilung, leerem Thema, ungГјltiger abweichender E-Mail, leerem oder doppeltem Slug und Datenbankfehlern.
- Frontend-AJAX lehnt deaktivierte Abteilungen und Themen jetzt serverseitig ab.
- Select-Felder validieren eingereichte Werte jetzt auch serverseitig gegen die erlaubten Optionen.
- Eine Anfrage wird nur noch als erfolgreich bestГ¤tigt, wenn der Ticket-Datensatz wirklich in der Datenbank gespeichert wurde; bei INSERT-Fehlern wird kein falscher Erfolg mehr ausgegeben.
- Protokolle enthalten jetzt auch Validierungs- und Ticket-Speicherfehler fГјr die technische Nachverfolgung.

## 3.0.16 - 2026-04-22

- Datenschutz-Auswahl im Frontend neutral gestaltet: keine grГјnen oder roten ButtonflГ¤chen mehr.
- AusgewГ¤hlte Datenschutz-Option zeigt jetzt eine Checkmark-Markierung direkt in der SchaltflГ¤che.
- Datenschutz-SchaltflГ¤chen sind kompakter.
- AbstГ¤nde zwischen den Eingabefeldern im Schritt `Welche Informationen brauchen wir?` reduziert.
- Asset-Version erhГ¶ht, damit WordPress und Browser den neuen Frontend-CSS/JS-Stand laden.

## 3.0.15 - 2026-04-22

- Erste finale stabile Version des neuen Feuer-Kontaktform Plugins.
- Sichtbare deutsche Texte in Adminbereich, Frontend, Autoantworten, E-Mail-Vorlagen, Update-Dialogen und Plugin-Seite verwenden jetzt konsequent Umlaute wie `Г¤`, `Г¶`, `Гј` und `Гџ`.
- Technische Slugs, Shortcode-Attribute, Dateinamen und interne Identifikatoren bleiben unverГ¤ndert, damit bestehende Einbindungen weiter funktionieren.

## 3.0.14 - 2026-04-22

- Datenschutz-Auswahl im Frontend fГјhrt bei `Ja, ich bin einverstanden` automatisch zum nГ¤chsten Schritt.
- Bei `Nein` bleibt der Nutzer im Datenschutz-Schritt und sieht die Meldung, dass die Anfrage ohne Einwilligung nicht verarbeitet werden kann.
- Wiederholter Klick auf die bereits gewГ¤hlte Datenschutz-Option funktioniert auch nach `ZurГјck`.

## 3.0.13 - 2026-04-22

- Einstellungen enthalten jetzt neben `Update prГјfen` auch `Update jetzt installieren`.
- Die manuelle Update-PrГјfung aktualisiert den WordPress-Update-Transient, damit WordPress das Entwicklerpaket sofort als Update erkennt.
- Update-Installation nutzt den WordPress `Plugin_Upgrader` und installiert das Paket von `wdmin.com/plugins/feuer-kontaktform/`.
- Erfolgreiche und fehlgeschlagene Update-Installationen werden in den Protokollen gespeichert.

## 3.0.12 - 2026-04-22

- Abteilungen kГ¶nnen in der Admin-OberflГ¤che per `Hoch` und `Runter` sortiert werden.
- Die neue Reihenfolge wird dauerhaft als `sort_order` gespeichert und gilt dadurch auch fГјr die Frontend-Auswahl.
- Protokolle zeigen das Verschieben einer Abteilung als eigenes Ereignis.

## 3.0.11 - 2026-04-22

- Verlauf in Anfragen zeigt jetzt den Namen des Absenders und den vollen Namen des antwortenden Administrators statt `inbound`/`outbound`.
- Protokolle zeigen den vollstГ¤ndigen Namen des Administrators, wenn Vorname/Nachname gesetzt sind.
- Standard-Feldreihenfolge fГјr neue Themen geГ¤ndert: zuerst `Titel / Betreff`, dann Name und Kontaktdaten.
- Themenfelder kГ¶nnen in der Themenkonfiguration per `Hoch` und `Runter` sortiert werden.
- Antwortformular in Anfragen wird mit BegrГјГџung `{{name}}` und Signatur mit Abteilung, Website-Name und Website-Link vorbelegt.
- Antwortmakros enthalten jetzt auch `{{site_url}}`.

## 3.0.10 - 2026-04-22

- Mindestanforderung fГјr WordPress auf `6.9` gesetzt.
- Update-Metadaten melden `requires` jetzt ebenfalls als `6.9`.
- Plugin-Info liefert auch bei temporГ¤r nicht erreichbarem Update-Server eine lokale Fallback-Antwort mit korrekter KompatibilitГ¤t.

## 3.0.9 - 2026-04-22

- Plugin-Info setzt `tested` mindestens auf die aktuelle WordPress-Version, wenn die Server-Metadaten niedriger sind.
- Warnung `Dieses Plugin wurde nicht mit deiner aktuellen WordPress-Version getestet` im WordPress-Detailfenster wird dadurch vermieden.
- Update-PrГјfung in den Einstellungen zeigt jetzt installierte Version, Server-Version, getestete WordPress-Version, Download-URL, letzte PrГјfung und klaren Status.
- Manuelle Update-PrГјfung unterscheidet zwischen `aktuell`, `Update verfГјgbar` und `fehlgeschlagen`.

## 3.0.8 - 2026-04-22

- Datenschutz-Schritt im Frontend verschoben: zuerst Abteilung, dann Thema, danach Datenschutz.
- Bei direkten Shortcodes auf Abteilung/Thema bleibt Datenschutz der erste sichtbare Schritt, wenn die vorherigen Schritte Гјbersprungen werden.

## 3.0.7 - 2026-04-22

- Antworten aus dem Anfrage-Bereich verwenden jetzt `Name der Website` aus den Einstellungen im HTML-Kopf und in der Signatur.
- Logo aus den Einstellungen wird in Antworten aus dem Plugin angezeigt, wenn gesetzt.
- Platzhalter im Antworttext werden ersetzt: `{{site_name}}`, `{{ticket_id}}`, `{{name}}`, `{{topic}}`, `{{subject}}`, `{{email}}`, `{{vorname}}`, `{{nachname}}`, `{{telefon}}`.
- Hinweis auf verfГјgbare Platzhalter im Antwortformular ergГ¤nzt.

## 3.0.6 - 2026-04-22

- Datenschutz-Schritt im Frontend kann in den Einstellungen aktiviert oder deaktiviert werden.
- Anfragen speichern, ob der Datenschutz-Schritt aktiv war oder deaktiviert wurde.
- WordPress Privacy Export unterscheidet zwischen bestГ¤tigter Zustimmung und nicht abgefragtem Datenschutz-Schritt.
- Admin-Tabs merken sich die zuletzt geГ¶ffnete Ansicht nach dem Speichern und Redirect.

## 3.0.5 - 2026-04-22

- Datenschutz-Auswahl im Frontend als zwei klare Buttons gestaltet.
- Zustimmung wird als grГјner Button hervorgehoben.
- Ablehnung wird als weisser Button mit roter Umrandung dargestellt.

## 3.0.4 - 2026-04-22

- Abteilungen & Themen neu geordnet: erster Tab `Neue Abteilung`, danach Abteilungs-Tabs mit `Abteilung`, `Shortcodes` und Themen.
- Frontend-Kontaktstrecke um Designvarianten und Feldstile erweitert.
- Гњberfluessige Rahmen um einzelne Frontend-Felder entfernt.
- Anfragen als aufklappbare Karten mit Kopfzeile Anfrage Nr., Abteilung, Thema, Absender und Datum neu gestaltet.
- Antworten kГ¶nnen direkt aus dem Plugin per E-Mail gesendet und im Anfrage-Verlauf gespeichert werden.
- Betreff fГјr Autoantwort und Abteilungsbenachrichtigung nutzt Anfrage Nr., Thema und den vom Besucher eingegebenen Betreff.
- Abteilungsbenachrichtigung als HTML-Mail ohne Datenschutz/IP/User-Agent-Daten neu gestaltet.
- WordPress Privacy Export/Erase fГјr gespeicherte Anfrage-Daten ergГ¤nzt.
- Erlaubte Dateiformate und maximale Upload-GrГ¶Гџe in den Einstellungen konfigurierbar gemacht.
- Update-Cache wird gegen die aktuelle Plugin-Version neu bewertet, damit Updates nach der Installation nicht dauerhaft erneut angezeigt werden.

## 3.0.3 - 2026-04-21

- Neuer Einstellungen-Tab `Zustellbarkeit` mit PrГјfung und Hinweisen zu From-Domain, SPF, DMARC, DKIM und SMTP.
- SMTP-Versand direkt im Plugin ergГ¤nzt, inklusive Host, Port, VerschlГјsselung, Benutzername und Passwort.
- Reply-To-Strategien fГјr interne Benachrichtigungen und Autoantworten hinzugefГјgt.
- Autoantworten setzen optional `Auto-Submitted` und `X-Auto-Response-Suppress`, damit Mailserver Antwortschleifen besser erkennen.
- HTML-Autoantworten werden vor dem Speichern strenger bereinigt.
- E-Mail-Einstellungen bewahren gespeicherte Werte, wenn andere Einstellungs-Tabs gespeichert werden.

## 3.0.2 - 2026-04-21

- Abteilungen & Themen als Tab-System aufgebaut: erster Tab fГјr Abteilungsname/E-Mail, weitere Tabs fГјr Themen.
- Einstellungen als Tab-System gegliedert: Website & Logo, E-Mail, Datenschutz, System und Shortcodes.
- Logo-Auswahl Гјber die WordPress-Mediathek ergГ¤nzt.
- Protokolle in eine verstГ¤ndlichere AktivitГ¤tsansicht Гјbersetzt.
- Begriff `Anfrage Nr.` in der OberflГ¤che eingefГјhrt und Hinweis fГјr E-Mail-Betreff ergГ¤nzt.
- Neue Abteilungen erhalten keine vorinstallierten Themen mehr.
- Autoantworten kГ¶nnen je Thema aktiviert/deaktiviert und als Text oder HTML versendet werden.

## 3.0.1 - 2026-04-21

- Standard-Autoantwort fГјr neue Themen erweitert: BegrГјГџung, PrГјfhinweis, Anfrage Nr. und formeller deutscher Abschluss.
- Themen besitzen jetzt zwei Autoantwort-Vorlagen: Plain-Text und HTML.
- HTML-Autoantwort mit Logo-Block, Website-Name, Anfrage Nr., Datenschutzlink und sauberem E-Mail-Layout.
- Makro-Гњbersicht direkt unter den Autoantwort-Editoren ergГ¤nzt.
- Mailer sendet die HTML-Autoantwort mit `text/html`, wenn eine HTML-Vorlage gesetzt ist; sonst Plain-Text.

## 3.0.0 - 2026-04-21

- VollstГ¤ndiger Rewrite als Support- und Ticket-System.
- Neue Datenstruktur fГјr Abteilungen, Themen, Anfragen, Anfrage-Nachrichten und Admin-Protokolle.
- AJAX-Wizard mit Datenschutz-Schritt, Abteilungswahl, Themenwahl, dynamischen Themenfeldern, Captcha und Abschlussmeldung.
- 8-stellige zufГ¤llige Anfrage Nr. fГјr jede Anfrage.
- Shortcodes fГјr kompletten Wizard und direkte Schnellformulare auf Abteilung/Thema.
- Neue Adminbereiche fГјr Anfragen, Abteilungen & Themen, Einstellungen, E-Mail-Test, Update-PrГјfung und Protokolle.
- Sauberer Release-Builder ohne Windows-Archiv-Metadaten, directory entries, ACL/Owner und verschachtelte ZIP-Dateien.

## 2.5.0 - 2026-04-21

- Plugin-Metadaten auf Walter FГ¤rber und `wdmin.com/plugins/feuer-kontaktform/` aktualisiert.
- Self-hosted Update-Check mit Button in den Einstellungen hinzugefГјgt.
- Frontend auf einen einheitlichen Ticket-Wizard mit Datenschutz-Schritt und Ladeanzeige umgestellt.
- Anfrage Nr., Cookie-ID, GerГ¤tetyp und Datenschutz-Kontext fГјr Anfragen eingefГјhrt.
- Themen pro Formular hinzugefГјgt; Themen kГ¶nnen EmpfГ¤nger und Autoantwort Гјberschreiben.
- AktivitГ¤tsprotokoll fГјr zentrale Plugin-Aktionen hinzugefГјgt.
- DB-Schema auf `dbDelta()` umgestellt und neue Spalten fГјr Anfrage-Protokolle vorbereitet.
- CSV-Export gegen Spreadsheet-Formula-Injection abgesichert.
- Frontend-Designwerte werden jetzt als scoped CSS ausgegeben.
- GitHub-Basisdateien, Update-Metadaten und PrГ¤sentationsseite ergГ¤nzt.

## 2.4.0

- Vorherige interne Version mit Formularverwaltung, SMTP, Autoantworten, Webhooks, JSON-Dateien und mehreren Layoutvarianten.
