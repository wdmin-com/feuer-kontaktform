<?php
declare(strict_types=1);

$version = '3.0.48';
?><!doctype html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Feuer-Kontaktform Plugin</title>
    <style>
        body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#1f2937;background:#f6f7f7;line-height:1.58}
        main{max-width:980px;margin:0 auto;padding:40px 20px}
        section{background:#fff;border:1px solid #d9dee7;border-radius:8px;margin:0 0 18px;padding:24px}
        h1,h2{margin:0 0 12px;color:#111827}
        h1{font-size:34px;line-height:1.18}
        h2{font-size:22px}
        p{margin:0 0 12px}
        .lead{font-size:18px}
        .meta{color:#4b5563}
        .grid{display:grid;gap:14px;grid-template-columns:repeat(2,minmax(0,1fr))}
        .box{background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:16px}
        .box strong{display:block;margin:0 0 6px;color:#111827}
        ul{margin:0;padding-left:20px}
        li{margin:0 0 8px}
        code{background:#f3f4f6;border-radius:4px;padding:2px 5px}
        a{color:#b42318}
        @media(max-width:720px){main{padding:22px 14px}.grid{grid-template-columns:1fr}h1{font-size:28px}}
    </style>
</head>
<body>
<main>
    <section>
        <h1>Feuer-Kontaktform</h1>
        <p class="lead">Professionelles WordPress-Plugin fР вЂњРЎВr Kontaktformulare, Anfragen und E-Mail-basierte Support-Kommunikation auf Websites freiwilliger Feuerwehren.</p>
        <p class="meta">Entwickelt von Walter FР вЂњР’В¤rber. Projekt und Updates: <a href="https://wdmin.com/plugins/feuer-kontaktform/">wdmin.com/plugins/feuer-kontaktform/</a></p>
    </section>

    <section>
        <h2>Zweck des Plugins</h2>
        <p>Feuer-Kontaktform ersetzt einfache Kontaktformulare durch eine strukturierte Anfrage- und TicketlР вЂњР’В¶sung. Besucher wР вЂњР’В¤hlen Abteilung und Thema, geben die dafР вЂњРЎВr notwendigen Informationen ein und erhalten eine nachvollziehbare Anfrage Nr. Die Feuerwehr sieht alle eingehenden Nachrichten zentral im WordPress-Backend und kann den Dialog per E-Mail oder Р вЂњРЎВber einen geschР вЂњРЎВtzten Browserzugriff weiterfР вЂњРЎВhren.</p>
        <p>Das Plugin ist besonders fР вЂњРЎВr freiwillige Feuerwehren geeignet, bei denen unterschiedliche ZustР вЂњР’В¤ndigkeiten wie WehrfР вЂњРЎВhrung, Jugendfeuerwehr, Veranstaltungen, Presse, Social Media oder FР вЂњР’В¶rderverein sauber getrennt werden mР вЂњРЎВssen.</p>
    </section>

    <section>
        <h2>Kernfunktionen</h2>
        <div class="grid">
            <div class="box">
                <strong>Mehrstufige Kontaktstrecke</strong>
                <p>AJAX-Wizard mit Abteilung, Thema, Datenschutz, dynamischen Feldern, Captcha und klarer Abschlussmeldung.</p>
            </div>
            <div class="box">
                <strong>Abteilungen und Themen</strong>
                <p>Jede Abteilung kann eigene EmpfР вЂњР’В¤nger, Themen, Pflichtfelder, Autoantworten und Shortcodes erhalten.</p>
            </div>
            <div class="box">
                <strong>Anfrage Nr. und Verlauf</strong>
                <p>Jede Anfrage bekommt eine 8-stellige Nummer. Nachrichten, Antworten und technische Zustellinformationen bleiben nachvollziehbar gespeichert.</p>
            </div>
            <div class="box">
                <strong>Ticket-Postfach</strong>
                <p>Ein eigenes Postfach wie <code>anfrage@domain.de</code> kann Antworten und direkte E-Mails per IMAP importieren.</p>
            </div>
            <div class="box">
                <strong>GeschР вЂњРЎВtzter Browserdialog</strong>
                <p>ZustР вЂњР’В¤ndige Personen kР вЂњР’В¶nnen Anfragen Р вЂњРЎВber einen zeitlich begrenzten Link Р вЂњР’В¶ffnen, den Verlauf sehen und direkt antworten.</p>
            </div>
            <div class="box">
                <strong>Design und Einbindung</strong>
                <p>Mehrere Frontend-Designs, Feldstile, Schnellformulare, direkte Links und Shortcodes fР вЂњРЎВr Abteilungen oder Themen.</p>
            </div>
        </div>
    </section>

    <section>
        <h2>Vorteile fР вЂњРЎВr Feuerwehren</h2>
        <ul>
            <li>Anfragen landen direkt bei der richtigen ZustР вЂњР’В¤ndigkeit und mР вЂњРЎВssen nicht manuell sortiert werden.</li>
            <li>Pflichtangaben kР вЂњР’В¶nnen je Thema festgelegt werden, zum Beispiel andere Felder fР вЂњРЎВr Mitgliedschaft, Veranstaltungen oder Presseanfragen.</li>
            <li>Autoantworten informieren den Absender sofort Р вЂњРЎВber den Eingang der Nachricht.</li>
            <li>Die Anfrage Nr. erleichtert die Zuordnung, ohne den BР вЂњРЎВrger zu einer bestimmten Antwortform zu zwingen.</li>
            <li>Der geschР вЂњРЎВtzte Browserdialog erlaubt Antworten auch ohne WordPress-Backendzugang.</li>
            <li>Versandstatus, EmpfangsbestР вЂњР’В¤tigung und Protokolle machen technische Probleme beim E-Mail-Versand sichtbar.</li>
            <li>Backups und Wiederherstellung sichern Einstellungen, Abteilungen, Themen, Anfragen, Nachrichten und Protokolle.</li>
        </ul>
    </section>

    <section>
        <h2>Datenschutz und Anforderungen in Deutschland</h2>
        <p>Das Plugin ist fР вЂњРЎВr den Betrieb auf deutschen Feuerwehr-Websites konzipiert und unterstР вЂњРЎВtzt eine datenschutzbewusste Verarbeitung personenbezogener Daten. Es ersetzt keine Rechtsberatung, stellt aber technische Funktionen bereit, die bei einer DSGVO-konformen Organisation helfen.</p>
        <ul>
            <li>Datenschutz-Hinweis und Einwilligung kР вЂњР’В¶nnen vor der Dateneingabe aktiviert werden.</li>
            <li>URL zur DatenschutzerklР вЂњР’В¤rung, Hinweistext und Version der Einwilligung sind konfigurierbar.</li>
            <li>IP-Adresse, Browser, GerР вЂњР’В¤tetyp, Cookie-ID, Zeitpunkt und Zustimmung werden nachvollziehbar gespeichert.</li>
            <li>Personenbezogene Anfrage-Daten sind in WordPress Privacy Export/Erase eingebunden.</li>
            <li>Administrationsaktionen, Р вЂњРІР‚С›nderungen und E-Mail-Ereignisse werden protokolliert.</li>
            <li>Zugriffslinks sind zeitlich begrenzt, nicht erratbar und kР вЂњР’В¶nnen vom Administrator widerrufen werden.</li>
            <li>Rollen und Zugriffsrechte kР вЂњР’В¶nnen fР вЂњРЎВr Administratoren, Redakteure und weitere WordPress-Rollen getrennt gesteuert werden.</li>
        </ul>
    </section>

    <section>
        <h2>E-Mail, Zustellbarkeit und Betrieb</h2>
        <p>Feuer-Kontaktform kann WordPress-Mail, SMTP-Versand und ein IMAP-basiertes Ticket-Postfach nutzen. FР вЂњРЎВr eine gute Zustellbarkeit sollten SPF, DKIM und DMARC fР вЂњРЎВr die Absenderdomain korrekt gesetzt sein. Das Plugin zeigt Zustellbarkeits-Hinweise und speichert Fehler aus dem Mailversand.</p>
        <p>FР вЂњРЎВr den bidirektionalen E-Mail-Dialog benР вЂњР’В¶tigt das Ticket-Postfach PHP-IMAP sowie Plus-Adressierung oder Catch-all beim Mailanbieter. Die automatische PostfachprР вЂњРЎВfung lР вЂњР’В¤uft Р вЂњРЎВber WordPress-Cron; wenn WordPress-Cron auf dem Server deaktiviert ist, muss ein externer Server-Cron <code>wp-cron.php</code> regelmР вЂњР’В¤Р вЂњРЎСџig aufrufen.</p>
    </section>

    <section>
        <h2>Einbindung in WordPress</h2>
        <p>Kompletter Wizard: <code>[feuer-kontaktform]</code></p>
        <p>Direkt zu einer Abteilung: <code>[feuer-kontaktform department="wehrfuehrung"]</code></p>
        <p>Direkt zu einem Thema: <code>[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]</code></p>
        <p>Schnellformular: <code>[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]</code></p>
    </section>

    <section>
        <h2>Version und Updates</h2>
        <p>Aktuelle Version: <strong><?php echo htmlspecialchars($version, ENT_QUOTES, 'UTF-8'); ?></strong></p>
        <p>Update-Metadaten: <code>https://wdmin.com/plugins/feuer-kontaktform/update.json</code></p>
        <p>Aktuelles Release-ZIP: <code>https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip</code></p>
        <p>Website des Entwicklers: <a href="https://wdmin.com/">wdmin.com</a></p>
    </section>
</main>
</body>
</html>
