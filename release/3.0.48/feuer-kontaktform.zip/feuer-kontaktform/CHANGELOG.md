# Changelog














## [3.0.48] - 2026-06-30

- Anfragen-Menue und Kopfbereich auf die funktionierende Struktur aus Version 3.0.40 zurueckgefuehrt.
- Der sichtbare Unterpunkt heisst wieder `Anfragen`, die Seite zeigt wieder `Anfragen` und den Container `Letzte Anfragen`.
- Zusatzschutz gegen doppelte Hook-Registrierung und doppelte Seitenausgabe bleibt erhalten.
- Beschädigte UTF-8-Zeichen in Runtime-Texten der Plugin-Metadaten und IMAP-Protokollmeldungen bereinigt.

## [3.0.47] - 2026-06-29

- Fehler in der WordPress-Menue-Registrierung behoben: der Hauptmenue-Slug rendert die Anfragen-Seite jetzt direkt, der erste Unterpunkt heisst sichtbar `Anfragen`.
- Unsichere Redirects aus dem Admin-Page-Callback entfernt; die passende Admin-Seite wird direkt gerendert.
- Suche, Dashboard-Links und Formularaktionen nutzen wieder denselben stabilen WordPress-Slug `feuer-kontaktform`.

## [3.0.46] - 2026-06-29

- Anfragen-Seite wieder als eigenes Untermenue `Anfragen` registriert, damit WordPress die Seite nicht mit dem Hauptmenue `Kontaktform` verwechselt.
- Der sichtbare Kopfbereich mit `Kontaktform Anfragen`, `Letzte Anfragen` und Beschreibung wurde wiederhergestellt.
- Der Release wurde mit neuer Patch-Version gebaut, damit WordPress das Update tatsaechlich erkennt und installiert.

## [3.0.45] - 2026-06-29

- Ursache fuer die doppelte Anfragen-Ausgabe behoben: Hauptmenue und Anfragen-Untermenue verwendeten denselben WordPress-Slug.
- Das Kontaktform-Hauptmenue rendert die Anfragen-Seite jetzt direkt, wenn die Rolle Anfragen sehen darf; das doppelte Untermenue mit identischem Slug wurde entfernt.
## [3.0.44] - 2026-06-29

- Der obere Bereich der Anfragen-Seite wurde vollstaendig reduziert: kein Seitentitel, kein erklaerender Text, kein innerer Card-Container.
- Die Anfragen-Seite beginnt jetzt direkt mit Suche und Anfragenliste.
## [3.0.43] - 2026-06-29

- Auf der Anfragen-Seite wurde der innere `feuer-admin-card` Container vollstaendig entfernt.
- Suche und Anfragenliste liegen jetzt direkt im einzigen Seitencontainer.
## [3.0.42] - 2026-06-29

- Auf der Anfragen-Seite wurde der zusaetzliche innere Titel `Letzte Anfragen` entfernt.
- Die Seite zeigt jetzt nur noch einen sichtbaren Titel und darunter direkt den Container mit Suche und Anfragenliste.
## [3.0.41] - 2026-06-29

- Online-Ticketansicht fuer Abteilungen bereinigt: erstes Anfragefeld und Verlauf werden nicht mehr als zwei getrennte, doppelte Bereiche angezeigt.
- Die Kommunikation wird jetzt als ein Dialog dargestellt; eingehende Nachrichten stehen links, Antworten der Abteilung rechts.
- Doppelte identische Nachrichten werden im Dialogauszug nur einmal angezeigt.
## [3.0.40] - 2026-06-29

- Doppelte sichtbare Bezeichnung `Kontaktform Anfragen` bereinigt.
- Die Anfragen-Seite heisst jetzt kurz `Anfragen`; das WordPress-Dashboard-Widget heisst `Letzte Kontaktform-Anfragen`.
## [3.0.39] - 2026-06-29

- Separate JSON-Sicherung fuer alle Anfragen hinzugefuegt: Abteilungen, Themen, Tickets und Nachrichtenverlauf ohne Systemeinstellungen und Protokolle.
- Neue Einstellung fuer den Abteilungs-Zugriff: Empfangsbestaetigung kann vor dem Anzeigen der Anfrage erzwungen oder deaktiviert werden.
- Bei deaktivierter Pflichtbestaetigung markiert der sichere Ticket-Link den Empfang automatisch und oeffnet die Anfrage direkt.
- Versions-Sync liest und schreibt Dateien jetzt explizit als UTF-8 ohne BOM, damit Umlaute bei neuen Versionen nicht erneut beschaedigt werden.
## [3.0.38] - 2026-06-29

- Kritischer PHP-Startfehler behoben: UTF-8-BOM vor `<?php` wurde aus PHP-Dateien entfernt.
- Versions-Sync schreibt Dateien jetzt explizit als UTF-8 ohne BOM, damit `declare(strict_types=1)` nicht blockiert wird.
- `uninstall.php` laedt den Inbound-Support jetzt vollstaendig, bevor die Plugin-Uninstall-Routine gestartet wird.
- Production-ZIP neu gebaut und auf sichere Pfade, Server-Entpackbarkeit und BOM-freie PHP-Dateien geprueft.

## [3.0.37] - 2026-06-29

- Hotfix gegen kritische Fehler nach 3.0.36.
- Riskante typed callbacks in den neuen IMAP-Postfach-Einstellungen entfernt.
- Fallback-Ketten in Empfaenger-Ausgabe und Dashboard-Widget vereinfacht.
- Sichere Fallbacks fuer String-Pruefungen und IV-Erzeugung bei Secret-Verschluesselung ergaenzt.
- Production-ZIP mit Strukturpruefung neu gebaut.
## [3.0.36] - 2026-06-29

- Mehrere zusГ¤tzliche IMAP-PostfГ¤cher kГ¶nnen fГјr den Ticket-Mailabruf konfiguriert werden.
- SMTP-, IMAP- und externe Antispam-Secrets werden verschlГјsselt in den WordPress-Optionen gespeichert.
- Frontend-Spamschutz erweitert: Honeypot, optional Cloudflare Turnstile und optional Google reCAPTCHA v2.
- WordPress-Dashboard-Widget fГјr berechtigte Benutzer mit den letzten Anfragen.
- Privacy-Erase entfernt jetzt zusГ¤tzlich hochgeladene Dateien aus Ticket-Feldern.
- Release-Build prГјft ZIP-EintrГ¤ge auf serverfreundliche Pfade und saubere Attribute.
- Composer-Konfiguration fГјr PHPCS/WPCS und PHPStan ergГ¤nzt.

## 3.0.35 - 2026-06-22

- Die Р“В¶ffentliche `index.php` wurde als professionelle Plugin-PrР“В¤sentationsseite neu aufgebaut.
- Angaben zu Dateianzahl, Codezeilen und Zeichen wurden entfernt.
- Die Seite beschreibt jetzt Zweck, Kernfunktionen, Vorteile fР“Сr freiwillige Feuerwehren, Datenschutzanforderungen in Deutschland, E-Mail-Betrieb, WordPress-Einbindung, Autor und Projektseite.
- Der Statistik-Scanner in `index.php` wurde entfernt, damit die Р“В¶ffentliche Seite statisch, schneller und einfacher zu betreiben ist.

## 3.0.34 - 2026-06-21

- WP-Cron fР“Сr das Ticket-Postfach wird bei Aktivierung, Update und nach dem Speichern der Einstellungen zuverlР“В¤ssig geplant.
- Im Tab `Ticket-Postfach` wird angezeigt, ob die nР“В¤chste automatische PostfachprР“Сfung geplant ist.
- Bei aktivem `DISABLE_WP_CRON` zeigt die Administration einen Hinweis, dass der Server WordPress-Cron extern aufrufen muss.
- GeschР“Сtzte Anfrage-Links nutzen jetzt kurze nicht erratbare Zugriffscodes statt langer Token.
- Der Zugriffscode wird zusР“В¤tzlich als Cookie-Sitzung gesetzt, aber nicht mehr aus der URL entfernt, damit berechtigte Personen den Link weitergeben und Р“В¶ffnen kР“В¶nnen.
- Das Р“вЂћndern der Anfrage-ID in der URL reicht weiterhin nicht aus, weil jede Anfrage einen eigenen geheimen Code benР“В¶tigt.
- Alte bereits versendete Links mit langem `token` bleiben bis zum Ablauf kompatibel.
- Wenn ein angemeldeter WordPress-Benutzer die geschР“Сtzte Anfrage Р“В¶ffnet, wird sein vollstР“В¤ndiger Name im Antwortformular automatisch eingetragen.

## 3.0.33 - 2026-06-14

- Neue E-Mails ohne Anfrage Nr. kР“В¶nnen direkt am Ticket-Postfach als eigenstР“В¤ndige Anfrage angenommen werden.
- Jede direkte E-Mail erhР“В¤lt automatisch eine 8-stellige Anfrage Nr. und wird vollstР“В¤ndig im Anfrageverlauf gespeichert.
- Direkte E-Mail-Anfragen werden an einen frei konfigurierbaren Standard-EmpfР“В¤nger weitergeleitet.
- Der Standard-EmpfР“В¤nger erhР“В¤lt den geschР“Сtzten Browserdialog mit Anfrageansicht, Verlauf, EmpfangsbestР“В¤tigung und Antwortformular.
- Optional erhР“В¤lt der ursprР“Сngliche Absender eine automatische EmpfangsbestР“В¤tigung mit Anfrage Nr.
- Antworten werden auch dann Р“Сber die sichere Plus-Adresse zugeordnet, wenn die Anfrage Nr. aus dem Betreff entfernt wurde.
- Automatische Antworten, Zustellberichte und interne Absenderadressen werden zum Schutz vor E-Mail-Schleifen abgewiesen.
- Direkte E-Mail-Anfragen werden in der Administration, im Datenschutzexport und in der JSON-Sicherung als eigener Eingangsweg gefР“Сhrt.

## 3.0.32 - 2026-06-14

- Abteilungen kР“В¶nnen eine Anfrage Р“Сber einen zeitlich begrenzten, signierten Zugriff sicher Р“В¶ffnen.
- Die geschР“Сtzte Seite zeigt Anfrage, Felder und vollstР“В¤ndigen Verlauf und erlaubt EmpfangsbestР“В¤tigung sowie direkte Antworten.
- Zugriffstoken werden nur als Hash gespeichert, nach dem ersten Р“вЂ“ffnen aus der URL entfernt und in eine `HttpOnly`-Cookie Р“Сbernommen.
- Administratoren sehen GР“Сltigkeit und letzte Nutzung und kР“В¶nnen einen Zugriff sofort widerrufen.
- Neues bidirektionales Ticket-Postfach, zum Beispiel `anfrage@domain.de`, mit IMAP-Import alle fР“Сnf Minuten.
- Antworten von Besuchern werden gespeichert und lР“В¶sen eine neue Benachrichtigung mit frischem Zugriffslink an die Abteilung aus.
- Antworten der Abteilung aus dem E-Mail-Programm werden gespeichert und Р“Сber den Plugin-Mailer an den Besucher weitergeleitet.
- Sichere Plus-Adressen wie `anfrage+fkt-12345678-securecode@domain.de` schР“Сtzen den Import zusР“В¤tzlich zu Anfrage Nr. und AbsenderprР“Сfung.
- Benutzerdefinierte Autoantwort-Betreffzeilen erhalten automatisch die Anfrage Nr., wenn sie dort fehlt.
- Der WordPress-Datenschutzexport enthР“В¤lt jetzt auch den vollstР“В¤ndigen Nachrichtenverlauf.
- Voraussetzung fР“Сr den E-Mail-Import: PHP-IMAP und Plus-Adressierung oder Catch-all beim Mailanbieter.

## 3.0.31 - 2026-06-14

- Abteilungs-E-Mails enthalten jetzt eine signierte EmpfangsbestР“В¤tigung.
- Die BestР“В¤tigung erfolgt erst nach einem bewussten Klick auf der BestР“В¤tigungsseite, damit automatische Link-PrР“Сfungen von Mailservern keinen falschen Empfang melden.
- Anfragen speichern und zeigen Versandstatus, EmpfР“В¤nger, Anzahl der Versuche, Versandzeit, BestР“В¤tigungszeit und den letzten technischen Fehler.
- Fehlgeschlagene oder unbestР“В¤tigte Abteilungs-E-Mails kР“В¶nnen direkt aus der Anfrage erneut gesendet werden, ohne die Autoantwort an den Besucher zu wiederholen.
- Fehler aus `wp_mail()` und PHPMailer werden jetzt fР“Сr Testmails, Abteilungs-E-Mails, Autoantworten und Antworten aus dem Plugin protokolliert.
- Eine aktivierte, aber unvollstР“В¤ndige SMTP-Konfiguration wird nicht mehr still Р“Сber den Standardversand umgangen.

## 3.0.30 - 2026-05-14

- Version 3.0.29 wurde als stabiler Zugriffs-Release dokumentiert.
- README, PrР“В¤sentationsseite und Update-Metadaten beschreiben die Rollen- und Rechteverwaltung jetzt explizit als eigenstР“В¤ndigen stabilen Release-Schritt.

## 3.0.29 - 2026-05-14

- Neue Zugriffssteuerung fР“Сr das Plugin nach WordPress-Rollen.
- Administratoren behalten immer Vollzugriff.
- FР“Сr Redakteur und andere Rollen kann jetzt pro Bereich festgelegt werden, ob sie Anfragen sehen, antworten, Abteilungen verwalten, Einstellungen Р“В¶ffnen oder Protokolle sehen dР“Сrfen.
- Die Zugriffs-Matrix selbst kann nur vom Administrator geР“В¤ndert werden.

## 3.0.28 - 2026-05-04

- Interne Benachrichtigungen zeigen bei `Direkte Antwort an` jetzt nur noch die reine E-Mail-Adresse.
- Der echte `Reply-To` Header fР“Сr interne Benachrichtigungen wird jetzt ebenfalls nur noch als reine E-Mail-Adresse gesetzt, um Probleme mit einzelnen Mailprogrammen und gespeicherten Antwortadressen zu vermeiden.

## 3.0.27 - 2026-05-04

- Bitte Texte in der AdminoberflР“В¤che wurden auf korrekte UTF-8-Umlaute bereinigt.
- Sichtbare Begriffe wie `EmpfР“В¤nger`, `PrР“Сfung`, `DatenschutzerklР“В¤rung`, `zurР“Сck`, `Р“Сber`, `GrР“В¶Р“Сџe`, `AktivitР“В¤ten` und die neue SicherungsoberflР“В¤che zeigen jetzt wieder normale deutsche Zeichen.

## 3.0.26 - 2026-05-04

- Neue Sicherungsfunktion im Adminbereich fР“Сr Export und Wiederherstellung aller Plugin-Daten als JSON-Datei.
- Gesichert werden jetzt Einstellungen, EmpfР“В¤nger-E-Mails, Abteilungen, Themen, Anfragen, NachrichtenverlР“В¤ufe und Protokolle.
- Wiederherstellungen ersetzen den kompletten aktuellen Plugin-Bestand und protokollieren den Import im Plugin-Log.

## 3.0.25 - 2026-05-01

- Der Updater liest nach der Installation die tatsР“В¤chlich installierte Plugin-Version direkt aus der Plugin-Datei.
- WordPress- und Plugin-Update-Caches werden nach der Installation konsequenter geleert.
- Wenn nach einem Update weiterhin die alte Version installiert ist, meldet der Updater jetzt einen klaren Fehler statt erneut still eine neue Version anzuzeigen.

## 3.0.24 - 2026-05-01

- Der Plugin-Name in der WordPress-Pluginliste und in den Plugin-Infos lautet wieder `Feuer-Kontaktform`.
- Das Admin-MenР“С bleibt weiterhin verkР“Сrzt bei `Kontaktform`.

## 3.0.23 - 2026-05-01

- Interne Benachrichtigungen setzen den `Reply-To` jetzt mit Name und E-Mail des eigentlichen Antwortziels.
- Benachrichtigungs-E-Mails zeigen sichtbar an, an wen eine direkte Antwort aus dem Mailprogramm gesendet wird.
- Die Einstellung `Reply-To fР“Сr interne Benachrichtigung` markiert den Absender der Anfrage jetzt als empfohlene Option.

## 3.0.22 - 2026-04-30

- Sichtbarer Plugin-Name in der WordPress-AdminoberflР“В¤che wurde auf `Kontaktform` verkР“Сrzt.
- MenР“СeintrР“В¤ge, Р“Сљberschriften, Plugin-Infos und Privacy-Labels verwenden jetzt ebenfalls `Kontaktform`.

## 3.0.21 - 2026-04-29

- Standard-Autoantworten verwenden wieder durchgehend `Anfrage Nr.`.
- Der alte Hinweistext zum FortfР“Сhren des Dialogs im Betreff wurde aus Text- und HTML-Autoantwort entfernt.
- Bestehende Themen werden beim Update auf die neue Standard-EingangsbestР“В¤tigung migriert.

## 3.0.20 - 2026-04-23

- Direkte Beispiel-Links werden jetzt auch direkt in der Abteilungs-Konfiguration angezeigt.
- Direkte Beispiel-Links werden jetzt auch direkt in der Themen-Konfiguration angezeigt.
- Der `Shortcodes`-Tab jeder Abteilung zeigt jetzt zusР“В¤tzlich direkte URL-Beispiele fР“Сr Abteilung und Thema.

## 3.0.19 - 2026-04-23

- Seiten mit eingebautem Formular unterstР“Сtzen jetzt direkte Sprung-Links Р“Сber URL-Parameter.
- UnterstР“Сtzt werden `?feuer_department=slug` und `?feuer_department=slug&feuer_topic=slug`.
- ZusР“В¤tzlich werden die deutschen Aliase `?abteilung=slug` und `?thema=slug` verstanden.
- Im Bereich `Einstellungen -> Shortcodes` werden jetzt konkrete Beispiel-Links angezeigt.

## 3.0.18 - 2026-04-23

- Admin-OberflР“В¤che erzeugt den Slug fР“Сr Abteilungen und Themen jetzt live aus `Name` oder `Thema`.
- Umlaute wie `Р“вЂћ`, `Р“вЂ“`, `Р“Сљ`, `Р“В¤`, `Р“В¶`, `Р“С` und `Р“Сџ` werden fР“Сr den Slug sauber in `ae`, `oe`, `ue` und `ss` umgesetzt.
- Manuell geР“В¤nderte Slugs bleiben erhalten und werden nicht automatisch Р“Сberschrieben.
- Asset-Version erhР“В¶ht, damit WordPress den neuen Admin-JavaScript-Stand direkt lР“В¤dt.

## 3.0.17 - 2026-04-23

- Speichern von Abteilungen zeigt jetzt konkrete Fehlermeldungen bei leerem Namen, ungР“Сltiger EmpfР“В¤nger-E-Mail, leerem Slug, doppeltem Slug und Datenbankfehlern.
- Leerer Abteilungs-Slug wird aus dem Namen erzeugt und leere Sortierung automatisch sauber fortgefР“Сhrt.
- Themen speichern jetzt dieselbe Validierungslogik: klare Meldungen bei ungР“Сltiger Abteilung, leerem Thema, ungР“Сltiger abweichender E-Mail, leerem oder doppeltem Slug und Datenbankfehlern.
- Frontend-AJAX lehnt deaktivierte Abteilungen und Themen jetzt serverseitig ab.
- Select-Felder validieren eingereichte Werte jetzt auch serverseitig gegen die erlaubten Optionen.
- Eine Anfrage wird nur noch als erfolgreich bestР“В¤tigt, wenn der Ticket-Datensatz wirklich in der Datenbank gespeichert wurde; bei INSERT-Fehlern wird kein falscher Erfolg mehr ausgegeben.
- Protokolle enthalten jetzt auch Validierungs- und Ticket-Speicherfehler fР“Сr die technische Nachverfolgung.

## 3.0.16 - 2026-04-22

- Datenschutz-Auswahl im Frontend neutral gestaltet: keine grР“Сnen oder roten ButtonflР“В¤chen mehr.
- AusgewР“В¤hlte Datenschutz-Option zeigt jetzt eine Checkmark-Markierung direkt in der SchaltflР“В¤che.
- Datenschutz-SchaltflР“В¤chen sind kompakter.
- AbstР“В¤nde zwischen den Eingabefeldern im Schritt `Welche Informationen brauchen wir?` reduziert.
- Asset-Version erhР“В¶ht, damit WordPress und Browser den neuen Frontend-CSS/JS-Stand laden.

## 3.0.15 - 2026-04-22

- Erste finale stabile Version des neuen Feuer-Kontaktform Plugins.
- Sichtbare deutsche Texte in Adminbereich, Frontend, Autoantworten, E-Mail-Vorlagen, Update-Dialogen und Plugin-Seite verwenden jetzt konsequent Umlaute wie `Р“В¤`, `Р“В¶`, `Р“С` und `Р“Сџ`.
- Technische Slugs, Shortcode-Attribute, Dateinamen und interne Identifikatoren bleiben unverР“В¤ndert, damit bestehende Einbindungen weiter funktionieren.

## 3.0.14 - 2026-04-22

- Datenschutz-Auswahl im Frontend fР“Сhrt bei `Ja, ich bin einverstanden` automatisch zum nР“В¤chsten Schritt.
- Bei `Nein` bleibt der Nutzer im Datenschutz-Schritt und sieht die Meldung, dass die Anfrage ohne Einwilligung nicht verarbeitet werden kann.
- Wiederholter Klick auf die bereits gewР“В¤hlte Datenschutz-Option funktioniert auch nach `ZurР“Сck`.

## 3.0.13 - 2026-04-22

- Einstellungen enthalten jetzt neben `Update prР“Сfen` auch `Update jetzt installieren`.
- Die manuelle Update-PrР“Сfung aktualisiert den WordPress-Update-Transient, damit WordPress das Entwicklerpaket sofort als Update erkennt.
- Update-Installation nutzt den WordPress `Plugin_Upgrader` und installiert das Paket von `wdmin.com/plugins/feuer-kontaktform/`.
- Erfolgreiche und fehlgeschlagene Update-Installationen werden in den Protokollen gespeichert.

## 3.0.12 - 2026-04-22

- Abteilungen kР“В¶nnen in der Admin-OberflР“В¤che per `Hoch` und `Runter` sortiert werden.
- Die neue Reihenfolge wird dauerhaft als `sort_order` gespeichert und gilt dadurch auch fР“Сr die Frontend-Auswahl.
- Protokolle zeigen das Verschieben einer Abteilung als eigenes Ereignis.

## 3.0.11 - 2026-04-22

- Verlauf in Anfragen zeigt jetzt den Namen des Absenders und den vollen Namen des antwortenden Administrators statt `inbound`/`outbound`.
- Protokolle zeigen den vollstР“В¤ndigen Namen des Administrators, wenn Vorname/Nachname gesetzt sind.
- Standard-Feldreihenfolge fР“Сr neue Themen geР“В¤ndert: zuerst `Titel / Betreff`, dann Name und Kontaktdaten.
- Themenfelder kР“В¶nnen in der Themenkonfiguration per `Hoch` und `Runter` sortiert werden.
- Antwortformular in Anfragen wird mit BegrР“СР“Сџung `{{name}}` und Signatur mit Abteilung, Website-Name und Website-Link vorbelegt.
- Antwortmakros enthalten jetzt auch `{{site_url}}`.

## 3.0.10 - 2026-04-22

- Mindestanforderung fР“Сr WordPress auf `6.9` gesetzt.
- Update-Metadaten melden `requires` jetzt ebenfalls als `6.9`.
- Plugin-Info liefert auch bei temporР“В¤r nicht erreichbarem Update-Server eine lokale Fallback-Antwort mit korrekter KompatibilitР“В¤t.

## 3.0.9 - 2026-04-22

- Plugin-Info setzt `tested` mindestens auf die aktuelle WordPress-Version, wenn die Server-Metadaten niedriger sind.
- Warnung `Dieses Plugin wurde nicht mit deiner aktuellen WordPress-Version getestet` im WordPress-Detailfenster wird dadurch vermieden.
- Update-PrР“Сfung in den Einstellungen zeigt jetzt installierte Version, Server-Version, getestete WordPress-Version, Download-URL, letzte PrР“Сfung und klaren Status.
- Manuelle Update-PrР“Сfung unterscheidet zwischen `aktuell`, `Update verfР“Сgbar` und `fehlgeschlagen`.

## 3.0.8 - 2026-04-22

- Datenschutz-Schritt im Frontend verschoben: zuerst Abteilung, dann Thema, danach Datenschutz.
- Bei direkten Shortcodes auf Abteilung/Thema bleibt Datenschutz der erste sichtbare Schritt, wenn die vorherigen Schritte Р“Сbersprungen werden.

## 3.0.7 - 2026-04-22

- Antworten aus dem Anfrage-Bereich verwenden jetzt `Name der Website` aus den Einstellungen im HTML-Kopf und in der Signatur.
- Logo aus den Einstellungen wird in Antworten aus dem Plugin angezeigt, wenn gesetzt.
- Platzhalter im Antworttext werden ersetzt: `{{site_name}}`, `{{ticket_id}}`, `{{name}}`, `{{topic}}`, `{{subject}}`, `{{email}}`, `{{vorname}}`, `{{nachname}}`, `{{telefon}}`.
- Hinweis auf verfР“Сgbare Platzhalter im Antwortformular ergР“В¤nzt.

## 3.0.6 - 2026-04-22

- Datenschutz-Schritt im Frontend kann in den Einstellungen aktiviert oder deaktiviert werden.
- Anfragen speichern, ob der Datenschutz-Schritt aktiv war oder deaktiviert wurde.
- WordPress Privacy Export unterscheidet zwischen bestР“В¤tigter Zustimmung und nicht abgefragtem Datenschutz-Schritt.
- Admin-Tabs merken sich die zuletzt geР“В¶ffnete Ansicht nach dem Speichern und Redirect.

## 3.0.5 - 2026-04-22

- Datenschutz-Auswahl im Frontend als zwei klare Buttons gestaltet.
- Zustimmung wird als grР“Сner Button hervorgehoben.
- Ablehnung wird als weisser Button mit roter Umrandung dargestellt.

## 3.0.4 - 2026-04-22

- Abteilungen & Themen neu geordnet: erster Tab `Neue Abteilung`, danach Abteilungs-Tabs mit `Abteilung`, `Shortcodes` und Themen.
- Frontend-Kontaktstrecke um Designvarianten und Feldstile erweitert.
- Р“Сљberfluessige Rahmen um einzelne Frontend-Felder entfernt.
- Anfragen als aufklappbare Karten mit Kopfzeile Anfrage Nr., Abteilung, Thema, Absender und Datum neu gestaltet.
- Antworten kР“В¶nnen direkt aus dem Plugin per E-Mail gesendet und im Anfrage-Verlauf gespeichert werden.
- Betreff fР“Сr Autoantwort und Abteilungsbenachrichtigung nutzt Anfrage Nr., Thema und den vom Besucher eingegebenen Betreff.
- Abteilungsbenachrichtigung als HTML-Mail ohne Datenschutz/IP/User-Agent-Daten neu gestaltet.
- WordPress Privacy Export/Erase fР“Сr gespeicherte Anfrage-Daten ergР“В¤nzt.
- Erlaubte Dateiformate und maximale Upload-GrР“В¶Р“Сџe in den Einstellungen konfigurierbar gemacht.
- Update-Cache wird gegen die aktuelle Plugin-Version neu bewertet, damit Updates nach der Installation nicht dauerhaft erneut angezeigt werden.

## 3.0.3 - 2026-04-21

- Neuer Einstellungen-Tab `Zustellbarkeit` mit PrР“Сfung und Hinweisen zu From-Domain, SPF, DMARC, DKIM und SMTP.
- SMTP-Versand direkt im Plugin ergР“В¤nzt, inklusive Host, Port, VerschlР“Сsselung, Benutzername und Passwort.
- Reply-To-Strategien fР“Сr interne Benachrichtigungen und Autoantworten hinzugefР“Сgt.
- Autoantworten setzen optional `Auto-Submitted` und `X-Auto-Response-Suppress`, damit Mailserver Antwortschleifen besser erkennen.
- HTML-Autoantworten werden vor dem Speichern strenger bereinigt.
- E-Mail-Einstellungen bewahren gespeicherte Werte, wenn andere Einstellungs-Tabs gespeichert werden.

## 3.0.2 - 2026-04-21

- Abteilungen & Themen als Tab-System aufgebaut: erster Tab fР“Сr Abteilungsname/E-Mail, weitere Tabs fР“Сr Themen.
- Einstellungen als Tab-System gegliedert: Website & Logo, E-Mail, Datenschutz, System und Shortcodes.
- Logo-Auswahl Р“Сber die WordPress-Mediathek ergР“В¤nzt.
- Protokolle in eine verstР“В¤ndlichere AktivitР“В¤tsansicht Р“Сbersetzt.
- Begriff `Anfrage Nr.` in der OberflР“В¤che eingefР“Сhrt und Hinweis fР“Сr E-Mail-Betreff ergР“В¤nzt.
- Neue Abteilungen erhalten keine vorinstallierten Themen mehr.
- Autoantworten kР“В¶nnen je Thema aktiviert/deaktiviert und als Text oder HTML versendet werden.

## 3.0.1 - 2026-04-21

- Standard-Autoantwort fР“Сr neue Themen erweitert: BegrР“СР“Сџung, PrР“Сfhinweis, Anfrage Nr. und formeller deutscher Abschluss.
- Themen besitzen jetzt zwei Autoantwort-Vorlagen: Plain-Text und HTML.
- HTML-Autoantwort mit Logo-Block, Website-Name, Anfrage Nr., Datenschutzlink und sauberem E-Mail-Layout.
- Makro-Р“Сљbersicht direkt unter den Autoantwort-Editoren ergР“В¤nzt.
- Mailer sendet die HTML-Autoantwort mit `text/html`, wenn eine HTML-Vorlage gesetzt ist; sonst Plain-Text.

## 3.0.0 - 2026-04-21

- VollstР“В¤ndiger Rewrite als Support- und Ticket-System.
- Neue Datenstruktur fР“Сr Abteilungen, Themen, Anfragen, Anfrage-Nachrichten und Admin-Protokolle.
- AJAX-Wizard mit Datenschutz-Schritt, Abteilungswahl, Themenwahl, dynamischen Themenfeldern, Captcha und Abschlussmeldung.
- 8-stellige zufР“В¤llige Anfrage Nr. fР“Сr jede Anfrage.
- Shortcodes fР“Сr kompletten Wizard und direkte Schnellformulare auf Abteilung/Thema.
- Neue Adminbereiche fР“Сr Anfragen, Abteilungen & Themen, Einstellungen, E-Mail-Test, Update-PrР“Сfung und Protokolle.
- Sauberer Release-Builder ohne Windows-Archiv-Metadaten, directory entries, ACL/Owner und verschachtelte ZIP-Dateien.

## 2.5.0 - 2026-04-21

- Plugin-Metadaten auf Walter FР“В¤rber und `wdmin.com/plugins/feuer-kontaktform/` aktualisiert.
- Self-hosted Update-Check mit Button in den Einstellungen hinzugefР“Сgt.
- Frontend auf einen einheitlichen Ticket-Wizard mit Datenschutz-Schritt und Ladeanzeige umgestellt.
- Anfrage Nr., Cookie-ID, GerР“В¤tetyp und Datenschutz-Kontext fР“Сr Anfragen eingefР“Сhrt.
- Themen pro Formular hinzugefР“Сgt; Themen kР“В¶nnen EmpfР“В¤nger und Autoantwort Р“Сberschreiben.
- AktivitР“В¤tsprotokoll fР“Сr zentrale Plugin-Aktionen hinzugefР“Сgt.
- DB-Schema auf `dbDelta()` umgestellt und neue Spalten fР“Сr Anfrage-Protokolle vorbereitet.
- CSV-Export gegen Spreadsheet-Formula-Injection abgesichert.
- Frontend-Designwerte werden jetzt als scoped CSS ausgegeben.
- GitHub-Basisdateien, Update-Metadaten und PrР“В¤sentationsseite ergР“В¤nzt.

## 2.4.0

- Vorherige interne Version mit Formularverwaltung, SMTP, Autoantworten, Webhooks, JSON-Dateien und mehreren Layoutvarianten.
