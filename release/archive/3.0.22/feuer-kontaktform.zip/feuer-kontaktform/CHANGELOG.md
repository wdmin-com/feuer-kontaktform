# Changelog

## 3.0.22 - 2026-04-30

- Sichtbarer Plugin-Name in der WordPress-Adminoberfläche wurde auf `Kontaktform` verkürzt.
- Menüeinträge, Überschriften, Plugin-Infos und Privacy-Labels verwenden jetzt ebenfalls `Kontaktform`.

## 3.0.21 - 2026-04-29

- Standard-Autoantworten verwenden wieder durchgehend `Anfrage Nr.`.
- Der alte Hinweistext zum Fortführen des Dialogs im Betreff wurde aus Text- und HTML-Autoantwort entfernt.
- Bestehende Themen werden beim Update auf die neue Standard-Eingangsbestätigung migriert.

## 3.0.20 - 2026-04-23

- Direkte Beispiel-Links werden jetzt auch direkt in der Abteilungs-Konfiguration angezeigt.
- Direkte Beispiel-Links werden jetzt auch direkt in der Themen-Konfiguration angezeigt.
- Der `Shortcodes`-Tab jeder Abteilung zeigt jetzt zusätzlich direkte URL-Beispiele für Abteilung und Thema.

## 3.0.19 - 2026-04-23

- Seiten mit eingebautem Formular unterstützen jetzt direkte Sprung-Links über URL-Parameter.
- Unterstützt werden `?feuer_department=slug` und `?feuer_department=slug&feuer_topic=slug`.
- Zusätzlich werden die deutschen Aliase `?abteilung=slug` und `?thema=slug` verstanden.
- Im Bereich `Einstellungen -> Shortcodes` werden jetzt konkrete Beispiel-Links angezeigt.

## 3.0.18 - 2026-04-23

- Admin-Oberfläche erzeugt den Slug für Abteilungen und Themen jetzt live aus `Name` oder `Thema`.
- Umlaute wie `Ä`, `Ö`, `Ü`, `ä`, `ö`, `ü` und `ß` werden für den Slug sauber in `ae`, `oe`, `ue` und `ss` umgesetzt.
- Manuell geänderte Slugs bleiben erhalten und werden nicht automatisch überschrieben.
- Asset-Version erhöht, damit WordPress den neuen Admin-JavaScript-Stand direkt lädt.

## 3.0.17 - 2026-04-23

- Speichern von Abteilungen zeigt jetzt konkrete Fehlermeldungen bei leerem Namen, ungültiger Empfänger-E-Mail, leerem Slug, doppeltem Slug und Datenbankfehlern.
- Leerer Abteilungs-Slug wird aus dem Namen erzeugt und leere Sortierung automatisch sauber fortgeführt.
- Themen speichern jetzt dieselbe Validierungslogik: klare Meldungen bei ungültiger Abteilung, leerem Thema, ungültiger abweichender E-Mail, leerem oder doppeltem Slug und Datenbankfehlern.
- Frontend-AJAX lehnt deaktivierte Abteilungen und Themen jetzt serverseitig ab.
- Select-Felder validieren eingereichte Werte jetzt auch serverseitig gegen die erlaubten Optionen.
- Eine Anfrage wird nur noch als erfolgreich bestätigt, wenn der Ticket-Datensatz wirklich in der Datenbank gespeichert wurde; bei INSERT-Fehlern wird kein falscher Erfolg mehr ausgegeben.
- Protokolle enthalten jetzt auch Validierungs- und Ticket-Speicherfehler für die technische Nachverfolgung.

## 3.0.16 - 2026-04-22

- Datenschutz-Auswahl im Frontend neutral gestaltet: keine grünen oder roten Buttonflächen mehr.
- Ausgewählte Datenschutz-Option zeigt jetzt eine Checkmark-Markierung direkt in der Schaltfläche.
- Datenschutz-Schaltflächen sind kompakter.
- Abstände zwischen den Eingabefeldern im Schritt `Welche Informationen brauchen wir?` reduziert.
- Asset-Version erhöht, damit WordPress und Browser den neuen Frontend-CSS/JS-Stand laden.

## 3.0.15 - 2026-04-22

- Erste finale stabile Version des neuen Feuer-Kontaktform Plugins.
- Sichtbare deutsche Texte in Adminbereich, Frontend, Autoantworten, E-Mail-Vorlagen, Update-Dialogen und Plugin-Seite verwenden jetzt konsequent Umlaute wie `ä`, `ö`, `ü` und `ß`.
- Technische Slugs, Shortcode-Attribute, Dateinamen und interne Identifikatoren bleiben unverändert, damit bestehende Einbindungen weiter funktionieren.

## 3.0.14 - 2026-04-22

- Datenschutz-Auswahl im Frontend führt bei `Ja, ich bin einverstanden` automatisch zum nächsten Schritt.
- Bei `Nein` bleibt der Nutzer im Datenschutz-Schritt und sieht die Meldung, dass die Anfrage ohne Einwilligung nicht verarbeitet werden kann.
- Wiederholter Klick auf die bereits gewählte Datenschutz-Option funktioniert auch nach `Zurück`.

## 3.0.13 - 2026-04-22

- Einstellungen enthalten jetzt neben `Update prüfen` auch `Update jetzt installieren`.
- Die manuelle Update-Prüfung aktualisiert den WordPress-Update-Transient, damit WordPress das Entwicklerpaket sofort als Update erkennt.
- Update-Installation nutzt den WordPress `Plugin_Upgrader` und installiert das Paket von `wdmin.com/plugins/feuer-kontaktform/`.
- Erfolgreiche und fehlgeschlagene Update-Installationen werden in den Protokollen gespeichert.

## 3.0.12 - 2026-04-22

- Abteilungen können in der Admin-Oberfläche per `Hoch` und `Runter` sortiert werden.
- Die neue Reihenfolge wird dauerhaft als `sort_order` gespeichert und gilt dadurch auch für die Frontend-Auswahl.
- Protokolle zeigen das Verschieben einer Abteilung als eigenes Ereignis.

## 3.0.11 - 2026-04-22

- Verlauf in Anfragen zeigt jetzt den Namen des Absenders und den vollen Namen des antwortenden Administrators statt `inbound`/`outbound`.
- Protokolle zeigen den vollständigen Namen des Administrators, wenn Vorname/Nachname gesetzt sind.
- Standard-Feldreihenfolge für neue Themen geändert: zuerst `Titel / Betreff`, dann Name und Kontaktdaten.
- Themenfelder können in der Themenkonfiguration per `Hoch` und `Runter` sortiert werden.
- Antwortformular in Anfragen wird mit Begrüßung `{{name}}` und Signatur mit Abteilung, Website-Name und Website-Link vorbelegt.
- Antwortmakros enthalten jetzt auch `{{site_url}}`.

## 3.0.10 - 2026-04-22

- Mindestanforderung für WordPress auf `6.9` gesetzt.
- Update-Metadaten melden `requires` jetzt ebenfalls als `6.9`.
- Plugin-Info liefert auch bei temporär nicht erreichbarem Update-Server eine lokale Fallback-Antwort mit korrekter Kompatibilität.

## 3.0.9 - 2026-04-22

- Plugin-Info setzt `tested` mindestens auf die aktuelle WordPress-Version, wenn die Server-Metadaten niedriger sind.
- Warnung `Dieses Plugin wurde nicht mit deiner aktuellen WordPress-Version getestet` im WordPress-Detailfenster wird dadurch vermieden.
- Update-Prüfung in den Einstellungen zeigt jetzt installierte Version, Server-Version, getestete WordPress-Version, Download-URL, letzte Prüfung und klaren Status.
- Manuelle Update-Prüfung unterscheidet zwischen `aktuell`, `Update verfügbar` und `fehlgeschlagen`.

## 3.0.8 - 2026-04-22

- Datenschutz-Schritt im Frontend verschoben: zuerst Abteilung, dann Thema, danach Datenschutz.
- Bei direkten Shortcodes auf Abteilung/Thema bleibt Datenschutz der erste sichtbare Schritt, wenn die vorherigen Schritte übersprungen werden.

## 3.0.7 - 2026-04-22

- Antworten aus dem Anfrage-Bereich verwenden jetzt `Name der Website` aus den Einstellungen im HTML-Kopf und in der Signatur.
- Logo aus den Einstellungen wird in Antworten aus dem Plugin angezeigt, wenn gesetzt.
- Platzhalter im Antworttext werden ersetzt: `{{site_name}}`, `{{ticket_id}}`, `{{name}}`, `{{topic}}`, `{{subject}}`, `{{email}}`, `{{vorname}}`, `{{nachname}}`, `{{telefon}}`.
- Hinweis auf verfügbare Platzhalter im Antwortformular ergänzt.

## 3.0.6 - 2026-04-22

- Datenschutz-Schritt im Frontend kann in den Einstellungen aktiviert oder deaktiviert werden.
- Anfragen speichern, ob der Datenschutz-Schritt aktiv war oder deaktiviert wurde.
- WordPress Privacy Export unterscheidet zwischen bestätigter Zustimmung und nicht abgefragtem Datenschutz-Schritt.
- Admin-Tabs merken sich die zuletzt geöffnete Ansicht nach dem Speichern und Redirect.

## 3.0.5 - 2026-04-22

- Datenschutz-Auswahl im Frontend als zwei klare Buttons gestaltet.
- Zustimmung wird als grüner Button hervorgehoben.
- Ablehnung wird als weisser Button mit roter Umrandung dargestellt.

## 3.0.4 - 2026-04-22

- Abteilungen & Themen neu geordnet: erster Tab `Neue Abteilung`, danach Abteilungs-Tabs mit `Abteilung`, `Shortcodes` und Themen.
- Frontend-Kontaktstrecke um Designvarianten und Feldstile erweitert.
- Überfluessige Rahmen um einzelne Frontend-Felder entfernt.
- Anfragen als aufklappbare Karten mit Kopfzeile Anfrage Nr., Abteilung, Thema, Absender und Datum neu gestaltet.
- Antworten können direkt aus dem Plugin per E-Mail gesendet und im Anfrage-Verlauf gespeichert werden.
- Betreff für Autoantwort und Abteilungsbenachrichtigung nutzt Anfrage Nr., Thema und den vom Besucher eingegebenen Betreff.
- Abteilungsbenachrichtigung als HTML-Mail ohne Datenschutz/IP/User-Agent-Daten neu gestaltet.
- WordPress Privacy Export/Erase für gespeicherte Anfrage-Daten ergänzt.
- Erlaubte Dateiformate und maximale Upload-Größe in den Einstellungen konfigurierbar gemacht.
- Update-Cache wird gegen die aktuelle Plugin-Version neu bewertet, damit Updates nach der Installation nicht dauerhaft erneut angezeigt werden.

## 3.0.3 - 2026-04-21

- Neuer Einstellungen-Tab `Zustellbarkeit` mit Prüfung und Hinweisen zu From-Domain, SPF, DMARC, DKIM und SMTP.
- SMTP-Versand direkt im Plugin ergänzt, inklusive Host, Port, Verschlüsselung, Benutzername und Passwort.
- Reply-To-Strategien für interne Benachrichtigungen und Autoantworten hinzugefügt.
- Autoantworten setzen optional `Auto-Submitted` und `X-Auto-Response-Suppress`, damit Mailserver Antwortschleifen besser erkennen.
- HTML-Autoantworten werden vor dem Speichern strenger bereinigt.
- E-Mail-Einstellungen bewahren gespeicherte Werte, wenn andere Einstellungs-Tabs gespeichert werden.

## 3.0.2 - 2026-04-21

- Abteilungen & Themen als Tab-System aufgebaut: erster Tab für Abteilungsname/E-Mail, weitere Tabs für Themen.
- Einstellungen als Tab-System gegliedert: Website & Logo, E-Mail, Datenschutz, System und Shortcodes.
- Logo-Auswahl über die WordPress-Mediathek ergänzt.
- Protokolle in eine verständlichere Aktivitätsansicht übersetzt.
- Begriff `Anfrage Nr.` in der Oberfläche eingeführt und Hinweis für E-Mail-Betreff ergänzt.
- Neue Abteilungen erhalten keine vorinstallierten Themen mehr.
- Autoantworten können je Thema aktiviert/deaktiviert und als Text oder HTML versendet werden.

## 3.0.1 - 2026-04-21

- Standard-Autoantwort für neue Themen erweitert: Begrüßung, Prüfhinweis, Anfrage Nr. und formeller deutscher Abschluss.
- Themen besitzen jetzt zwei Autoantwort-Vorlagen: Plain-Text und HTML.
- HTML-Autoantwort mit Logo-Block, Website-Name, Anfrage Nr., Datenschutzlink und sauberem E-Mail-Layout.
- Makro-Übersicht direkt unter den Autoantwort-Editoren ergänzt.
- Mailer sendet die HTML-Autoantwort mit `text/html`, wenn eine HTML-Vorlage gesetzt ist; sonst Plain-Text.

## 3.0.0 - 2026-04-21

- Vollständiger Rewrite als Support- und Ticket-System.
- Neue Datenstruktur für Abteilungen, Themen, Anfragen, Anfrage-Nachrichten und Admin-Protokolle.
- AJAX-Wizard mit Datenschutz-Schritt, Abteilungswahl, Themenwahl, dynamischen Themenfeldern, Captcha und Abschlussmeldung.
- 8-stellige zufällige Anfrage Nr. für jede Anfrage.
- Shortcodes für kompletten Wizard und direkte Schnellformulare auf Abteilung/Thema.
- Neue Adminbereiche für Anfragen, Abteilungen & Themen, Einstellungen, E-Mail-Test, Update-Prüfung und Protokolle.
- Sauberer Release-Builder ohne Windows-Archiv-Metadaten, directory entries, ACL/Owner und verschachtelte ZIP-Dateien.

## 2.5.0 - 2026-04-21

- Plugin-Metadaten auf Walter Färber und `wdmin.com/plugins/feuer-kontaktform/` aktualisiert.
- Self-hosted Update-Check mit Button in den Einstellungen hinzugefügt.
- Frontend auf einen einheitlichen Ticket-Wizard mit Datenschutz-Schritt und Ladeanzeige umgestellt.
- Anfrage Nr., Cookie-ID, Gerätetyp und Datenschutz-Kontext für Anfragen eingeführt.
- Themen pro Formular hinzugefügt; Themen können Empfänger und Autoantwort überschreiben.
- Aktivitätsprotokoll für zentrale Plugin-Aktionen hinzugefügt.
- DB-Schema auf `dbDelta()` umgestellt und neue Spalten für Anfrage-Protokolle vorbereitet.
- CSV-Export gegen Spreadsheet-Formula-Injection abgesichert.
- Frontend-Designwerte werden jetzt als scoped CSS ausgegeben.
- GitHub-Basisdateien, Update-Metadaten und Präsentationsseite ergänzt.

## 2.4.0

- Vorherige interne Version mit Formularverwaltung, SMTP, Autoantworten, Webhooks, JSON-Dateien und mehreren Layoutvarianten.
