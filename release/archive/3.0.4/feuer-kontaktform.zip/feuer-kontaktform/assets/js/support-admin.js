document.addEventListener('DOMContentLoaded', function () {
  function syncRequired(row) {
    var hidden = row.querySelector('[data-required-hidden]');
    var checkbox = row.querySelector('[data-required-checkbox]');
    if (hidden && checkbox) {
      hidden.value = checkbox.checked ? '1' : '0';
    }
  }

  function bindRow(row) {
    var remove = row.querySelector('[data-remove-field]');
    var checkbox = row.querySelector('[data-required-checkbox]');

    if (remove) {
      remove.addEventListener('click', function () {
        row.remove();
      });
    }

    if (checkbox) {
      checkbox.addEventListener('change', function () {
        syncRequired(row);
      });
    }
  }

  function createRow() {
    var row = document.createElement('div');
    row.className = 'feuer-field-row';
    row.setAttribute('data-field-row', '1');
    row.innerHTML =
      '<input name="topic_fields[key][]" placeholder="key">' +
      '<input name="topic_fields[label][]" placeholder="Label">' +
      '<select name="topic_fields[type][]">' +
        '<option value="text">text</option>' +
        '<option value="email">email</option>' +
        '<option value="tel">tel</option>' +
        '<option value="textarea">textarea</option>' +
        '<option value="select">select</option>' +
        '<option value="file">file</option>' +
      '</select>' +
      '<select name="topic_fields[width][]">' +
        '<option value="full">full</option>' +
        '<option value="half">half</option>' +
        '<option value="third">third</option>' +
      '</select>' +
      '<input type="hidden" name="topic_fields[required][]" value="0" data-required-hidden>' +
      '<label><input type="checkbox" value="1" data-required-checkbox> Pflicht</label>' +
      '<input name="topic_fields[options][]" placeholder="Optionen bei select">' +
      '<button type="button" class="button" data-remove-field>Entfernen</button>';
    bindRow(row);
    return row;
  }

  document.querySelectorAll('[data-field-row]').forEach(bindRow);

  document.querySelectorAll('[data-topic-form]').forEach(function (form) {
    form.addEventListener('submit', function () {
      form.querySelectorAll('[data-field-row]').forEach(syncRequired);
    });
  });

  document.querySelectorAll('[data-add-field]').forEach(function (button) {
    button.addEventListener('click', function () {
      var form = button.closest('[data-topic-form]');
      var list = form ? form.querySelector('[data-fields-list]') : null;
      if (list) {
        list.appendChild(createRow());
      }
    });
  });

  document.querySelectorAll('[data-feuer-tabs]').forEach(function (tabs) {
    var buttons = Array.prototype.slice.call(tabs.querySelectorAll('[data-tab-target]')).filter(function (button) {
      return button.closest('[data-feuer-tabs]') === tabs;
    });
    var panels = Array.prototype.slice.call(tabs.querySelectorAll('[data-tab-panel]')).filter(function (panel) {
      return panel.closest('[data-feuer-tabs]') === tabs;
    });

    function activate(target) {
      buttons.forEach(function (button) {
        button.classList.toggle('is-active', button.getAttribute('data-tab-target') === target);
      });
      panels.forEach(function (panel) {
        panel.classList.toggle('is-active', panel.getAttribute('data-tab-panel') === target);
      });
    }

    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        activate(button.getAttribute('data-tab-target'));
      });
    });
  });

  document.querySelectorAll('[data-media-select]').forEach(function (button) {
    button.addEventListener('click', function () {
      var wrap = button.closest('.feuer-media-picker');
      var input = wrap ? wrap.querySelector('[data-media-url]') : null;
      var label = button.closest('label');
      var preview = label ? label.querySelector('[data-media-preview]') : null;
      var frame;

      if (!input || !window.wp || !window.wp.media) {
        return;
      }

      frame = window.wp.media({
        title: 'Logo auswaehlen',
        button: { text: 'Logo verwenden' },
        multiple: false
      });

      frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        input.value = attachment.url || '';
        if (preview) {
          preview.src = input.value;
          preview.hidden = !input.value;
        }
      });

      frame.open();
    });
  });

  document.querySelectorAll('[data-media-clear]').forEach(function (button) {
    button.addEventListener('click', function () {
      var wrap = button.closest('.feuer-media-picker');
      var input = wrap ? wrap.querySelector('[data-media-url]') : null;
      var label = button.closest('label');
      var preview = label ? label.querySelector('[data-media-preview]') : null;
      if (input) {
        input.value = '';
      }
      if (preview) {
        preview.removeAttribute('src');
        preview.hidden = true;
      }
    });
  });
});
