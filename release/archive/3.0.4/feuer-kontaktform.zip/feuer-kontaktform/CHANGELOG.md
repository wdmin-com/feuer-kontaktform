# Changelog

## 3.0.4 - 2026-04-22

- Abteilungen & Themen neu geordnet: erster Tab `Neue Abteilung`, danach Abteilungs-Tabs mit `Abteilung`, `Shortcodes` und Themen.
- Frontend-Kontaktstrecke um Designvarianten und Feldstile erweitert.
- Ueberfluessige Rahmen um einzelne Frontend-Felder entfernt.
- Anfragen als aufklappbare Karten mit Kopfzeile Anfrage Nr., Abteilung, Thema, Absender und Datum neu gestaltet.
- Antworten koennen direkt aus dem Plugin per E-Mail gesendet und im Anfrage-Verlauf gespeichert werden.
- Betreff fuer Autoantwort und Abteilungsbenachrichtigung nutzt Anfrage Nr., Thema und den vom Besucher eingegebenen Betreff.
- Abteilungsbenachrichtigung als HTML-Mail ohne Datenschutz/IP/User-Agent-Daten neu gestaltet.
- WordPress Privacy Export/Erase fuer gespeicherte Anfrage-Daten ergaenzt.
- Erlaubte Dateiformate und maximale Upload-Groesse in den Einstellungen konfigurierbar gemacht.
- Update-Cache wird gegen die aktuelle Plugin-Version neu bewertet, damit Updates nach der Installation nicht dauerhaft erneut angezeigt werden.

## 3.0.3 - 2026-04-21

- Neuer Einstellungen-Tab `Zustellbarkeit` mit Pruefung und Hinweisen zu From-Domain, SPF, DMARC, DKIM und SMTP.
- SMTP-Versand direkt im Plugin ergaenzt, inklusive Host, Port, Verschluesselung, Benutzername und Passwort.
- Reply-To-Strategien fuer interne Benachrichtigungen und Autoantworten hinzugefuegt.
- Autoantworten setzen optional `Auto-Submitted` und `X-Auto-Response-Suppress`, damit Mailserver Antwortschleifen besser erkennen.
- HTML-Autoantworten werden vor dem Speichern strenger bereinigt.
- E-Mail-Einstellungen bewahren gespeicherte Werte, wenn andere Einstellungs-Tabs gespeichert werden.

## 3.0.2 - 2026-04-21

- Abteilungen & Themen als Tab-System aufgebaut: erster Tab fuer Abteilungsname/E-Mail, weitere Tabs fuer Themen.
- Einstellungen als Tab-System gegliedert: Website & Logo, E-Mail, Datenschutz, System und Shortcodes.
- Logo-Auswahl ueber die WordPress-Mediathek ergaenzt.
- Protokolle in eine verstaendlichere Aktivitaetsansicht uebersetzt.
- Begriff `Anfrage Nr.` in der Oberflaeche eingefuehrt und Hinweis fuer E-Mail-Betreff ergaenzt.
- Neue Abteilungen erhalten keine vorinstallierten Themen mehr.
- Autoantworten koennen je Thema aktiviert/deaktiviert und als Text oder HTML versendet werden.

## 3.0.1 - 2026-04-21

- Standard-Autoantwort fuer neue Themen erweitert: Begruessung, Pruefhinweis, Anfrage Nr. und formeller deutscher Abschluss.
- Themen besitzen jetzt zwei Autoantwort-Vorlagen: Plain-Text und HTML.
- HTML-Autoantwort mit Logo-Block, Website-Name, Anfrage Nr., Datenschutzlink und sauberem E-Mail-Layout.
- Makro-Uebersicht direkt unter den Autoantwort-Editoren ergaenzt.
- Mailer sendet die HTML-Autoantwort mit `text/html`, wenn eine HTML-Vorlage gesetzt ist; sonst Plain-Text.

## 3.0.0 - 2026-04-21

- Vollstaendiger Rewrite als Support- und Ticket-System.
- Neue Datenstruktur fuer Abteilungen, Themen, Anfragen, Anfrage-Nachrichten und Admin-Protokolle.
- AJAX-Wizard mit Datenschutz-Schritt, Abteilungswahl, Themenwahl, dynamischen Themenfeldern, Captcha und Abschlussmeldung.
- 8-stellige zufaellige Anfrage Nr. fuer jede Anfrage.
- Shortcodes fuer kompletten Wizard und direkte Schnellformulare auf Abteilung/Thema.
- Neue Adminbereiche fuer Anfragen, Abteilungen & Themen, Einstellungen, E-Mail-Test, Update-Pruefung und Protokolle.
- Sauberer Release-Builder ohne Windows-Archiv-Metadaten, directory entries, ACL/Owner und verschachtelte ZIP-Dateien.

## 2.5.0 - 2026-04-21

- Plugin-Metadaten auf Walter Faerber und `wdmin.com/plugins/feuer-kontaktform/` aktualisiert.
- Self-hosted Update-Check mit Button in den Einstellungen hinzugefuegt.
- Frontend auf einen einheitlichen Ticket-Wizard mit Datenschutz-Schritt und Ladeanzeige umgestellt.
- Anfrage Nr., Cookie-ID, Geraetetyp und Datenschutz-Kontext fuer Anfragen eingefuehrt.
- Themen pro Formular hinzugefuegt; Themen koennen Empfaenger und Autoantwort ueberschreiben.
- Aktivitaetsprotokoll fuer zentrale Plugin-Aktionen hinzugefuegt.
- DB-Schema auf `dbDelta()` umgestellt und neue Spalten fuer Anfrage-Protokolle vorbereitet.
- CSV-Export gegen Spreadsheet-Formula-Injection abgesichert.
- Frontend-Designwerte werden jetzt als scoped CSS ausgegeben.
- GitHub-Basisdateien, Update-Metadaten und Praesentationsseite ergaenzt.

## 2.4.0

- Vorherige interne Version mit Formularverwaltung, SMTP, Autoantworten, Webhooks, JSON-Dateien und mehreren Layoutvarianten.
