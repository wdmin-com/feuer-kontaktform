# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin für Support- und Anfrage-Kommunikation auf Websites freiwilliger Feuerwehren. Jede Anfrage wird über einen AJAX-Wizard erfasst, bekommt eine 8-stellige Anfrage Nr. und wird per E-Mail an die passende Abteilung oder das passende Thema weitergeleitet.

Mindestanforderung: WordPress 6.9 und PHP 8.0.

Status: Version 3.0.15 ist die erste finale stabile Version des neuen Plugins. Version 3.0.30 ist die aktuelle stabile Version. Der Zugriffs- und Rollen-Ausbau aus Version 3.0.29 ist damit als eigener stabiler Release-Schritt festgeschrieben: Administratoren behalten Vollzugriff, während Redakteur und andere Rollen pro Bereich gezielt freigeschaltet oder eingeschränkt werden können. Zusätzlich enthält die aktuelle stabile Version die robuste Validierung, klarere Fehlermeldungen, den sauberen Ticket-Speicherpfad, Live-Slug-Autofill in der Admin-Oberfläche, direkte URL-Sprünge zu Abteilung und Thema, vereinheitlichte Autoantworten mit Anfrage Nr. für neue und bestehende Themen, die verkürzte Admin-Anzeige `Kontaktform` im Menü, den wiederhergestellten Plugin-Namen `Feuer-Kontaktform` in der Pluginliste, das klarere Reply-To-Verhalten für direkte E-Mail-Antworten, den zuverlässigeren Self-Update-Prozess, die vollständige JSON-Sicherung mit Wiederherstellung für Einstellungen, Abteilungen, Themen und Anfragehistorie sowie bereinigte UTF-8-Texte in der Adminoberfläche.

## Funktionen

- Mehrstufiger AJAX-Wizard mit Datenschutz, Abteilung, Thema, dynamischen Feldern, Captcha und Abschlussmeldung.
- Datenschutz-Schritt kann in den Einstellungen aktiviert oder deaktiviert werden.
- Abteilungen mit Name, Kurzname und Empfänger-E-Mail.
- Themen je Abteilung mit optional eigener E-Mail, Autoantwort und eigenen Pflichtfeldern.
- Shortcodes werden allgemein in den Einstellungen und direkt je Abteilung angezeigt.
- Autoantworten pro Thema als Plain-Text und HTML-Vorlage mit Logo, Website-Name, Anfrage Nr. und Makros.
- Mehrere Frontend-Designvarianten und Feldstile für die Kontaktstrecke.
- Zustellbarkeits-Einstellungen für SPF/DMARC/DKIM-Hinweise, Reply-To-Strategien, SMTP-Versand und Autoantwort-Header.
- 8-stellige zufällige Anfrage Nr. für jede Anfrage.
- Anfrageprotokoll mit aufklappbarer Detailansicht, Verlauf und Antwortfunktion per E-Mail.
- WordPress Privacy Export/Erase für personenbezogene Anfrage-Daten.
- Konfigurierbare Dateiformate und Upload-Größen für Datei-Felder.
- Admin-Protokoll für Einstellungen, Abteilungen, Themen, Testmails, Updates und Anfrage-Erstellung.
- E-Mail-Test über den konfigurierten WordPress-Mailweg oder den SMTP-Zugang des Plugins.
- JSON-Sicherung und Wiederherstellung für Einstellungen, Empfänger-E-Mails, Abteilungen, Themen, Anfragen, Nachrichten und Protokolle.
- Self-hosted Updates über `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## E-Mail-Zustellbarkeit

Der Plugin-Absender sollte eine Adresse der eigenen Domain sein, zum Beispiel `kontakt@wdmin.com`. Für diese Domain sollten SPF, DKIM und DMARC beim DNS-Anbieter gesetzt sein. Im WordPress-Backend zeigt der Tab `Zustellbarkeit`, welche Punkte konfiguriert sind und welche noch offen sind.

Autoantworten enthalten optional technische Header gegen automatische Antwortschleifen. Für Antworten an den Besucher wird die Abteilung oder die Basisadresse als `Reply-To` gesetzt, damit der weitere Dialog unter der Anfrage Nr. nachvollziehbar bleibt.

## Shortcodes

```text
[feuer-kontaktform]
[feuer-kontaktform department="wehrfuehrung"]
[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]
[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket wird mit `tools/build-release.ps1` erzeugt. Der Builder schreibt keine Ordner-Einträge in das ZIP, setzt `ExternalAttributes` auf `0`, schreibt keine ZIP extra fields und vermeidet dadurch Windows-Owner/ACL-Metadaten. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
