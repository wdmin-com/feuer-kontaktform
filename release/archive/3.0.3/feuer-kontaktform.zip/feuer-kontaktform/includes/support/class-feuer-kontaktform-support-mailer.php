<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Mailer
{
    public function __construct(private Feuer_Kontaktform_Support_DB $db)
    {
    }

    public function send_ticket(array $ticket, array $department, array $topic, array $settings): array
    {
        $recipient = sanitize_email((string) ($topic['email_override'] ?: $department['email']));
        if ($recipient === '') {
            return ['success' => false, 'message' => 'Kein Empfaenger fuer diese Abteilung konfiguriert.'];
        }

        $headers = $this->notification_headers($settings, $ticket, $department, $topic);
        $subject = '[Anfrage Nr. ' . (string) $ticket['ticket_code'] . '] ' . (string) ($topic['title'] ?? 'Kontaktanfrage');
        $body = $this->notification_body($ticket, $department, $topic, $settings);

        $sent = wp_mail($recipient, $subject, $body, $headers);
        if (! $sent) {
            return ['success' => false, 'message' => 'Die Benachrichtigung konnte nicht gesendet werden.'];
        }

        $reply_email = sanitize_email((string) ($ticket['sender_email'] ?? ''));
        if ($reply_email !== '' && ! empty($topic['auto_reply_enabled'])) {
            $auto_subject = $this->replace_macros((string) ($topic['auto_subject'] ?: Feuer_Kontaktform_Support_DB::default_auto_subject()), $ticket, $department, $topic, $settings, false);
            $auto_body = $this->replace_macros((string) ($topic['auto_body'] ?: Feuer_Kontaktform_Support_DB::default_auto_body()), $ticket, $department, $topic, $settings, false);
            $auto_html = trim((string) ($topic['auto_html'] ?? ''));
            $format = (string) ($topic['auto_reply_format'] ?? 'html');

            if ($format === 'html' && $auto_html !== '') {
                $auto_html = $this->replace_macros($auto_html, $ticket, $department, $topic, $settings, true);
                wp_mail($reply_email, $auto_subject, $auto_html, $this->headers($settings, $this->auto_reply_to($settings, $department), true, true));
            } else {
                wp_mail($reply_email, $auto_subject, $auto_body, $this->headers($settings, $this->auto_reply_to($settings, $department), false, true));
            }
        }

        return ['success' => true, 'message' => 'E-Mail wurde gesendet.', 'recipient' => $recipient];
    }

    public function send_test(array $settings, string $target_email): bool
    {
        $target = sanitize_email($target_email);
        if ($target === '') {
            return false;
        }

        $subject = 'Feuer-Kontaktform Testmail';
        $body = "Diese Testmail wurde ueber WordPress wp_mail() gesendet.\n\nWenn diese Nachricht ankommt, ist der konfigurierte Versandweg grundsaetzlich erreichbar.";
        return wp_mail($target, $subject, $body, $this->headers($settings));
    }

    public function configure_phpmailer($phpmailer): void
    {
        $settings = $this->db->get_settings();
        if (empty($settings['smtp_enabled'])) {
            return;
        }

        $host = sanitize_text_field((string) ($settings['smtp_host'] ?? ''));
        if ($host === '') {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = $host;
        $phpmailer->Port = max(1, absint($settings['smtp_port'] ?? 587));
        $phpmailer->SMTPAuth = (string) ($settings['smtp_username'] ?? '') !== '';
        $phpmailer->Username = (string) ($settings['smtp_username'] ?? '');
        $phpmailer->Password = (string) ($settings['smtp_password'] ?? '');

        $encryption = (string) ($settings['smtp_encryption'] ?? 'tls');
        if ($encryption === 'ssl' || $encryption === 'tls') {
            $phpmailer->SMTPSecure = $encryption;
        } else {
            $phpmailer->SMTPSecure = '';
        }
    }

    private function notification_body(array $ticket, array $department, array $topic, array $settings): string
    {
        $lines = [
            'Neue Anfrage ueber Feuer-Kontaktform',
            '',
            'Anfrage Nr.: ' . (string) $ticket['ticket_code'],
            'Abteilung: ' . (string) ($department['name'] ?? ''),
            'Thema: ' . (string) ($topic['title'] ?? ''),
            'Name: ' . (string) ($ticket['sender_name'] ?? ''),
            'E-Mail: ' . (string) ($ticket['sender_email'] ?? ''),
            'Telefon: ' . (string) ($ticket['sender_phone'] ?? ''),
            '',
            'Nachricht:',
            (string) ($ticket['message'] ?? ''),
            '',
            'Zusatzfelder:',
        ];

        foreach ((array) ($ticket['fields'] ?? []) as $key => $value) {
            if (is_array($value)) {
                $value = implode(', ', array_map('strval', $value));
            }

            $lines[] = (string) $key . ': ' . (string) $value;
        }

        $lines[] = '';
        $lines[] = 'Datenschutz bestaetigt: ' . (! empty($ticket['privacy_accepted']) ? 'Ja' : 'Nein');
        $lines[] = 'Datenschutz-Version: ' . (string) ($ticket['privacy_version'] ?? '');
        $lines[] = 'Datenschutzerklaerung: ' . (string) ($settings['privacy_url'] ?? '');
        $lines[] = 'IP-Adresse: ' . (string) ($ticket['ip_address'] ?? '');
        $lines[] = 'Cookie-ID: ' . (string) ($ticket['visitor_cookie'] ?? '');
        $lines[] = 'Geraet: ' . (string) ($ticket['device_type'] ?? '');
        $lines[] = 'Browser: ' . (string) ($ticket['browser'] ?? '');
        $lines[] = 'User-Agent: ' . (string) ($ticket['user_agent'] ?? '');

        return implode("\n", $lines);
    }

    private function replace_macros(string $text, array $ticket, array $department, array $topic, array $settings, bool $html): string
    {
        $fields = is_array($ticket['fields'] ?? null) ? $ticket['fields'] : [];
        $site_name = (string) ($settings['site_name'] ?? get_bloginfo('name'));
        $logo_url = esc_url_raw((string) ($settings['logo_url'] ?? ''));
        $privacy_url = esc_url_raw((string) ($settings['privacy_url'] ?? ''));
        $logo_html = $logo_url !== ''
            ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($site_name) . '" style="max-width:150px;max-height:72px;margin:0 0 14px 0;display:block;">'
            : '';
        $macros = [
            '{{ticket}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{ticket_id}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{site_name}}' => $site_name,
            '{{logo_url}}' => $logo_url,
            '{{logo_html}}' => $logo_html,
            '{{privacy_url}}' => $privacy_url,
            '{{department}}' => (string) ($department['name'] ?? ''),
            '{{topic}}' => (string) ($topic['title'] ?? ''),
            '{{name}}' => (string) ($ticket['sender_name'] ?? ''),
            '{{email}}' => (string) ($ticket['sender_email'] ?? ''),
            '{{vorname}}' => (string) ($fields['vorname'] ?? ''),
            '{{nachname}}' => (string) ($fields['nachname'] ?? ''),
            '{{telefon}}' => (string) ($fields['telefon'] ?? ''),
        ];

        if (! $html) {
            $macros['{{logo_html}}'] = $logo_url;
            return strtr($text, $macros);
        }

        $safe = [];
        foreach ($macros as $macro => $value) {
            $safe[$macro] = $macro === '{{logo_html}}' ? $value : esc_html($value);
        }

        return wp_kses_post(strtr($text, $safe));
    }

    private function notification_headers(array $settings, array $ticket, array $department, array $topic): array
    {
        $strategy = (string) ($settings['notification_reply_to'] ?? 'sender');
        $reply_to = '';

        if ($strategy === 'sender') {
            $reply_to = (string) ($ticket['sender_email'] ?? '');
        } elseif ($strategy === 'department') {
            $reply_to = (string) ($topic['email_override'] ?: ($department['email'] ?? ''));
        }

        return $this->headers($settings, $reply_to);
    }

    private function auto_reply_to(array $settings, array $department): string
    {
        $strategy = (string) ($settings['auto_reply_reply_to'] ?? 'department');

        if ($strategy === 'department') {
            return (string) ($department['email'] ?? '');
        }

        if ($strategy === 'base') {
            return (string) ($settings['base_email'] ?? '');
        }

        return '';
    }

    private function headers(array $settings, string $reply_to = '', bool $html = false, bool $auto_response = false): array
    {
        $from_email = sanitize_email((string) ($settings['from_email'] ?? get_option('admin_email')));
        if ($from_email === '') {
            $from_email = sanitize_email((string) get_option('admin_email'));
        }

        $from_name = sanitize_text_field((string) ($settings['from_name'] ?? get_bloginfo('name')));
        $headers = [
            'Content-Type: ' . ($html ? 'text/html' : 'text/plain') . '; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];

        $reply = sanitize_email($reply_to);
        if ($reply !== '') {
            $headers[] = 'Reply-To: ' . $reply;
        }

        if ($auto_response && ! empty($settings['auto_response_headers'])) {
            $headers[] = 'Auto-Submitted: auto-replied';
            $headers[] = 'X-Auto-Response-Suppress: All';
        }

        return $headers;
    }
}
