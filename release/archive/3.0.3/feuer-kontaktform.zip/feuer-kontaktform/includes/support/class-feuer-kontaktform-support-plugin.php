<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Plugin
{
    private Feuer_Kontaktform_Updater $updater;
    private Feuer_Kontaktform_Support_Admin $admin;
    private Feuer_Kontaktform_Support_Frontend $frontend;

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer
    ) {
        $this->updater = new Feuer_Kontaktform_Updater();
        $this->admin = new Feuer_Kontaktform_Support_Admin($this->db, $this->mailer, $this->updater);
        $this->frontend = new Feuer_Kontaktform_Support_Frontend($this->db, $this->mailer);

        $this->register();
    }

    public static function activate(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->create_tables();
        flush_rewrite_rules();
    }

    public static function uninstall(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->uninstall();
    }

    private function register(): void
    {
        add_action('plugins_loaded', [$this, 'maybe_upgrade']);
        add_action('phpmailer_init', [$this->mailer, 'configure_phpmailer']);
        $this->updater->register();
        $this->admin->register();
        $this->frontend->register();
    }

    public function maybe_upgrade(): void
    {
        $installed = (string) get_option(Feuer_Kontaktform_Support_DB::OPTION_VERSION, '');
        if ($installed !== FEUER_KONTAKTFORM_VERSION) {
            $this->db->create_tables();
        }
    }
}
