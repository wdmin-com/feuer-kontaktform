# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin fuer Support- und Anfrage-Kommunikation auf Websites freiwilliger Feuerwehren. Jede Anfrage wird ueber einen AJAX-Wizard erfasst, bekommt eine 8-stellige Anfrage Nr. und wird per E-Mail an die passende Abteilung oder das passende Thema weitergeleitet.

Mindestanforderung: WordPress 6.9 und PHP 8.0.

## Funktionen

- Mehrstufiger AJAX-Wizard mit Datenschutz, Abteilung, Thema, dynamischen Feldern, Captcha und Abschlussmeldung.
- Datenschutz-Schritt kann in den Einstellungen aktiviert oder deaktiviert werden.
- Abteilungen mit Name, Kurzname und Empfaenger-E-Mail.
- Themen je Abteilung mit optional eigener E-Mail, Autoantwort und eigenen Pflichtfeldern.
- Shortcodes werden allgemein in den Einstellungen und direkt je Abteilung angezeigt.
- Autoantworten pro Thema als Plain-Text und HTML-Vorlage mit Logo, Website-Name, Anfrage Nr. und Makros.
- Mehrere Frontend-Designvarianten und Feldstile fuer die Kontaktstrecke.
- Zustellbarkeits-Einstellungen fuer SPF/DMARC/DKIM-Hinweise, Reply-To-Strategien, SMTP-Versand und Autoantwort-Header.
- 8-stellige zufaellige Anfrage Nr. fuer jede Anfrage.
- Anfrageprotokoll mit aufklappbarer Detailansicht, Verlauf und Antwortfunktion per E-Mail.
- WordPress Privacy Export/Erase fuer personenbezogene Anfrage-Daten.
- Konfigurierbare Dateiformate und Upload-Groessen fuer Datei-Felder.
- Admin-Protokoll fuer Einstellungen, Abteilungen, Themen, Testmails, Updates und Anfrage-Erstellung.
- E-Mail-Test ueber den konfigurierten WordPress-Mailweg oder den SMTP-Zugang des Plugins.
- Self-hosted Updates ueber `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## E-Mail-Zustellbarkeit

Der Plugin-Absender sollte eine Adresse der eigenen Domain sein, zum Beispiel `kontakt@wdmin.com`. Fuer diese Domain sollten SPF, DKIM und DMARC beim DNS-Anbieter gesetzt sein. Im WordPress-Backend zeigt der Tab `Zustellbarkeit`, welche Punkte konfiguriert sind und welche noch offen sind.

Autoantworten enthalten optional technische Header gegen automatische Antwortschleifen. Fuer Antworten an den Besucher wird die Abteilung oder die Basisadresse als `Reply-To` gesetzt, damit der weitere Dialog unter der Anfrage Nr. nachvollziehbar bleibt.

## Shortcodes

```text
[feuer-kontaktform]
[feuer-kontaktform department="wehrfuehrung"]
[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]
[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket wird mit `tools/build-release.ps1` erzeugt. Der Builder schreibt keine Ordner-Eintraege in das ZIP, setzt `ExternalAttributes` auf `0`, schreibt keine ZIP extra fields und vermeidet dadurch Windows-Owner/ACL-Metadaten. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
