<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Plugin
{
    private Feuer_Kontaktform_Updater $updater;
    private Feuer_Kontaktform_Support_Admin $admin;
    private Feuer_Kontaktform_Support_Frontend $frontend;

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer
    ) {
        $this->updater = new Feuer_Kontaktform_Updater();
        $this->admin = new Feuer_Kontaktform_Support_Admin($this->db, $this->mailer, $this->updater);
        $this->frontend = new Feuer_Kontaktform_Support_Frontend($this->db, $this->mailer);

        $this->register();
    }

    public static function activate(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->create_tables();
        flush_rewrite_rules();
    }

    public static function uninstall(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->uninstall();
    }

    private function register(): void
    {
        add_action('plugins_loaded', [$this, 'maybe_upgrade']);
        add_action('phpmailer_init', [$this->mailer, 'configure_phpmailer']);
        add_filter('wp_privacy_personal_data_exporters', [$this, 'register_privacy_exporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'register_privacy_eraser']);
        $this->updater->register();
        $this->admin->register();
        $this->frontend->register();
    }

    public function maybe_upgrade(): void
    {
        $installed = (string) get_option(Feuer_Kontaktform_Support_DB::OPTION_VERSION, '');
        if ($installed !== FEUER_KONTAKTFORM_VERSION) {
            $this->db->create_tables();
            $this->updater->clear_cache();
            delete_site_transient('update_plugins');
        }
    }

    public function register_privacy_exporter(array $exporters): array
    {
        $exporters['feuer-kontaktform'] = [
            'exporter_friendly_name' => 'Feuer-Kontaktform Anfragen',
            'callback' => [$this, 'export_personal_data'],
        ];

        return $exporters;
    }

    public function register_privacy_eraser(array $erasers): array
    {
        $erasers['feuer-kontaktform'] = [
            'eraser_friendly_name' => 'Feuer-Kontaktform Anfragen',
            'callback' => [$this, 'erase_personal_data'],
        ];

        return $erasers;
    }

    public function export_personal_data(string $email_address, int $page = 1): array
    {
        $items = [];
        if ($page > 1) {
            return ['data' => [], 'done' => true];
        }

        foreach ($this->db->get_tickets_by_email($email_address, 500) as $ticket) {
            $data = [
                ['name' => 'Anfrage Nr.', 'value' => (string) $ticket['ticket_code']],
                ['name' => 'Abteilung', 'value' => (string) ($ticket['department_name'] ?? '')],
                ['name' => 'Thema', 'value' => (string) ($ticket['topic_title'] ?? '')],
                ['name' => 'Betreff', 'value' => (string) $ticket['subject']],
                ['name' => 'Name', 'value' => (string) $ticket['sender_name']],
                ['name' => 'E-Mail', 'value' => (string) $ticket['sender_email']],
                ['name' => 'Telefon', 'value' => (string) $ticket['sender_phone']],
                ['name' => 'Nachricht', 'value' => (string) $ticket['message']],
                ['name' => 'Datenschutz-Schritt aktiv', 'value' => ! empty($ticket['privacy_required']) ? 'ja' : 'nein'],
                ['name' => 'Datenschutz bestätigt', 'value' => empty($ticket['privacy_required']) ? 'nicht abgefragt' : (! empty($ticket['privacy_accepted']) ? 'ja' : 'nein')],
                ['name' => 'Datenschutz-Version', 'value' => (string) $ticket['privacy_version']],
                ['name' => 'IP-Adresse', 'value' => (string) $ticket['ip_address']],
                ['name' => 'Cookie-ID', 'value' => (string) $ticket['visitor_cookie']],
                ['name' => 'Gerät', 'value' => (string) $ticket['device_type']],
                ['name' => 'Browser', 'value' => (string) $ticket['browser']],
                ['name' => 'Erstellt am', 'value' => (string) $ticket['created_at']],
            ];

            foreach ((array) ($ticket['fields'] ?? []) as $key => $value) {
                $data[] = [
                    'name' => 'Feld: ' . (string) $key,
                    'value' => is_array($value) ? implode(', ', array_map('strval', $value)) : (string) $value,
                ];
            }

            $items[] = [
                'group_id' => 'feuer-kontaktform',
                'group_label' => 'Feuer-Kontaktform',
                'item_id' => 'feuer-ticket-' . (string) $ticket['id'],
                'data' => $data,
            ];
        }

        return ['data' => $items, 'done' => true];
    }

    public function erase_personal_data(string $email_address, int $page = 1): array
    {
        if ($page > 1) {
            return ['items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true];
        }

        $count = $this->db->erase_personal_data($email_address);
        return [
            'items_removed' => $count > 0,
            'items_retained' => false,
            'messages' => $count > 0 ? ['Feuer-Kontaktform Anfragen wurden anonymisiert.'] : [],
            'done' => true,
        ];
    }
}
