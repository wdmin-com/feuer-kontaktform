<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Mailer
{
    public function __construct(private Feuer_Kontaktform_Support_DB $db)
    {
    }

    public function send_ticket(array $ticket, array $department, array $topic, array $settings): array
    {
        $recipient = sanitize_email((string) ($topic['email_override'] ?: $department['email']));
        if ($recipient === '') {
            return ['success' => false, 'message' => 'Kein Empfänger für diese Abteilung konfiguriert.'];
        }

        $headers = $this->notification_headers($settings, $ticket, $department, $topic, true);
        $subject = $this->ticket_subject($ticket, $topic);
        $body = $this->notification_body($ticket, $department, $topic, $settings);

        $sent = wp_mail($recipient, $subject, $body, $headers);
        if (! $sent) {
            return ['success' => false, 'message' => 'Die Benachrichtigung konnte nicht gesendet werden.'];
        }

        $reply_email = sanitize_email((string) ($ticket['sender_email'] ?? ''));
        if ($reply_email !== '' && ! empty($topic['auto_reply_enabled'])) {
            $auto_subject = $this->replace_macros((string) ($topic['auto_subject'] ?: Feuer_Kontaktform_Support_DB::default_auto_subject()), $ticket, $department, $topic, $settings, false);
            $auto_body = $this->replace_macros((string) ($topic['auto_body'] ?: Feuer_Kontaktform_Support_DB::default_auto_body()), $ticket, $department, $topic, $settings, false);
            $auto_html = trim((string) ($topic['auto_html'] ?? ''));
            $format = (string) ($topic['auto_reply_format'] ?? 'html');

            if ($format === 'html' && $auto_html !== '') {
                $auto_html = $this->replace_macros($auto_html, $ticket, $department, $topic, $settings, true);
                wp_mail($reply_email, $auto_subject, $auto_html, $this->headers($settings, $this->auto_reply_to($settings, $department), '', true, true));
            } else {
                wp_mail($reply_email, $auto_subject, $auto_body, $this->headers($settings, $this->auto_reply_to($settings, $department), '', false, true));
            }
        }

        return ['success' => true, 'message' => 'E-Mail wurde gesendet.', 'recipient' => $recipient];
    }

    public function send_admin_reply(array $ticket, array $settings, string $message): bool
    {
        $recipient = sanitize_email((string) ($ticket['sender_email'] ?? ''));
        if ($recipient === '' || trim($message) === '') {
            return false;
        }

        $subject = '[Anfrage Nr. ' . (string) $ticket['ticket_code'] . '] ' . (string) ($ticket['topic_title'] ?? 'Anfrage') . ' - ' . (string) ($ticket['subject'] ?: 'Ohne Betreff');
        $site_name = sanitize_text_field((string) (($settings['site_name'] ?? '') ?: get_bloginfo('name')));
        $logo_url = esc_url_raw((string) ($settings['logo_url'] ?? ''));
        $logo_html = $logo_url !== ''
            ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($site_name) . '" style="max-width:150px;max-height:72px;margin:0 0 14px 0;display:block;">'
            : '';
        $body = nl2br(esc_html($this->replace_admin_reply_macros($message, $ticket, $settings)));
        $body = '<div style="margin:0;padding:0;background:#f3f5f7;font-family:Arial,Helvetica,sans-serif;color:#20242a;">'
            . '<div style="max-width:680px;margin:0 auto;padding:28px 18px;">'
            . '<div style="background:#ffffff;border:1px solid #dde2e8;border-radius:10px;overflow:hidden;">'
            . '<div style="padding:24px 28px;border-bottom:4px solid #b3192b;">'
            . $logo_html
            . '<div style="font-size:13px;color:#b3192b;font-weight:700;text-transform:uppercase;">Anfrage Nr. ' . esc_html((string) $ticket['ticket_code']) . '</div>'
            . '<h1 style="margin:8px 0 0;font-size:22px;line-height:1.25;color:#20242a;">' . esc_html($site_name) . '</h1>'
            . '</div>'
            . '<div style="padding:28px;font-size:16px;line-height:1.55;">'
            . '<p style="margin:0 0 16px;">' . $body . '</p>'
            . '<hr style="border:0;border-top:1px solid #e1e5ea;margin:22px 0;">'
            . '<p style="font-size:13px;color:#687281;margin:0;">Bitte lassen Sie die Anfrage Nr. im Betreff, damit der Dialog eindeutig zugeordnet werden kann.</p>'
            . '<p style="margin:18px 0 0;font-size:15px;line-height:1.55;">Mit freundlichen Grüßen<br><strong>' . esc_html($site_name) . '</strong></p>'
            . '</div>'
            . '</div>'
            . '</div>'
            . '</div>';

        return wp_mail($recipient, $subject, $body, $this->headers($settings, '', '', true));
    }

    public function send_test(array $settings, string $target_email): bool
    {
        $target = sanitize_email($target_email);
        if ($target === '') {
            return false;
        }

        $subject = 'Kontaktform Testmail';
        $body = "Diese Testmail wurde über WordPress wp_mail() gesendet.\n\nWenn diese Nachricht ankommt, ist der konfigurierte Versandweg grundsätzlich erreichbar.";
        return wp_mail($target, $subject, $body, $this->headers($settings));
    }

    public function configure_phpmailer($phpmailer): void
    {
        $settings = $this->db->get_settings();
        if (empty($settings['smtp_enabled'])) {
            return;
        }

        $host = sanitize_text_field((string) ($settings['smtp_host'] ?? ''));
        if ($host === '') {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = $host;
        $phpmailer->Port = max(1, absint($settings['smtp_port'] ?? 587));
        $phpmailer->SMTPAuth = (string) ($settings['smtp_username'] ?? '') !== '';
        $phpmailer->Username = (string) ($settings['smtp_username'] ?? '');
        $phpmailer->Password = (string) ($settings['smtp_password'] ?? '');

        $encryption = (string) ($settings['smtp_encryption'] ?? 'tls');
        if ($encryption === 'ssl' || $encryption === 'tls') {
            $phpmailer->SMTPSecure = $encryption;
        } else {
            $phpmailer->SMTPSecure = '';
        }
    }

    private function notification_body(array $ticket, array $department, array $topic, array $settings): string
    {
        $fields = is_array($ticket['fields'] ?? null) ? $ticket['fields'] : [];
        $skip = ['vorname', 'nachname', 'titel', 'telefon', 'email', 'nachricht'];
        $subject = (string) ($ticket['subject'] ?: ($topic['title'] ?? 'Kontaktanfrage'));
        $reply_target = $this->notification_reply_target($settings, $ticket, $department, $topic);
        $reply_hint = $reply_target['email'] !== ''
            ? $this->mail_field('Direkte Antwort an', $reply_target['email'])
            : '';
        $html = '<div style="margin:0;padding:0;background:#f3f5f7;font-family:Arial,Helvetica,sans-serif;color:#20242a;">'
            . '<div style="max-width:720px;margin:0 auto;padding:28px 18px;">'
            . '<div style="background:#ffffff;border:1px solid #dde2e8;border-radius:10px;overflow:hidden;">'
            . '<div style="padding:24px 28px;border-bottom:4px solid #b3192b;">'
            . '<div style="font-size:13px;color:#b3192b;font-weight:700;text-transform:uppercase;">Neue Anfrage Nr. ' . esc_html((string) $ticket['ticket_code']) . '</div>'
            . '<h1 style="margin:8px 0 0;font-size:24px;line-height:1.25;color:#20242a;">' . esc_html((string) ($topic['title'] ?? 'Kontaktanfrage')) . ' - ' . esc_html($subject) . '</h1>'
            . '</div>'
            . '<div style="padding:26px 28px;">'
            . '<div style="display:grid;gap:10px;margin:0 0 20px;">'
            . $this->mail_field('Abteilung', (string) ($department['name'] ?? ''))
            . $this->mail_field('Name', (string) ($ticket['sender_name'] ?? ''))
            . $this->mail_field('E-Mail', (string) ($ticket['sender_email'] ?? ''))
            . $this->mail_field('Telefon', (string) ($ticket['sender_phone'] ?? ''))
            . $reply_hint
            . '</div>'
            . '<div style="margin:18px 0;padding:18px;border-radius:8px;background:#f8f9fb;border:1px solid #e1e5ea;">'
            . '<div style="font-size:12px;color:#687281;text-transform:uppercase;font-weight:700;">Nachricht</div>'
            . '<p style="margin:8px 0 0;font-size:16px;line-height:1.55;">' . nl2br(esc_html((string) ($ticket['message'] ?? ''))) . '</p>'
            . '</div>';

        $extra = '';
        foreach ($fields as $key => $value) {
            if (in_array((string) $key, $skip, true) || $value === '' || $value === []) {
                continue;
            }
            if (is_array($value)) {
                $value = implode(', ', array_map('strval', $value));
            }
            $extra .= $this->mail_field($this->field_label((string) $key), (string) $value);
        }

        if ($extra !== '') {
            $html .= '<div style="display:grid;gap:10px;margin-top:18px;">' . $extra . '</div>';
        }

        $html .= '<p style="margin:22px 0 0;font-size:13px;color:#687281;">'
            . ($reply_target['email'] !== ''
                ? 'Bei Klick auf Antworten wird die E-Mail direkt an ' . esc_html($reply_target['email']) . ' gesendet. Der Betreff mit der Anfrage Nr. bleibt dabei erhalten.'
                : 'Für diese Nachricht ist aktuell kein direkter Reply-To gesetzt.')
            . '</p>'
            . '</div></div></div></div>';

        return $html;
    }

    private function replace_macros(string $text, array $ticket, array $department, array $topic, array $settings, bool $html): string
    {
        $fields = is_array($ticket['fields'] ?? null) ? $ticket['fields'] : [];
        $site_name = (string) ($settings['site_name'] ?? get_bloginfo('name'));
        $logo_url = esc_url_raw((string) ($settings['logo_url'] ?? ''));
        $privacy_url = esc_url_raw((string) ($settings['privacy_url'] ?? ''));
        $logo_html = $logo_url !== ''
            ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($site_name) . '" style="max-width:150px;max-height:72px;margin:0 0 14px 0;display:block;">'
            : '';
        $macros = [
            '{{ticket}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{ticket_id}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{site_name}}' => $site_name,
            '{{logo_url}}' => $logo_url,
            '{{logo_html}}' => $logo_html,
            '{{privacy_url}}' => $privacy_url,
            '{{department}}' => (string) ($department['name'] ?? ''),
            '{{topic}}' => (string) ($topic['title'] ?? ''),
            '{{subject}}' => (string) ($ticket['subject'] ?? ''),
            '{{name}}' => (string) ($ticket['sender_name'] ?? ''),
            '{{email}}' => (string) ($ticket['sender_email'] ?? ''),
            '{{vorname}}' => (string) ($fields['vorname'] ?? ''),
            '{{nachname}}' => (string) ($fields['nachname'] ?? ''),
            '{{telefon}}' => (string) ($fields['telefon'] ?? ''),
        ];

        if (! $html) {
            $macros['{{logo_html}}'] = $logo_url;
            return strtr($text, $macros);
        }

        $safe = [];
        foreach ($macros as $macro => $value) {
            $safe[$macro] = $macro === '{{logo_html}}' ? $value : esc_html($value);
        }

        return wp_kses_post(strtr($text, $safe));
    }

    private function replace_admin_reply_macros(string $text, array $ticket, array $settings): string
    {
        $fields = is_array($ticket['fields'] ?? null) ? $ticket['fields'] : [];
        $macros = [
            '{{ticket}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{ticket_id}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{site_name}}' => (string) (($settings['site_name'] ?? '') ?: get_bloginfo('name')),
            '{{site_url}}' => (string) home_url('/'),
            '{{department}}' => (string) ($ticket['department_name'] ?? ''),
            '{{topic}}' => (string) ($ticket['topic_title'] ?? ''),
            '{{subject}}' => (string) ($ticket['subject'] ?? ''),
            '{{name}}' => (string) ($ticket['sender_name'] ?? ''),
            '{{email}}' => (string) ($ticket['sender_email'] ?? ''),
            '{{vorname}}' => (string) ($fields['vorname'] ?? ''),
            '{{nachname}}' => (string) ($fields['nachname'] ?? ''),
            '{{telefon}}' => (string) ($fields['telefon'] ?? ''),
        ];

        return strtr($text, $macros);
    }

    private function ticket_subject(array $ticket, array $topic): string
    {
        $subject = (string) ($ticket['subject'] ?: 'Ohne Betreff');
        return '[Anfrage Nr. ' . (string) $ticket['ticket_code'] . '] ' . (string) ($topic['title'] ?? 'Anfrage') . ' - ' . $subject;
    }

    private function mail_field(string $label, string $value): string
    {
        return '<div style="padding:12px 14px;border-radius:8px;background:#f8f9fb;border:1px solid #e1e5ea;">'
            . '<div style="font-size:12px;color:#687281;text-transform:uppercase;font-weight:700;">' . esc_html($label) . '</div>'
            . '<div style="font-size:15px;color:#20242a;margin-top:4px;">' . esc_html($value) . '</div>'
            . '</div>';
    }

    private function field_label(string $key): string
    {
        $labels = [
            'vorname' => 'Vorname',
            'nachname' => 'Nachname',
            'titel' => 'Titel / Betreff',
            'telefon' => 'Telefon',
            'email' => 'E-Mail',
            'nachricht' => 'Nachricht',
        ];

        return $labels[$key] ?? ucfirst(str_replace(['_', '-'], ' ', $key));
    }

    private function notification_headers(array $settings, array $ticket, array $department, array $topic, bool $html = false): array
    {
        $reply_target = $this->notification_reply_target($settings, $ticket, $department, $topic);
        return $this->headers($settings, $reply_target['email'], $reply_target['name'], $html);
    }

    private function auto_reply_to(array $settings, array $department): string
    {
        $strategy = (string) ($settings['auto_reply_reply_to'] ?? 'department');

        if ($strategy === 'department') {
            return (string) ($department['email'] ?? '');
        }

        if ($strategy === 'base') {
            return (string) ($settings['base_email'] ?? '');
        }

        return '';
    }

    private function headers(array $settings, string $reply_to = '', string $reply_name = '', bool $html = false, bool $auto_response = false): array
    {
        $from_email = sanitize_email((string) ($settings['from_email'] ?? get_option('admin_email')));
        if ($from_email === '') {
            $from_email = sanitize_email((string) get_option('admin_email'));
        }

        $from_name = sanitize_text_field((string) ($settings['from_name'] ?? get_bloginfo('name')));
        $headers = [
            'Content-Type: ' . ($html ? 'text/html' : 'text/plain') . '; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];

        $reply = sanitize_email($reply_to);
        if ($reply !== '') {
            $headers[] = 'Reply-To: ' . $reply;
        }

        if ($auto_response && ! empty($settings['auto_response_headers'])) {
            $headers[] = 'Auto-Submitted: auto-replied';
            $headers[] = 'X-Auto-Response-Suppress: All';
        }

        return $headers;
    }

    private function notification_reply_target(array $settings, array $ticket, array $department, array $topic): array
    {
        $strategy = (string) ($settings['notification_reply_to'] ?? 'sender');
        $email = '';
        $name = '';

        if ($strategy === 'sender') {
            $email = (string) ($ticket['sender_email'] ?? '');
            $name = (string) ($ticket['sender_name'] ?? '');
        } elseif ($strategy === 'department') {
            $email = (string) ($topic['email_override'] ?: ($department['email'] ?? ''));
            $name = (string) ($department['name'] ?? '');
        }

        $email = sanitize_email($email);
        $name = sanitize_text_field($name);

        return [
            'email' => $email,
            'name' => $email !== '' ? $name : '',
        ];
    }

}
