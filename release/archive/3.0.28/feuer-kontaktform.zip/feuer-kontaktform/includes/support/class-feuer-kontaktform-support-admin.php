<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Admin
{
    private const MENU_SLUG = 'feuer-kontaktform';

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer,
        private Feuer_Kontaktform_Updater $updater
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'handle_actions']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function assets(string $hook): void
    {
        if (! str_contains($hook, 'feuer-kontaktform')) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/css/support-admin.css', [], FEUER_KONTAKTFORM_VERSION);
        wp_enqueue_script('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/js/support-admin.js', [], FEUER_KONTAKTFORM_VERSION, true);
    }

    public function menu(): void
    {
        add_menu_page('Kontaktform', 'Kontaktform', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page'], 'dashicons-sos', 56);
        add_submenu_page(self::MENU_SLUG, 'Anfragen', 'Anfragen', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page']);
        add_submenu_page(self::MENU_SLUG, 'Abteilungen & Themen', 'Abteilungen & Themen', 'manage_options', 'feuer-kontaktform-departments', [$this, 'departments_page']);
        add_submenu_page(self::MENU_SLUG, 'Einstellungen', 'Einstellungen', 'manage_options', 'feuer-kontaktform-settings', [$this, 'settings_page']);
        add_submenu_page(self::MENU_SLUG, 'Protokolle', 'Protokolle', 'manage_options', 'feuer-kontaktform-logs', [$this, 'logs_page']);
    }

    public function handle_actions(): void
    {
        if (! current_user_can('manage_options') || empty($_POST['feuer_support_action'])) {
            return;
        }

        check_admin_referer('feuer_support_admin');
        $action = sanitize_key((string) wp_unslash($_POST['feuer_support_action']));

        switch ($action) {
            case 'save_settings':
                $settings = $this->sanitize_settings($_POST);
                $this->db->update_settings($settings);
                $this->db->log('settings_saved', 'settings', 0, []);
                $this->redirect('feuer-kontaktform-settings', 'settings_saved');
                break;

            case 'send_test_mail':
                $settings = $this->db->get_settings();
                $target = sanitize_email((string) wp_unslash($_POST['test_email'] ?? get_option('admin_email')));
                $ok = $this->mailer->send_test($settings, $target);
                $this->db->log('test_mail_sent', 'settings', 0, ['target' => $target, 'success' => $ok]);
                $this->redirect('feuer-kontaktform-settings', $ok ? 'test_mail_sent' : 'test_mail_failed');
                break;

            case 'check_updates':
                $status = $this->updater->check_now();
                $this->db->log('update_checked', 'update', 0, $status);
                $this->redirect(
                    'feuer-kontaktform-settings',
                    ! empty($status['error']) ? 'update_failed' : (! empty($status['update_available']) ? 'update_available' : 'update_current'),
                    ! empty($status['error']) ? ['feuer-detail' => (string) ($status['error'] ?? '')] : []
                );
                break;

            case 'install_update':
                $result = $this->updater->install_update();
                $context = [
                    'success' => ! empty($result['success']),
                    'message' => (string) ($result['message'] ?? ''),
                    'remote_version' => (string) ($result['info']['version'] ?? ''),
                    'download_url' => (string) ($result['info']['download_url'] ?? ''),
                ];
                $this->db->log(! empty($result['success']) ? 'update_installed' : 'update_install_failed', 'update', 0, $context);

                if (! empty($result['success'])) {
                    $this->redirect('feuer-kontaktform-settings', 'update_installed');
                }

                if (! empty($result['info']) && empty($result['info']['error']) && empty($result['info']['update_available'])) {
                    $this->redirect('feuer-kontaktform-settings', 'update_no_update');
                }

                $this->redirect(
                    'feuer-kontaktform-settings',
                    'update_install_failed',
                    ['feuer-detail' => (string) ($result['message'] ?? '')]
                );
                break;

            case 'download_backup':
                $payload = $this->db->export_backup_payload();
                $this->db->log('backup_exported', 'backup', 0, [
                    'plugin_version' => (string) ($payload['plugin_version'] ?? ''),
                    'departments' => count((array) ($payload['departments'] ?? [])),
                    'topics' => count((array) ($payload['topics'] ?? [])),
                    'tickets' => count((array) ($payload['tickets'] ?? [])),
                    'messages' => count((array) ($payload['messages'] ?? [])),
                    'logs' => count((array) ($payload['logs'] ?? [])),
                ]);
                $this->send_backup_download($payload);
                break;

            case 'restore_backup':
                if (empty($_POST['backup_confirm'])) {
                    $this->redirect(
                        'feuer-kontaktform-settings',
                        'backup_restore_failed',
                        ['feuer-detail' => 'Bitte bestätigen Sie, dass die aktuellen Plugin-Daten ersetzt werden dürfen.']
                    );
                }

                $uploaded = $this->read_uploaded_backup();
                if (empty($uploaded['success'])) {
                    $this->db->log('backup_restore_failed', 'backup', 0, ['message' => (string) ($uploaded['message'] ?? '')]);
                    $this->redirect(
                        'feuer-kontaktform-settings',
                        'backup_restore_failed',
                        ['feuer-detail' => (string) ($uploaded['message'] ?? '')]
                    );
                }

                $result = $this->db->import_backup_payload((array) ($uploaded['payload'] ?? []));
                if (empty($result['success'])) {
                    $this->db->log('backup_restore_failed', 'backup', 0, ['message' => (string) ($result['message'] ?? '')]);
                }

                $this->redirect(
                    'feuer-kontaktform-settings',
                    ! empty($result['success']) ? 'backup_restored' : 'backup_restore_failed',
                    ['feuer-detail' => (string) ($result['message'] ?? '')]
                );
                break;

            case 'save_department':
                $result = $this->db->save_department([
                    'id' => absint($_POST['department_id'] ?? 0),
                    'name' => wp_unslash($_POST['department_name'] ?? ''),
                    'slug' => wp_unslash($_POST['department_slug'] ?? ''),
                    'email' => wp_unslash($_POST['department_email'] ?? ''),
                    'description' => wp_unslash($_POST['department_description'] ?? ''),
                    'sort_order' => absint($_POST['department_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['department_is_active']),
                ]);
                $this->redirect(
                    'feuer-kontaktform-departments',
                    ! empty($result['success']) ? 'department_saved' : 'department_failed',
                    ! empty($result['success']) ? [] : ['feuer-detail' => (string) ($result['message'] ?? '')]
                );
                break;

            case 'delete_department':
                $this->db->deactivate_department(absint($_POST['department_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'department_deleted');
                break;

            case 'move_department':
                $moved = $this->db->move_department(
                    absint($_POST['department_id'] ?? 0),
                    sanitize_key((string) wp_unslash($_POST['department_direction'] ?? ''))
                );
                $this->redirect('feuer-kontaktform-departments', $moved ? 'department_moved' : 'department_move_failed');
                break;

            case 'save_topic':
                $result = $this->db->save_topic([
                    'id' => absint($_POST['topic_id'] ?? 0),
                    'department_id' => absint($_POST['department_id'] ?? 0),
                    'title' => wp_unslash($_POST['topic_title'] ?? ''),
                    'slug' => wp_unslash($_POST['topic_slug'] ?? ''),
                    'email_override' => wp_unslash($_POST['topic_email_override'] ?? ''),
                    'auto_reply_enabled' => ! empty($_POST['topic_auto_reply_enabled']),
                    'auto_reply_format' => wp_unslash($_POST['topic_auto_reply_format'] ?? 'html'),
                    'auto_subject' => wp_unslash($_POST['topic_auto_subject'] ?? ''),
                    'auto_body' => wp_unslash($_POST['topic_auto_body'] ?? ''),
                    'auto_html' => wp_unslash($_POST['topic_auto_html'] ?? ''),
                    'sort_order' => absint($_POST['topic_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['topic_is_active']),
                    'fields' => $this->collect_fields(),
                ]);
                $this->redirect(
                    'feuer-kontaktform-departments',
                    ! empty($result['success']) ? 'topic_saved' : 'topic_failed',
                    ! empty($result['success']) ? [] : ['feuer-detail' => (string) ($result['message'] ?? '')]
                );
                break;

            case 'delete_topic':
                $this->db->deactivate_topic(absint($_POST['topic_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'topic_deleted');
                break;

            case 'reply_ticket':
                $ticket_id = absint($_POST['ticket_id'] ?? 0);
                $message = sanitize_textarea_field((string) wp_unslash($_POST['reply_message'] ?? ''));
                $ticket = $this->db->get_ticket($ticket_id);
                $ok = false;

                if ($ticket && $message !== '') {
                    $settings = $this->db->get_settings();
                    $actor = wp_get_current_user();
                    $actor_name = $this->user_display_name($actor);
                    $ok = $this->mailer->send_admin_reply($ticket, $settings, $message);
                    if ($ok) {
                        $this->db->add_message($ticket_id, 'outbound', (string) $settings['from_email'], (string) $ticket['sender_email'], $message, [
                            'source' => 'admin_reply',
                            'actor_id' => get_current_user_id(),
                            'actor_name' => $actor_name,
                            'actor_email' => (string) ($actor->user_email ?? ''),
                        ]);
                        $this->db->log('ticket_replied', 'ticket', $ticket_id, ['ticket_code' => (string) $ticket['ticket_code'], 'actor_name' => $actor_name]);
                    }
                }

                $this->redirect('feuer-kontaktform', $ok ? 'ticket_reply_sent' : 'ticket_reply_failed');
                break;
        }
    }

    public function tickets_page(): void
    {
        $search = sanitize_text_field((string) wp_unslash($_GET['feuer_search'] ?? ''));
        $tickets = $this->db->get_tickets(200, $search);
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Kontaktform Anfragen</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-card">
                <h2>Letzte Anfragen</h2>
                <p class="description">Die <strong>Anfrage Nr.</strong> gehört in den Betreff jeder E-Mail-Antwort, damit der Dialog eindeutig zugeordnet werden kann.</p>
                <form method="get" class="feuer-search-row">
                    <input type="hidden" name="page" value="<?php echo esc_attr(self::MENU_SLUG); ?>">
                    <input class="regular-text" type="search" name="feuer_search" value="<?php echo esc_attr($search); ?>" placeholder="E-Mail, Name oder Anfrage Nr.">
                    <button class="button">Suchen</button>
                    <?php if ($search !== '') : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)); ?>">Zurücksetzen</a><?php endif; ?>
                </form>
                <div class="feuer-ticket-list">
                    <?php if ($tickets === []) : ?>
                        <p>Noch keine Anfragen vorhanden.</p>
                    <?php endif; ?>
                    <?php foreach ($tickets as $ticket) : ?>
                        <?php $messages = $this->db->get_ticket_messages((int) $ticket['id']); ?>
                        <details class="feuer-ticket-card">
                            <summary>
                                <strong><?php echo esc_html((string) $ticket['ticket_code']); ?></strong>
                                <span><?php echo esc_html((string) ($ticket['department_name'] ?? '')); ?></span>
                                <span><?php echo esc_html((string) ($ticket['topic_title'] ?? '')); ?></span>
                                <span><?php echo esc_html((string) $ticket['sender_name']); ?></span>
                                <time><?php echo esc_html((string) $ticket['created_at']); ?></time>
                            </summary>
                            <div class="feuer-ticket-body">
                                <div class="feuer-ticket-meta">
                                    <span>Status: <strong><?php echo esc_html((string) $ticket['status']); ?></strong></span>
                                    <span>Datenschutz: <strong><?php echo empty($ticket['privacy_required']) ? 'deaktiviert' : (! empty($ticket['privacy_accepted']) ? 'ja' : 'nein'); ?></strong> / <?php echo esc_html((string) $ticket['privacy_version']); ?></span>
                                    <span>IP: <strong><?php echo esc_html((string) $ticket['ip_address']); ?></strong></span>
                                    <span>Gerät: <strong><?php echo esc_html((string) $ticket['device_type']); ?></strong></span>
                                    <span>Browser: <strong><?php echo esc_html((string) $ticket['browser']); ?></strong></span>
                                </div>
                                <div class="feuer-ticket-field-grid">
                                    <?php foreach ((array) $ticket['fields'] as $key => $value) : ?>
                                        <?php if ($value === '' || $value === []) { continue; } ?>
                                        <div class="feuer-ticket-field">
                                            <small><?php echo esc_html($this->field_label((string) $key)); ?></small>
                                            <strong><?php echo esc_html($this->field_value($value)); ?></strong>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="feuer-ticket-message">
                                    <small>Nachricht</small>
                                    <p><?php echo nl2br(esc_html((string) $ticket['message'])); ?></p>
                                </div>
                                <?php if ($messages !== []) : ?>
                                    <div class="feuer-message-timeline">
                                        <h3>Verlauf</h3>
                                        <?php foreach ($messages as $message) : ?>
                                            <article>
                                                <b><?php echo esc_html($this->message_actor_label($message, $ticket)); ?></b>
                                                <span><?php echo esc_html((string) $message['created_at']); ?></span>
                                                <p><?php echo nl2br(esc_html((string) $message['body'])); ?></p>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                <form method="post" class="feuer-reply-form">
                                    <?php wp_nonce_field('feuer_support_admin'); ?>
                                    <input type="hidden" name="feuer_support_action" value="reply_ticket">
                                    <input type="hidden" name="ticket_id" value="<?php echo esc_attr((string) $ticket['id']); ?>">
                                    <h3>Antwort per E-Mail schreiben</h3>
                                    <p class="description">Betreff: <?php echo esc_html($this->ticket_subject($ticket)); ?></p>
                                    <p class="description">Verfügbare Platzhalter: <code>{{site_name}}</code>, <code>{{site_url}}</code>, <code>{{ticket_id}}</code>, <code>{{name}}</code>, <code>{{topic}}</code>, <code>{{subject}}</code>.</p>
                                    <label>Antwort<textarea class="large-text" name="reply_message" rows="9" required><?php echo esc_textarea($this->default_reply_template($ticket)); ?></textarea></label>
                                    <button class="button button-primary">Antwort senden</button>
                                </form>
                            </div>
                        </details>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function departments_page(): void
    {
        $departments = $this->db->get_departments();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Abteilungen & Themen</h1>
            <?php $this->notice(); ?>
            <p class="description">Jede Abteilung ist eine eigene Support-Route. In den Tabs bearbeiten Sie zuerst Name und E-Mail, danach die einzelnen Themen mit Autoantwort und Feldern.</p>

            <div class="feuer-admin-card">
                <div class="feuer-tabs feuer-department-tabs" data-feuer-tabs>
                    <div class="feuer-tab-nav" role="tablist">
                        <button type="button" class="is-active" data-tab-target="department-new">Neue Abteilung</button>
                        <?php foreach ($departments as $department) : ?>
                            <button type="button" data-tab-target="<?php echo esc_attr('department-' . (int) $department['id']); ?>"><?php echo esc_html((string) $department['name']); ?></button>
                        <?php endforeach; ?>
                    </div>
                    <div class="feuer-tab-panel is-active" data-tab-panel="department-new">
                        <h2>Neue Abteilung</h2>
                        <?php $this->department_form(); ?>
                    </div>
                    <?php foreach ($departments as $department_index => $department) : ?>
                        <?php $topics = $this->db->get_topics((int) $department['id']); ?>
                        <?php $tab_prefix = 'department-' . (int) $department['id']; ?>
                        <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix); ?>">
                            <div class="feuer-department-head">
                                <div>
                                    <h2><?php echo esc_html((string) $department['name']); ?></h2>
                                    <p><code><?php echo esc_html((string) $department['slug']); ?></code> - <?php echo esc_html((string) $department['email']); ?></p>
                                </div>
                                <div class="feuer-department-actions">
                                    <strong><?php echo esc_html((string) count($topics)); ?> Themen</strong>
                                    <form method="post">
                                        <?php wp_nonce_field('feuer_support_admin'); ?>
                                        <input type="hidden" name="feuer_support_action" value="move_department">
                                        <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                                        <input type="hidden" name="department_direction" value="up">
                                        <button class="button" <?php disabled($department_index === 0); ?>>Hoch</button>
                                    </form>
                                    <form method="post">
                                        <?php wp_nonce_field('feuer_support_admin'); ?>
                                        <input type="hidden" name="feuer_support_action" value="move_department">
                                        <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                                        <input type="hidden" name="department_direction" value="down">
                                        <button class="button" <?php disabled($department_index === count($departments) - 1); ?>>Runter</button>
                                    </form>
                                </div>
                            </div>
                            <div class="feuer-tabs feuer-topic-tabs" data-feuer-tabs>
                                <div class="feuer-tab-nav" role="tablist">
                                    <button type="button" class="is-active" data-tab-target="<?php echo esc_attr($tab_prefix . '-base'); ?>">Abteilung</button>
                                    <button type="button" data-tab-target="<?php echo esc_attr($tab_prefix . '-shortcodes'); ?>">Shortcodes</button>
                                    <?php foreach ($topics as $topic) : ?>
                                        <button type="button" data-tab-target="<?php echo esc_attr($tab_prefix . '-topic-' . (int) $topic['id']); ?>"><?php echo esc_html((string) $topic['title']); ?></button>
                                    <?php endforeach; ?>
                                    <button type="button" data-tab-target="<?php echo esc_attr($tab_prefix . '-new-topic'); ?>">+ Thema</button>
                                </div>
                                <div class="feuer-tab-panel is-active" data-tab-panel="<?php echo esc_attr($tab_prefix . '-base'); ?>">
                                    <h3>Abteilung</h3>
                                    <p class="description"><strong>Name und E-Mail der Abteilung</strong>. Diese E-Mail wird verwendet, wenn ein Thema keine eigene E-Mail-Adresse hat.</p>
                                    <?php $this->department_form($department); ?>
                                </div>
                                <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix . '-shortcodes'); ?>">
                                    <?php $this->department_shortcodes($department, $topics); ?>
                                </div>
                                <?php foreach ($topics as $topic) : ?>
                                    <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix . '-topic-' . (int) $topic['id']); ?>">
                                        <?php $this->topic_form($department, $topic); ?>
                                    </div>
                                <?php endforeach; ?>
                                <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix . '-new-topic'); ?>">
                                    <h3>Neues Thema</h3>
                                    <p class="description">Neue Themen starten mit einer Standard-Autoantwort und den Standardfeldern.</p>
                                    <?php $this->topic_form($department); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function settings_page(): void
    {
        $settings = $this->db->get_settings();
        $update = $this->updater->get_status();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Einstellungen</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-card">
                <div class="feuer-tabs" data-feuer-tabs>
                    <div class="feuer-tab-nav" role="tablist">
                        <button type="button" class="is-active" data-tab-target="settings-brand">Website & Logo</button>
                        <button type="button" data-tab-target="settings-design">Darstellung</button>
                        <button type="button" data-tab-target="settings-mail">E-Mail</button>
                        <button type="button" data-tab-target="settings-deliverability">Zustellbarkeit</button>
                        <button type="button" data-tab-target="settings-privacy">Datenschutz</button>
                        <button type="button" data-tab-target="settings-system">System</button>
                        <button type="button" data-tab-target="settings-backup">Sicherung</button>
                        <button type="button" data-tab-target="settings-shortcodes">Shortcodes</button>
                    </div>

                    <div class="feuer-tab-panel is-active" data-tab-panel="settings-brand">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>Website & Logo</h2>
                            <?php $this->input('site_name', 'Name der Website', $settings['site_name']); ?>
                            <label>
                                Logo
                                <div class="feuer-media-picker">
                                    <input class="regular-text" type="url" name="logo_url" value="<?php echo esc_attr((string) $settings['logo_url']); ?>" data-media-url>
                                    <button type="button" class="button" data-media-select>Bild aus Mediathek wählen</button>
                                    <button type="button" class="button" data-media-clear>Entfernen</button>
                                </div>
                                <span class="description">Das Logo wird in der Kontaktstrecke und in HTML-Autoantworten verwendet.</span>
                                <img class="feuer-logo-preview" src="<?php echo esc_url((string) $settings['logo_url']); ?>" alt="" data-media-preview<?php echo (string) $settings['logo_url'] === '' ? ' hidden' : ''; ?>>
                            </label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-design">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>Darstellung der Kontaktstrecke</h2>
                            <p class="description">Diese Auswahl steuert nur die Optik. Logik, Pflichtfelder und AJAX-Ablauf bleiben gleich.</p>
                            <div class="feuer-form-grid">
                                <label>
                                    Design
                                    <select name="design_variant">
                                        <option value="classic" <?php selected((string) $settings['design_variant'], 'classic'); ?>>Klassisch</option>
                                        <option value="clean" <?php selected((string) $settings['design_variant'], 'clean'); ?>>Clean</option>
                                        <option value="stepper" <?php selected((string) $settings['design_variant'], 'stepper'); ?>>Schritt-Karten</option>
                                        <option value="rail" <?php selected((string) $settings['design_variant'], 'rail'); ?>>Linke Bewegungsleiste</option>
                                        <option value="stripe" <?php selected((string) $settings['design_variant'], 'stripe'); ?>>Obere Bewegungsleiste</option>
                                    </select>
                                </label>
                                <label>
                                    Eingabefelder
                                    <select name="field_variant">
                                        <option value="soft" <?php selected((string) $settings['field_variant'], 'soft'); ?>>Weich ohne Kartenrand</option>
                                        <option value="line" <?php selected((string) $settings['field_variant'], 'line'); ?>>Linie</option>
                                        <option value="filled" <?php selected((string) $settings['field_variant'], 'filled'); ?>>Gefüllt</option>
                                        <option value="compact" <?php selected((string) $settings['field_variant'], 'compact'); ?>>Kompakt</option>
                                    </select>
                                </label>
                            </div>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-mail">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>E-Mail</h2>
                            <div class="feuer-form-grid">
                                <?php $this->input('base_email', 'Basis E-Mail', $settings['base_email'], 'email'); ?>
                                <?php $this->input('from_email', 'Absender E-Mail', $settings['from_email'], 'email'); ?>
                                <?php $this->input('from_name', 'Absender Name', $settings['from_name']); ?>
                            </div>
                            <h3>SMTP Versand</h3>
                            <p class="description">Empfohlen: SMTP-Konto mit demselben Domain wie die Absender-E-Mail. Wenn ein separates SMTP-Plugin genutzt wird, diese Option deaktiviert lassen.</p>
                            <input type="hidden" name="smtp_enabled" value="0">
                            <label class="feuer-check-label"><input type="checkbox" name="smtp_enabled" value="1" <?php checked(! empty($settings['smtp_enabled'])); ?>> SMTP direkt im Plugin verwenden</label>
                            <div class="feuer-form-grid">
                                <?php $this->input('smtp_host', 'SMTP Host', $settings['smtp_host']); ?>
                                <?php $this->input('smtp_port', 'SMTP Port', $settings['smtp_port'], 'number'); ?>
                                <label>
                                    Verschlüsselung
                                    <select name="smtp_encryption">
                                        <option value="tls" <?php selected((string) $settings['smtp_encryption'], 'tls'); ?>>TLS</option>
                                        <option value="ssl" <?php selected((string) $settings['smtp_encryption'], 'ssl'); ?>>SSL</option>
                                        <option value="none" <?php selected((string) $settings['smtp_encryption'], 'none'); ?>>Keine</option>
                                    </select>
                                </label>
                                <?php $this->input('smtp_username', 'SMTP Benutzername', $settings['smtp_username']); ?>
                            </div>
                            <label>
                                SMTP Passwort
                                <input class="regular-text" type="password" name="smtp_password" value="" autocomplete="new-password" placeholder="<?php echo empty($settings['smtp_password']) ? 'Nicht gespeichert' : 'Gespeichert - leer lassen zum Beibehalten'; ?>">
                                <span class="description">Leer lassen, um ein gespeichertes Passwort beizubehalten.</span>
                            </label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                        <form method="post" class="feuer-subform">
                            <h3>E-Mail Verbindung prüfen</h3>
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="send_test_mail">
                            <?php $this->input('test_email', 'Test-Empfänger', get_option('admin_email'), 'email'); ?>
                            <p><button class="button">Testmail senden</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-deliverability">
                        <?php $report = $this->deliverability_report($settings); ?>
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>E-Mail Zustellbarkeit</h2>
                            <p class="description">Diese Einstellungen reduzieren Spam-Risiken. Die wichtigsten Punkte bleiben SPF, DKIM und DMARC im DNS des Absender-Domains sowie ein sauber konfigurierter SMTP-Versand.</p>
                            <div class="feuer-form-grid">
                                <label>
                                    Reply-To für interne Benachrichtigung
                                    <select name="notification_reply_to">
                                        <option value="sender" <?php selected((string) $settings['notification_reply_to'], 'sender'); ?>>Absender der Anfrage (empfohlen)</option>
                                        <option value="department" <?php selected((string) $settings['notification_reply_to'], 'department'); ?>>Abteilung</option>
                                        <option value="none" <?php selected((string) $settings['notification_reply_to'], 'none'); ?>>Kein Reply-To</option>
                                    </select>
                                    <span class="description">Wenn hier <strong>Absender der Anfrage</strong> gewählt ist, geht die Antwort aus dem Mailprogramm direkt an den Besucher.</span>
                                </label>
                                <label>
                                    Reply-To für Autoantwort
                                    <select name="auto_reply_reply_to">
                                        <option value="department" <?php selected((string) $settings['auto_reply_reply_to'], 'department'); ?>>Abteilung</option>
                                        <option value="base" <?php selected((string) $settings['auto_reply_reply_to'], 'base'); ?>>Basis E-Mail</option>
                                        <option value="none" <?php selected((string) $settings['auto_reply_reply_to'], 'none'); ?>>Kein Reply-To</option>
                                    </select>
                                </label>
                                <?php $this->input('dkim_selector', 'DKIM Selector für DNS-Prüfung', $settings['dkim_selector']); ?>
                            </div>
                            <input type="hidden" name="enforce_from_domain" value="0">
                            <label class="feuer-check-label"><input type="checkbox" name="enforce_from_domain" value="1" <?php checked(! empty($settings['enforce_from_domain'])); ?>> Warnen, wenn Absender-Domain nicht zur Website passt</label>
                            <input type="hidden" name="auto_response_headers" value="0">
                            <label class="feuer-check-label"><input type="checkbox" name="auto_response_headers" value="1" <?php checked(! empty($settings['auto_response_headers'])); ?>> Autoantwort-Header setzen: Auto-Submitted und X-Auto-Response-Suppress</label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>

                        <div class="feuer-delivery-grid">
                            <div class="feuer-delivery-card <?php echo esc_attr($report['domain_match_class']); ?>">
                                <strong>Absender-Domain</strong>
                                <span><?php echo esc_html($report['from_domain']); ?></span>
                                <small><?php echo esc_html($report['domain_match_text']); ?></small>
                            </div>
                            <div class="feuer-delivery-card <?php echo esc_attr($report['spf_class']); ?>">
                                <strong>SPF</strong>
                                <span><?php echo esc_html($report['spf_text']); ?></span>
                                <small><?php echo esc_html($report['spf_hint']); ?></small>
                            </div>
                            <div class="feuer-delivery-card <?php echo esc_attr($report['dmarc_class']); ?>">
                                <strong>DMARC</strong>
                                <span><?php echo esc_html($report['dmarc_text']); ?></span>
                                <small><?php echo esc_html($report['dmarc_hint']); ?></small>
                            </div>
                            <div class="feuer-delivery-card <?php echo esc_attr($report['dkim_class']); ?>">
                                <strong>DKIM</strong>
                                <span><?php echo esc_html($report['dkim_text']); ?></span>
                                <small><?php echo esc_html($report['dkim_hint']); ?></small>
                            </div>
                            <div class="feuer-delivery-card <?php echo esc_attr($report['smtp_class']); ?>">
                                <strong>SMTP</strong>
                                <span><?php echo esc_html($report['smtp_text']); ?></span>
                                <small><?php echo esc_html($report['smtp_hint']); ?></small>
                            </div>
                        </div>

                        <div class="feuer-delivery-advice">
                            <h3>Empfohlene Praxis</h3>
                            <ul>
                                <li>From muss ein Postfach des eigenen Domains sein, z.B. <code>kontakt@<?php echo esc_html($report['site_domain']); ?></code>.</li>
                                <li>Autoantworten werden nie vom E-Mail-Absender des Besuchers verschickt.</li>
                                <li>SMTP sollte über denselben Domain laufen wie die From-Adresse.</li>
                                <li>SPF, DKIM und DMARC müssen beim DNS-Provider des Domains gesetzt sein.</li>
                                <li>HTML-Autoantworten sollten wenige Links, keine Scripts, keine Base64-Bilder und keine URL-Shortener enthalten.</li>
                            </ul>
                        </div>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-privacy">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>Datenschutz</h2>
                            <input type="hidden" name="privacy_enabled" value="0">
                            <label class="feuer-check-label"><input type="checkbox" name="privacy_enabled" value="1" <?php checked(! empty($settings['privacy_enabled'])); ?>> Datenschutz-Schritt im Frontend aktivieren</label>
                            <?php $this->input('privacy_url', 'URL zur Datenschutzerklärung', $settings['privacy_url'], 'url'); ?>
                            <label>Text für Datenschutzhinweis<textarea name="privacy_text" rows="5" class="large-text"><?php echo esc_textarea((string) $settings['privacy_text']); ?></textarea></label>
                            <?php $this->input('privacy_version', 'Datenschutz-Version', $settings['privacy_version']); ?>
                            <label>Text nach erfolgreichem Versand<textarea name="ticket_success_text" rows="4" class="large-text"><?php echo esc_textarea((string) $settings['ticket_success_text']); ?></textarea></label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-system">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>System</h2>
                            <?php $this->input('rate_limit_minutes', 'Captcha nach Wiederholung innerhalb Minuten', $settings['rate_limit_minutes'], 'number'); ?>
                            <div class="feuer-form-grid">
                                <?php $this->input('allowed_file_types', 'Erlaubte Dateiformate', $settings['allowed_file_types']); ?>
                                <?php $this->input('max_upload_mb', 'Maximale Dateigröße in MB', $settings['max_upload_mb'], 'number'); ?>
                            </div>
                            <p class="description">Dateiformate als kommagetrennte Liste, zum Beispiel <code>pdf,jpg,jpeg,png,doc,docx</code>.</p>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                        <div class="feuer-subform">
                            <h3>Plugin Update</h3>
                            <div class="feuer-update-status <?php echo ! empty($update['error']) ? 'is-error' : (! empty($update['update_available']) ? 'is-update' : 'is-current'); ?>">
                                <div><span>Installiert</span><strong><?php echo esc_html((string) $update['current_version']); ?></strong></div>
                                <div><span>Server</span><strong><?php echo esc_html((string) ($update['remote_version'] !== '' ? $update['remote_version'] : 'unbekannt')); ?></strong></div>
                                <div><span>WordPress getestet bis</span><strong><?php echo esc_html((string) ($update['tested'] !== '' ? $update['tested'] : 'unbekannt')); ?></strong></div>
                                <div><span>Status</span><strong><?php echo esc_html($this->update_status_label($update)); ?></strong></div>
                            </div>
                            <p>Entwickler-URL: <code><?php echo esc_html((string) $update['base_url']); ?></code></p>
                            <p>Update-Metadaten: <code><?php echo esc_html((string) $update['meta_url']); ?></code></p>
                            <?php if ((string) $update['download_url'] !== '') : ?><p>Download: <code><?php echo esc_html((string) $update['download_url']); ?></code></p><?php endif; ?>
                            <?php if ((string) $update['checked_at'] !== '') : ?><p>Letzte manuelle Prüfung: <strong><?php echo esc_html((string) $update['checked_at']); ?></strong></p><?php endif; ?>
                            <?php if (! empty($update['error'])) : ?><p class="notice notice-error inline"><?php echo esc_html((string) $update['error']); ?></p><?php endif; ?>
                            <form method="post">
                                <?php wp_nonce_field('feuer_support_admin'); ?>
                                <input type="hidden" name="feuer_support_action" value="check_updates">
                                <button class="button button-primary">Update prüfen</button>
                            </form>
                            <form method="post" class="feuer-update-install-form">
                                <?php wp_nonce_field('feuer_support_admin'); ?>
                                <input type="hidden" name="feuer_support_action" value="install_update">
                                <button class="button button-primary" <?php disabled(empty($update['update_available']) || ! empty($update['error'])); ?>>Update jetzt installieren</button>
                                <span class="description">Installiert die Version vom Entwickler-Server direkt über den WordPress-Updater.</span>
                            </form>
                        </div>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-backup">
                        <div class="feuer-subform">
                            <h2>Sicherung & Wiederherstellung</h2>
                            <p class="description">Die Sicherung enthält alle Plugin-Einstellungen, Abteilungen, Themen, Empfänger-E-Mails, Anfragen, Nachrichtenverlauf und Protokolle.</p>
                            <p class="description">Die Datei kann auch SMTP-Zugangsdaten und personenbezogene Daten enthalten. Bitte nur geschützt speichern.</p>
                            <form method="post">
                                <?php wp_nonce_field('feuer_support_admin'); ?>
                                <input type="hidden" name="feuer_support_action" value="download_backup">
                                <p><button class="button button-primary">Sicherung herunterladen</button></p>
                            </form>
                        </div>

                        <div class="feuer-subform">
                            <h3>Sicherung wiederherstellen</h3>
                            <p class="description">Beim Wiederherstellen werden die aktuellen Plugin-Daten komplett ersetzt: Einstellungen, Abteilungen, Themen, Anfragen, Verlauf und Protokolle.</p>
                            <p class="description">Datei-Uploads aus Anfragen bleiben nur dann vollständig nutzbar, wenn die zugehörigen Dateien im WordPress-Uploads-Ordner weiterhin vorhanden sind.</p>
                            <form method="post" enctype="multipart/form-data">
                                <?php wp_nonce_field('feuer_support_admin'); ?>
                                <input type="hidden" name="feuer_support_action" value="restore_backup">
                                <label>
                                    Sicherungsdatei (JSON)
                                    <input type="file" name="backup_file" accept=".json,application/json" required>
                                </label>
                                <label class="feuer-check-label">
                                    <input type="checkbox" name="backup_confirm" value="1" required>
                                    Aktuelle Plugin-Daten vollständig ersetzen
                                </label>
                                <p><button class="button">Sicherung wiederherstellen</button></p>
                            </form>
                        </div>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-shortcodes">
                        <h2>Shortcodes</h2>
                        <p><code>[feuer-kontaktform]</code> kompletter Wizard.</p>
                        <p><code>[feuer-kontaktform department="wehrfuehrung"]</code> direkt zu einer Abteilung.</p>
                        <p><code>[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]</code> direkt zu einem Thema.</p>
                        <p><code>[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]</code> schnelle klassische Form.</p>
                        <p class="description">Links auf eine Seite mit eingebautem Formular können zusätzlich über URL-Parameter direkt zu einer Abteilung oder zu einem Thema springen.</p>
                        <p><code><?php echo esc_html($this->frontend_link_example(['feuer_department' => 'wehrfuehrung'])); ?></code></p>
                        <p><code><?php echo esc_html($this->frontend_link_example(['feuer_department' => 'wehrfuehrung', 'feuer_topic' => 'mitglied-werden'])); ?></code></p>
                        <p class="description">Ersetzen Sie <code>/ihre-formularseite/</code> durch die Seite, auf der der Shortcode eingebunden ist.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function logs_page(): void
    {
        $logs = $this->db->get_logs();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Protokolle</h1>
            <div class="feuer-admin-card">
                <h2>Aktivitäten im Plugin</h2>
                <p class="description">Hier steht in normaler Sprache, was im Plugin passiert ist: Einstellungen, Abteilungen, Themen, Update-Prüfungen und neue Anfragen.</p>
                <div class="feuer-log-list">
                    <?php if ($logs === []) : ?>
                        <p>Noch keine Protokolle vorhanden.</p>
                    <?php endif; ?>
                    <?php foreach ($logs as $log) : ?>
                        <?php $user = ! empty($log['actor_id']) ? get_user_by('id', (int) $log['actor_id']) : null; ?>
                        <article class="feuer-log-item">
                            <div class="feuer-log-main">
                                <strong><?php echo esc_html($this->log_action_label((string) $log['action'])); ?></strong>
                                <span><?php echo esc_html($this->object_type_label((string) $log['object_type'])); ?><?php echo ! empty($log['object_id']) ? ' #' . esc_html((string) $log['object_id']) : ''; ?></span>
                            </div>
                            <div class="feuer-log-meta">
                                <span><?php echo esc_html((string) $log['created_at']); ?></span>
                                <span>Admin: <?php echo esc_html($user ? $this->user_display_name($user) : ((int) $log['actor_id'] > 0 ? '#' . (string) $log['actor_id'] : 'System')); ?></span>
                                <span>IP: <?php echo esc_html((string) $log['ip_address']); ?></span>
                            </div>
                            <?php $context = $this->format_context((string) ($log['context_json'] ?? '')); ?>
                            <?php if ($context !== '') : ?><p class="feuer-log-context"><?php echo esc_html($context); ?></p><?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    private function log_action_label(string $action): string
    {
        $labels = [
            'settings_saved' => 'Einstellungen gespeichert',
            'test_mail_sent' => 'Testmail gesendet',
            'update_checked' => 'Update geprüft',
            'update_installed' => 'Update installiert',
            'update_install_failed' => 'Update-Installation fehlgeschlagen',
            'backup_exported' => 'Sicherung exportiert',
            'backup_restored' => 'Sicherung wiederhergestellt',
            'backup_restore_failed' => 'Sicherung konnte nicht wiederhergestellt werden',
            'department_name_required' => 'Abteilung konnte nicht gespeichert werden',
            'department_slug_invalid' => 'Abteilung konnte nicht gespeichert werden',
            'department_email_invalid' => 'Abteilung konnte nicht gespeichert werden',
            'department_slug_exists' => 'Abteilung konnte nicht gespeichert werden',
            'department_update_failed' => 'Abteilung konnte nicht gespeichert werden',
            'department_insert_failed' => 'Abteilung konnte nicht gespeichert werden',
            'department_insert_missing_id' => 'Abteilung konnte nicht gespeichert werden',
            'department_created' => 'Abteilung erstellt',
            'department_updated' => 'Abteilung bearbeitet',
            'department_deleted' => 'Abteilung deaktiviert',
            'department_moved' => 'Abteilung verschoben',
            'default_department_created' => 'Standard-Abteilung angelegt',
            'topic_department_missing' => 'Thema konnte nicht gespeichert werden',
            'topic_title_required' => 'Thema konnte nicht gespeichert werden',
            'topic_slug_invalid' => 'Thema konnte nicht gespeichert werden',
            'topic_email_invalid' => 'Thema konnte nicht gespeichert werden',
            'topic_slug_exists' => 'Thema konnte nicht gespeichert werden',
            'topic_update_failed' => 'Thema konnte nicht gespeichert werden',
            'topic_insert_failed' => 'Thema konnte nicht gespeichert werden',
            'topic_insert_missing_id' => 'Thema konnte nicht gespeichert werden',
            'topic_created' => 'Thema erstellt',
            'topic_updated' => 'Thema bearbeitet',
            'topic_deleted' => 'Thema deaktiviert',
            'ticket_created' => 'Neue Anfrage gespeichert',
            'ticket_create_failed' => 'Anfrage konnte nicht gespeichert werden',
            'ticket_replied' => 'Antwort gesendet',
        ];

        return $labels[$action] ?? $action;
    }

    private function object_type_label(string $type): string
    {
        $labels = [
            'settings' => 'Einstellungen',
            'update' => 'Update',
            'backup' => 'Sicherung',
            'validation' => 'Validierung',
            'department' => 'Abteilung',
            'topic' => 'Thema',
            'ticket' => 'Anfrage',
        ];

        return $labels[$type] ?? ($type !== '' ? $type : 'Plugin');
    }

    private function format_context(string $json): string
    {
        $decoded = json_decode($json, true);
        if (! is_array($decoded) || $decoded === []) {
            return '';
        }

        $parts = [];
        foreach ($decoded as $key => $value) {
            if (is_array($value)) {
                $value = wp_json_encode($value);
            } elseif (is_bool($value)) {
                $value = $value ? 'ja' : 'nein';
            }

            $parts[] = (string) $key . ': ' . (string) $value;
        }

        return implode(' | ', $parts);
    }

    private function update_status_label(array $update): string
    {
        if (! empty($update['error'])) {
            return 'Prüfung fehlgeschlagen';
        }

        if (! empty($update['update_available'])) {
            return 'Update verfügbar';
        }

        if ((string) ($update['remote_version'] ?? '') === '') {
            return 'Noch keine Server-Version gelesen';
        }

        return 'Aktuell, kein Update verfügbar';
    }

    private function user_display_name($user): string
    {
        if (! $user || empty($user->ID)) {
            return 'System';
        }

        $name = trim((string) ($user->first_name ?? '') . ' ' . (string) ($user->last_name ?? ''));
        if ($name !== '') {
            return $name;
        }

        if (! empty($user->display_name)) {
            return (string) $user->display_name;
        }

        return (string) ($user->user_login ?? ('#' . (string) $user->ID));
    }

    private function message_actor_label(array $message, array $ticket): string
    {
        $raw = json_decode((string) ($message['raw_json'] ?? ''), true);
        $raw = is_array($raw) ? $raw : [];
        $direction = (string) ($message['direction'] ?? '');

        if ($direction === 'inbound') {
            return (string) ($raw['sender_name'] ?? $ticket['sender_name'] ?? $message['from_email'] ?? 'Absender');
        }

        if ($direction === 'outbound') {
            return (string) ($raw['actor_name'] ?? $message['from_email'] ?? 'Antwort aus dem Plugin');
        }

        return (string) ($message['from_email'] ?: $direction);
    }

    private function default_reply_template(array $ticket): string
    {
        return "Hallo {{name}},\n\n\n\nMit freundlichen Grüßen\n{{department}}\n{{site_name}}\n{{site_url}}";
    }

    private function department_shortcodes(array $department, array $topics): void
    {
        ?>
        <div class="feuer-shortcode-list">
            <h3>Shortcodes für <?php echo esc_html((string) $department['name']); ?></h3>
            <p class="description">Diese Shortcodes sind direkt auf diese Abteilung oder ein Thema vorkonfiguriert.</p>
            <div><code>[feuer-kontaktform department="<?php echo esc_attr((string) $department['slug']); ?>"]</code><span>Wizard direkt für diese Abteilung.</span></div>
            <div><code>[feuer-kontaktform-schnell department="<?php echo esc_attr((string) $department['slug']); ?>"]</code><span>Schnellformular für diese Abteilung.</span></div>
            <div><code><?php echo esc_html($this->frontend_link_example(['feuer_department' => (string) $department['slug']])); ?></code><span>Direkter Link in diese Abteilung.</span></div>
            <?php foreach ($topics as $topic) : ?>
                <div><code>[feuer-kontaktform department="<?php echo esc_attr((string) $department['slug']); ?>" topic="<?php echo esc_attr((string) $topic['slug']); ?>"]</code><span><?php echo esc_html((string) $topic['title']); ?></span></div>
                <div><code>[feuer-kontaktform-schnell department="<?php echo esc_attr((string) $department['slug']); ?>" topic="<?php echo esc_attr((string) $topic['slug']); ?>"]</code><span>Schnellformular: <?php echo esc_html((string) $topic['title']); ?></span></div>
                <div><code><?php echo esc_html($this->frontend_link_example(['feuer_department' => (string) $department['slug'], 'feuer_topic' => (string) $topic['slug']])); ?></code><span>Direkter Link in <?php echo esc_html((string) $topic['title']); ?>.</span></div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    private function frontend_link_example(array $args): string
    {
        return add_query_arg($args, home_url('/ihre-formularseite/'));
    }

    private function ticket_subject(array $ticket): string
    {
        return '[Anfrage Nr. ' . (string) $ticket['ticket_code'] . '] ' . (string) ($ticket['topic_title'] ?? 'Anfrage') . ' - ' . (string) ($ticket['subject'] ?: 'Ohne Betreff');
    }

    private function field_label(string $key): string
    {
        $labels = [
            'vorname' => 'Vorname',
            'nachname' => 'Nachname',
            'titel' => 'Titel / Betreff',
            'telefon' => 'Telefon',
            'email' => 'E-Mail',
            'nachricht' => 'Nachricht',
        ];

        return $labels[$key] ?? ucfirst(str_replace(['_', '-'], ' ', $key));
    }

    private function field_value($value): string
    {
        if (is_array($value)) {
            return implode(', ', array_map('strval', $value));
        }

        return (string) $value;
    }

    private function department_form(?array $department = null): void
    {
        $department = $department ?? ['id' => 0, 'name' => '', 'slug' => '', 'email' => '', 'description' => '', 'sort_order' => 0, 'is_active' => true];
        ?>
        <form method="post" class="feuer-inline-form">
            <?php wp_nonce_field('feuer_support_admin'); ?>
            <input type="hidden" name="feuer_support_action" value="save_department">
            <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
            <div class="feuer-form-grid">
                <label>Name<input class="regular-text" type="text" name="department_name" value="<?php echo esc_attr((string) $department['name']); ?>" data-slug-source></label>
                <label>Kurzname / Slug<input class="regular-text" type="text" name="department_slug" value="<?php echo esc_attr((string) $department['slug']); ?>" data-slug-target></label>
                <?php $this->input('department_email', 'E-Mail Empfänger', $department['email'], 'email'); ?>
                <?php $this->input('department_sort_order', 'Sortierung', $department['sort_order'], 'number'); ?>
            </div>
            <?php if ((string) $department['slug'] !== '') : ?>
                <p class="description">Direkt-Link zu dieser Abteilung: <code><?php echo esc_html($this->frontend_link_example(['feuer_department' => (string) $department['slug']])); ?></code></p>
            <?php endif; ?>
            <label>Beschreibung<textarea class="large-text" name="department_description" rows="2"><?php echo esc_textarea((string) $department['description']); ?></textarea></label>
            <label><input type="checkbox" name="department_is_active" value="1" <?php checked(! empty($department['is_active'])); ?>> aktiv</label>
            <p><button class="button button-primary">Abteilung speichern</button></p>
        </form>
        <?php if ((int) $department['id'] > 0) : ?>
            <form method="post">
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="delete_department">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <button class="button button-link-delete">Abteilung deaktivieren</button>
            </form>
        <?php endif; ?>
        <?php
    }

    private function topic_form(array $department, ?array $topic = null): void
    {
        $topic = $topic ?? [
            'id' => 0,
            'department_id' => (int) $department['id'],
            'title' => '',
            'slug' => '',
            'email_override' => '',
            'auto_reply_enabled' => true,
            'auto_reply_format' => 'html',
            'auto_subject' => Feuer_Kontaktform_Support_DB::default_auto_subject(),
            'auto_body' => Feuer_Kontaktform_Support_DB::default_auto_body(),
            'auto_html' => Feuer_Kontaktform_Support_DB::default_auto_html_body(),
            'sort_order' => 0,
            'is_active' => true,
            'fields' => Feuer_Kontaktform_Support_DB::default_fields(),
        ];
        ?>
        <div class="feuer-topic-box">
            <h3><?php echo (int) $topic['id'] > 0 ? esc_html((string) $topic['title']) : 'Neues Thema konfigurieren'; ?></h3>
            <form method="post" data-topic-form>
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="save_topic">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                <div class="feuer-form-grid">
                    <label>Thema<input class="regular-text" type="text" name="topic_title" value="<?php echo esc_attr((string) $topic['title']); ?>" data-slug-source></label>
                    <label>Kurzname / Slug<input class="regular-text" type="text" name="topic_slug" value="<?php echo esc_attr((string) $topic['slug']); ?>" data-slug-target></label>
                    <?php $this->input('topic_email_override', 'E-Mail falls abweichend', $topic['email_override'], 'email'); ?>
                    <?php $this->input('topic_sort_order', 'Sortierung', $topic['sort_order'], 'number'); ?>
                </div>
                <?php if ((string) $department['slug'] !== '' && (string) $topic['slug'] !== '') : ?>
                    <p class="description">Direkt-Link zu diesem Thema: <code><?php echo esc_html($this->frontend_link_example(['feuer_department' => (string) $department['slug'], 'feuer_topic' => (string) $topic['slug']])); ?></code></p>
                <?php endif; ?>
                <div class="feuer-topic-auto-controls">
                    <label class="feuer-check-label"><input type="checkbox" name="topic_auto_reply_enabled" value="1" <?php checked(! empty($topic['auto_reply_enabled'])); ?>> Autoantwort für dieses Thema senden</label>
                    <div class="feuer-radio-row">
                        <span>Antwortformat</span>
                        <label><input type="radio" name="topic_auto_reply_format" value="text" <?php checked((string) ($topic['auto_reply_format'] ?? 'html'), 'text'); ?>> Text</label>
                        <label><input type="radio" name="topic_auto_reply_format" value="html" <?php checked((string) ($topic['auto_reply_format'] ?? 'html'), 'html'); ?>> HTML</label>
                    </div>
                </div>
                <?php $this->input('topic_auto_subject', 'Autoantwort Betreff', $topic['auto_subject']); ?>
                <div class="feuer-auto-reply-grid">
                    <label>
                        Autoantwort Text
                        <span class="description">Plain-Text Fallback für einfache Mailprogramme.</span>
                        <textarea class="large-text code" name="topic_auto_body" rows="11"><?php echo esc_textarea((string) $topic['auto_body']); ?></textarea>
                    </label>
                    <label>
                        Autoantwort HTML
                        <span class="description">Formatierte E-Mail mit Logo, Website-Name und Anfrage Nr.</span>
                        <textarea class="large-text code" name="topic_auto_html" rows="16"><?php echo esc_textarea((string) ($topic['auto_html'] ?? Feuer_Kontaktform_Support_DB::default_auto_html_body())); ?></textarea>
                    </label>
                </div>
                <?php $this->auto_reply_macro_help(); ?>
                <label><input type="checkbox" name="topic_is_active" value="1" <?php checked(! empty($topic['is_active'])); ?>> aktiv</label>
                <h4>Felder für dieses Thema</h4>
                <div data-fields-list>
                    <?php foreach ((array) $topic['fields'] as $field) : ?>
                        <?php $this->field_row($field); ?>
                    <?php endforeach; ?>
                </div>
                <p><button type="button" class="button" data-add-field>Feld hinzufügen</button></p>
                <p><button class="button button-primary">Thema speichern</button></p>
            </form>
            <?php if ((int) $topic['id'] > 0) : ?>
                <form method="post">
                    <?php wp_nonce_field('feuer_support_admin'); ?>
                    <input type="hidden" name="feuer_support_action" value="delete_topic">
                    <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                    <button class="button button-link-delete">Thema deaktivieren</button>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    private function field_row(array $field): void
    {
        ?>
        <div class="feuer-field-row" data-field-row>
            <input name="topic_fields[key][]" value="<?php echo esc_attr((string) ($field['key'] ?? '')); ?>" placeholder="key">
            <input name="topic_fields[label][]" value="<?php echo esc_attr((string) ($field['label'] ?? '')); ?>" placeholder="Label">
            <select name="topic_fields[type][]">
                <?php foreach (['text', 'email', 'tel', 'textarea', 'select', 'file'] as $type) : ?>
                    <option value="<?php echo esc_attr($type); ?>" <?php selected((string) ($field['type'] ?? 'text'), $type); ?>><?php echo esc_html($type); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="topic_fields[width][]">
                <?php foreach (['full', 'half', 'third'] as $width) : ?>
                    <option value="<?php echo esc_attr($width); ?>" <?php selected((string) ($field['width'] ?? 'full'), $width); ?>><?php echo esc_html($width); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="topic_fields[required][]" value="<?php echo ! empty($field['required']) ? '1' : '0'; ?>" data-required-hidden>
            <label><input type="checkbox" value="1" data-required-checkbox <?php checked(! empty($field['required'])); ?>> Pflicht</label>
            <input name="topic_fields[options][]" value="<?php echo esc_attr(implode(', ', (array) ($field['options'] ?? []))); ?>" placeholder="Optionen bei select">
            <div class="feuer-field-actions">
                <button type="button" class="button" data-move-field="up">Hoch</button>
                <button type="button" class="button" data-move-field="down">Runter</button>
                <button type="button" class="button" data-remove-field>Entfernen</button>
            </div>
        </div>
        <?php
    }

    private function auto_reply_macro_help(): void
    {
        ?>
        <div class="feuer-macro-help">
            <h4>Shortcodes für Autoantworten</h4>
            <p class="description">Diese Platzhalter können im Betreff, im Text und in der HTML-Vorlage verwendet werden.</p>
            <div class="feuer-macro-grid">
                <?php foreach (Feuer_Kontaktform_Support_DB::auto_reply_macros() as $macro => $description) : ?>
                    <div><code><?php echo esc_html($macro); ?></code><span><?php echo esc_html($description); ?></span></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private function deliverability_report(array $settings): array
    {
        $from_email = sanitize_email((string) ($settings['from_email'] ?? ''));
        $from_domain = $this->email_domain($from_email);
        $site_domain = $this->site_domain();
        $dkim_selector = sanitize_key((string) ($settings['dkim_selector'] ?? ''));
        $warn_domain = ! empty($settings['enforce_from_domain']);

        $domain_match = $from_domain !== '' && ($from_domain === $site_domain || str_ends_with($from_domain, '.' . $site_domain));
        $spf = $this->dns_txt_contains($from_domain, 'v=spf1');
        $dmarc = $this->dns_txt_contains('_dmarc.' . $from_domain, 'v=DMARC1');
        $dkim = $dkim_selector !== '' ? $this->dns_txt_contains($dkim_selector . '._domainkey.' . $from_domain, 'DKIM') : null;
        $smtp_enabled = ! empty($settings['smtp_enabled']);
        $smtp_host = sanitize_text_field((string) ($settings['smtp_host'] ?? ''));

        return [
            'from_domain' => $from_domain !== '' ? $from_domain : 'Keine gültige From-Adresse',
            'site_domain' => $site_domain !== '' ? $site_domain : 'website-domain.tld',
            'domain_match_class' => $domain_match ? 'is-good' : ($warn_domain ? 'is-warning' : 'is-neutral'),
            'domain_match_text' => $domain_match ? 'From-Domain passt zur Website.' : 'From-Domain weicht von der Website ab.',
            'spf_class' => $this->dns_status_class($spf),
            'spf_text' => $this->dns_status_text($spf, 'SPF-Eintrag gefunden.', 'Kein SPF-Eintrag gefunden.'),
            'spf_hint' => 'TXT am Domain, z.B. v=spf1 include:mailserver.example -all',
            'dmarc_class' => $this->dns_status_class($dmarc),
            'dmarc_text' => $this->dns_status_text($dmarc, 'DMARC-Eintrag gefunden.', 'Kein DMARC-Eintrag gefunden.'),
            'dmarc_hint' => 'TXT unter _dmarc.' . ($from_domain !== '' ? $from_domain : 'domain.tld'),
            'dkim_class' => $dkim_selector === '' ? 'is-neutral' : $this->dns_status_class($dkim),
            'dkim_text' => $dkim_selector === '' ? 'Kein Selector eingetragen.' : $this->dns_status_text($dkim, 'DKIM-Eintrag gefunden.', 'DKIM-Eintrag nicht gefunden.'),
            'dkim_hint' => 'Selector vom SMTP-Anbieter, z.B. default oder mail.',
            'smtp_class' => $smtp_enabled && $smtp_host !== '' ? 'is-good' : 'is-neutral',
            'smtp_text' => $smtp_enabled && $smtp_host !== '' ? 'SMTP im Plugin aktiviert.' : 'SMTP im Plugin nicht aktiviert.',
            'smtp_hint' => $smtp_enabled && $smtp_host !== '' ? $smtp_host : 'Alternativ kann ein separates SMTP-Plugin genutzt werden.',
        ];
    }

    private function email_domain(string $email): string
    {
        $position = strrpos($email, '@');
        if ($position === false) {
            return '';
        }

        return $this->normalize_domain(substr($email, $position + 1));
    }

    private function site_domain(): string
    {
        $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
        return $this->normalize_domain($host);
    }

    private function normalize_domain(string $domain): string
    {
        $domain = strtolower(trim($domain));
        $domain = preg_replace('/^www\./', '', $domain) ?: '';
        return preg_replace('/[^a-z0-9.-]/', '', $domain) ?: '';
    }

    private function dns_txt_contains(string $domain, string $needle): ?bool
    {
        if ($domain === '' || ! function_exists('dns_get_record') || ! defined('DNS_TXT')) {
            return null;
        }

        $records = @dns_get_record($domain, DNS_TXT);
        if (! is_array($records)) {
            return null;
        }

        foreach ($records as $record) {
            $value = '';
            if (isset($record['txt'])) {
                $value = (string) $record['txt'];
            } elseif (isset($record['entries']) && is_array($record['entries'])) {
                $value = implode('', array_map('strval', $record['entries']));
            }

            if ($value !== '' && stripos($value, $needle) !== false) {
                return true;
            }
        }

        return false;
    }

    private function dns_status_class(?bool $status): string
    {
        if ($status === true) {
            return 'is-good';
        }

        if ($status === false) {
            return 'is-warning';
        }

        return 'is-neutral';
    }

    private function dns_status_text(?bool $status, string $good, string $bad): string
    {
        if ($status === true) {
            return $good;
        }

        if ($status === false) {
            return $bad;
        }

        return 'DNS-Prüfung auf diesem Server nicht verfügbar.';
    }

    private function collect_fields(): array
    {
        $input = isset($_POST['topic_fields']) && is_array($_POST['topic_fields']) ? wp_unslash($_POST['topic_fields']) : [];
        $labels = is_array($input['label'] ?? null) ? $input['label'] : [];
        $fields = [];

        foreach ($labels as $index => $label) {
            $fields[] = [
                'key' => (string) (($input['key'][$index] ?? '') ?: $label),
                'label' => (string) $label,
                'type' => (string) ($input['type'][$index] ?? 'text'),
                'width' => (string) ($input['width'][$index] ?? 'full'),
                'required' => ! empty($input['required'][$index]),
                'options' => (string) ($input['options'][$index] ?? ''),
                'sort_order' => $index,
            ];
        }

        return $fields;
    }

    private function sanitize_settings(array $source): array
    {
        $defaults = $this->db->get_settings();
        $notification_reply_to = (string) wp_unslash($source['notification_reply_to'] ?? $defaults['notification_reply_to']);
        if (! in_array($notification_reply_to, ['sender', 'department', 'none'], true)) {
            $notification_reply_to = 'sender';
        }

        $auto_reply_reply_to = (string) wp_unslash($source['auto_reply_reply_to'] ?? $defaults['auto_reply_reply_to']);
        if (! in_array($auto_reply_reply_to, ['department', 'base', 'none'], true)) {
            $auto_reply_reply_to = 'department';
        }

        $smtp_encryption = (string) wp_unslash($source['smtp_encryption'] ?? $defaults['smtp_encryption']);
        if (! in_array($smtp_encryption, ['tls', 'ssl', 'none'], true)) {
            $smtp_encryption = 'tls';
        }

        $smtp_password = array_key_exists('smtp_password', $source)
            ? (string) wp_unslash($source['smtp_password'])
            : (string) $defaults['smtp_password'];
        if ($smtp_password === '') {
            $smtp_password = (string) $defaults['smtp_password'];
        }

        $design_variant = sanitize_key((string) wp_unslash($source['design_variant'] ?? $defaults['design_variant']));
        if (! in_array($design_variant, ['classic', 'clean', 'stepper', 'rail', 'stripe'], true)) {
            $design_variant = 'classic';
        }

        $field_variant = sanitize_key((string) wp_unslash($source['field_variant'] ?? $defaults['field_variant']));
        if (! in_array($field_variant, ['soft', 'line', 'filled', 'compact'], true)) {
            $field_variant = 'soft';
        }

        return [
            'site_name' => sanitize_text_field((string) wp_unslash($source['site_name'] ?? $defaults['site_name'])),
            'logo_url' => esc_url_raw((string) wp_unslash($source['logo_url'] ?? $defaults['logo_url'])),
            'base_email' => sanitize_email((string) wp_unslash($source['base_email'] ?? $defaults['base_email'])),
            'from_email' => sanitize_email((string) wp_unslash($source['from_email'] ?? $defaults['from_email'])),
            'from_name' => sanitize_text_field((string) wp_unslash($source['from_name'] ?? $defaults['from_name'])),
            'smtp_enabled' => array_key_exists('smtp_enabled', $source) ? (! empty($source['smtp_enabled']) ? 1 : 0) : (int) $defaults['smtp_enabled'],
            'smtp_host' => sanitize_text_field((string) wp_unslash($source['smtp_host'] ?? $defaults['smtp_host'])),
            'smtp_port' => max(1, absint($source['smtp_port'] ?? $defaults['smtp_port'])),
            'smtp_encryption' => $smtp_encryption,
            'smtp_username' => sanitize_text_field((string) wp_unslash($source['smtp_username'] ?? $defaults['smtp_username'])),
            'smtp_password' => $smtp_password,
            'notification_reply_to' => $notification_reply_to,
            'auto_reply_reply_to' => $auto_reply_reply_to,
            'enforce_from_domain' => array_key_exists('enforce_from_domain', $source) ? (! empty($source['enforce_from_domain']) ? 1 : 0) : (int) $defaults['enforce_from_domain'],
            'auto_response_headers' => array_key_exists('auto_response_headers', $source) ? (! empty($source['auto_response_headers']) ? 1 : 0) : (int) $defaults['auto_response_headers'],
            'dkim_selector' => sanitize_key((string) wp_unslash($source['dkim_selector'] ?? $defaults['dkim_selector'])),
            'privacy_enabled' => array_key_exists('privacy_enabled', $source) ? (! empty($source['privacy_enabled']) ? 1 : 0) : (int) $defaults['privacy_enabled'],
            'privacy_url' => esc_url_raw((string) wp_unslash($source['privacy_url'] ?? $defaults['privacy_url'])),
            'privacy_text' => sanitize_textarea_field((string) wp_unslash($source['privacy_text'] ?? $defaults['privacy_text'])),
            'privacy_version' => sanitize_text_field((string) wp_unslash($source['privacy_version'] ?? $defaults['privacy_version'])),
            'ticket_success_text' => sanitize_textarea_field((string) wp_unslash($source['ticket_success_text'] ?? $defaults['ticket_success_text'])),
            'rate_limit_minutes' => max(1, absint($source['rate_limit_minutes'] ?? $defaults['rate_limit_minutes'])),
            'design_variant' => $design_variant,
            'field_variant' => $field_variant,
            'allowed_file_types' => $this->sanitize_file_types((string) wp_unslash($source['allowed_file_types'] ?? $defaults['allowed_file_types'])),
            'max_upload_mb' => max(1, min(64, absint($source['max_upload_mb'] ?? $defaults['max_upload_mb']))),
        ];
    }

    private function sanitize_file_types(string $types): string
    {
        $allowed = [];
        foreach (preg_split('/[\s,;]+/', strtolower($types)) ?: [] as $type) {
            $type = preg_replace('/[^a-z0-9]/', '', $type) ?: '';
            if ($type !== '') {
                $allowed[] = $type;
            }
        }

        return implode(',', array_values(array_unique($allowed))) ?: 'pdf,jpg,jpeg,png,doc,docx';
    }

    private function input(string $name, string $label, $value, string $type = 'text'): void
    {
        ?>
        <label><?php echo esc_html($label); ?><input class="regular-text" type="<?php echo esc_attr($type); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) $value); ?>"></label>
        <?php
    }

    private function send_backup_download(array $payload): void
    {
        $json = wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (! is_string($json) || $json === '') {
            $this->redirect(
                'feuer-kontaktform-settings',
                'backup_download_failed',
                ['feuer-detail' => 'Die Sicherungsdatei konnte nicht erstellt werden.']
            );
        }

        $filename = sanitize_file_name('kontaktform-backup-' . gmdate('Y-m-d-His') . '.json');
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . (string) strlen($json));
        header('X-Content-Type-Options: nosniff');
        echo $json;
        exit;
    }

    private function read_uploaded_backup(): array
    {
        $file = $_FILES['backup_file'] ?? null;
        if (! is_array($file)) {
            return [
                'success' => false,
                'message' => 'Es wurde keine Sicherungsdatei hochgeladen.',
            ];
        }

        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            return [
                'success' => false,
                'message' => $this->upload_error_message($error),
            ];
        }

        $tmp_name = (string) ($file['tmp_name'] ?? '');
        if ($tmp_name === '' || (! is_uploaded_file($tmp_name) && ! file_exists($tmp_name))) {
            return [
                'success' => false,
                'message' => 'Die hochgeladene Sicherungsdatei konnte nicht gelesen werden.',
            ];
        }

        $raw = file_get_contents($tmp_name);
        if (! is_string($raw) || trim($raw) === '') {
            return [
                'success' => false,
                'message' => 'Die Sicherungsdatei ist leer.',
            ];
        }

        $payload = json_decode($raw, true);
        if (! is_array($payload)) {
            return [
                'success' => false,
                'message' => 'Die Sicherungsdatei ist kein gültiges JSON.',
            ];
        }

        return [
            'success' => true,
            'payload' => $payload,
        ];
    }

    private function upload_error_message(int $error): string
    {
        return match ($error) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Die Sicherungsdatei ist größer als das erlaubte Upload-Limit des Servers.',
            UPLOAD_ERR_PARTIAL => 'Die Sicherungsdatei wurde nur teilweise hochgeladen.',
            UPLOAD_ERR_NO_FILE => 'Es wurde keine Sicherungsdatei ausgewählt.',
            UPLOAD_ERR_NO_TMP_DIR => 'Dem Server fehlt ein temporärer Upload-Ordner.',
            UPLOAD_ERR_CANT_WRITE => 'Die Sicherungsdatei konnte nicht auf den Server geschrieben werden.',
            UPLOAD_ERR_EXTENSION => 'Der Upload der Sicherungsdatei wurde vom Server blockiert.',
            default => 'Beim Hochladen der Sicherungsdatei ist ein unbekannter Fehler aufgetreten.',
        };
    }

    private function redirect(string $page, string $message, array $args = []): void
    {
        wp_safe_redirect(add_query_arg($args + ['page' => $page, 'feuer-message' => $message], admin_url('admin.php')));
        exit;
    }

    private function notice(): void
    {
        $message = sanitize_key((string) ($_GET['feuer-message'] ?? ''));
        $detail = sanitize_text_field((string) wp_unslash($_GET['feuer-detail'] ?? ''));
        if ($message === '') {
            return;
        }

        $labels = [
            'settings_saved' => 'Einstellungen gespeichert.',
            'test_mail_sent' => 'Testmail wurde gesendet.',
            'test_mail_failed' => 'Testmail konnte nicht gesendet werden.',
            'update_checked' => 'Update-Prüfung wurde ausgeführt.',
            'update_current' => 'Update-Prüfung wurde ausgeführt. Die installierte Version ist aktuell.',
            'update_available' => 'Update-Prüfung wurde ausgeführt. Eine neue Version ist verfügbar.',
            'update_failed' => 'Update-Prüfung fehlgeschlagen.',
            'update_installed' => 'Update wurde installiert.',
            'update_install_failed' => 'Update konnte nicht installiert werden.',
            'update_no_update' => 'Es ist keine neuere Version verfügbar.',
            'backup_restored' => 'Sicherung wurde wiederhergestellt.',
            'backup_restore_failed' => 'Sicherung konnte nicht wiederhergestellt werden.',
            'backup_download_failed' => 'Sicherung konnte nicht erstellt werden.',
            'department_saved' => 'Abteilung gespeichert.',
            'department_failed' => 'Abteilung konnte nicht gespeichert werden.',
            'department_deleted' => 'Abteilung wurde deaktiviert.',
            'department_moved' => 'Abteilung wurde verschoben.',
            'department_move_failed' => 'Abteilung konnte nicht verschoben werden.',
            'topic_saved' => 'Thema gespeichert.',
            'topic_failed' => 'Thema konnte nicht gespeichert werden.',
            'topic_deleted' => 'Thema wurde deaktiviert.',
            'ticket_reply_sent' => 'Antwort wurde gesendet.',
            'ticket_reply_failed' => 'Antwort konnte nicht gesendet werden.',
        ];

        if (! isset($labels[$message])) {
            return;
        }

        $type = str_contains($message, 'failed') ? 'error' : 'success';
        $text = $labels[$message];
        if ($detail !== '') {
            $text .= ' ' . $detail;
        }

        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
    }
}
