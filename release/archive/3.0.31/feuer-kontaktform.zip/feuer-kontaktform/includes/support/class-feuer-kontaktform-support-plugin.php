<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Plugin
{
    private Feuer_Kontaktform_Updater $updater;
    private Feuer_Kontaktform_Support_Admin $admin;
    private Feuer_Kontaktform_Support_Frontend $frontend;

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer
    ) {
        $this->updater = new Feuer_Kontaktform_Updater();
        $this->admin = new Feuer_Kontaktform_Support_Admin($this->db, $this->mailer, $this->updater);
        $this->frontend = new Feuer_Kontaktform_Support_Frontend($this->db, $this->mailer);

        $this->register();
    }

    public static function activate(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->create_tables();
        flush_rewrite_rules();
    }

    public static function uninstall(): void
    {
        $db = new Feuer_Kontaktform_Support_DB();
        $db->uninstall();
    }

    private function register(): void
    {
        add_action('plugins_loaded', [$this, 'maybe_upgrade']);
        add_action('phpmailer_init', [$this->mailer, 'configure_phpmailer']);
        add_action('admin_post_feuer_confirm_delivery', [$this, 'confirm_delivery']);
        add_action('admin_post_nopriv_feuer_confirm_delivery', [$this, 'confirm_delivery']);
        add_filter('wp_privacy_personal_data_exporters', [$this, 'register_privacy_exporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'register_privacy_eraser']);
        $this->updater->register();
        $this->admin->register();
        $this->frontend->register();
    }

    public function confirm_delivery(): void
    {
        $ticket_id = absint($_REQUEST['ticket'] ?? 0);
        $token = sanitize_text_field((string) wp_unslash($_REQUEST['token'] ?? ''));
        $ticket = $ticket_id > 0 ? $this->db->get_ticket($ticket_id) : null;

        if (! $ticket || ! $this->mailer->verify_delivery_confirmation($ticket, $token)) {
            wp_die(
                'Der Bestätigungslink ist ungültig oder nicht mehr aktuell.',
                'Empfang konnte nicht bestätigt werden',
                ['response' => 403]
            );
        }

        $request_method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if ($request_method !== 'POST') {
            $form = '<p>Bitte bestätigen Sie, dass die Anfrage Nr. <strong>'
                . esc_html((string) $ticket['ticket_code'])
                . '</strong> die zuständige Abteilung erreicht hat.</p>'
                . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'
                . '<input type="hidden" name="action" value="feuer_confirm_delivery">'
                . '<input type="hidden" name="ticket" value="' . esc_attr((string) $ticket_id) . '">'
                . '<input type="hidden" name="token" value="' . esc_attr($token) . '">'
                . '<p><button type="submit" class="button button-primary">Empfang jetzt bestätigen</button></p>'
                . '</form>';

            wp_die($form, 'Empfang der Anfrage bestätigen', ['response' => 200]);
        }

        if (! $this->db->confirm_delivery($ticket_id)) {
            wp_die(
                'Die Empfangsbestätigung konnte nicht gespeichert werden. Bitte informieren Sie den Website-Administrator.',
                'Technischer Fehler',
                ['response' => 500]
            );
        }

        wp_die(
            '<p>Der Empfang der Anfrage Nr. <strong>' . esc_html((string) $ticket['ticket_code']) . '</strong> wurde bestätigt.</p><p>Sie können dieses Fenster jetzt schließen.</p>',
            'Empfang bestätigt',
            ['response' => 200]
        );
    }

    public function maybe_upgrade(): void
    {
        $installed = (string) get_option(Feuer_Kontaktform_Support_DB::OPTION_VERSION, '');
        if ($installed !== FEUER_KONTAKTFORM_VERSION) {
            $this->db->create_tables();
            $this->updater->clear_cache();
            delete_site_transient('update_plugins');
        }
    }

    public function register_privacy_exporter(array $exporters): array
    {
        $exporters['feuer-kontaktform'] = [
            'exporter_friendly_name' => 'Kontaktform Anfragen',
            'callback' => [$this, 'export_personal_data'],
        ];

        return $exporters;
    }

    public function register_privacy_eraser(array $erasers): array
    {
        $erasers['feuer-kontaktform'] = [
            'eraser_friendly_name' => 'Kontaktform Anfragen',
            'callback' => [$this, 'erase_personal_data'],
        ];

        return $erasers;
    }

    public function export_personal_data(string $email_address, int $page = 1): array
    {
        $items = [];
        if ($page > 1) {
            return ['data' => [], 'done' => true];
        }

        foreach ($this->db->get_tickets_by_email($email_address, 500) as $ticket) {
            $data = [
                ['name' => 'Anfrage Nr.', 'value' => (string) $ticket['ticket_code']],
                ['name' => 'Abteilung', 'value' => (string) ($ticket['department_name'] ?? '')],
                ['name' => 'Thema', 'value' => (string) ($ticket['topic_title'] ?? '')],
                ['name' => 'Betreff', 'value' => (string) $ticket['subject']],
                ['name' => 'Name', 'value' => (string) $ticket['sender_name']],
                ['name' => 'E-Mail', 'value' => (string) $ticket['sender_email']],
                ['name' => 'Telefon', 'value' => (string) $ticket['sender_phone']],
                ['name' => 'Nachricht', 'value' => (string) $ticket['message']],
                ['name' => 'Datenschutz-Schritt aktiv', 'value' => ! empty($ticket['privacy_required']) ? 'ja' : 'nein'],
                ['name' => 'Datenschutz bestätigt', 'value' => empty($ticket['privacy_required']) ? 'nicht abgefragt' : (! empty($ticket['privacy_accepted']) ? 'ja' : 'nein')],
                ['name' => 'Datenschutz-Version', 'value' => (string) $ticket['privacy_version']],
                ['name' => 'IP-Adresse', 'value' => (string) $ticket['ip_address']],
                ['name' => 'Cookie-ID', 'value' => (string) $ticket['visitor_cookie']],
                ['name' => 'Gerät', 'value' => (string) $ticket['device_type']],
                ['name' => 'Browser', 'value' => (string) $ticket['browser']],
                ['name' => 'Erstellt am', 'value' => (string) $ticket['created_at']],
            ];

            foreach ((array) ($ticket['fields'] ?? []) as $key => $value) {
                $data[] = [
                    'name' => 'Feld: ' . (string) $key,
                    'value' => is_array($value) ? implode(', ', array_map('strval', $value)) : (string) $value,
                ];
            }

            $items[] = [
                'group_id' => 'feuer-kontaktform',
                'group_label' => 'Kontaktform',
                'item_id' => 'feuer-ticket-' . (string) $ticket['id'],
                'data' => $data,
            ];
        }

        return ['data' => $items, 'done' => true];
    }

    public function erase_personal_data(string $email_address, int $page = 1): array
    {
        if ($page > 1) {
            return ['items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true];
        }

        $count = $this->db->erase_personal_data($email_address);
        return [
            'items_removed' => $count > 0,
            'items_retained' => false,
            'messages' => $count > 0 ? ['Kontaktform Anfragen wurden anonymisiert.'] : [],
            'done' => true,
        ];
    }
}
