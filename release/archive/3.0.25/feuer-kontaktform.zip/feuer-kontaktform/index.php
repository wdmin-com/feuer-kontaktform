<?php
declare(strict_types=1);

$root = __DIR__;
$excluded = ['.git', 'release', 'feuer-kontaktform.zip'];
$stats = [
    'files' => 0,
    'lines' => 0,
    'chars' => 0,
];

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);

foreach ($iterator as $item) {
    $path = (string) $item->getPathname();
    $relative = ltrim(str_replace('\\', '/', substr($path, strlen($root))), '/');
    foreach ($excluded as $part) {
        if ($relative === $part || str_starts_with($relative, $part . '/')) {
            continue 2;
        }
    }

    if (! $item->isFile()) {
        continue;
    }

    $stats['files']++;
    $contents = @file_get_contents($path);
    if (is_string($contents)) {
        $stats['lines'] += substr_count($contents, "\n") + 1;
        $stats['chars'] += strlen($contents);
    }
}

$version = '3.0.25';
?><!doctype html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Feuer-Kontaktform Plugin</title>
    <style>
        body{margin:0;font-family:Arial,sans-serif;color:#1f2937;background:#f6f7f7;line-height:1.55}
        main{max-width:980px;margin:0 auto;padding:40px 20px}
        section{background:#fff;border:1px solid #d9dee7;border-radius:8px;margin:0 0 18px;padding:24px}
        h1,h2{margin:0 0 12px;color:#111827}
        h1{font-size:34px}
        h2{font-size:22px}
        .lead{font-size:18px}
        .grid{display:grid;gap:12px;grid-template-columns:repeat(3,minmax(0,1fr))}
        .metric{background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:16px}
        .metric strong{display:block;font-size:24px}
        ul{padding-left:20px}
        code{background:#f3f4f6;border-radius:4px;padding:2px 5px}
        a{color:#b42318}
        @media(max-width:720px){.grid{grid-template-columns:1fr}h1{font-size:28px}}
    </style>
</head>
<body>
<main>
    <section>
        <h1>Feuer-Kontaktform</h1>
        <p class="lead">Ein Kontaktformular- und Anfrage-System für Websites freiwilliger Feuerwehren.</p>
        <p>Autor: Walter Färber. Projektseite: <a href="https://wdmin.com/plugins/feuer-kontaktform/">wdmin.com/plugins/feuer-kontaktform/</a></p>
    </section>

    <section>
        <h2>Was das Plugin macht</h2>
        <ul>
            <li>Erstellt Kontaktformulare für Abteilungen wie Wehrführer, Jugendfeuerwehr oder Veranstaltungen.</li>
            <li>Führt Besucher Schritt für Schritt durch Datenschutz, Abteilung, Thema, Kontaktdaten und Nachricht.</li>
            <li>Führt Besucher per AJAX durch Datenschutz, Abteilung, Thema, individuelle Felder und Captcha.</li>
            <li>Speichert jede Anfrage mit 8-stelliger Anfrage Nr.</li>
            <li>Zeigt Anfragen als aufklappbare Karten und erlaubt Antworten direkt aus dem Plugin.</li>
            <li>Bietet mehrere Frontend-Designs, Feldstile und konfigurierbare Dateiuploads.</li>
            <li>Bindet gespeicherte Anfragen in WordPress Privacy Export/Erase ein.</li>
            <li>Versendet Benachrichtigungen und themenspezifische Autoantworten per WordPress-Mail.</li>
            <li>Unterstützt direkten SMTP-Versand, Reply-To-Regeln und Zustellbarkeits-Hinweise für SPF, DKIM und DMARC.</li>
            <li>Protokolliert IP-Adresse, Cookie-ID, Browser, Gerätetyp, Datenschutz-Zustimmung und Admin-Aktionen.</li>
            <li>Bietet direkte Shortcodes für Abteilung oder Thema sowie self-hosted Updates.</li>
        </ul>
    </section>

    <section>
        <h2>Codeumfang dieser Version</h2>
        <div class="grid">
            <div class="metric"><strong><?php echo htmlspecialchars((string) $stats['files'], ENT_QUOTES, 'UTF-8'); ?></strong>Dateien</div>
            <div class="metric"><strong><?php echo htmlspecialchars((string) $stats['lines'], ENT_QUOTES, 'UTF-8'); ?></strong>Zeilen Code/Text</div>
            <div class="metric"><strong><?php echo htmlspecialchars(number_format((int) $stats['chars'], 0, ',', '.'), ENT_QUOTES, 'UTF-8'); ?></strong>Zeichen</div>
        </div>
    </section>

    <section>
        <h2>Einbindung</h2>
        <p>Kompletter Wizard: <code>[feuer-kontaktform]</code></p>
        <p>Direkt zu einer Abteilung: <code>[feuer-kontaktform department="wehrfuehrung"]</code></p>
        <p>Direkt zu einem Thema: <code>[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]</code></p>
        <p>Schnellformular: <code>[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]</code></p>
    </section>

    <section>
        <h2>Version und Updates</h2>
        <p>Aktuelle Version: <strong><?php echo htmlspecialchars($version, ENT_QUOTES, 'UTF-8'); ?></strong></p>
        <p>Status: <strong>aktuelle stabile Version</strong>. Version 3.0.15 war die erste finale stabile Version. Version 3.0.25 ergänzt einen zuverlässigeren Self-Update-Prozess mit Versionsprüfung nach der Installation, die verkürzte Admin-Anzeige `Kontaktform` im Menü, den wiederhergestellten Plugin-Namen `Feuer-Kontaktform` in der Pluginliste, klareres Reply-To-Verhalten für direkte E-Mail-Antworten, vereinheitlichte Autoantworten mit Anfrage Nr. für neue und bestehende Themen, sichtbare Beispiel-Links direkt in Abteilungen und Themen sowie direkte URL-Sprünge in Abteilungen und Themen und Live-Slug-Autofill in der Admin-Oberfläche.</p>
        <p>Update-Metadaten: <code>https://wdmin.com/plugins/feuer-kontaktform/update.json</code></p>
        <p>Letztes Release-ZIP: <code>https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip</code></p>
    </section>
</main>
</body>
</html>
