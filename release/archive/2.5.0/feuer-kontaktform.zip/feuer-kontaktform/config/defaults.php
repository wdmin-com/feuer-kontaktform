<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

function feuer_kontaktform_default_settings(): array
{
    $home_url     = home_url('/');
    $privacy_url  = function_exists('get_privacy_policy_url') ? (string) get_privacy_policy_url() : '';
    $website_host = (string) wp_parse_url($home_url, PHP_URL_HOST);
    $website_host = $website_host !== '' ? preg_replace('/^www\./', '', $website_host) : $home_url;

    return [
        'sender_name' => get_bloginfo('name') ?: 'Feuer-Kontaktform',
        'sender_email' => get_option('admin_email'),
        'default_success_message' => 'Vielen Dank. Ihre Anfrage wurde erfolgreich versendet.',
        'default_auto_reply_subject' => 'Ihre Anfrage ist bei uns eingegangen',
        'default_auto_reply_message' => "Guten Tag {{name}},\n\nvielen Dank fuer Ihre Nachricht. Wir haben Ihre Anfrage unter der Ticket-ID {{ticket_id}} erhalten und melden uns schnellstmoeglich zurueck.\n\nFreundliche Gruesse\n\n{{logo}}\n{{website}}",
        'brand_logo_url' => '',
        'brand_logo_width' => 180,
        'brand_label' => get_bloginfo('name') ?: 'Feuer-Kontaktform',
        'brand_tagline' => 'Bitte schildern Sie Ihr Anliegen so konkret wie moeglich. Wir melden uns zeitnah zurueck.',
        'brand_website_url' => $home_url,
        'brand_website_text' => $website_host !== '' ? $website_host : $home_url,
        'forms_page_url' => '',
        'privacy_policy_url' => $privacy_url,
        'privacy_notice_text' => 'Ich habe den Datenschutzhinweis gelesen und akzeptiere die Datenschutzerklaerung.',
        'privacy_notice_version' => '1',
        'allowed_referrer_hosts' => '',
        'log_retention_days' => 0,
        'webhook_url' => '',
        'webhook_timeout' => 10,
        'admin_notification_email' => get_option('admin_email'),
        'rewrite_enabled' => true,
        'popup_button_label' => 'Kontakt aufnehmen',
        'smtp_enabled' => false,
        'smtp_host' => '',
        'smtp_port' => 587,
        'smtp_encryption' => 'tls',
        'smtp_auth' => true,
        'smtp_username' => '',
        'smtp_password' => '',
        'smtp_timeout' => 15,
    ];
}

function feuer_kontaktform_brand_context(array $settings): array
{
    $defaults     = feuer_kontaktform_default_settings();
    $website_url  = esc_url_raw((string) ($settings['brand_website_url'] ?? $defaults['brand_website_url']));
    $website_url  = $website_url !== '' ? $website_url : (string) $defaults['brand_website_url'];
    $website_text = sanitize_text_field((string) ($settings['brand_website_text'] ?? $defaults['brand_website_text']));
    $website_host = (string) wp_parse_url($website_url, PHP_URL_HOST);

    if ($website_text === '') {
        $website_text = $website_host !== '' ? preg_replace('/^www\./', '', $website_host) : $website_url;
    }

    return [
        'logo_url' => feuer_kontaktform_normalize_local_asset_url((string) ($settings['brand_logo_url'] ?? $defaults['brand_logo_url'])),
        'logo_width' => max(60, min(320, (int) ($settings['brand_logo_width'] ?? $defaults['brand_logo_width']))),
        'label' => sanitize_text_field((string) ($settings['brand_label'] ?? $defaults['brand_label'])),
        'tagline' => sanitize_textarea_field((string) ($settings['brand_tagline'] ?? $defaults['brand_tagline'])),
        'website_url' => $website_url,
        'website_text' => $website_text,
        'contact_email' => sanitize_email((string) ($settings['sender_email'] ?? $defaults['sender_email'])),
    ];
}

function feuer_kontaktform_normalize_local_asset_url(string $url): string
{
    $url = esc_url_raw(trim($url));
    if ($url === '') {
        return '';
    }

    $asset_host = (string) wp_parse_url($url, PHP_URL_HOST);
    if ($asset_host === '') {
        return str_starts_with($url, '/') ? $url : '';
    }

    $site_host  = (string) wp_parse_url(home_url('/'), PHP_URL_HOST);
    $asset_host = strtolower((string) preg_replace('/^www\./', '', $asset_host));
    $site_host  = strtolower((string) preg_replace('/^www\./', '', $site_host));

    if ($asset_host !== $site_host) {
        return '';
    }

    return $url;
}

function feuer_kontaktform_default_design_settings(): array
{
    return [
        'shell_background_color' => '',
        'panel_background_color' => '',
        'panel_text_color' => '',
        'title_color' => '',
        'aside_background_color' => '',
        'aside_text_color' => '',
        'accent_color' => '',
        'button_background_color' => '',
        'button_text_color' => '',
        'input_background_color' => '',
        'input_text_color' => '',
        'input_border_color' => '',
        'overlay_color' => '',
        'overlay_opacity' => 72,
        'background_image_url' => '',
        'background_image_target' => 'aside',
    ];
}

function feuer_kontaktform_default_display_settings(): array
{
    return [
        'intro_copy' => '',
        'aside_copy' => '',
        'department_label' => 'Abteilung',
        'website_label' => 'Website',
        'website_url' => '',
        'website_text' => '',
    ];
}

function feuer_kontaktform_default_behavior_settings(): array
{
    return [
        'template_key' => '',
        'submit_mode' => 'ajax',
        'draft_enabled' => true,
        'multi_step_enabled' => true,
        'progress_enabled' => true,
        'popup_enabled' => false,
        'popup_trigger_label' => 'Kontakt aufnehmen',
        'topics' => [],
        'routing_rules' => [],
    ];
}

function feuer_kontaktform_normalize_display_settings($input): array
{
    $defaults = feuer_kontaktform_default_display_settings();
    $settings = is_array($input) ? $input : [];
    $truncate = static function (string $value, int $length): string {
        return strlen($value) > $length ? substr($value, 0, $length) : $value;
    };

    $result = $defaults;
    $result['intro_copy'] = $truncate(sanitize_textarea_field((string) ($settings['intro_copy'] ?? '')), 1000);
    $result['aside_copy'] = $truncate(sanitize_textarea_field((string) ($settings['aside_copy'] ?? '')), 1000);
    $result['department_label'] = $truncate(sanitize_text_field((string) ($settings['department_label'] ?? $defaults['department_label'])), 80);
    $result['website_label'] = $truncate(sanitize_text_field((string) ($settings['website_label'] ?? $defaults['website_label'])), 80);
    $result['website_url'] = esc_url_raw((string) ($settings['website_url'] ?? ''));
    $result['website_text'] = $truncate(sanitize_text_field((string) ($settings['website_text'] ?? '')), 190);

    if ($result['department_label'] === '') {
        $result['department_label'] = (string) $defaults['department_label'];
    }

    if ($result['website_label'] === '') {
        $result['website_label'] = (string) $defaults['website_label'];
    }

    return $result;
}

function feuer_kontaktform_normalize_behavior_settings($input): array
{
    $defaults = feuer_kontaktform_default_behavior_settings();
    $settings = is_array($input) ? $input : [];
    $result = $defaults;

    $result['template_key'] = sanitize_key((string) ($settings['template_key'] ?? ''));
    $submit_mode = sanitize_key((string) ($settings['submit_mode'] ?? $defaults['submit_mode']));
    $result['submit_mode'] = in_array($submit_mode, ['post', 'ajax'], true) ? $submit_mode : $defaults['submit_mode'];
    $result['draft_enabled'] = ! empty($settings['draft_enabled']);
    $result['multi_step_enabled'] = ! empty($settings['multi_step_enabled']);
    $result['progress_enabled'] = ! empty($settings['progress_enabled']);
    $result['popup_enabled'] = ! empty($settings['popup_enabled']);

    $popup_trigger_label = sanitize_text_field((string) ($settings['popup_trigger_label'] ?? $defaults['popup_trigger_label']));
    $result['popup_trigger_label'] = $popup_trigger_label !== '' ? $popup_trigger_label : $defaults['popup_trigger_label'];

    $topics = is_array($settings['topics'] ?? null) ? $settings['topics'] : [];
    $normalized_topics = [];
    $used_topic_slugs = [];
    foreach ($topics as $topic) {
        if (! is_array($topic)) {
            continue;
        }

        $label = sanitize_text_field((string) ($topic['label'] ?? ''));
        $slug = sanitize_title((string) ($topic['slug'] ?? $label));
        $recipient_email = sanitize_textarea_field((string) ($topic['recipient_email'] ?? ''));
        $auto_reply_subject = sanitize_text_field((string) ($topic['auto_reply_subject'] ?? ''));
        $auto_reply_message = wp_kses_post((string) ($topic['auto_reply_message'] ?? ''));

        if ($label === '') {
            continue;
        }

        if ($slug === '') {
            $slug = sanitize_title($label);
        }

        if ($slug === '' || in_array($slug, $used_topic_slugs, true)) {
            continue;
        }

        $used_topic_slugs[] = $slug;
        $normalized_topics[] = [
            'slug' => $slug,
            'label' => $label,
            'recipient_email' => $recipient_email,
            'auto_reply_subject' => $auto_reply_subject,
            'auto_reply_message' => $auto_reply_message,
        ];
    }

    $result['topics'] = array_slice($normalized_topics, 0, 30);

    $routing_rules = is_array($settings['routing_rules'] ?? null) ? $settings['routing_rules'] : [];
    $normalized_rules = [];
    foreach ($routing_rules as $rule) {
        if (! is_array($rule)) {
            continue;
        }

        $field_key = sanitize_key((string) ($rule['field_key'] ?? ''));
        $match_value = sanitize_text_field((string) ($rule['match_value'] ?? ''));
        $recipient_email = sanitize_textarea_field((string) ($rule['recipient_email'] ?? ''));
        $label = sanitize_text_field((string) ($rule['label'] ?? ''));
        $mode = sanitize_key((string) ($rule['mode'] ?? 'append'));

        if ($field_key === '' || $match_value === '' || $recipient_email === '') {
            continue;
        }

        $normalized_rules[] = [
            'field_key' => $field_key,
            'match_value' => $match_value,
            'recipient_email' => $recipient_email,
            'label' => $label,
            'mode' => in_array($mode, ['append', 'replace'], true) ? $mode : 'append',
        ];
    }

    $result['routing_rules'] = $normalized_rules;

    return $result;
}

function feuer_kontaktform_design_fallback_palette(): array
{
    return [
        'shell_background_color' => '#f5efe6',
        'panel_background_color' => '#ffffff',
        'panel_text_color' => '#2b2117',
        'title_color' => '#1d2327',
        'aside_background_color' => '#74421b',
        'aside_text_color' => '#ffffff',
        'accent_color' => '#74421b',
        'button_background_color' => '#22160b',
        'button_text_color' => '#ffffff',
        'input_background_color' => '#ffffff',
        'input_text_color' => '#1f2937',
        'input_border_color' => '#cbbca8',
        'overlay_color' => '#2d1d0b',
        'overlay_opacity' => 72,
    ];
}

function feuer_kontaktform_design_image_targets(): array
{
    return [
        'aside' => 'Info-Bereich',
        'panel' => 'Formularbereich',
        'both' => 'Beide Bereiche',
    ];
}

function feuer_kontaktform_normalize_design_settings($input): array
{
    $defaults = feuer_kontaktform_default_design_settings();
    $colors   = [
        'shell_background_color',
        'panel_background_color',
        'panel_text_color',
        'title_color',
        'aside_background_color',
        'aside_text_color',
        'accent_color',
        'button_background_color',
        'button_text_color',
        'input_background_color',
        'input_text_color',
        'input_border_color',
        'overlay_color',
    ];

    $settings = is_array($input) ? $input : [];
    $result   = $defaults;

    foreach ($colors as $key) {
        $value = sanitize_text_field((string) ($settings[$key] ?? ''));
        if ($value === '') {
            $result[$key] = '';
            continue;
        }

        $normalized = sanitize_hex_color($value);
        $result[$key] = is_string($normalized) ? $normalized : '';
    }

    $result['background_image_url'] = feuer_kontaktform_normalize_local_asset_url((string) ($settings['background_image_url'] ?? ''));

    $target = sanitize_key((string) ($settings['background_image_target'] ?? $defaults['background_image_target']));
    if (! isset(feuer_kontaktform_design_image_targets()[$target])) {
        $target = (string) $defaults['background_image_target'];
    }
    $result['background_image_target'] = $target;

    $opacity = isset($settings['overlay_opacity']) ? (int) $settings['overlay_opacity'] : (int) $defaults['overlay_opacity'];
    $result['overlay_opacity'] = max(0, min(100, $opacity));

    return $result;
}

function feuer_kontaktform_table_names(?wpdb $database = null): array
{
    global $wpdb;

    $database = $database instanceof wpdb ? $database : $wpdb;
    $table_prefix = $database->prefix . 'feu-kontakt';

    return [
        'forms' => $table_prefix . '_forms',
        'submissions' => $table_prefix . '_submissions',
        'blocked_ips' => $table_prefix . '_blocked_ips',
        'blocked_emails' => $table_prefix . '_blocked_emails',
        'activity_logs' => $table_prefix . '_activity_logs',
    ];
}

