<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Repository
{
    private string $forms_table;
    private string $forms_table_sql;
    private string $submissions_table;
    private string $submissions_table_sql;
    private string $blocked_ips_table;
    private string $blocked_ips_table_sql;
    private string $blocked_emails_table;
    private string $blocked_emails_table_sql;
    private string $activity_table;
    private string $activity_table_sql;

    public function __construct()
    {
        $tables                    = feuer_kontaktform_table_names();
        $this->forms_table         = $tables['forms'];
        $this->forms_table_sql     = $this->quote_table($this->forms_table);
        $this->submissions_table   = $tables['submissions'];
        $this->submissions_table_sql = $this->quote_table($this->submissions_table);
        $this->blocked_ips_table   = $tables['blocked_ips'];
        $this->blocked_ips_table_sql = $this->quote_table($this->blocked_ips_table);
        $this->blocked_emails_table = $tables['blocked_emails'];
        $this->blocked_emails_table_sql = $this->quote_table($this->blocked_emails_table);
        $this->activity_table = $tables['activity_logs'];
        $this->activity_table_sql = $this->quote_table($this->activity_table);
    }

    public function create_tables(): void
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schemas = [];
        $schemas[] = "CREATE TABLE IF NOT EXISTS {$this->forms_table_sql} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            title varchar(190) NOT NULL,
            slug varchar(190) NOT NULL,
            design_variant varchar(50) NOT NULL DEFAULT 'design-1',
            design_settings longtext NOT NULL,
            display_settings longtext NOT NULL,
            behavior_settings longtext NOT NULL,
            recipient_email text NOT NULL,
            auto_reply_subject varchar(190) NOT NULL DEFAULT '',
            auto_reply_message longtext NOT NULL,
            fields longtext NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug)
        ) {$charset_collate};";

        $schemas[] = "CREATE TABLE IF NOT EXISTS {$this->submissions_table_sql} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            form_id bigint(20) unsigned NOT NULL,
            ticket_code varchar(40) NOT NULL DEFAULT '',
            reply_email varchar(190) NOT NULL DEFAULT '',
            ip_address varchar(100) NOT NULL,
            visitor_cookie varchar(80) NOT NULL DEFAULT '',
            device_type varchar(60) NOT NULL DEFAULT '',
            user_agent text NOT NULL,
            fields longtext NOT NULL,
            mail_status varchar(60) NOT NULL,
            mail_details text NOT NULL,
            auto_reply_status varchar(60) NOT NULL,
            auto_reply_details text NOT NULL,
            webhook_status varchar(60) NOT NULL,
            webhook_details text NOT NULL,
            status varchar(40) NOT NULL DEFAULT 'new',
            captcha_required tinyint(1) NOT NULL DEFAULT 0,
            privacy_accepted tinyint(1) NOT NULL DEFAULT 0,
            privacy_version varchar(190) NOT NULL DEFAULT '',
            referrer_url text NOT NULL,
            consent_context longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_code (ticket_code),
            KEY form_id (form_id),
            KEY reply_email (reply_email),
            KEY ip_address (ip_address),
            KEY created_at (created_at),
            KEY status (status)
        ) {$charset_collate};";

        $schemas[] = "CREATE TABLE IF NOT EXISTS {$this->blocked_ips_table_sql} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ip_address varchar(100) NOT NULL,
            reason varchar(255) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ip_address (ip_address)
        ) {$charset_collate};";

        $schemas[] = "CREATE TABLE IF NOT EXISTS {$this->blocked_emails_table_sql} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            email varchar(190) NOT NULL,
            reason varchar(255) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email)
        ) {$charset_collate};";

        $schemas[] = "CREATE TABLE IF NOT EXISTS {$this->activity_table_sql} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(80) NOT NULL,
            object_type varchar(80) NOT NULL DEFAULT '',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
            actor_ip varchar(100) NOT NULL DEFAULT '',
            message text NOT NULL,
            context longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY event_type (event_type),
            KEY object_type (object_type),
            KEY object_id (object_id),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ($schemas as $schema) {
            dbDelta(str_replace('CREATE TABLE IF NOT EXISTS', 'CREATE TABLE', $schema));
        }
    }

    public function drop_tables(): void
    {
        global $wpdb;

        $wpdb->query("DROP TABLE IF EXISTS {$this->submissions_table_sql}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->forms_table_sql}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->blocked_ips_table_sql}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->blocked_emails_table_sql}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->activity_table_sql}");
    }

    public function get_forms(): array
    {
        global $wpdb;

        $rows = $wpdb->get_results("SELECT * FROM {$this->forms_table_sql} ORDER BY title ASC", ARRAY_A);

        return $this->hydrate_forms($rows);
    }

    public function get_form(int $id): ?array
    {
        global $wpdb;

        if ($id <= 0) {
            return null;
        }

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->forms_table_sql} WHERE id = %d LIMIT 1", $id),
            ARRAY_A
        );

        return is_array($row) ? $this->hydrate_form($row) : null;
    }

    public function get_form_by_slug(string $slug): ?array
    {
        global $wpdb;

        $slug = sanitize_title($slug);
        if ($slug === '') {
            return null;
        }

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->forms_table_sql} WHERE slug = %s LIMIT 1", $slug),
            ARRAY_A
        );

        return is_array($row) ? $this->hydrate_form($row) : null;
    }

    public function get_form_by_slug_excluding_id(string $slug, int $exclude_id): ?int
    {
        global $wpdb;

        $found = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$this->forms_table_sql} WHERE slug = %s AND id != %d LIMIT 1", $slug, $exclude_id)
        );

        return $found ? (int) $found : null;
    }

    public function save_form(array $data, int $form_id = 0): int
    {
        global $wpdb;

        $payload = [
            'title' => $data['title'],
            'slug' => $data['slug'],
            'design_variant' => $data['design_variant'],
            'design_settings' => wp_json_encode($data['design_settings'], JSON_UNESCAPED_UNICODE),
            'display_settings' => wp_json_encode($data['display_settings'], JSON_UNESCAPED_UNICODE),
            'behavior_settings' => wp_json_encode($data['behavior_settings'], JSON_UNESCAPED_UNICODE),
            'recipient_email' => $data['recipient_email'],
            'auto_reply_subject' => $data['auto_reply_subject'],
            'auto_reply_message' => $data['auto_reply_message'],
            'fields' => wp_json_encode($data['fields'], JSON_UNESCAPED_UNICODE),
            'updated_at' => current_time('mysql'),
        ];

        if ($form_id > 0) {
            $wpdb->update($this->forms_table, $payload, ['id' => $form_id], ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'], ['%d']);
            return $form_id;
        }

        $payload['created_at'] = current_time('mysql');
        $wpdb->insert($this->forms_table, $payload, ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);

        return (int) $wpdb->insert_id;
    }

    public function delete_form(int $form_id): void
    {
        global $wpdb;

        $wpdb->delete($this->submissions_table, ['form_id' => $form_id], ['%d']);
        $wpdb->delete($this->forms_table, ['id' => $form_id], ['%d']);
    }

    public function get_submission_count(int $form_id): int
    {
        global $wpdb;

        return (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(id) FROM {$this->submissions_table_sql} WHERE form_id = %d", $form_id)
        );
    }

    public function get_recent_submissions_for_form(int $form_id, int $limit = 5): array
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->submissions_table_sql} WHERE form_id = %d ORDER BY created_at DESC LIMIT %d",
                $form_id,
                $limit
            ),
            ARRAY_A
        );

        return $this->hydrate_submissions($rows);
    }

    public function get_submissions(int $form_id = 0, int $limit = 100): array
    {
        global $wpdb;

        if ($form_id > 0) {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT s.*, f.title AS form_title
                    FROM {$this->submissions_table_sql} s
                    INNER JOIN {$this->forms_table_sql} f ON f.id = s.form_id
                    WHERE s.form_id = %d
                    ORDER BY s.created_at DESC
                    LIMIT %d",
                    $form_id,
                    $limit
                ),
                ARRAY_A
            );
        } else {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT s.*, f.title AS form_title
                    FROM {$this->submissions_table_sql} s
                    INNER JOIN {$this->forms_table_sql} f ON f.id = s.form_id
                    ORDER BY s.created_at DESC
                    LIMIT %d",
                    $limit
                ),
                ARRAY_A
            );
        }

        return $this->hydrate_submissions($rows);
    }

    public function get_submission(int $submission_id): ?array
    {
        global $wpdb;

        if ($submission_id <= 0) {
            return null;
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT s.*, f.title AS form_title
                FROM {$this->submissions_table_sql} s
                INNER JOIN {$this->forms_table_sql} f ON f.id = s.form_id
                WHERE s.id = %d
                LIMIT 1",
                $submission_id
            ),
            ARRAY_A
        );

        if (! is_array($row)) {
            return null;
        }

        $submissions = $this->hydrate_submissions([$row]);
        return $submissions[0] ?? null;
    }

    public function update_submission_status(int $submission_id, string $status): void
    {
        global $wpdb;

        if ($submission_id <= 0) {
            return;
        }

        $wpdb->update(
            $this->submissions_table,
            ['status' => $status],
            ['id' => $submission_id],
            ['%s'],
            ['%d']
        );
    }

    public function anonymize_old_submissions(int $days): void
    {
        global $wpdb;

        if ($days <= 0) {
            return;
        }

        $threshold = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->submissions_table_sql}
                SET reply_email = '',
                    ip_address = '',
                    visitor_cookie = '',
                    device_type = '',
                    user_agent = '',
                    referrer_url = '',
                    consent_context = '',
                    fields = %s
                WHERE created_at < %s",
                wp_json_encode(['Aufbewahrung' => 'Anonymisiert'], JSON_UNESCAPED_UNICODE),
                $threshold
            )
        );
    }

    public function insert_submission(
        int $form_id,
        string $ticket_code,
        string $reply_email,
        string $ip_address,
        string $visitor_cookie,
        string $device_type,
        string $user_agent,
        array $values,
        string $mail_status,
        string $mail_details,
        string $auto_reply_status,
        string $auto_reply_details,
        string $webhook_status,
        string $webhook_details,
        bool $captcha_required,
        bool $privacy_accepted,
        string $privacy_policy_url = '',
        string $privacy_version = '',
        string $referrer_url = '',
        array $consent_context = [],
        string $status = 'new'
    ): int {
        global $wpdb;

        $form = $this->get_form($form_id);
        $payload = [];
        if (is_array($form)) {
            foreach ($form['fields'] as $field) {
                $payload[$field['label']] = (string) ($values[$field['key']] ?? '');
            }
        }

        $payload['Datenschutzhinweis bestaetigt'] = $privacy_accepted ? 'Ja' : 'Nein';
        if ($ticket_code !== '') {
            $payload['Ticket-ID'] = $ticket_code;
        }
        if ($privacy_policy_url !== '') {
            $payload['Datenschutzerklaerung'] = $privacy_policy_url;
        }

        $wpdb->insert(
            $this->submissions_table,
            [
                'form_id' => $form_id,
                'ticket_code' => $ticket_code,
                'reply_email' => $reply_email,
                'ip_address' => $ip_address,
                'visitor_cookie' => $visitor_cookie,
                'device_type' => $device_type,
                'user_agent' => $user_agent,
                'fields' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
                'mail_status' => $mail_status,
                'mail_details' => $mail_details,
                'auto_reply_status' => $auto_reply_status,
                'auto_reply_details' => $auto_reply_details,
                'webhook_status' => $webhook_status,
                'webhook_details' => $webhook_details,
                'status' => $status,
                'captcha_required' => $captcha_required ? 1 : 0,
                'privacy_accepted' => $privacy_accepted ? 1 : 0,
                'privacy_version' => $privacy_version,
                'referrer_url' => $referrer_url,
                'consent_context' => wp_json_encode($consent_context, JSON_UNESCAPED_UNICODE),
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s']
        );

        return (int) $wpdb->insert_id;
    }

    public function has_recent_submission(string $ip_address, string $reply_email): bool
    {
        global $wpdb;

        $now = current_time('mysql');

        if ($reply_email !== '') {
            $count = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(id)
                    FROM {$this->submissions_table_sql}
                    WHERE created_at >= DATE_SUB(%s, INTERVAL 30 MINUTE)
                    AND (ip_address = %s OR reply_email = %s)",
                    $now,
                    $ip_address,
                    $reply_email
                )
            );
        } else {
            $count = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(id)
                    FROM {$this->submissions_table_sql}
                    WHERE created_at >= DATE_SUB(%s, INTERVAL 30 MINUTE)
                    AND ip_address = %s",
                    $now,
                    $ip_address
                )
            );
        }

        return (int) $count > 0;
    }

    public function get_blocked_ips(): array
    {
        global $wpdb;

        $rows = $wpdb->get_results("SELECT * FROM {$this->blocked_ips_table_sql} ORDER BY created_at DESC", ARRAY_A);

        return is_array($rows) ? $rows : [];
    }

    public function get_blocked_emails(): array
    {
        global $wpdb;

        $rows = $wpdb->get_results("SELECT * FROM {$this->blocked_emails_table_sql} ORDER BY created_at DESC", ARRAY_A);

        return is_array($rows) ? $rows : [];
    }

    public function add_blocked_ip(string $ip_address, string $reason): void
    {
        global $wpdb;

        $wpdb->replace(
            $this->blocked_ips_table,
            [
                'ip_address' => $ip_address,
                'reason' => $reason,
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s']
        );
    }

    public function add_blocked_email(string $email, string $reason): void
    {
        global $wpdb;

        $wpdb->replace(
            $this->blocked_emails_table,
            [
                'email' => $email,
                'reason' => $reason,
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s']
        );
    }

    public function delete_blocked_ip(int $id): void
    {
        global $wpdb;

        $wpdb->delete($this->blocked_ips_table, ['id' => $id], ['%d']);
    }

    public function delete_blocked_email(int $id): void
    {
        global $wpdb;

        $wpdb->delete($this->blocked_emails_table, ['id' => $id], ['%d']);
    }

    public function is_ip_blocked(string $ip_address): bool
    {
        global $wpdb;

        if ($ip_address === '') {
            return false;
        }

        $found = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$this->blocked_ips_table_sql} WHERE ip_address = %s LIMIT 1", $ip_address)
        );

        return (int) $found > 0;
    }

    public function is_auto_reply_blocked(string $email): bool
    {
        global $wpdb;

        if ($email === '') {
            return false;
        }

        $found = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$this->blocked_emails_table_sql} WHERE email = %s LIMIT 1", $email)
        );

        return (int) $found > 0;
    }

    public function insert_activity_log(string $event_type, string $object_type, int $object_id, string $message, array $context = []): void
    {
        global $wpdb;

        $wpdb->insert(
            $this->activity_table,
            [
                'event_type' => sanitize_key($event_type),
                'object_type' => sanitize_key($object_type),
                'object_id' => max(0, $object_id),
                'actor_id' => get_current_user_id(),
                'actor_ip' => sanitize_text_field((string) ($_SERVER['REMOTE_ADDR'] ?? '')),
                'message' => sanitize_text_field($message),
                'context' => wp_json_encode($context, JSON_UNESCAPED_UNICODE),
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s']
        );
    }

    public function get_activity_logs(int $limit = 100): array
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->activity_table_sql} ORDER BY created_at DESC LIMIT %d",
                max(1, min(500, $limit))
            ),
            ARRAY_A
        );

        if (! is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {
            $row['id'] = (int) ($row['id'] ?? 0);
            $row['object_id'] = (int) ($row['object_id'] ?? 0);
            $row['actor_id'] = (int) ($row['actor_id'] ?? 0);
            $row['event_type'] = (string) ($row['event_type'] ?? '');
            $row['object_type'] = (string) ($row['object_type'] ?? '');
            $row['actor_ip'] = (string) ($row['actor_ip'] ?? '');
            $row['message'] = (string) ($row['message'] ?? '');
            $row['created_at'] = (string) ($row['created_at'] ?? '');
            $row['context'] = $this->decode_submission_payload((string) ($row['context'] ?? ''));
        }

        return $rows;
    }

    private function hydrate_forms($rows): array
    {
        if (! is_array($rows)) {
            return [];
        }

        return array_map([$this, 'hydrate_form'], $rows);
    }

    private function hydrate_form(array $row): array
    {
        $row['id']                 = (int) ($row['id'] ?? 0);
        $row['title']              = (string) ($row['title'] ?? '');
        $row['slug']               = (string) ($row['slug'] ?? '');
        $row['design_variant']     = (string) ($row['design_variant'] ?? 'design-1');
        $row['design_settings']    = $this->decode_design_settings((string) ($row['design_settings'] ?? ''));
        $row['display_settings']   = $this->decode_display_settings((string) ($row['display_settings'] ?? ''));
        $row['behavior_settings']  = $this->decode_behavior_settings((string) ($row['behavior_settings'] ?? ''));
        $row['recipient_email']    = (string) ($row['recipient_email'] ?? '');
        $row['auto_reply_subject'] = (string) ($row['auto_reply_subject'] ?? '');
        $row['auto_reply_message'] = (string) ($row['auto_reply_message'] ?? '');
        $row['fields']             = $this->decode_fields((string) ($row['fields'] ?? ''));

        return $row;
    }

    private function hydrate_submissions($rows): array
    {
        if (! is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {
            $row['id']                = (int) ($row['id'] ?? 0);
            $row['form_id']           = (int) ($row['form_id'] ?? 0);
            $row['ticket_code']       = (string) ($row['ticket_code'] ?? '');
            $row['reply_email']       = (string) ($row['reply_email'] ?? '');
            $row['ip_address']        = (string) ($row['ip_address'] ?? '');
            $row['visitor_cookie']    = (string) ($row['visitor_cookie'] ?? '');
            $row['device_type']       = (string) ($row['device_type'] ?? '');
            $row['user_agent']        = (string) ($row['user_agent'] ?? '');
            $row['mail_status']       = (string) ($row['mail_status'] ?? '');
            $row['mail_details']      = (string) ($row['mail_details'] ?? '');
            $row['auto_reply_status'] = (string) ($row['auto_reply_status'] ?? '');
            $row['auto_reply_details'] = (string) ($row['auto_reply_details'] ?? '');
            $row['webhook_status']    = (string) ($row['webhook_status'] ?? '');
            $row['webhook_details']   = (string) ($row['webhook_details'] ?? '');
            $row['status']            = (string) ($row['status'] ?? 'new');
            $row['captcha_required']  = ! empty($row['captcha_required']);
            $row['privacy_accepted']  = ! empty($row['privacy_accepted']);
            $row['privacy_version']   = (string) ($row['privacy_version'] ?? '');
            $row['referrer_url']      = (string) ($row['referrer_url'] ?? '');
            $row['consent_context']   = $this->decode_submission_payload((string) ($row['consent_context'] ?? ''));
            $row['form_title']        = (string) ($row['form_title'] ?? '');
            $row['fields']            = $this->decode_submission_payload((string) ($row['fields'] ?? ''));
        }

        return $rows;
    }

    private function decode_fields(string $json): array
    {
        $decoded = json_decode($json, true);
        if (! is_array($decoded)) {
            return [];
        }

        $fields = [];
        foreach ($decoded as $field) {
            if (! is_array($field)) {
                continue;
            }

            $type = sanitize_key((string) ($field['type'] ?? 'text'));
            $default_width = match ($type) {
                'nachricht', 'textarea' => 'full',
                'kind_alter' => 'small',
                default => 'medium',
            };
            $options = [];
            if (is_array($field['options'] ?? null)) {
                foreach ($field['options'] as $option) {
                    $option = sanitize_text_field((string) $option);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            } elseif (is_string($field['options'] ?? null)) {
                $parts = preg_split('/[\r\n,;]+/', (string) $field['options']) ?: [];
                foreach ($parts as $option) {
                    $option = sanitize_text_field((string) $option);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            }

            $fields[] = [
                'type' => $type,
                'label' => sanitize_text_field((string) ($field['label'] ?? 'Feld')),
                'key' => sanitize_key((string) ($field['key'] ?? 'feld')),
                'placeholder' => sanitize_text_field((string) ($field['placeholder'] ?? '')),
                'required' => ! empty($field['required']),
                'width' => in_array((string) ($field['width'] ?? $default_width), ['small', 'medium', 'large', 'full'], true) ? (string) ($field['width'] ?? $default_width) : $default_width,
                'rows' => in_array((string) ($field['rows'] ?? 'medium'), ['small', 'medium', 'large'], true) ? (string) $field['rows'] : 'medium',
                'step' => max(1, (int) ($field['step'] ?? 1)),
                'condition_field' => sanitize_key((string) ($field['condition_field'] ?? '')),
                'condition_value' => sanitize_text_field((string) ($field['condition_value'] ?? '')),
                'help_text' => sanitize_text_field((string) ($field['help_text'] ?? '')),
                'options' => array_values(array_unique($options)),
            ];
        }

        return $fields;
    }

    private function decode_submission_payload(string $json): array
    {
        $decoded = json_decode($json, true);
        if (! is_array($decoded)) {
            return [];
        }

        $payload = [];
        foreach ($decoded as $label => $value) {
            $payload[sanitize_text_field((string) $label)] = sanitize_textarea_field((string) $value);
        }

        return $payload;
    }

    private function decode_design_settings(string $json): array
    {
        $decoded = json_decode($json, true);

        return feuer_kontaktform_normalize_design_settings(is_array($decoded) ? $decoded : []);
    }

    private function decode_display_settings(string $json): array
    {
        $decoded = json_decode($json, true);

        return feuer_kontaktform_normalize_display_settings(is_array($decoded) ? $decoded : []);
    }

    private function decode_behavior_settings(string $json): array
    {
        $decoded = json_decode($json, true);

        return feuer_kontaktform_normalize_behavior_settings(is_array($decoded) ? $decoded : []);
    }

    private function quote_table(string $table): string
    {
        return '`' . str_replace('`', '``', $table) . '`';
    }
}

