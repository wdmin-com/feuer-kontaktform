<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_View
{
    public function __construct(private string $templates_path)
    {
    }

    public function render(string $template, array $vars = []): string
    {
        $path = trailingslashit($this->templates_path) . ltrim($template, '/');
        if (! is_file($path)) {
            return '';
        }

        ob_start();
        extract($vars, EXTR_SKIP);
        include $path;

        return (string) ob_get_clean();
    }
}

