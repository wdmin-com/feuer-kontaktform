<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Form_Files
{
    private const STORAGE_SUBDIR = 'feuer-kontaktform/forms';
    private const STYLES_SUBDIR = 'feuer-kontaktform/styles';
    private const MAX_FILE_BYTES = 131072;

    public function initialize_storage(): void
    {
        $this->ensure_storage_directory();
        $this->ensure_stylesheet_directory();
    }

    public function sync_form(array $form): array
    {
        $state = $this->get_form_state($form);

        if (! $state['available']) {
            $form['_file_sync'] = $state;
            return $form;
        }

        if (! $state['exists']) {
            $legacy_path = $this->get_legacy_form_path($form);
            if ($legacy_path !== '' && $this->is_allowed_storage_path($legacy_path) && is_file($legacy_path)) {
                $legacy_loaded = $this->read_form_file($legacy_path, $form);
                if ($legacy_loaded['success']) {
                    $legacy_form = (array) $legacy_loaded['form'];
                    $write = $this->write_form($legacy_form, (string) ($legacy_form['slug'] ?? ''));
                    $legacy_form['_file_sync'] = $write['state'];
                    $this->delete_legacy_form_file_by_slug((int) ($form['id'] ?? 0), (string) ($form['slug'] ?? ''));
                    return $legacy_form;
                }
            }

            $write = $this->write_form($form);
            $form['_file_sync'] = $write['state'];
            return $form;
        }

        $loaded = $this->read_form_file((string) $state['path'], $form);
        if (! $loaded['success']) {
            $state['source'] = 'database';
            $state['error'] = (string) $loaded['error'];
            $form['_file_sync'] = $state;
            return $form;
        }

        $resolved = (array) $loaded['form'];
        $state['source'] = 'file';
        $state['error'] = '';
        $resolved['_file_sync'] = $state;

        return $resolved;
    }

    public function write_form(array $form, string $old_slug = ''): array
    {
        $state = $this->get_form_state($form);
        if (! $state['available']) {
            return ['success' => false, 'state' => $state];
        }

        $directory = $this->ensure_storage_directory();
        if (! $directory['success']) {
            $state['error'] = (string) $directory['error'];
            return ['success' => false, 'state' => $state];
        }

        $path = (string) $state['path'];
        $json = wp_json_encode($this->build_export_payload($form), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (! is_string($json) || $json === '') {
            $state['error'] = 'Die JSON-Datei konnte nicht erzeugt werden.';
            return ['success' => false, 'state' => $state];
        }

        if (strlen($json) > self::MAX_FILE_BYTES) {
            $state['error'] = 'Die JSON-Datei ist groesser als erlaubt.';
            return ['success' => false, 'state' => $state];
        }

        if (! $this->is_allowed_storage_path($path)) {
            $state['error'] = 'Der Zielpfad fuer die JSON-Datei ist ungueltig.';
            return ['success' => false, 'state' => $state];
        }

        $written = @file_put_contents($path, $json, LOCK_EX);
        if ($written === false) {
            $state['error'] = 'Die JSON-Datei konnte nicht gespeichert werden.';
            return ['success' => false, 'state' => $state];
        }

        @chmod($path, 0640);

        if ($old_slug !== '' && $old_slug !== (string) $form['slug']) {
            $this->delete_form_file_by_slug((int) ($form['id'] ?? 0), $old_slug);
            $this->delete_form_stylesheet_by_slug((int) ($form['id'] ?? 0), $old_slug);
            $this->delete_legacy_form_file_by_slug((int) ($form['id'] ?? 0), $old_slug);
        }
        $this->delete_legacy_form_file_by_slug((int) ($form['id'] ?? 0), (string) ($form['slug'] ?? ''));

        clearstatcache(true, $path);

        $state = $this->get_form_state($form);
        $state['source'] = 'database';

        return ['success' => true, 'state' => $state];
    }

    public function ensure_form_stylesheet(array $form, string $css): array
    {
        $state = $this->get_form_stylesheet_state($form);
        if (! $state['available']) {
            return ['success' => false, 'state' => $state];
        }

        $directory = $this->ensure_stylesheet_directory();
        if (! $directory['success']) {
            $state['error'] = (string) $directory['error'];
            return ['success' => false, 'state' => $state];
        }

        $path = (string) $state['path'];
        if (! $this->is_allowed_stylesheet_path($path)) {
            $state['error'] = 'Der Zielpfad fuer die CSS-Datei ist ungueltig.';
            return ['success' => false, 'state' => $state];
        }

        if ($css === '') {
            if (is_file($path)) {
                @unlink($path);
                clearstatcache(true, $path);
            }

            return ['success' => true, 'state' => $this->get_form_stylesheet_state($form)];
        }

        if (strlen($css) > self::MAX_FILE_BYTES) {
            $state['error'] = 'Die CSS-Datei ist groesser als erlaubt.';
            return ['success' => false, 'state' => $state];
        }

        if (is_file($path)) {
            $current = @file_get_contents($path);
            if (is_string($current) && $current === $css) {
                return ['success' => true, 'state' => $this->get_form_stylesheet_state($form)];
            }
        }

        $written = @file_put_contents($path, $css, LOCK_EX);
        if ($written === false) {
            $state['error'] = 'Die CSS-Datei konnte nicht gespeichert werden.';
            return ['success' => false, 'state' => $state];
        }

        @chmod($path, 0640);
        clearstatcache(true, $path);

        return ['success' => true, 'state' => $this->get_form_stylesheet_state($form)];
    }

    public function delete_form_file(array $form): void
    {
        $this->delete_form_file_by_slug((int) ($form['id'] ?? 0), (string) ($form['slug'] ?? ''));
        $this->delete_form_stylesheet_by_slug((int) ($form['id'] ?? 0), (string) ($form['slug'] ?? ''));
        $this->delete_legacy_form_file_by_slug((int) ($form['id'] ?? 0), (string) ($form['slug'] ?? ''));
    }

    public function delete_storage(): void
    {
        $directory = $this->get_storage_directory();
        if ($directory === '' || ! is_dir($directory)) {
            $styles_directory = $this->get_stylesheet_directory();
            if ($styles_directory !== '' && is_dir($styles_directory)) {
                $this->delete_directory($styles_directory, true);
            }

            return;
        }

        $this->delete_directory($directory, false);

        $styles_directory = $this->get_stylesheet_directory();
        if ($styles_directory !== '' && is_dir($styles_directory)) {
            $this->delete_directory($styles_directory, true);
        }
    }

    private function read_form_file(string $path, array $base_form): array
    {
        if (! $this->is_allowed_storage_path($path) || ! is_file($path)) {
            return ['success' => false, 'error' => 'Der Pfad der JSON-Datei ist ungueltig.'];
        }

        if (is_link($path)) {
            return ['success' => false, 'error' => 'Symbolische Links sind fuer JSON-Dateien nicht erlaubt.'];
        }

        $size = @filesize($path);
        if (is_int($size) && $size > self::MAX_FILE_BYTES) {
            return ['success' => false, 'error' => 'Die JSON-Datei ist groesser als erlaubt.'];
        }

        $raw = @file_get_contents($path);
        if (! is_string($raw) || trim($raw) === '') {
            return ['success' => false, 'error' => 'Die JSON-Datei ist leer oder nicht lesbar.'];
        }

        $decoded = json_decode($raw, true);
        if (! is_array($decoded)) {
            return ['success' => false, 'error' => 'Die JSON-Datei enthaelt kein gueltiges JSON.'];
        }

        $file_form = $decoded['form'] ?? null;
        if (! is_array($file_form)) {
            return ['success' => false, 'error' => 'In der JSON-Datei fehlt der Abschnitt "form".'];
        }

        return [
            'success' => true,
            'form' => $this->normalize_loaded_form($file_form, $base_form),
        ];
    }

    private function normalize_loaded_form(array $file_form, array $base_form): array
    {
        $design_variant = sanitize_key((string) ($file_form['design_variant'] ?? $base_form['design_variant'] ?? 'design-1'));
        if (! preg_match('/^design-\d+$/', $design_variant)) {
            $design_variant = (string) ($base_form['design_variant'] ?? 'design-1');
        }

        $fields = $this->normalize_fields(is_array($file_form['fields'] ?? null) ? $file_form['fields'] : []);
        if ($fields === []) {
            $fields = is_array($base_form['fields'] ?? null) ? $base_form['fields'] : [];
        }

        $title = $this->truncate(sanitize_text_field((string) ($file_form['title'] ?? $base_form['title'] ?? '')), 190);
        if ($title === '') {
            $title = (string) ($base_form['title'] ?? '');
        }

        $recipient_email = $this->truncate(sanitize_textarea_field((string) ($file_form['recipient_email'] ?? $base_form['recipient_email'] ?? '')), 1000);
        if ($recipient_email === '') {
            $recipient_email = (string) ($base_form['recipient_email'] ?? '');
        }

        return [
            'id' => (int) ($base_form['id'] ?? 0),
            'title' => $title,
            'slug' => (string) ($base_form['slug'] ?? ''),
            'design_variant' => $design_variant,
            'design_settings' => feuer_kontaktform_normalize_design_settings(is_array($file_form['design_settings'] ?? null) ? $file_form['design_settings'] : (array) ($base_form['design_settings'] ?? [])),
            'display_settings' => feuer_kontaktform_normalize_display_settings(is_array($file_form['display_settings'] ?? null) ? $file_form['display_settings'] : (array) ($base_form['display_settings'] ?? [])),
            'behavior_settings' => feuer_kontaktform_normalize_behavior_settings(is_array($file_form['behavior_settings'] ?? null) ? $file_form['behavior_settings'] : (array) ($base_form['behavior_settings'] ?? [])),
            'recipient_email' => $recipient_email,
            'auto_reply_subject' => $this->truncate(sanitize_text_field((string) ($file_form['auto_reply_subject'] ?? $base_form['auto_reply_subject'] ?? '')), 190),
            'auto_reply_message' => $this->truncate(wp_kses_post((string) ($file_form['auto_reply_message'] ?? $base_form['auto_reply_message'] ?? '')), 12000),
            'fields' => $fields,
            'created_at' => (string) ($base_form['created_at'] ?? ''),
            'updated_at' => (string) ($base_form['updated_at'] ?? ''),
        ];
    }

    private function normalize_fields(array $fields): array
    {
        $normalized = [];
        $used_keys = [];

        foreach ($fields as $field) {
            if (count($normalized) >= 40) {
                break;
            }

            if (! is_array($field)) {
                continue;
            }

            $type = sanitize_key((string) ($field['type'] ?? 'text'));
            if (! in_array($type, ['vorname', 'nachname', 'email', 'telefon', 'nachricht', 'kind_name', 'kind_alter', 'text', 'textarea', 'select', 'radio', 'date', 'time'], true)) {
                $type = 'text';
            }

            $default_width = in_array($type, ['nachricht', 'textarea'], true) ? 'full' : (in_array($type, ['kind_alter'], true) ? 'small' : 'medium');
            $label = $this->truncate(sanitize_text_field((string) ($field['label'] ?? 'Feld')), 120);
            $key = sanitize_key((string) ($field['key'] ?? $label));
            $placeholder = $this->truncate(sanitize_text_field((string) ($field['placeholder'] ?? '')), 180);
            $required = ! empty($field['required']) || in_array($type, ['email', 'nachricht', 'textarea'], true);
            $width = sanitize_key((string) ($field['width'] ?? $default_width));
            $rows = sanitize_key((string) ($field['rows'] ?? 'medium'));

            if ($key === '') {
                $key = 'feld';
            }

            $base_key = $key;
            $suffix = 2;
            while (in_array($key, $used_keys, true)) {
                $key = $base_key . '_' . $suffix;
                ++$suffix;
            }

            if (! in_array($width, ['small', 'medium', 'large', 'full'], true)) {
                $width = $default_width;
            }

            if (! in_array($rows, ['small', 'medium', 'large'], true)) {
                $rows = 'medium';
            }

            $options = [];
            if (is_array($field['options'] ?? null)) {
                foreach ($field['options'] as $option) {
                    $option = $this->truncate(sanitize_text_field((string) $option), 120);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            } elseif (is_string($field['options'] ?? null)) {
                $parts = preg_split('/[\r\n,;]+/', (string) $field['options']) ?: [];
                foreach ($parts as $option) {
                    $option = $this->truncate(sanitize_text_field((string) $option), 120);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            }

            $used_keys[] = $key;
            $normalized[] = [
                'type' => $type,
                'label' => $label !== '' ? $label : 'Feld',
                'key' => $key,
                'placeholder' => $placeholder,
                'required' => $required,
                'width' => $width,
                'rows' => $rows,
                'step' => max(1, (int) ($field['step'] ?? 1)),
                'condition_field' => sanitize_key((string) ($field['condition_field'] ?? '')),
                'condition_value' => $this->truncate(sanitize_text_field((string) ($field['condition_value'] ?? '')), 120),
                'help_text' => $this->truncate(sanitize_text_field((string) ($field['help_text'] ?? '')), 180),
                'options' => array_values(array_unique($options)),
            ];
        }

        return $normalized;
    }

    private function build_export_payload(array $form): array
    {
        return [
            'meta' => [
                'plugin' => 'Feuer-Kontaktform',
                'version' => defined('FEUER_KONTAKTFORM_VERSION') ? (string) FEUER_KONTAKTFORM_VERSION : '',
                'exported_at' => current_time('mysql'),
                'note' => 'Diese Datei kann manuell bearbeitet werden. ID und Slug dienen nur der Zuordnung und sollten nicht geaendert werden.',
            ],
            'form' => [
                'id' => (int) ($form['id'] ?? 0),
                'slug' => (string) ($form['slug'] ?? ''),
                'title' => (string) ($form['title'] ?? ''),
                'design_variant' => (string) ($form['design_variant'] ?? 'design-1'),
                'design_settings' => is_array($form['design_settings'] ?? null) ? $form['design_settings'] : [],
                'display_settings' => is_array($form['display_settings'] ?? null) ? $form['display_settings'] : [],
                'behavior_settings' => is_array($form['behavior_settings'] ?? null) ? $form['behavior_settings'] : [],
                'recipient_email' => (string) ($form['recipient_email'] ?? ''),
                'auto_reply_subject' => (string) ($form['auto_reply_subject'] ?? ''),
                'auto_reply_message' => (string) ($form['auto_reply_message'] ?? ''),
                'fields' => is_array($form['fields'] ?? null) ? array_values($form['fields']) : [],
            ],
        ];
    }

    public function export_form_json(array $form): string
    {
        $json = wp_json_encode($this->build_export_payload($form), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($json) ? $json : '';
    }

    private function get_form_state(array $form): array
    {
        $directory = $this->get_storage_directory();
        $slug = sanitize_title((string) ($form['slug'] ?? ''));
        $id = (int) ($form['id'] ?? 0);
        $path = '';

        if ($directory !== '' && $id > 0 && $slug !== '') {
            $path = trailingslashit($directory) . $this->build_filename($id, $slug);
        }

        $modified_at = '';
        if ($path !== '' && $this->is_allowed_storage_path($path) && is_file($path)) {
            $timestamp = @filemtime($path);
            if (is_int($timestamp) && $timestamp > 0) {
                $modified_at = wp_date('d.m.Y H:i', $timestamp);
            }
        }

        return [
            'available' => $directory !== '' && $id > 0 && $slug !== '',
            'exists' => $path !== '' && $this->is_allowed_storage_path($path) && is_file($path),
            'path' => $path,
            'directory' => $directory,
            'source' => 'database',
            'error' => $directory === '' ? 'Das Upload-Verzeichnis ist nicht verfuegbar.' : '',
            'modified_at' => $modified_at,
        ];
    }

    private function get_form_stylesheet_state(array $form): array
    {
        $directory = $this->get_stylesheet_directory();
        $base_url  = $this->get_stylesheet_base_url();
        $slug      = sanitize_title((string) ($form['slug'] ?? ''));
        $id        = (int) ($form['id'] ?? 0);
        $path      = '';
        $url       = '';

        if ($directory !== '' && $id > 0 && $slug !== '') {
            $filename = $this->build_stylesheet_filename($id, $slug);
            $path     = trailingslashit($directory) . $filename;
            $url      = $base_url !== '' ? trailingslashit($base_url) . $filename : '';
        }

        $exists      = $path !== '' && $this->is_allowed_stylesheet_path($path) && is_file($path);
        $modified_at = '';
        $version     = defined('FEUER_KONTAKTFORM_VERSION') ? (string) FEUER_KONTAKTFORM_VERSION : '1';
        if ($exists) {
            $timestamp = @filemtime($path);
            if (is_int($timestamp) && $timestamp > 0) {
                $modified_at = wp_date('d.m.Y H:i', $timestamp);
                $version     = (string) $timestamp;
            }
        }

        return [
            'available' => $directory !== '' && $id > 0 && $slug !== '',
            'exists' => $exists,
            'path' => $path,
            'url' => $url,
            'directory' => $directory,
            'error' => $directory === '' ? 'Das Upload-Verzeichnis ist nicht verfuegbar.' : '',
            'modified_at' => $modified_at,
            'version' => $version,
        ];
    }

    private function ensure_storage_directory(): array
    {
        $directory = $this->get_storage_directory();
        if ($directory === '') {
            return ['success' => false, 'error' => 'Das Upload-Verzeichnis ist nicht verfuegbar.'];
        }

        if (is_dir($directory)) {
            $this->write_protection_files($directory);
            return ['success' => true, 'error' => ''];
        }

        if (wp_mkdir_p($directory)) {
            $this->write_protection_files($directory);
            return ['success' => true, 'error' => ''];
        }

        return ['success' => false, 'error' => 'Das Verzeichnis fuer die Formular-Dateien konnte nicht angelegt werden.'];
    }

    private function ensure_stylesheet_directory(): array
    {
        $directory = $this->get_stylesheet_directory();
        if ($directory === '') {
            return ['success' => false, 'error' => 'Das Upload-Verzeichnis ist nicht verfuegbar.'];
        }

        if (is_dir($directory)) {
            $this->write_public_directory_files($directory);
            return ['success' => true, 'error' => ''];
        }

        if (wp_mkdir_p($directory)) {
            $this->write_public_directory_files($directory);
            return ['success' => true, 'error' => ''];
        }

        return ['success' => false, 'error' => 'Das Verzeichnis fuer die Formular-CSS-Dateien konnte nicht angelegt werden.'];
    }

    private function get_storage_directory(): string
    {
        $filtered = apply_filters('feuer-kontaktform-form-storage-directory', '');
        if (is_string($filtered) && trim($filtered) !== '') {
            return untrailingslashit(wp_normalize_path(trim($filtered)));
        }

        $upload = wp_upload_dir();
        if (! empty($upload['error']) || empty($upload['basedir'])) {
            return '';
        }

        return untrailingslashit(wp_normalize_path(trailingslashit((string) $upload['basedir']) . self::STORAGE_SUBDIR));
    }

    private function get_stylesheet_directory(): string
    {
        $filtered = apply_filters('feuer-kontaktform-form-style-directory', '');
        if (is_string($filtered) && trim($filtered) !== '') {
            return untrailingslashit(wp_normalize_path(trim($filtered)));
        }

        $upload = wp_upload_dir();
        if (! empty($upload['error']) || empty($upload['basedir'])) {
            return '';
        }

        return untrailingslashit(wp_normalize_path(trailingslashit((string) $upload['basedir']) . self::STYLES_SUBDIR));
    }

    private function get_stylesheet_base_url(): string
    {
        $filtered = apply_filters('feuer-kontaktform-form-style-base-url', '');
        if (is_string($filtered) && trim($filtered) !== '') {
            return untrailingslashit(esc_url_raw(trim($filtered)));
        }

        $upload = wp_upload_dir();
        if (! empty($upload['error']) || empty($upload['baseurl'])) {
            return '';
        }

        return untrailingslashit(trailingslashit((string) $upload['baseurl']) . self::STYLES_SUBDIR);
    }

    private function build_filename(int $form_id, string $slug): string
    {
        return 'form-' . $form_id . '-' . sanitize_file_name($slug) . '-' . $this->build_file_token($form_id, $slug) . '.json';
    }

    private function build_stylesheet_filename(int $form_id, string $slug): string
    {
        return 'form-' . $form_id . '-' . sanitize_file_name($slug) . '-' . $this->build_file_token($form_id, $slug) . '.css';
    }

    private function build_file_token(int $form_id, string $slug): string
    {
        return substr(hash_hmac('sha256', $form_id . '|' . $slug, wp_salt('auth')), 0, 12);
    }

    private function build_legacy_filename(int $form_id, string $slug): string
    {
        return 'form-' . $form_id . '-' . sanitize_file_name($slug) . '.json';
    }

    private function delete_form_file_by_slug(int $form_id, string $slug): void
    {
        $directory = $this->get_storage_directory();
        $slug = sanitize_title($slug);
        if ($directory === '' || $form_id <= 0 || $slug === '') {
            return;
        }

        $path = trailingslashit($directory) . $this->build_filename($form_id, $slug);
        if ($this->is_allowed_storage_path($path) && is_file($path)) {
            @unlink($path);
        }
    }

    private function delete_form_stylesheet_by_slug(int $form_id, string $slug): void
    {
        $directory = $this->get_stylesheet_directory();
        $slug = sanitize_title($slug);
        if ($directory === '' || $form_id <= 0 || $slug === '') {
            return;
        }

        $path = trailingslashit($directory) . $this->build_stylesheet_filename($form_id, $slug);
        if ($this->is_allowed_stylesheet_path($path) && is_file($path)) {
            @unlink($path);
        }
    }

    private function delete_legacy_form_file_by_slug(int $form_id, string $slug): void
    {
        $path = $this->get_legacy_form_path(['id' => $form_id, 'slug' => $slug]);
        if ($path !== '' && $this->is_allowed_storage_path($path) && is_file($path)) {
            @unlink($path);
        }
    }

    private function get_legacy_form_path(array $form): string
    {
        $directory = $this->get_storage_directory();
        $slug = sanitize_title((string) ($form['slug'] ?? ''));
        $form_id = (int) ($form['id'] ?? 0);

        if ($directory === '' || $slug === '' || $form_id <= 0) {
            return '';
        }

        return trailingslashit($directory) . $this->build_legacy_filename($form_id, $slug);
    }

    private function delete_directory(string $directory, bool $public_directory): void
    {
        if ($public_directory) {
            if (! $this->is_allowed_stylesheet_path($directory)) {
                return;
            }
        } elseif (! $this->is_allowed_storage_path($directory)) {
            return;
        }

        if (is_link($directory)) {
            @unlink($directory);
            return;
        }

        $items = @scandir($directory);
        if (! is_array($items)) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $directory . DIRECTORY_SEPARATOR . $item;
            if (is_link($path)) {
                @unlink($path);
                continue;
            }

            if (is_dir($path)) {
                $this->delete_directory($path, $public_directory);
                continue;
            }

            @unlink($path);
        }

        @rmdir($directory);
    }

    private function is_allowed_storage_path(string $path): bool
    {
        $directory = $this->get_storage_directory();
        if ($directory === '' || $path === '') {
            return false;
        }

        if (is_link($path)) {
            return false;
        }

        $normalized_dir = untrailingslashit(wp_normalize_path($directory));
        $normalized_path = wp_normalize_path($path);

        if (file_exists($path) || is_dir($path)) {
            $real_path = realpath($path);
            if ($real_path === false) {
                return false;
            }

            $normalized_path = wp_normalize_path($real_path);
        }

        return $normalized_path === $normalized_dir || str_starts_with($normalized_path, trailingslashit($normalized_dir));
    }

    private function is_allowed_stylesheet_path(string $path): bool
    {
        $directory = $this->get_stylesheet_directory();
        if ($directory === '' || $path === '') {
            return false;
        }

        if (is_link($path)) {
            return false;
        }

        $normalized_dir = untrailingslashit(wp_normalize_path($directory));
        $normalized_path = wp_normalize_path($path);

        if (file_exists($path) || is_dir($path)) {
            $real_path = realpath($path);
            if ($real_path === false) {
                return false;
            }

            $normalized_path = wp_normalize_path($real_path);
        }

        return $normalized_path === $normalized_dir || str_starts_with($normalized_path, trailingslashit($normalized_dir));
    }

    private function write_protection_files(string $directory): void
    {
        $files = [
            'index.php' => "<?php\nif (! defined('ABSPATH')) { exit; }\n",
            '.htaccess' => "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n",
            'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration>\n  <system.webServer>\n    <security>\n      <authorization>\n        <remove users=\"*\" roles=\"\" verbs=\"\" />\n        <add accessType=\"Deny\" users=\"*\" />\n      </authorization>\n    </security>\n  </system.webServer>\n</configuration>\n",
        ];

        foreach ($files as $filename => $contents) {
            $path = trailingslashit($directory) . $filename;
            if (! $this->is_allowed_storage_path($path) || is_file($path)) {
                continue;
            }

            @file_put_contents($path, $contents, LOCK_EX);
        }
    }

    private function write_public_directory_files(string $directory): void
    {
        $files = [
            'index.php' => "<?php\nif (! defined('ABSPATH')) { exit; }\n",
            '.htaccess' => "Options -Indexes\n",
            'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration>\n  <system.webServer>\n    <directoryBrowse enabled=\"false\" />\n  </system.webServer>\n</configuration>\n",
        ];

        foreach ($files as $filename => $contents) {
            $path = trailingslashit($directory) . $filename;
            if (! $this->is_allowed_stylesheet_path($path) || is_file($path)) {
                continue;
            }

            @file_put_contents($path, $contents, LOCK_EX);
        }
    }

    private function truncate(string $value, int $length): string
    {
        if ($length <= 0) {
            return '';
        }

        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, 0, $length);
        }

        return substr($value, 0, $length);
    }
}


