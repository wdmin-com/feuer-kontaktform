<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Plugin
{
    private const OPTION_SETTINGS = 'feuer-kontaktform-settings';
    private const OPTION_VERSION = 'feuer-kontaktform-version';
    private const FLASH_PREFIX = 'feuer-kontaktform-flash-';
    private const MENU_SLUG = 'feuer-kontaktform';
    private const RATE_LIMIT_PREFIX = 'feuer-kontaktform-rate-';
    private const RATE_LIMIT_SECONDS = 5;
    private const HONEYPOT_FIELD = 'feuer_kontaktform_company_website';
    private const PRIVACY_FIELD = 'feuer_kontaktform_privacy_accepted';
    private const VISITOR_COOKIE = 'feuer_kontaktform_visitor';
    private const FORM_QUERY_ARG = 'feuer-kontaktform-form';
    private const MAX_SUBMISSION_BYTES = 12000;

    private ?array $request_flash = null;
    private bool $request_flash_loaded = false;
    private ?array $request_frontend_result = null;
    private bool $request_frontend_result_loaded = false;
    private Feuer_Kontaktform_Updater $updater;

    public function __construct(
        private Feuer_Kontaktform_Repository $repository,
        private Feuer_Kontaktform_View $view,
        private Feuer_Kontaktform_Mailer $mailer,
        private Feuer_Kontaktform_Form_Files $form_files
    ) {
        $this->updater = new Feuer_Kontaktform_Updater();
        $this->updater->register();

        add_action('init', [$this, 'maybe_upgrade_schema']);
        add_action('init', [$this, 'register_rewrite_rules']);
        add_action('init', [$this, 'cleanup_old_submissions']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_init', [$this, 'handle_admin_requests']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'register_frontend_assets']);
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_block_editor_assets']);
        add_action('wp_dashboard_setup', [$this, 'register_dashboard_widget']);
        add_filter('query_vars', [$this, 'register_query_vars']);

        add_shortcode('feuer-kontaktform-formular', [$this, 'render_single_form_shortcode']);
        add_shortcode('feuer-kontaktform-alle', [$this, 'render_all_forms_shortcode']);
        add_shortcode('feuer-kontaktform-popup', [$this, 'render_popup_form_shortcode']);
        add_shortcode('feuer-kontaktform-schnell', [$this, 'render_quick_form_shortcode']);

        add_action('admin_post_feuer-kontaktform-submit', [$this, 'handle_frontend_submission']);
        add_action('admin_post_nopriv_feuer-kontaktform-submit', [$this, 'handle_frontend_submission']);
        add_action('wp_ajax_feuer-kontaktform-submit-async', [$this, 'handle_frontend_submission_ajax']);
        add_action('wp_ajax_nopriv_feuer-kontaktform-submit-async', [$this, 'handle_frontend_submission_ajax']);
    }

    public function maybe_upgrade_schema(): void
    {
        if (get_option(self::OPTION_VERSION) === FEUER_KONTAKTFORM_VERSION) {
            return;
        }

        $this->repository->create_tables();
        update_option(self::OPTION_VERSION, FEUER_KONTAKTFORM_VERSION);
    }

    public function register_admin_menu(): void
    {
        add_menu_page('Feuer-Kontaktform', 'Feuer-Kontaktform', 'manage_options', self::MENU_SLUG, [$this, 'render_forms_page'], 'dashicons-email-alt2', 56);
        add_submenu_page(self::MENU_SLUG, 'Formulare', 'Formulare', 'manage_options', self::MENU_SLUG, [$this, 'render_forms_page']);
        add_submenu_page(self::MENU_SLUG, 'Neues Formular', 'Neues Formular', 'manage_options', 'feuer-kontaktform-formular', [$this, 'render_form_editor_page']);
        add_submenu_page(self::MENU_SLUG, 'Nachrichtenprotokoll', 'Nachrichtenprotokoll', 'manage_options', 'feuer-kontaktform-logs', [$this, 'render_logs_page']);
        add_submenu_page(self::MENU_SLUG, 'Einstellungen', 'Einstellungen', 'manage_options', 'feuer-kontaktform-einstellungen', [$this, 'render_settings_page']);
    }

    public function enqueue_admin_assets(string $hook): void
    {
        if (! str_contains($hook, 'feuer-kontaktform')) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (in_array($page, ['feuer-kontaktform-formular', 'feuer-kontaktform-einstellungen'], true)) {
            wp_enqueue_media();
        }

        wp_enqueue_style('feuer-kontaktform-admin', FEUER_KONTAKTFORM_URL . 'assets/css/admin.css', [], FEUER_KONTAKTFORM_VERSION);
        wp_enqueue_script('feuer-kontaktform-admin', FEUER_KONTAKTFORM_URL . 'assets/js/admin.js', [], FEUER_KONTAKTFORM_VERSION, true);
        wp_localize_script('feuer-kontaktform-admin', 'FeuerKontaktformAdmin', [
            'fieldDefaults' => $this->get_field_type_defaults(),
            'designVariants' => $this->get_design_variants(),
            'designFallbacks' => feuer_kontaktform_design_fallback_palette(),
        ]);
    }

    public function register_frontend_assets(): void
    {
        wp_register_style('feuer-kontaktform-frontend', FEUER_KONTAKTFORM_URL . 'assets/css/frontend.css', [], FEUER_KONTAKTFORM_VERSION);
        wp_register_script('feuer-kontaktform-frontend-script', FEUER_KONTAKTFORM_URL . 'assets/js/frontend.js', [], FEUER_KONTAKTFORM_VERSION, true);
    }

    public function handle_admin_requests(): void
    {
        if (! is_admin() || ! current_user_can('manage_options')) {
            return;
        }

        $this->handle_admin_get_actions();

        $action = isset($_POST['feuer-kontaktform-action']) ? sanitize_key(wp_unslash($_POST['feuer-kontaktform-action'])) : '';
        if ($action === '') {
            return;
        }

        switch ($action) {
            case 'save_form':
                $this->save_form();
                break;

            case 'save_settings':
                $this->save_settings();
                break;

            case 'test_smtp_connection':
                $this->test_smtp_connection();
                break;

            case 'send_test_email':
                $this->send_test_email();
                break;

            case 'check_plugin_update':
                $this->check_plugin_update();
                break;

            case 'import_form_json':
                $this->import_form_json();
                break;

            case 'add_blocked_ip':
                $this->add_blocked_ip();
                break;

            case 'add_blocked_email':
                $this->add_blocked_email();
                break;

            case 'save_submission_status':
                $this->save_submission_status();
                break;
        }
    }

    public function render_forms_page(): void
    {
        $cards = [];
        $settings = $this->get_settings();

        foreach ($this->resolve_forms($this->repository->get_forms()) as $form) {
            $recent = [];
            foreach ($this->repository->get_recent_submissions_for_form($form['id'], 5) as $submission) {
                $submission['created_display'] = $this->format_datetime($submission['created_at']);
                $recent[] = $submission;
            }

            $designs = $this->get_design_variants();

            $cards[] = [
                'form' => $form,
                'design_label' => $designs[$form['design_variant']]['label'] ?? $designs['design-1']['label'],
                'count' => $this->repository->get_submission_count($form['id']),
                'recent' => $recent,
                'file_state' => is_array($form['_file_sync'] ?? null) ? $form['_file_sync'] : [],
                'edit_url' => $this->admin_page_url('feuer-kontaktform-formular', ['id' => $form['id']]),
                'logs_url' => $this->admin_page_url('feuer-kontaktform-logs', ['form_id' => $form['id']]),
                'delete_url' => wp_nonce_url($this->admin_page_url(self::MENU_SLUG, ['feuer-kontaktform-action' => 'delete_form', 'id' => $form['id']]), 'feuer-kontaktform-delete-form'),
                'duplicate_url' => wp_nonce_url($this->admin_page_url(self::MENU_SLUG, ['feuer-kontaktform-action' => 'duplicate_form', 'id' => $form['id']]), 'feuer-kontaktform-duplicate-form'),
                'export_json_url' => wp_nonce_url($this->admin_page_url(self::MENU_SLUG, ['feuer-kontaktform-action' => 'export_form_json', 'id' => $form['id']]), 'feuer-kontaktform-export-form-json'),
                'direct_link' => $this->build_form_direct_link_data($form, $settings),
                'popup_shortcode' => sprintf('[feuer-kontaktform-popup slug="%s"]', esc_attr((string) $form['slug'])),
            ];
        }

        echo $this->view->render('admin/forms-list.php', [
            'notice' => $this->get_notice_from_query(),
            'cards' => $cards,
            'action_url' => $this->admin_page_url(self::MENU_SLUG),
        ]);
    }

    public function render_form_editor_page(): void
    {
        $form_id = isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0;
        $form    = $form_id > 0 ? $this->resolve_form($this->repository->get_form($form_id)) : null;
        $data    = $form ?? $this->get_empty_form();
        $errors  = [];
        $flash   = $this->get_request_flash();

        if (is_array($flash) && ($flash['type'] ?? '') === 'admin-form' && (int) ($flash['editor_form_id'] ?? 0) === $form_id) {
            $errors = is_array($flash['errors'] ?? null) ? $flash['errors'] : [];
            $data   = is_array($flash['data'] ?? null) ? $flash['data'] : $data;
        }

        $data['design_settings'] = feuer_kontaktform_normalize_design_settings($data['design_settings'] ?? []);
        $data['display_settings'] = feuer_kontaktform_normalize_display_settings($data['display_settings'] ?? []);
        $data['behavior_settings'] = feuer_kontaktform_normalize_behavior_settings($data['behavior_settings'] ?? []);

        if ($data['fields'] === []) {
            $data['fields'] = $this->get_default_form_fields();
        }

        $field_rows = '';
        foreach ($data['fields'] as $index => $field) {
            $field_rows .= $this->render_admin_field_row($field, (string) $index);
        }

        $settings = $this->get_settings();
        $topic_lines = [];
        foreach ((array) ($data['behavior_settings']['topics'] ?? []) as $topic) {
            if (! is_array($topic)) {
                continue;
            }

            $topic_lines[] = implode('|', [
                (string) ($topic['slug'] ?? ''),
                (string) ($topic['label'] ?? ''),
                (string) ($topic['recipient_email'] ?? ''),
                (string) ($topic['auto_reply_subject'] ?? ''),
                (string) ($topic['auto_reply_message'] ?? ''),
            ]);
        }

        echo $this->view->render('admin/form-editor.php', [
            'notice' => $this->get_notice_from_query(),
            'errors' => $errors,
            'form_id' => $form_id,
            'data' => $data,
            'brand' => feuer_kontaktform_brand_context($settings),
            'configuration_checks' => $this->get_form_configuration_checks($data),
            'design_variants' => $this->get_design_variants(),
            'design_palette' => feuer_kontaktform_design_fallback_palette(),
            'design_image_targets' => feuer_kontaktform_design_image_targets(),
            'action_url' => $this->admin_page_url('feuer-kontaktform-formular', $form_id > 0 ? ['id' => $form_id] : []),
            'overview_url' => $this->admin_page_url(self::MENU_SLUG),
            'settings_url' => $this->admin_page_url('feuer-kontaktform-einstellungen'),
            'file_state' => is_array($data['_file_sync'] ?? null) ? $data['_file_sync'] : [],
            'topic_lines' => $topic_lines,
            'field_rows' => $field_rows,
            'field_template' => $this->render_admin_field_row($this->get_empty_field(), '__INDEX__'),
            'direct_link' => $form_id > 0 ? $this->build_form_direct_link_data($data, $settings) : null,
        ]);
    }

    public function render_logs_page(): void
    {
        $form_id = isset($_GET['form_id']) ? absint(wp_unslash($_GET['form_id'])) : 0;
        $logs    = [];

        foreach ($this->repository->get_submissions($form_id, 100) as $submission) {
            $submission['created_display'] = $this->format_datetime($submission['created_at']);
            $logs[] = $submission;
        }

        echo $this->view->render('admin/logs.php', [
            'notice' => $this->get_notice_from_query(),
            'forms' => $this->resolve_forms($this->repository->get_forms()),
            'selected_form_id' => $form_id,
            'logs' => $logs,
            'action_url' => $this->admin_page_url('feuer-kontaktform-logs'),
            'export_csv_url' => wp_nonce_url($this->admin_page_url('feuer-kontaktform-logs', array_filter([
                'feuer-kontaktform-action' => 'export_csv',
                'form_id' => $form_id > 0 ? $form_id : null,
            ])), 'feuer-kontaktform-export-csv'),
            'status_options' => $this->get_submission_status_options(),
            'activity_logs' => $this->repository->get_activity_logs(50),
        ]);
    }

    public function render_settings_page(): void
    {
        $settings = $this->get_settings();
        $flash = $this->get_request_flash();
        $flash_settings = $this->get_request_admin_settings('feuer-kontaktform-einstellungen');
        if (is_array($flash_settings)) {
            $settings = wp_parse_args($flash_settings, $settings);
        }

        $notice = $this->get_request_admin_notice('feuer-kontaktform-einstellungen') ?? $this->get_notice_from_query();
        $blocked_ips = [];
        foreach ($this->repository->get_blocked_ips() as $item) {
            $item['created_display'] = $this->format_datetime($item['created_at']);
            $item['delete_url'] = wp_nonce_url($this->admin_page_url('feuer-kontaktform-einstellungen', ['feuer-kontaktform-action' => 'delete_blocked_ip', 'id' => $item['id']]), 'feuer-kontaktform-delete-blocked-ip');
            $blocked_ips[] = $item;
        }

        $blocked_emails = [];
        foreach ($this->repository->get_blocked_emails() as $item) {
            $item['created_display'] = $this->format_datetime($item['created_at']);
            $item['delete_url'] = wp_nonce_url($this->admin_page_url('feuer-kontaktform-einstellungen', ['feuer-kontaktform-action' => 'delete_blocked_email', 'id' => $item['id']]), 'feuer-kontaktform-delete-blocked-email');
            $blocked_emails[] = $item;
        }

        $forms = $this->resolve_forms($this->repository->get_forms());
        $form_links = [];
        foreach ($forms as $form) {
            $form_links[] = [
                'id' => (int) $form['id'],
                'title' => (string) $form['title'],
                'slug' => (string) $form['slug'],
                'link' => $this->build_form_direct_link_data($form, $settings),
            ];
        }

        echo $this->view->render('admin/settings.php', [
            'notice' => $notice,
            'settings' => $settings,
            'smtp_test_recipient' => is_array($flash) && ($flash['type'] ?? '') === 'admin-notice' && ($flash['page'] ?? '') === 'feuer-kontaktform-einstellungen'
                ? sanitize_email((string) ($flash['smtp_test_recipient'] ?? ''))
                : '',
            'action_url' => $this->admin_page_url('feuer-kontaktform-einstellungen'),
            'blocked_ips' => $blocked_ips,
            'blocked_emails' => $blocked_emails,
            'form_links' => $form_links,
            'update_status' => $this->updater->get_status(),
        ]);
    }

    public function render_single_form_shortcode(array $atts = []): string
    {
        $atts = shortcode_atts(['id' => 0, 'slug' => ''], $atts, 'feuer-kontaktform-formular');
        $form = (int) $atts['id'] > 0 ? $this->repository->get_form((int) $atts['id']) : $this->repository->get_form_by_slug((string) $atts['slug']);
        $form = $this->resolve_form($form);

        if (! is_array($form)) {
            return '<div class="feuer-kontaktform-box feuer-kontaktform-message feuer-kontaktform-error">Das angeforderte Formular wurde nicht gefunden.</div>';
        }

        wp_enqueue_style('feuer-kontaktform-frontend');
        wp_enqueue_script('feuer-kontaktform-frontend-script');

        $state = $this->resolve_frontend_state_for_form((int) $form['id']);

        return $this->render_frontend_form($form, $state, false);
    }

    public function render_all_forms_shortcode(array $atts = []): string
    {
        $forms = $this->resolve_forms($this->repository->get_forms());
        if ($forms === []) {
            return '<div class="feuer-kontaktform-box feuer-kontaktform-message">Derzeit sind keine Kontaktformulare verfuegbar.</div>';
        }

        wp_enqueue_style('feuer-kontaktform-frontend');
        wp_enqueue_script('feuer-kontaktform-frontend-script');

        $flash          = $this->get_request_flash();
        $request_result = $this->get_request_frontend_result();
        $selected_form = $this->resolve_selected_form_id($forms);
        if (is_array($request_result) && (int) ($request_result['form_id'] ?? 0) > 0) {
            $selected_form = (int) ($request_result['form_id'] ?? $selected_form);
        } elseif (is_array($flash) && ($flash['type'] ?? '') === 'frontend') {
            $selected_form = (int) ($flash['form_id'] ?? $selected_form);
        }

        $blocks = [];
        foreach ($forms as $form) {
            $state = $this->resolve_frontend_state_for_form((int) $form['id']);
            $blocks[] = $this->render_frontend_form($form, $state, (int) $form['id'] !== $selected_form);
        }

        return $this->view->render('frontend/all-forms.php', [
            'forms' => $forms,
            'selected_form_id' => $selected_form,
            'blocks' => $blocks,
            'show_selector' => $this->get_requested_form_query_value() === '',
        ]);
    }

    public function handle_frontend_submission(): void
    {
        $result = $this->process_frontend_submission($_POST);
        $form   = $result['form'] ?? null;

        if (! is_array($form)) {
            wp_die('Das Formular wurde nicht gefunden.');
        }

        $payload = $this->build_frontend_state_payload($result);

        $this->redirect_frontend_with_state(
            (string) ($result['redirect_to'] ?? $this->get_current_url()),
            $form,
            $payload,
            ! empty($result['success']) ? 300 : 900
        );
    }

    private function save_form(): void
    {
        check_admin_referer('feuer-kontaktform-save-form');

        $form_id               = isset($_POST['form_id']) ? absint(wp_unslash($_POST['form_id'])) : 0;
        $existing_form         = $form_id > 0 ? $this->repository->get_form($form_id) : null;
        $title                 = $this->truncate_input_value(sanitize_text_field(wp_unslash($_POST['title'] ?? '')), 190);
        $slug_raw              = sanitize_title(wp_unslash($_POST['slug'] ?? ''));
        $design_variant        = sanitize_key(wp_unslash($_POST['design_variant'] ?? 'design-1'));
        $design_settings_input = isset($_POST['design_settings']) && is_array($_POST['design_settings']) ? wp_unslash($_POST['design_settings']) : [];
        $design_settings       = feuer_kontaktform_normalize_design_settings($design_settings_input);
        $display_settings_input = isset($_POST['display_settings']) && is_array($_POST['display_settings']) ? wp_unslash($_POST['display_settings']) : [];
        $display_settings       = feuer_kontaktform_normalize_display_settings($display_settings_input);
        $behavior_settings_input = isset($_POST['behavior_settings']) && is_array($_POST['behavior_settings']) ? wp_unslash($_POST['behavior_settings']) : [];
        if (isset($behavior_settings_input['routing_rules_text'])) {
            $behavior_settings_input['routing_rules'] = $this->parse_routing_rules_text((string) $behavior_settings_input['routing_rules_text']);
        }
        if (isset($behavior_settings_input['topics_text'])) {
            $behavior_settings_input['topics'] = $this->parse_topics_text((string) $behavior_settings_input['topics_text']);
        }
        $behavior_settings       = feuer_kontaktform_normalize_behavior_settings($behavior_settings_input);
        $recipient_email_input = $this->truncate_input_value(sanitize_textarea_field(wp_unslash($_POST['recipient_email'] ?? '')), 1000);
        $recipient_email       = implode(', ', $this->normalize_email_list($recipient_email_input));
        $has_valid_recipients  = $this->has_valid_email_list($recipient_email_input);
        $auto_subject          = $this->truncate_input_value(sanitize_text_field(wp_unslash($_POST['auto_reply_subject'] ?? '')), 190);
        $auto_message          = $this->truncate_input_value(wp_kses_post(wp_unslash($_POST['auto_reply_message'] ?? '')), 12000);
        $fields_input          = isset($_POST['fields']) && is_array($_POST['fields']) ? wp_unslash($_POST['fields']) : [];
        $fields                = $this->normalize_admin_fields($fields_input);
        $fields                = $this->ensure_topic_field($fields, (array) ($behavior_settings['topics'] ?? []));
        $slug                  = $slug_raw !== '' ? $slug_raw : sanitize_title($title);
        $errors                = [];
        if (! isset($this->get_design_variants()[$design_variant])) {
            $design_variant = 'design-1';
        }

        if ($title === '') {
            $errors[] = 'Bitte geben Sie einen Formularnamen an.';
        }

        if ($slug === '') {
            $errors[] = 'Fuer dieses Formular konnte kein gueltiger Slug erzeugt werden.';
        }

        if (! $has_valid_recipients) {
            $errors[] = 'Bitte geben Sie eine gueltige Empfaenger-E-Mail an.';
        }

        if ($fields === []) {
            $errors[] = 'Bitte legen Sie mindestens ein Formularfeld an.';
        }

        $types = wp_list_pluck($fields, 'type');
        if (! in_array('email', $types, true)) {
            $errors[] = 'Jedes Formular benoetigt mindestens ein E-Mail-Feld.';
        }

        if (! array_intersect(['nachricht', 'textarea'], $types)) {
            $errors[] = 'Jedes Formular benoetigt mindestens ein Nachrichtenfeld.';
        }

        foreach ($fields as $field) {
            $field_type = (string) ($field['type'] ?? '');
            $field_label = (string) ($field['label'] ?? '');
            $options = is_array($field['options'] ?? null) ? array_values(array_filter(array_map('strval', $field['options']))) : [];

            if (in_array($field_type, ['select', 'radio'], true) && count($options) < 2) {
                $errors[] = sprintf('Das Feld "%s" benoetigt mindestens zwei Auswahloptionen.', $field_label !== '' ? $field_label : 'Auswahl');
            }
        }

        if ($this->repository->get_form_by_slug_excluding_id($slug, $form_id) !== null) {
            $errors[] = 'Der Slug ist bereits vergeben.';
        }

        if ($errors !== []) {
            $flash = $this->create_flash([
                'type' => 'admin-form',
                'editor_form_id' => $form_id,
                'errors' => $errors,
                'data' => [
                    'id' => $form_id,
                    'title' => $title,
                    'slug' => $slug,
                    'design_variant' => $design_variant,
                    'design_settings' => $design_settings,
                    'display_settings' => $display_settings,
                    'behavior_settings' => $behavior_settings,
                    'recipient_email' => $recipient_email,
                    'auto_reply_subject' => $auto_subject,
                    'auto_reply_message' => $auto_message,
                    'fields' => $fields !== [] ? $fields : $this->get_default_form_fields(),
                ],
            ]);

            $this->redirect_admin('feuer-kontaktform-formular', ['id' => $form_id, 'feuer-kontaktform-flash' => $flash]);
        }

        $saved_id = $this->repository->save_form([
            'title' => $title,
            'slug' => $slug,
            'design_variant' => $design_variant,
            'design_settings' => $design_settings,
            'display_settings' => $display_settings,
            'behavior_settings' => $behavior_settings,
            'recipient_email' => $recipient_email,
            'auto_reply_subject' => $auto_subject,
            'auto_reply_message' => $auto_message,
            'fields' => $fields,
        ], $form_id);

        $saved_form = $this->repository->get_form($saved_id);
        $file_write = is_array($saved_form)
            ? $this->form_files->write_form($saved_form, (string) ($existing_form['slug'] ?? ''))
            : ['success' => false];
        $style_write = is_array($saved_form)
            ? $this->form_files->ensure_form_stylesheet($saved_form, $this->build_frontend_design_css($saved_form))
            : ['success' => false];

        $this->repository->insert_activity_log(
            $form_id > 0 ? 'form_updated' : 'form_created',
            'form',
            $saved_id,
            ($form_id > 0 ? 'Formular aktualisiert: ' : 'Formular erstellt: ') . $title,
            ['slug' => $slug, 'fields' => count($fields)]
        );

        $this->redirect_admin('feuer-kontaktform-formular', [
            'id' => $saved_id,
            'feuer-kontaktform-notice' => ! empty($file_write['success']) && ! empty($style_write['success']) ? 'form_saved' : 'form_saved_file_warning',
        ]);
    }

    private function save_settings(): void
    {
        check_admin_referer('feuer-kontaktform-save-settings');

        $previous = $this->get_settings();
        $settings = $this->sanitize_settings_from_request($_POST, $previous);

        update_option(self::OPTION_SETTINGS, $settings);
        if (
            (string) ($previous['forms_page_url'] ?? '') !== (string) ($settings['forms_page_url'] ?? '')
            || ! empty($previous['rewrite_enabled']) !== ! empty($settings['rewrite_enabled'])
        ) {
            flush_rewrite_rules(false);
        }
        $this->repository->insert_activity_log('settings_saved', 'settings', 0, 'Plugin-Einstellungen gespeichert.');
        $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'settings_saved']);
    }

    private function test_smtp_connection(): void
    {
        check_admin_referer('feuer-kontaktform-save-settings');

        $settings = $this->sanitize_settings_from_request($_POST, $this->get_settings());
        $result = $this->mailer->test_smtp_connection($settings);
        $settings_preview = $this->prepare_settings_preview($settings);

        $message = ! empty($result['success'])
            ? 'SMTP-Verbindung erfolgreich geprueft.'
            : 'SMTP-Verbindung fehlgeschlagen: ' . (string) ($result['details'] ?? 'Unbekannter Fehler.');

        $this->redirect_admin_with_flash_notice(
            'feuer-kontaktform-einstellungen',
            ! empty($result['success']) ? 'success' : 'error',
            $message,
            ['settings' => $settings_preview]
        );
    }

    private function send_test_email(): void
    {
        check_admin_referer('feuer-kontaktform-save-settings');

        $settings = $this->sanitize_settings_from_request($_POST, $this->get_settings());
        $settings_preview = $this->prepare_settings_preview($settings);
        $recipient = sanitize_email((string) wp_unslash($_POST['smtp_test_recipient'] ?? ''));
        if (! is_email($recipient)) {
            $this->redirect_admin_with_flash_notice(
                'feuer-kontaktform-einstellungen',
                'error',
                'Bitte geben Sie eine gueltige Empfaengeradresse fuer die Test-E-Mail an.',
                ['settings' => $settings_preview]
            );
        }

        $result = $this->mailer->send_test_email($settings, $recipient);

        $message = ! empty($result['success'])
            ? 'Test-E-Mail erfolgreich an ' . $recipient . ' gesendet.'
            : 'Test-E-Mail fehlgeschlagen: ' . (string) ($result['details'] ?? 'Unbekannter Fehler.');

        $this->redirect_admin_with_flash_notice(
            'feuer-kontaktform-einstellungen',
            ! empty($result['success']) ? 'success' : 'error',
            $message,
            ['settings' => $settings_preview, 'smtp_test_recipient' => $recipient]
        );
    }

    private function check_plugin_update(): void
    {
        check_admin_referer('feuer-kontaktform-save-settings');

        $settings = $this->sanitize_settings_from_request($_POST, $this->get_settings());
        $settings_preview = $this->prepare_settings_preview($settings);
        $result = $this->updater->check_now();
        $this->repository->insert_activity_log('update_checked', 'plugin', 0, 'Plugin-Update manuell geprueft.', [
            'remote_version' => (string) ($result['version'] ?? ''),
            'error' => (string) ($result['error'] ?? ''),
        ]);

        if (($result['error'] ?? '') !== '') {
            $this->redirect_admin_with_flash_notice(
                'feuer-kontaktform-einstellungen',
                'error',
                'Update-Pruefung fehlgeschlagen: ' . (string) $result['error'],
                ['settings' => $settings_preview]
            );
        }

        if (! empty($result['update_available'])) {
            $this->redirect_admin_with_flash_notice(
                'feuer-kontaktform-einstellungen',
                'success',
                'Neue Version ' . (string) $result['version'] . ' ist verfuegbar.',
                ['settings' => $settings_preview]
            );
        }

        $this->redirect_admin_with_flash_notice(
            'feuer-kontaktform-einstellungen',
            'success',
            'Keine neue Version gefunden. Installiert ist Version ' . FEUER_KONTAKTFORM_VERSION . '.',
            ['settings' => $settings_preview]
        );
    }

    private function sanitize_settings_from_request(array $source, array $previous = []): array
    {
        $defaults = feuer_kontaktform_default_settings();
        $previous = wp_parse_args($previous, $defaults);

        $sender_name = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['sender_name'] ?? $previous['sender_name'])), 120);
        $sender_email = sanitize_email((string) wp_unslash($source['sender_email'] ?? $previous['sender_email']));
        $default_success_message = $this->truncate_input_value(sanitize_textarea_field((string) wp_unslash($source['default_success_message'] ?? $previous['default_success_message'])), 500);
        $default_auto_reply_subject = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['default_auto_reply_subject'] ?? $previous['default_auto_reply_subject'])), 190);
        $default_auto_reply_message = $this->truncate_input_value(wp_kses_post((string) wp_unslash($source['default_auto_reply_message'] ?? $previous['default_auto_reply_message'])), 12000);
        $brand_logo_url = feuer_kontaktform_normalize_local_asset_url((string) wp_unslash($source['brand_logo_url'] ?? $previous['brand_logo_url']));
        $brand_logo_width = max(60, min(320, (int) ($source['brand_logo_width'] ?? $previous['brand_logo_width'])));
        $brand_label = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['brand_label'] ?? $previous['brand_label'])), 120);
        $brand_tagline = $this->truncate_input_value(sanitize_textarea_field((string) wp_unslash($source['brand_tagline'] ?? $previous['brand_tagline'])), 1000);
        $brand_website_url = esc_url_raw((string) wp_unslash($source['brand_website_url'] ?? $previous['brand_website_url']));
        $brand_website_text = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['brand_website_text'] ?? $previous['brand_website_text'])), 190);
        $forms_page_url = esc_url_raw((string) wp_unslash($source['forms_page_url'] ?? $previous['forms_page_url']));
        $privacy_policy_url = esc_url_raw((string) wp_unslash($source['privacy_policy_url'] ?? $previous['privacy_policy_url']));
        $privacy_notice_text = $this->truncate_input_value(sanitize_textarea_field((string) wp_unslash($source['privacy_notice_text'] ?? $previous['privacy_notice_text'])), 500);
        $privacy_notice_version = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['privacy_notice_version'] ?? $previous['privacy_notice_version'])), 60);
        $allowed_referrer_hosts = $this->truncate_input_value(sanitize_textarea_field((string) wp_unslash($source['allowed_referrer_hosts'] ?? $previous['allowed_referrer_hosts'])), 2000);
        $log_retention_days = max(0, min(3650, (int) ($source['log_retention_days'] ?? $previous['log_retention_days'])));
        $webhook_url = esc_url_raw((string) wp_unslash($source['webhook_url'] ?? $previous['webhook_url']));
        $webhook_timeout = max(3, min(30, (int) ($source['webhook_timeout'] ?? $previous['webhook_timeout'])));
        $admin_notification_email = sanitize_email((string) wp_unslash($source['admin_notification_email'] ?? $previous['admin_notification_email']));
        $popup_button_label = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['popup_button_label'] ?? $previous['popup_button_label'])), 120);
        $smtp_host = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['smtp_host'] ?? $previous['smtp_host'])), 190);
        $smtp_port = max(1, min(65535, (int) ($source['smtp_port'] ?? $previous['smtp_port'])));
        $smtp_encryption = sanitize_key((string) wp_unslash($source['smtp_encryption'] ?? $previous['smtp_encryption']));
        $smtp_username = $this->truncate_input_value(sanitize_text_field((string) wp_unslash($source['smtp_username'] ?? $previous['smtp_username'])), 190);
        $smtp_timeout = max(3, min(60, (int) ($source['smtp_timeout'] ?? $previous['smtp_timeout'])));
        $smtp_password_input = array_key_exists('smtp_password', $source) ? (string) wp_unslash($source['smtp_password']) : '';
        $smtp_password = $this->sanitize_secret_value($smtp_password_input, 255);

        if (! in_array($smtp_encryption, ['none', 'tls', 'ssl'], true)) {
            $smtp_encryption = (string) $defaults['smtp_encryption'];
        }

        if ($sender_name === '') {
            $sender_name = (string) $defaults['sender_name'];
        }

        if (! is_email($sender_email)) {
            $sender_email = sanitize_email((string) $defaults['sender_email']);
        }

        if ($default_success_message === '') {
            $default_success_message = (string) $defaults['default_success_message'];
        }

        if ($default_auto_reply_subject === '') {
            $default_auto_reply_subject = (string) $defaults['default_auto_reply_subject'];
        }

        if ($default_auto_reply_message === '') {
            $default_auto_reply_message = (string) $defaults['default_auto_reply_message'];
        }

        if ($brand_label === '') {
            $brand_label = (string) $defaults['brand_label'];
        }

        if ($brand_tagline === '') {
            $brand_tagline = (string) $defaults['brand_tagline'];
        }

        if ($brand_website_url === '') {
            $brand_website_url = (string) $defaults['brand_website_url'];
        }

        if ($brand_website_text === '') {
            $brand_website_text = (string) $defaults['brand_website_text'];
        }

        if ($privacy_notice_text === '') {
            $privacy_notice_text = (string) $defaults['privacy_notice_text'];
        }

        if ($privacy_notice_version === '') {
            $privacy_notice_version = (string) $defaults['privacy_notice_version'];
        }

        if ($admin_notification_email !== '' && ! is_email($admin_notification_email)) {
            $admin_notification_email = '';
        }

        if ($popup_button_label === '') {
            $popup_button_label = (string) $defaults['popup_button_label'];
        }

        if ($smtp_password === '') {
            $smtp_password = (string) ($previous['smtp_password'] ?? '');
        }

        return [
            'sender_name' => $sender_name,
            'sender_email' => $sender_email,
            'default_success_message' => $default_success_message,
            'default_auto_reply_subject' => $default_auto_reply_subject,
            'default_auto_reply_message' => $default_auto_reply_message,
            'brand_logo_url' => $brand_logo_url,
            'brand_logo_width' => $brand_logo_width,
            'brand_label' => $brand_label,
            'brand_tagline' => $brand_tagline,
            'brand_website_url' => $brand_website_url,
            'brand_website_text' => $brand_website_text,
            'forms_page_url' => $forms_page_url,
            'privacy_policy_url' => $privacy_policy_url,
            'privacy_notice_text' => $privacy_notice_text,
            'privacy_notice_version' => $privacy_notice_version,
            'allowed_referrer_hosts' => $allowed_referrer_hosts,
            'log_retention_days' => $log_retention_days,
            'webhook_url' => $webhook_url,
            'webhook_timeout' => $webhook_timeout,
            'admin_notification_email' => $admin_notification_email,
            'rewrite_enabled' => ! empty($source['rewrite_enabled']),
            'popup_button_label' => $popup_button_label,
            'smtp_enabled' => ! empty($source['smtp_enabled']),
            'smtp_host' => $smtp_host,
            'smtp_port' => $smtp_port,
            'smtp_encryption' => $smtp_encryption,
            'smtp_auth' => ! empty($source['smtp_auth']),
            'smtp_username' => $smtp_username,
            'smtp_password' => $smtp_password,
            'smtp_timeout' => $smtp_timeout,
        ];
    }

    private function sanitize_secret_value(string $value, int $limit = 255): string
    {
        $value = preg_replace('/[\r\n\x00]+/u', '', $value) ?? $value;
        return $this->truncate_input_value($value, $limit);
    }

    private function prepare_settings_preview(array $settings): array
    {
        unset($settings['smtp_password']);

        return $settings;
    }

    private function add_blocked_ip(): void
    {
        check_admin_referer('feuer-kontaktform-add-blocked-ip');

        $ip     = sanitize_text_field(wp_unslash($_POST['ip_address'] ?? ''));
        $reason = $this->truncate_input_value(sanitize_text_field(wp_unslash($_POST['reason'] ?? '')), 255);

        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
            $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'invalid_ip']);
        }

        $this->repository->add_blocked_ip($ip, $reason);
        $this->repository->insert_activity_log('blocked_ip_added', 'blocked_ip', 0, 'IP-Adresse gesperrt: ' . $ip, ['reason' => $reason]);
        $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'blocked_ip_saved']);
    }

    private function add_blocked_email(): void
    {
        check_admin_referer('feuer-kontaktform-add-blocked-email');

        $email  = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $reason = $this->truncate_input_value(sanitize_text_field(wp_unslash($_POST['reason'] ?? '')), 255);

        if (! is_email($email)) {
            $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'invalid_email']);
        }

        $this->repository->add_blocked_email($email, $reason);
        $this->repository->insert_activity_log('blocked_email_added', 'blocked_email', 0, 'Autoantwort fuer E-Mail gesperrt: ' . $email, ['reason' => $reason]);
        $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'blocked_email_saved']);
    }

    private function handle_admin_get_actions(): void
    {
        $action = isset($_GET['feuer-kontaktform-action']) ? sanitize_key(wp_unslash($_GET['feuer-kontaktform-action'])) : '';
        if ($action === '') {
            return;
        }

        switch ($action) {
            case 'delete_form':
                check_admin_referer('feuer-kontaktform-delete-form');
                $form = $this->repository->get_form(isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0);
                if (is_array($form)) {
                    $this->form_files->delete_form_file($form);
                    $this->repository->delete_form((int) $form['id']);
                    $this->repository->insert_activity_log('form_deleted', 'form', (int) $form['id'], 'Formular geloescht: ' . (string) ($form['title'] ?? ''));
                }
                $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'form_deleted']);
                break;

            case 'duplicate_form':
                check_admin_referer('feuer-kontaktform-duplicate-form');
                $this->duplicate_form(isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0);
                break;

            case 'export_form_json':
                check_admin_referer('feuer-kontaktform-export-form-json');
                $this->export_form_json(isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0);
                break;

            case 'export_csv':
                check_admin_referer('feuer-kontaktform-export-csv');
                $this->export_submissions_csv(isset($_GET['form_id']) ? absint(wp_unslash($_GET['form_id'])) : 0);
                break;

            case 'delete_blocked_ip':
                check_admin_referer('feuer-kontaktform-delete-blocked-ip');
                $this->repository->delete_blocked_ip(isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0);
                $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'blocked_ip_deleted']);
                break;

            case 'delete_blocked_email':
                check_admin_referer('feuer-kontaktform-delete-blocked-email');
                $this->repository->delete_blocked_email(isset($_GET['id']) ? absint(wp_unslash($_GET['id'])) : 0);
                $this->redirect_admin('feuer-kontaktform-einstellungen', ['feuer-kontaktform-notice' => 'blocked_email_deleted']);
                break;
        }
    }

    public function render_admin_field_row(array $field, string $index): string
    {
        return $this->view->render('admin/partials/field-row.php', [
            'field' => $field,
            'index' => $index,
            'field_types' => [
                'vorname' => 'Vorname',
                'nachname' => 'Nachname',
                'email' => 'E-Mail',
                'telefon' => 'Telefon',
                'nachricht' => 'Nachricht',
                'kind_name' => 'Name des Kindes',
                'kind_alter' => 'Alter des Kindes',
                'text' => 'Freies Textfeld',
                'textarea' => 'Freies Textfeld (mehrzeilig)',
                'select' => 'Auswahl',
                'radio' => 'Radio-Auswahl',
                'date' => 'Datum',
                'time' => 'Uhrzeit',
            ],
            'width_options' => $this->get_field_width_options(),
            'textarea_size_options' => $this->get_textarea_size_options(),
        ]);
    }

    public function format_datetime(string $datetime): string
    {
        $timestamp = strtotime($datetime);
        return $timestamp === false ? $datetime : wp_date('d.m.Y H:i', $timestamp);
    }

    private function render_frontend_form(array $form, array $state, bool $hidden): string
    {
        $settings = $this->get_settings();
        $behavior = feuer_kontaktform_normalize_behavior_settings($form['behavior_settings'] ?? []);
        $form['fields'] = $this->ensure_topic_field(is_array($form['fields'] ?? null) ? $form['fields'] : [], (array) ($behavior['topics'] ?? []));
        $design_variants = $this->get_design_variants();
        $design_variant_key = sanitize_key((string) ($form['design_variant'] ?? 'design-1'));
        $design_variant_meta = $design_variants[$design_variant_key] ?? $design_variants['design-1'];
        wp_enqueue_script('feuer-kontaktform-frontend-script');
        $custom_css = $this->build_frontend_design_css($form);
        if ($custom_css !== '') {
            wp_add_inline_style('feuer-kontaktform-frontend', $custom_css);
        }
        if (! $hidden) {
            $this->maybe_log_form_view($form);
        }

        return $this->view->render('frontend/single-form.php', [
            'form' => $form,
            'state' => $state,
            'hidden' => $hidden,
            'brand' => feuer_kontaktform_brand_context($settings),
            'privacy_policy_url' => esc_url_raw((string) ($settings['privacy_policy_url'] ?? '')),
            'privacy_notice_text' => (string) ($settings['privacy_notice_text'] ?? ''),
            'privacy_notice_version' => (string) ($settings['privacy_notice_version'] ?? ''),
            'behavior_settings' => $behavior,
            'design_variant_key' => $design_variant_key,
            'design_variant_meta' => $design_variant_meta,
            'render_partial' => fn (string $template, array $vars = []): string => $this->view->render($template, $vars),
            'redirect_to' => $this->get_current_url(),
            'action_url' => admin_url('admin-post.php'),
            'ajax_url' => admin_url('admin-ajax.php'),
            'input_type_resolver' => fn (string $type): string => $this->get_frontend_input_type($type),
        ]);
    }

    private function get_settings(): array
    {
        $stored_settings = get_option(self::OPTION_SETTINGS, []);
        return wp_parse_args(is_array($stored_settings) ? $stored_settings : [], feuer_kontaktform_default_settings());
    }

    private function is_submission_rate_limited(int $form_id, string $ip_address): bool
    {
        return get_transient($this->get_submission_rate_limit_key($form_id, $ip_address)) !== false;
    }

    private function mark_submission_attempt(int $form_id, string $ip_address): void
    {
        set_transient($this->get_submission_rate_limit_key($form_id, $ip_address), time(), self::RATE_LIMIT_SECONDS);
    }

    private function get_submission_rate_limit_key(int $form_id, string $ip_address): string
    {
        $fingerprint = $form_id . '|' . ($ip_address !== '' ? $ip_address : 'unknown');
        return self::RATE_LIMIT_PREFIX . hash_hmac('sha256', $fingerprint, wp_salt('nonce'));
    }

    private function maybe_log_form_view(array $form): void
    {
        if (is_admin()) {
            return;
        }

        $form_id = (int) ($form['id'] ?? 0);
        if ($form_id <= 0) {
            return;
        }

        $ip_address = $this->get_user_ip();
        $user_agent = $this->get_user_agent();
        $key = 'feuer-kontaktform-view-' . hash_hmac('sha256', $form_id . '|' . $ip_address . '|' . $user_agent, wp_salt('nonce'));
        if (get_transient($key) !== false) {
            return;
        }

        set_transient($key, '1', 15 * MINUTE_IN_SECONDS);
        $this->repository->insert_activity_log('form_viewed', 'form', $form_id, 'Kontaktformular angezeigt: ' . (string) ($form['title'] ?? ''), [
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'device_type' => $this->detect_device_type($user_agent),
        ]);
    }

    private function resolve_form(?array $form): ?array
    {
        return is_array($form) ? $this->form_files->sync_form($form) : null;
    }

    private function resolve_forms(array $forms): array
    {
        $resolved = [];

        foreach ($forms as $form) {
            if (! is_array($form)) {
                continue;
            }

            $resolved[] = $this->form_files->sync_form($form);
        }

        return $resolved;
    }

    private function get_notice_from_query(): ?array
    {
        $key = isset($_GET['feuer-kontaktform-notice']) ? sanitize_key(wp_unslash($_GET['feuer-kontaktform-notice'])) : '';
        $messages = [
            'form_saved' => ['success', 'Das Formular wurde gespeichert.'],
            'form_saved_file_warning' => ['warning', 'Das Formular wurde gespeichert, aber die JSON-Datei konnte nicht geschrieben werden.'],
            'form_deleted' => ['success', 'Das Formular und die zugehoerigen Nachrichten wurden geloescht.'],
            'form_duplicated' => ['success', 'Das Formular wurde dupliziert.'],
            'form_imported' => ['success', 'Das Formular wurde aus JSON importiert.'],
            'import_invalid' => ['error', 'Der JSON-Import konnte nicht verarbeitet werden.'],
            'settings_saved' => ['success', 'Die Einstellungen wurden gespeichert.'],
            'status_saved' => ['success', 'Der Status wurde gespeichert.'],
            'blocked_ip_saved' => ['success', 'Die IP-Adresse wurde gespeichert.'],
            'blocked_ip_deleted' => ['success', 'Die IP-Adresse wurde entfernt.'],
            'blocked_email_saved' => ['success', 'Die E-Mail-Adresse wurde gespeichert.'],
            'blocked_email_deleted' => ['success', 'Die E-Mail-Adresse wurde entfernt.'],
            'invalid_ip' => ['error', 'Bitte geben Sie eine gueltige IP-Adresse an.'],
            'invalid_email' => ['error', 'Bitte geben Sie eine gueltige E-Mail-Adresse an.'],
        ];

        if (! isset($messages[$key])) {
            return null;
        }

        return ['type' => $messages[$key][0], 'message' => $messages[$key][1]];
    }

    private function admin_page_url(string $page, array $args = []): string
    {
        return add_query_arg(array_merge(['page' => $page], $args), admin_url('admin.php'));
    }

    private function redirect_admin(string $page, array $args = []): void
    {
        wp_safe_redirect($this->admin_page_url($page, $args));
        exit;
    }

    private function create_flash(array $payload, int $ttl = 900): string
    {
        $token = strtolower(wp_generate_password(20, false, false));
        set_transient(self::FLASH_PREFIX . $token, $payload, $ttl);
        return $token;
    }

    private function get_request_flash(): ?array
    {
        if ($this->request_flash_loaded) {
            return $this->request_flash;
        }

        $this->request_flash_loaded = true;
        $token = isset($_GET['feuer-kontaktform-flash']) ? sanitize_text_field(wp_unslash($_GET['feuer-kontaktform-flash'])) : '';
        if ($token === '') {
            return null;
        }

        $flash = get_transient(self::FLASH_PREFIX . $token);
        if (! is_array($flash)) {
            return null;
        }

        delete_transient(self::FLASH_PREFIX . $token);
        $this->request_flash = $flash;

        return $flash;
    }

    private function get_request_admin_notice(string $page): ?array
    {
        $flash = $this->get_request_flash();
        if (! is_array($flash) || ($flash['type'] ?? '') !== 'admin-notice' || ($flash['page'] ?? '') !== $page) {
            return null;
        }

        $notice = is_array($flash['notice'] ?? null) ? $flash['notice'] : null;
        if (! is_array($notice)) {
            return null;
        }

        $type = sanitize_key((string) ($notice['type'] ?? ''));
        $message = sanitize_text_field((string) ($notice['message'] ?? ''));
        if ($type === '' || $message === '') {
            return null;
        }

        return [
            'type' => $type,
            'message' => $message,
        ];
    }

    private function get_request_admin_settings(string $page): ?array
    {
        $flash = $this->get_request_flash();
        if (! is_array($flash) || ($flash['type'] ?? '') !== 'admin-notice' || ($flash['page'] ?? '') !== $page) {
            return null;
        }

        return is_array($flash['settings'] ?? null) ? $flash['settings'] : null;
    }

    private function redirect_admin_with_flash_notice(string $page, string $type, string $message, array $payload = []): void
    {
        $flash_payload = array_merge([
            'type' => 'admin-notice',
            'page' => $page,
            'notice' => [
                'type' => sanitize_key($type),
                'message' => sanitize_text_field($message),
            ],
        ], $payload);

        $flash = $this->create_flash($flash_payload, 900);
        $this->redirect_admin($page, ['feuer-kontaktform-flash' => $flash]);
    }

    private function get_request_frontend_result(): ?array
    {
        if ($this->request_frontend_result_loaded) {
            return $this->request_frontend_result;
        }

        $this->request_frontend_result_loaded = true;

        if (is_admin() || strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
            return null;
        }

        $action = sanitize_text_field((string) wp_unslash($_POST['action'] ?? ''));
        if ($action !== 'feuer-kontaktform-submit' || empty($_POST['form_id']) || empty($_POST['feuer-kontaktform-nonce'])) {
            return null;
        }

        $this->request_frontend_result = $this->process_frontend_submission($_POST);

        return $this->request_frontend_result;
    }

    private function build_frontend_state_payload(array $result): array
    {
        $payload = [
            'type' => 'frontend',
            'form_id' => (int) ($result['form_id'] ?? 0),
            'success' => ! empty($result['success']),
            'message' => (string) ($result['message'] ?? ''),
            'values' => is_array($result['values'] ?? null) ? $result['values'] : [],
            'errors' => is_array($result['errors'] ?? null) ? $result['errors'] : [],
            'field_errors' => is_array($result['field_errors'] ?? null) ? $result['field_errors'] : [],
            'privacy_accepted' => ! empty($result['privacy_accepted']),
            'ticket_code' => (string) ($result['ticket_code'] ?? ''),
            'submission_id' => (int) ($result['submission_id'] ?? 0),
        ];

        if (is_array($result['captcha'] ?? null) && $result['captcha'] !== []) {
            $payload['captcha'] = $result['captcha'];
        }

        return $payload;
    }

    private function resolve_frontend_state_for_form(int $form_id): array
    {
        $request_result = $this->get_request_frontend_result();
        if (is_array($request_result) && (int) ($request_result['form_id'] ?? 0) === $form_id) {
            return $this->build_frontend_state_payload($request_result);
        }

        $flash = $this->get_request_flash();
        if (is_array($flash) && ($flash['type'] ?? '') === 'frontend' && (int) ($flash['form_id'] ?? 0) === $form_id) {
            return $flash;
        }

        return [];
    }

    private function redirect_frontend_with_state(string $redirect_to, array $form, array $payload, int $ttl = 900): void
    {
        $form_id = (int) ($form['id'] ?? 0);
        $flash   = $this->create_flash($payload, $ttl);
        $url     = add_query_arg(
            [
                'feuer-kontaktform-flash' => $flash,
                self::FORM_QUERY_ARG => $this->get_form_query_value($form),
            ],
            remove_query_arg(['feuer-kontaktform-flash'], $redirect_to)
        );

        if ($form_id > 0) {
            $url .= '#feuer-kontaktform-form-' . $form_id;
        }

        wp_safe_redirect($url);
        exit;
    }

    private function sanitize_redirect_target(string $redirect_to): string
    {
        return (string) wp_validate_redirect($redirect_to !== '' ? $redirect_to : home_url('/'), home_url('/'));
    }

    private function get_current_url(): string
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
        return remove_query_arg(['feuer-kontaktform-flash'], home_url($request_uri));
    }

    private function get_form_configuration_checks(array $data): array
    {
        $fields = is_array($data['fields'] ?? null) ? $data['fields'] : [];
        $types = wp_list_pluck($fields, 'type');
        $recipient_email = trim((string) ($data['recipient_email'] ?? ''));

        return [
            [
                'ok' => trim((string) ($data['title'] ?? '')) !== '',
                'label' => 'Formularname ist gesetzt',
            ],
            [
                'ok' => $recipient_email !== '' && $this->has_valid_email_list($recipient_email),
                'label' => 'Mindestens eine gueltige Empfaenger-E-Mail ist hinterlegt',
            ],
            [
                'ok' => $fields !== [],
                'label' => 'Mindestens ein Feld ist angelegt',
            ],
            [
                'ok' => in_array('email', $types, true),
                'label' => 'Mindestens ein E-Mail-Feld ist vorhanden',
            ],
            [
                'ok' => array_intersect(['nachricht', 'textarea'], $types) !== [],
                'label' => 'Mindestens ein Nachrichtenfeld ist vorhanden',
            ],
        ];
    }

    private function resolve_selected_form_id(array $forms): int
    {
        if ($forms === []) {
            return 0;
        }

        $requested = $this->find_form_by_query_value($forms, $this->get_requested_form_query_value());
        if (is_array($requested)) {
            return (int) $requested['id'];
        }

        return (int) $forms[0]['id'];
    }

    private function get_requested_form_query_value(): string
    {
        $query_var = get_query_var(self::FORM_QUERY_ARG, '');
        if (is_string($query_var) && $query_var !== '') {
            return sanitize_text_field($query_var);
        }

        $raw = $_GET[self::FORM_QUERY_ARG] ?? '';
        if (is_array($raw)) {
            return '';
        }

        return sanitize_text_field((string) wp_unslash($raw));
    }

    private function find_form_by_query_value(array $forms, string $query_value): ?array
    {
        if ($query_value === '') {
            return null;
        }

        if (ctype_digit($query_value)) {
            $requested_id = (int) $query_value;
            foreach ($forms as $form) {
                if ((int) ($form['id'] ?? 0) === $requested_id) {
                    return $form;
                }
            }
        }

        $requested_slug = sanitize_title($query_value);
        if ($requested_slug === '') {
            return null;
        }

        foreach ($forms as $form) {
            if (sanitize_title((string) ($form['slug'] ?? '')) === $requested_slug) {
                return $form;
            }
        }

        return null;
    }

    private function get_form_query_value(array $form): string
    {
        $slug = sanitize_title((string) ($form['slug'] ?? ''));
        if ($slug !== '') {
            return $slug;
        }

        return (string) ((int) ($form['id'] ?? 0));
    }

    private function build_form_direct_link_data(array $form, array $settings): array
    {
        $query_value = $this->get_form_query_value($form);
        $query_code  = '?' . self::FORM_QUERY_ARG . '=' . rawurlencode($query_value);
        $url         = '';
        $pretty_url  = '';
        $base_url    = $this->get_forms_page_url($settings);

        if ($base_url !== '') {
            $url = add_query_arg(
                [self::FORM_QUERY_ARG => $query_value],
                remove_query_arg(['feuer-kontaktform-flash', self::FORM_QUERY_ARG], $base_url)
            );

            if (! empty($form['id'])) {
                $url .= '#feuer-kontaktform-form-' . (int) $form['id'];
            }

            if (! empty($settings['rewrite_enabled'])) {
                $pretty_url = trailingslashit(remove_query_arg(['feuer-kontaktform-flash', self::FORM_QUERY_ARG], $base_url)) . rawurlencode($query_value) . '/';
                if (! empty($form['id'])) {
                    $pretty_url .= '#feuer-kontaktform-form-' . (int) $form['id'];
                }
            }
        }

        return [
            'query_value' => $query_value,
            'query_code' => $query_code,
            'url' => $url,
            'pretty_url' => $pretty_url,
        ];
    }

    private function get_forms_page_url(array $settings): string
    {
        return esc_url_raw((string) ($settings['forms_page_url'] ?? ''));
    }

    private function get_user_ip(): string
    {
        $remote_addr = ! empty($_SERVER['REMOTE_ADDR']) ? trim((string) wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        if ($remote_addr === '' || ! filter_var($remote_addr, FILTER_VALIDATE_IP)) {
            return '';
        }

        if (! $this->is_trusted_proxy_ip($remote_addr)) {
            return $remote_addr;
        }

        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP'] as $header_name) {
            $candidate = $_SERVER[$header_name] ?? '';
            if (! is_array($candidate)) {
                $candidate = trim((string) wp_unslash($candidate));
                if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP)) {
                    return $candidate;
                }
            }
        }

        $forwarded = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
        if (! is_array($forwarded) && $forwarded !== '') {
            foreach (explode(',', (string) wp_unslash($forwarded)) as $candidate) {
                $candidate = trim((string) $candidate);
                if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP)) {
                    return $candidate;
                }
            }
        }

        return $remote_addr;
    }

    private function is_trusted_proxy_ip(string $ip_address): bool
    {
        $trusted_proxies = apply_filters('feuer-kontaktform-trusted-proxies', []);
        if (! is_array($trusted_proxies) || $trusted_proxies === []) {
            return false;
        }

        foreach ($trusted_proxies as $trusted_proxy) {
            if (! is_string($trusted_proxy) || trim($trusted_proxy) === '') {
                continue;
            }

            if ($ip_address === trim($trusted_proxy)) {
                return true;
            }
        }

        return false;
    }

    private function get_user_agent(): string
    {
        return sanitize_text_field((string) wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));
    }

    private function get_empty_form(): array
    {
        return [
            'id' => 0,
            'title' => '',
            'slug' => '',
            'design_variant' => 'design-1',
            'design_settings' => feuer_kontaktform_default_design_settings(),
            'display_settings' => feuer_kontaktform_default_display_settings(),
            'behavior_settings' => feuer_kontaktform_default_behavior_settings(),
            'recipient_email' => '',
            'auto_reply_subject' => '',
            'auto_reply_message' => '',
            'fields' => $this->get_default_form_fields(),
        ];
    }

    private function get_default_form_fields(): array
    {
        return [
            $this->build_field('vorname', true),
            $this->build_field('nachname', true),
            $this->build_field('email', true),
            $this->build_field('telefon', false),
            $this->build_field('nachricht', true),
        ];
    }

    private function get_empty_field(): array
    {
        return $this->build_field('text', false);
    }

    private function build_field(string $type, bool $required): array
    {
        $defaults = $this->get_field_type_defaults()[$type] ?? $this->get_field_type_defaults()['text'];
        return [
            'type' => $type,
            'label' => $defaults['label'],
            'key' => $defaults['key'],
            'placeholder' => $defaults['placeholder'],
            'required' => $required || in_array($type, ['email', 'nachricht', 'textarea'], true),
            'width' => $defaults['width'],
            'rows' => $defaults['rows'],
            'step' => 1,
            'condition_field' => '',
            'condition_value' => '',
            'help_text' => '',
            'options' => $defaults['options'] ?? [],
        ];
    }

    private function get_field_type_defaults(): array
    {
        return [
            'vorname' => ['label' => 'Vorname', 'key' => 'vorname', 'placeholder' => 'Vorname', 'width' => 'medium', 'rows' => 'medium'],
            'nachname' => ['label' => 'Nachname', 'key' => 'nachname', 'placeholder' => 'Nachname', 'width' => 'medium', 'rows' => 'medium'],
            'email' => ['label' => 'E-Mail', 'key' => 'email', 'placeholder' => 'name@beispiel.de', 'width' => 'medium', 'rows' => 'medium'],
            'telefon' => ['label' => 'Telefon', 'key' => 'telefon', 'placeholder' => 'Telefonnummer', 'width' => 'medium', 'rows' => 'medium'],
            'nachricht' => ['label' => 'Nachricht', 'key' => 'nachricht', 'placeholder' => 'Ihre Nachricht', 'width' => 'full', 'rows' => 'medium'],
            'kind_name' => ['label' => 'Name des Kindes', 'key' => 'kind_name', 'placeholder' => 'Name des Kindes', 'width' => 'medium', 'rows' => 'medium'],
            'kind_alter' => ['label' => 'Alter des Kindes', 'key' => 'kind_alter', 'placeholder' => 'Alter', 'width' => 'small', 'rows' => 'medium'],
            'text' => ['label' => 'Textfeld', 'key' => 'feld', 'placeholder' => '', 'width' => 'medium', 'rows' => 'medium'],
            'textarea' => ['label' => 'Mehrzeiliges Textfeld', 'key' => 'feld_textarea', 'placeholder' => '', 'width' => 'full', 'rows' => 'medium'],
            'select' => ['label' => 'Auswahl', 'key' => 'auswahl', 'placeholder' => '', 'width' => 'medium', 'rows' => 'medium', 'options' => ['Option 1', 'Option 2']],
            'radio' => ['label' => 'Radio-Auswahl', 'key' => 'radio_auswahl', 'placeholder' => '', 'width' => 'full', 'rows' => 'medium', 'options' => ['Option 1', 'Option 2']],
            'date' => ['label' => 'Datum', 'key' => 'datum', 'placeholder' => '', 'width' => 'medium', 'rows' => 'medium'],
            'time' => ['label' => 'Uhrzeit', 'key' => 'uhrzeit', 'placeholder' => '', 'width' => 'medium', 'rows' => 'medium'],
        ];
    }

    private function get_field_width_options(): array
    {
        return [
            'small' => 'Klein',
            'medium' => 'Mittel',
            'large' => 'Breit',
            'full' => 'Volle Breite',
        ];
    }

    private function get_textarea_size_options(): array
    {
        return [
            'small' => 'Klein',
            'medium' => 'Mittel',
            'large' => 'Gross',
        ];
    }

    private function normalize_email_list(string $raw): array
    {
        $parts = preg_split('/[\r\n,;]+/', $raw) ?: [];
        $parts = array_values(array_filter(array_map('trim', $parts), static fn (string $email): bool => $email !== ''));
        $parts = array_filter($parts, static fn (string $email): bool => is_email($email) !== false);

        return array_values(array_unique($parts));
    }

    private function has_valid_email_list(string $raw): bool
    {
        $parts = preg_split('/[\r\n,;]+/', $raw) ?: [];
        $parts = array_values(array_filter(array_map('trim', $parts), static fn (string $email): bool => $email !== ''));
        $valid = array_filter($parts, static fn (string $email): bool => is_email($email) !== false);

        return $parts !== [] && count($parts) === count($valid);
    }

    private function get_design_variants(): array
    {
        return [
            'design-1' => ['label' => 'Ticket Wizard', 'description' => 'Einheitliche Kontaktform mit Datenschutz-Schritt, Themenauswahl, Ticket-ID und Protokollierung.', 'template' => 'design-1'],
        ];
    }

    private function normalize_admin_fields(array $fields_input): array
    {
        $defaults   = $this->get_field_type_defaults();
        $normalized = [];
        $used_keys  = [];

        foreach ($fields_input as $field) {
            if (count($normalized) >= 40) {
                break;
            }

            if (! is_array($field)) {
                continue;
            }

            $type = sanitize_key((string) ($field['type'] ?? ''));
            if (! isset($defaults[$type])) {
                continue;
            }

            $label       = $this->truncate_input_value(sanitize_text_field((string) ($field['label'] ?? $defaults[$type]['label'])), 120);
            $key         = sanitize_key((string) ($field['key'] ?? $defaults[$type]['key']));
            $placeholder = $this->truncate_input_value(sanitize_text_field((string) ($field['placeholder'] ?? $defaults[$type]['placeholder'])), 180);
            $required    = ! empty($field['required']) || in_array($type, ['email', 'nachricht', 'textarea'], true);
            $width       = sanitize_key((string) ($field['width'] ?? $defaults[$type]['width']));
            $rows        = sanitize_key((string) ($field['rows'] ?? $defaults[$type]['rows']));
            $step        = max(1, (int) ($field['step'] ?? 1));
            $condition_field = sanitize_key((string) ($field['condition_field'] ?? ''));
            $condition_value = $this->truncate_input_value(sanitize_text_field((string) ($field['condition_value'] ?? '')), 120);
            $help_text   = $this->truncate_input_value(sanitize_text_field((string) ($field['help_text'] ?? '')), 180);
            $options_raw = isset($field['options']) ? $field['options'] : [];
            $options     = [];

            if ($label === '') {
                $label = $defaults[$type]['label'];
            }

            if ($key === '') {
                $key = sanitize_key($label);
            }

            if ($key === '') {
                $key = 'feld';
            }

            $base   = $key;
            $suffix = 2;
            while (in_array($key, $used_keys, true)) {
                $key = $base . '_' . $suffix;
                ++$suffix;
            }

            if (! isset($this->get_field_width_options()[$width])) {
                $width = $defaults[$type]['width'];
            }

            if (! isset($this->get_textarea_size_options()[$rows])) {
                $rows = $defaults[$type]['rows'];
            }

            if (is_array($options_raw)) {
                foreach ($options_raw as $option) {
                    $option = $this->truncate_input_value(sanitize_text_field((string) $option), 120);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            } elseif (is_string($options_raw)) {
                $parts = preg_split('/[\r\n,;]+/', $options_raw) ?: [];
                foreach ($parts as $option) {
                    $option = $this->truncate_input_value(sanitize_text_field((string) $option), 120);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            } elseif (is_array($defaults[$type]['options'] ?? null)) {
                $options = array_values(array_filter(array_map(fn ($option): string => $this->truncate_input_value(sanitize_text_field((string) $option), 120), $defaults[$type]['options'])));
            }

            $used_keys[] = $key;
            $normalized[] = [
                'type' => $type,
                'label' => $label,
                'key' => $key,
                'placeholder' => $placeholder,
                'required' => $required,
                'width' => $width,
                'rows' => $rows,
                'step' => $step,
                'condition_field' => $condition_field,
                'condition_value' => $condition_value,
                'help_text' => $help_text,
                'options' => array_values(array_unique($options)),
            ];
        }

        return $normalized;
    }

    private function ensure_topic_field(array $fields, array $topics): array
    {
        if ($topics === []) {
            return $fields;
        }

        $options = [];
        foreach ($topics as $topic) {
            if (! is_array($topic)) {
                continue;
            }

            $label = sanitize_text_field((string) ($topic['label'] ?? ''));
            if ($label !== '') {
                $options[] = $label;
            }
        }

        $options = array_values(array_unique($options));
        if ($options === []) {
            return $fields;
        }

        foreach ($fields as &$field) {
            if ((string) ($field['key'] ?? '') !== 'thema') {
                continue;
            }

            $field['type'] = 'select';
            $field['label'] = 'Thema der Anfrage';
            $field['required'] = true;
            $field['options'] = $options;
            $field['step'] = min(2, max(1, (int) ($field['step'] ?? 2)));
            return $fields;
        }
        unset($field);

        $insert_at = 0;
        foreach ($fields as $index => $field) {
            if (in_array((string) ($field['type'] ?? ''), ['email', 'telefon'], true)) {
                $insert_at = $index + 1;
            }
        }

        array_splice($fields, $insert_at, 0, [[
            'type' => 'select',
            'label' => 'Thema der Anfrage',
            'key' => 'thema',
            'placeholder' => '',
            'required' => true,
            'width' => 'full',
            'rows' => 'medium',
            'step' => 2,
            'condition_field' => '',
            'condition_value' => '',
            'help_text' => 'Bitte waehlen Sie das Thema, damit die Anfrage richtig zugeordnet wird.',
            'options' => $options,
        ]]);

        return $fields;
    }

    private function build_frontend_design_css(array $form): string
    {
        $form_id = (int) ($form['id'] ?? 0);
        if ($form_id <= 0) {
            return '';
        }

        $settings = feuer_kontaktform_normalize_design_settings($form['design_settings'] ?? []);
        $scope = '#feuer-kontaktform-form-' . $form_id;
        $rules = [];
        $vars = [];

        $map = [
            'shell_background_color' => '--fk-shell-bg',
            'panel_background_color' => '--fk-panel-bg',
            'panel_text_color' => '--fk-panel-text',
            'title_color' => '--fk-title-color',
            'aside_background_color' => '--fk-aside-bg',
            'aside_text_color' => '--fk-aside-text',
            'accent_color' => '--fk-accent',
            'button_background_color' => '--fk-button-bg',
            'button_text_color' => '--fk-button-text',
            'input_background_color' => '--fk-input-bg',
            'input_text_color' => '--fk-input-text',
            'input_border_color' => '--fk-input-border',
            'overlay_color' => '--fk-overlay-color',
        ];

        foreach ($map as $setting_key => $var_name) {
            $value = (string) ($settings[$setting_key] ?? '');
            if ($value !== '') {
                $vars[] = $var_name . ':' . $value;
            }
        }

        $vars[] = '--fk-overlay-opacity:' . (max(0, min(100, (int) ($settings['overlay_opacity'] ?? 72))) / 100);
        $image_url = (string) ($settings['background_image_url'] ?? '');
        if ($image_url !== '') {
            $vars[] = '--fk-bg-image:url("' . $this->escape_css_url($image_url) . '")';
        }

        if ($vars !== []) {
            $rules[] = $scope . '{' . implode(';', $vars) . ';}';
        }

        $rules[] = $scope . ' .feuer-kontaktform-ticket-shell{background:var(--fk-shell-bg,#f5f7fb);color:var(--fk-panel-text,#1f2937);}';
        $rules[] = $scope . ' .feuer-kontaktform-ticket-panel{background:var(--fk-panel-bg,#fff);color:var(--fk-panel-text,#1f2937);}';
        $rules[] = $scope . ' .feuer-kontaktform-panel-head h1,' . $scope . ' .feuer-kontaktform-panel-head h2,' . $scope . ' .feuer-kontaktform-panel-head h3{color:var(--fk-title-color,var(--fk-panel-text,#1f2937));}';
        $rules[] = $scope . ' .feuer-kontaktform-ticket-kicker,' . $scope . ' .feuer-kontaktform-required{color:var(--fk-accent,#b42318);}';
        $rules[] = $scope . ' .btn-dark{background:var(--fk-button-bg,#111827);border-color:var(--fk-button-bg,#111827);color:var(--fk-button-text,#fff);}';
        $rules[] = $scope . ' .form-control,' . $scope . ' .form-select{background-color:var(--fk-input-bg,#fff);border-color:var(--fk-input-border,#cbd5e1);color:var(--fk-input-text,#111827);}';
        if ($image_url !== '') {
            $target = (string) ($settings['background_image_target'] ?? 'aside');
            if (in_array($target, ['panel', 'both'], true)) {
                $rules[] = $scope . ' .feuer-kontaktform-ticket-panel{background-image:linear-gradient(rgba(255,255,255,.90),rgba(255,255,255,.90)),var(--fk-bg-image);background-size:cover;background-position:center;}';
            }
            if (in_array($target, ['aside', 'both'], true)) {
                $rules[] = $scope . ' .feuer-kontaktform-ticket-shell:before{background-image:linear-gradient(rgba(0,0,0,var(--fk-overlay-opacity,.72)),rgba(0,0,0,var(--fk-overlay-opacity,.72))),var(--fk-bg-image);}';
            }
        }

        return implode("\n", $rules);
    }

    private function escape_css_url(string $url): string
    {
        return str_replace(['\\', '"'], ['\\\\', '\\"'], esc_url_raw($url));
    }

    private function hex_to_rgba(string $hex, float $alpha): string
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        if (strlen($hex) !== 6) {
            return 'rgba(0, 0, 0, ' . $alpha . ')';
        }

        $red   = hexdec(substr($hex, 0, 2));
        $green = hexdec(substr($hex, 2, 2));
        $blue  = hexdec(substr($hex, 4, 2));

        return sprintf('rgba(%d, %d, %d, %.2f)', $red, $green, $blue, $alpha);
    }

    private function sanitize_submission_values(array $form, array $raw_values): array
    {
        $values = [];

        foreach ($form['fields'] as $field) {
            $raw = isset($raw_values[$field['key']]) && is_string($raw_values[$field['key']]) ? $raw_values[$field['key']] : '';
            $sanitized = in_array($field['type'], ['nachricht', 'textarea'], true) ? sanitize_textarea_field($raw) : sanitize_text_field($raw);
            $values[$field['key']] = $this->truncate_input_value($sanitized, $this->get_frontend_field_limit((string) $field['type']));
        }

        return $values;
    }

    private function validate_submission(array $form, array $values, bool $privacy_accepted): array
    {
        $reply_email  = '';
        $errors       = [];
        $field_errors = [];

        foreach ($form['fields'] as $field) {
            $field_key = (string) ($field['key'] ?? '');
            if ($field_key === '') {
                continue;
            }

            if (! $this->is_field_visible($field, $values)) {
                $values[$field_key] = '';
                continue;
            }

            $value = (string) ($values[$field_key] ?? '');

            if (! empty($field['required']) && $value === '') {
                $message = sprintf('Bitte fuellen Sie das Feld "%s" aus.', $field['label']);
                $errors[] = $message;
                $field_errors[$field_key] = $message;
                continue;
            }

            if (($field['type'] ?? '') === 'email') {
                if ($value !== '' && ! is_email($value)) {
                    $message = sprintf('Bitte geben Sie im Feld "%s" eine gueltige E-Mail-Adresse an.', $field['label']);
                    $errors[] = $message;
                    $field_errors[$field_key] = $message;
                } elseif ($reply_email === '') {
                    $reply_email = $value;
                }
            }

            if (($field['type'] ?? '') === 'kind_alter' && $value !== '' && ! preg_match('/^\d{1,3}$/', $value)) {
                $message = sprintf('Bitte geben Sie im Feld "%s" nur Zahlen an.', $field['label']);
                $errors[] = $message;
                $field_errors[$field_key] = $message;
            }

            if (in_array((string) ($field['type'] ?? ''), ['select', 'radio'], true) && $value !== '') {
                $options = is_array($field['options'] ?? null) ? array_map('strval', $field['options']) : [];
                if ($options !== [] && ! in_array($value, $options, true)) {
                    $message = sprintf('Bitte waehlen Sie im Feld "%s" einen gueltigen Wert.', $field['label']);
                    $errors[] = $message;
                    $field_errors[$field_key] = $message;
                }
            }

            if (($field['type'] ?? '') === 'date' && $value !== '' && ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                $message = sprintf('Bitte geben Sie im Feld "%s" ein gueltiges Datum an.', $field['label']);
                $errors[] = $message;
                $field_errors[$field_key] = $message;
            }

            if (($field['type'] ?? '') === 'time' && $value !== '' && ! preg_match('/^\d{2}:\d{2}$/', $value)) {
                $message = sprintf('Bitte geben Sie im Feld "%s" eine gueltige Uhrzeit an.', $field['label']);
                $errors[] = $message;
                $field_errors[$field_key] = $message;
            }

            if (($field['type'] ?? '') === 'telefon' && $value !== '' && ! preg_match('/^[0-9+\-\s()\/]{5,60}$/', $value)) {
                $message = sprintf('Bitte geben Sie im Feld "%s" eine gueltige Telefonnummer an.', $field['label']);
                $errors[] = $message;
                $field_errors[$field_key] = $message;
            }
        }

        $payload_size = wp_json_encode($values);
        if (is_string($payload_size) && strlen($payload_size) > self::MAX_SUBMISSION_BYTES) {
            $errors[] = 'Die uebermittelten Daten sind zu umfangreich. Bitte kuerzen Sie Ihre Eingaben.';
        }

        if (! $privacy_accepted) {
            $errors[] = 'Bitte bestaetigen Sie den Datenschutzhinweis.';
            $field_errors[self::PRIVACY_FIELD] = 'Bitte bestaetigen Sie den Datenschutzhinweis.';
        }

        return [$values, $reply_email, array_values(array_unique($errors)), $field_errors];
    }

    private function get_frontend_input_type(string $type): string
    {
        return match ($type) {
            'email' => 'email',
            'telefon' => 'tel',
            'kind_alter' => 'number',
            'date' => 'date',
            'time' => 'time',
            default => 'text',
        };
    }

    private function get_frontend_field_limit(string $type): int
    {
        return match ($type) {
            'nachricht', 'textarea' => 4000,
            'email' => 190,
            'telefon' => 60,
            'kind_alter' => 3,
            'date', 'time' => 20,
            default => 255,
        };
    }

    private function truncate_input_value(string $value, int $limit): string
    {
        if ($limit <= 0) {
            return '';
        }

        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, 0, $limit);
        }

        return substr($value, 0, $limit);
    }

    private function generate_captcha(int $form_id, string $ip_address): array
    {
        $a       = wp_rand(1, 9);
        $b       = wp_rand(1, 9);
        $created = time();
        $hash    = hash_hmac('sha256', $form_id . '|' . $ip_address . '|' . $a . '|' . $b . '|' . $created, wp_salt('auth'));

        return [
            'question' => sprintf('Sicherheitsfrage: Wie viel ist %d + %d?', $a, $b),
            'token' => base64_encode(wp_json_encode(['a' => $a, 'b' => $b, 'created' => $created, 'hash' => $hash])),
        ];
    }

    private function validate_captcha(int $form_id, string $ip_address, string $token, string $answer): bool
    {
        if ($token === '' || $answer === '') {
            return false;
        }

        $decoded = base64_decode($token, true);
        if (! is_string($decoded) || $decoded === '') {
            return false;
        }

        $payload = json_decode($decoded, true);
        if (! is_array($payload)) {
            return false;
        }

        $a       = isset($payload['a']) ? (int) $payload['a'] : -1;
        $b       = isset($payload['b']) ? (int) $payload['b'] : -1;
        $created = isset($payload['created']) ? (int) $payload['created'] : 0;
        $hash    = (string) ($payload['hash'] ?? '');

        if ($a < 0 || $b < 0 || $created <= 0 || $hash === '' || $created < (time() - HOUR_IN_SECONDS)) {
            return false;
        }

        $expected = hash_hmac('sha256', $form_id . '|' . $ip_address . '|' . $a . '|' . $b . '|' . $created, wp_salt('auth'));
        return hash_equals($expected, $hash) && (int) $answer === ($a + $b);
    }

    private function generate_ticket_code(): string
    {
        return 'FK-' . gmdate('Ymd') . '-' . strtoupper(wp_generate_password(6, false, false));
    }

    private function get_or_create_visitor_cookie_id(): string
    {
        $existing = isset($_COOKIE[self::VISITOR_COOKIE]) ? sanitize_text_field((string) wp_unslash($_COOKIE[self::VISITOR_COOKIE])) : '';
        if ($existing !== '' && preg_match('/^[a-zA-Z0-9_-]{16,80}$/', $existing)) {
            return $existing;
        }

        $cookie_id = strtolower(wp_generate_password(24, false, false));
        if (! headers_sent()) {
            $cookie_options = [
                'expires' => time() + YEAR_IN_SECONDS,
                'path' => COOKIEPATH !== '' ? COOKIEPATH : '/',
                'secure' => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ];
            if (defined('COOKIE_DOMAIN') && COOKIE_DOMAIN !== '') {
                $cookie_options['domain'] = COOKIE_DOMAIN;
            }
            setcookie(self::VISITOR_COOKIE, $cookie_id, $cookie_options);
            $_COOKIE[self::VISITOR_COOKIE] = $cookie_id;
        }

        return $cookie_id;
    }

    private function detect_device_type(string $user_agent): string
    {
        $ua = strtolower($user_agent);
        if ($ua === '') {
            return 'unknown';
        }

        if (str_contains($ua, 'tablet') || str_contains($ua, 'ipad')) {
            return 'tablet';
        }

        if (str_contains($ua, 'mobile') || str_contains($ua, 'iphone') || str_contains($ua, 'android')) {
            return 'mobile';
        }

        return 'desktop';
    }

    public function register_query_vars(array $vars): array
    {
        $vars[] = self::FORM_QUERY_ARG;
        return array_values(array_unique($vars));
    }

    public function register_rewrite_rules(): void
    {
        $settings = $this->get_settings();
        if (empty($settings['rewrite_enabled'])) {
            return;
        }

        $forms_page_url = $this->get_forms_page_url($settings);
        $page_path      = $this->get_forms_page_path($forms_page_url);
        if ($forms_page_url === '' || $page_path === '') {
            return;
        }

        $page_id = url_to_postid($forms_page_url);
        $query   = $page_id > 0
            ? 'index.php?page_id=' . $page_id . '&' . self::FORM_QUERY_ARG . '=$matches[1]'
            : 'index.php?pagename=' . $page_path . '&' . self::FORM_QUERY_ARG . '=$matches[1]';

        add_rewrite_rule('^' . preg_quote($page_path, '#') . '/([^/]+)/?$', $query, 'top');
    }

    public function cleanup_old_submissions(): void
    {
        $settings = $this->get_settings();
        $days     = max(0, (int) ($settings['log_retention_days'] ?? 0));

        if ($days <= 0 || get_transient('feuer-kontaktform-cleanup-ran') !== false) {
            return;
        }

        $this->repository->anonymize_old_submissions($days);
        set_transient('feuer-kontaktform-cleanup-ran', '1', DAY_IN_SECONDS);
    }

    public function enqueue_block_editor_assets(): void
    {
        if (! function_exists('register_block_type')) {
            return;
        }

        wp_register_script(
            'feuer-kontaktform-block-editor',
            FEUER_KONTAKTFORM_URL . 'assets/js/block-editor.js',
            ['wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wp-block-editor'],
            FEUER_KONTAKTFORM_VERSION,
            true
        );
        wp_localize_script('feuer-kontaktform-block-editor', 'FeuerKontaktformBlock', [
            'forms' => array_map(
                static fn (array $form): array => [
                    'id' => (int) ($form['id'] ?? 0),
                    'title' => (string) ($form['title'] ?? ''),
                    'slug' => (string) ($form['slug'] ?? ''),
                ],
                $this->resolve_forms($this->repository->get_forms())
            ),
        ]);
        wp_enqueue_script('feuer-kontaktform-block-editor');

        static $registered = false;
        if ($registered) {
            return;
        }

        register_block_type('feuer-kontaktform/form', [
            'editor_script' => 'feuer-kontaktform-block-editor',
            'render_callback' => [$this, 'render_block'],
            'attributes' => [
                'formId' => ['type' => 'number', 'default' => 0],
                'slug' => ['type' => 'string', 'default' => ''],
                'showAll' => ['type' => 'boolean', 'default' => false],
            ],
        ]);
        $registered = true;
    }

    public function render_block(array $attributes = []): string
    {
        if (! empty($attributes['showAll'])) {
            return $this->render_all_forms_shortcode();
        }

        if (! empty($attributes['formId'])) {
            return $this->render_single_form_shortcode(['id' => (int) $attributes['formId']]);
        }

        if ((string) ($attributes['slug'] ?? '') !== '') {
            return $this->render_single_form_shortcode(['slug' => (string) $attributes['slug']]);
        }

        return $this->render_all_forms_shortcode();
    }

    public function register_dashboard_widget(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        wp_add_dashboard_widget('feuer_kontaktform_dashboard_widget', 'Feuer-Kontaktform', [$this, 'render_dashboard_widget']);
    }

    public function render_dashboard_widget(): void
    {
        $logs      = $this->repository->get_submissions(0, 5);
        $new_count = 0;

        foreach ($this->repository->get_submissions(0, 25) as $submission) {
            if ((string) ($submission['status'] ?? 'new') === 'new') {
                ++$new_count;
            }
        }

        echo '<p><strong>Neue Anfragen:</strong> ' . esc_html((string) $new_count) . '</p>';
        if ($logs === []) {
            echo '<p>Keine Nachrichten vorhanden.</p>';
            return;
        }

        echo '<ul class="ka-dashboard-list">';
        foreach ($logs as $submission) {
            $label = (string) (($submission['reply_email'] ?? '') !== '' ? $submission['reply_email'] : $submission['form_title']);
            echo '<li><strong>' . esc_html($this->format_datetime((string) $submission['created_at'])) . '</strong> ';
            echo esc_html((string) $submission['form_title']) . ' - ' . esc_html($label) . '</li>';
        }
        echo '</ul>';
        echo '<p><a class="button button-secondary" href="' . esc_url($this->admin_page_url('feuer-kontaktform-logs')) . '">Protokoll oeffnen</a></p>';
    }

    public function render_popup_form_shortcode(array $atts = []): string
    {
        $atts = shortcode_atts(['id' => 0, 'slug' => '', 'button_label' => ''], $atts, 'feuer-kontaktform-popup');
        $form = (int) $atts['id'] > 0 ? $this->repository->get_form((int) $atts['id']) : $this->repository->get_form_by_slug((string) $atts['slug']);
        $form = $this->resolve_form($form);

        if (! is_array($form)) {
            return '<div class="feuer-kontaktform-box feuer-kontaktform-message feuer-kontaktform-error">Das angeforderte Formular wurde nicht gefunden.</div>';
        }

        wp_enqueue_style('feuer-kontaktform-frontend');
        wp_enqueue_script('feuer-kontaktform-frontend-script');

        $settings = $this->get_settings();
        $state    = $this->resolve_frontend_state_for_form((int) $form['id']);
        $button   = sanitize_text_field((string) $atts['button_label']);
        if ($button === '') {
            $behavior = feuer_kontaktform_normalize_behavior_settings($form['behavior_settings'] ?? []);
            $button   = (string) (($behavior['popup_trigger_label'] ?? '') !== '' ? $behavior['popup_trigger_label'] : ($settings['popup_button_label'] ?? 'Kontakt aufnehmen'));
        }

        $modal_id = 'ka-popup-' . (int) $form['id'] . '-' . wp_rand(100, 999);

        return $this->view->render('frontend/popup-form.php', [
            'form' => $form,
            'modal_id' => $modal_id,
            'button_label' => $button,
            'open_on_load' => ! empty($state),
            'content' => $this->render_frontend_form($form, $state, false),
        ]);
    }

    public function render_quick_form_shortcode(array $atts = []): string
    {
        $atts = shortcode_atts(['id' => 0, 'slug' => ''], $atts, 'feuer-kontaktform-schnell');
        return $this->render_single_form_shortcode($atts);
    }

    public function handle_frontend_submission_ajax(): void
    {
        $result = $this->process_frontend_submission($_POST, true);
        $form   = $result['form'] ?? null;

        if (! is_array($form)) {
            wp_send_json_error(['message' => 'Das Formular wurde nicht gefunden.'], 404);
        }

        $payload = [
            'formId' => (int) ($result['form_id'] ?? 0),
            'success' => ! empty($result['success']),
            'message' => (string) ($result['message'] ?? ''),
            'values' => is_array($result['values'] ?? null) ? $result['values'] : [],
            'errors' => is_array($result['errors'] ?? null) ? $result['errors'] : [],
            'fieldErrors' => is_array($result['field_errors'] ?? null) ? $result['field_errors'] : [],
            'privacyAccepted' => ! empty($result['privacy_accepted']),
            'captcha' => is_array($result['captcha'] ?? null) ? $result['captcha'] : [],
            'ticketCode' => (string) ($result['ticket_code'] ?? ''),
            'submissionId' => (int) ($result['submission_id'] ?? 0),
        ];

        if (! empty($result['success'])) {
            wp_send_json_success($payload);
        }

        wp_send_json_error($payload, 400);
    }

    private function process_frontend_submission(array $request, bool $is_ajax = false): array
    {
        $form_id = isset($request['form_id']) ? absint(wp_unslash($request['form_id'])) : 0;
        $form    = $this->resolve_form($this->repository->get_form($form_id));

        if (! is_array($form)) {
            return [
                'success' => false,
                'form' => null,
                'form_id' => $form_id,
                'errors' => ['Das Formular wurde nicht gefunden.'],
                'field_errors' => [],
                'redirect_to' => $this->get_current_url(),
                'values' => [],
                'privacy_accepted' => false,
            ];
        }

        $submission_behavior = feuer_kontaktform_normalize_behavior_settings($form['behavior_settings'] ?? []);
        $form['fields'] = $this->ensure_topic_field(is_array($form['fields'] ?? null) ? $form['fields'] : [], (array) ($submission_behavior['topics'] ?? []));

        $nonce       = sanitize_text_field((string) wp_unslash($request['feuer-kontaktform-nonce'] ?? ''));
        $redirect_to = $this->sanitize_redirect_target(isset($request['redirect_to']) ? (string) wp_unslash($request['redirect_to']) : '');
        $ip_address  = $this->get_user_ip();
        $user_agent  = $this->get_user_agent();
        $honeypot    = sanitize_text_field((string) wp_unslash($request[self::HONEYPOT_FIELD] ?? ''));
        $settings    = $this->get_settings();
        $referrer    = $this->get_request_referrer();
        $privacy_accepted = ! empty($request[self::PRIVACY_FIELD]);
        if (! $privacy_accepted) {
            $privacy_accepted = ! empty($request[self::PRIVACY_FIELD]);
        }
        $values      = $this->sanitize_submission_values(
            $form,
            isset($request['feuer_kontaktform_fields']) && is_array($request['feuer_kontaktform_fields']) ? wp_unslash($request['feuer_kontaktform_fields']) : []
        );

        if (! wp_verify_nonce($nonce, 'feuer-kontaktform-send-' . $form_id)) {
            return [
                'success' => false,
                'form' => $form,
                'form_id' => $form_id,
                'errors' => ['Die Sicherheitspruefung ist fehlgeschlagen. Bitte laden Sie die Seite neu.'],
                'field_errors' => [],
                'redirect_to' => $redirect_to,
                'values' => $values,
                'privacy_accepted' => $privacy_accepted,
            ];
        }

        if ($honeypot !== '') {
            return [
                'success' => true,
                'form' => $form,
                'form_id' => $form_id,
                'message' => (string) ($settings['default_success_message'] ?? feuer_kontaktform_default_settings()['default_success_message']),
                'errors' => [],
                'field_errors' => [],
                'redirect_to' => $redirect_to,
                'values' => [],
                'privacy_accepted' => false,
            ];
        }

        if ($this->is_submission_rate_limited($form_id, $ip_address)) {
            return [
                'success' => false,
                'form' => $form,
                'form_id' => $form_id,
                'errors' => ['Bitte warten Sie einen Moment, bevor Sie eine weitere Anfrage absenden.'],
                'field_errors' => [],
                'redirect_to' => $redirect_to,
                'values' => $values,
                'privacy_accepted' => $privacy_accepted,
            ];
        }

        $this->mark_submission_attempt($form_id, $ip_address);

        if ($this->repository->is_ip_blocked($ip_address)) {
            return [
                'success' => false,
                'form' => $form,
                'form_id' => $form_id,
                'errors' => ['Ihre Anfrage kann derzeit nicht verarbeitet werden.'],
                'field_errors' => [],
                'redirect_to' => $redirect_to,
                'values' => $values,
                'privacy_accepted' => $privacy_accepted,
            ];
        }

        $errors       = [];
        $field_errors = [];

        if (! $this->is_referrer_allowed($referrer, $settings)) {
            $errors[] = 'Diese Anfrage darf nur von freigegebenen Seiten abgesendet werden.';
        }

        [$values, $reply_email, $validation_errors, $validation_field_errors] = $this->validate_submission($form, $values, $privacy_accepted);
        $errors       = array_merge($errors, $validation_errors);
        $field_errors = array_merge($field_errors, $validation_field_errors);

        $captcha_required = $this->repository->has_recent_submission($ip_address, $reply_email);
        $captcha_state    = [];
        if ($captcha_required) {
            $captcha_token  = sanitize_text_field((string) wp_unslash($request['captcha_token'] ?? ''));
            $captcha_answer = sanitize_text_field((string) wp_unslash($request['captcha_answer'] ?? ''));

            if (! $this->validate_captcha($form_id, $ip_address, $captcha_token, $captcha_answer)) {
                $errors[] = 'Bitte loesen Sie die Sicherheitsfrage, da innerhalb von 30 Minuten bereits eine Anfrage eingegangen ist.';
                $field_errors['captcha_answer'] = 'Sicherheitsfrage nicht korrekt geloest.';
                $captcha_state = $this->generate_captcha($form_id, $ip_address);
            }
        }

        if ($errors !== []) {
            return [
                'success' => false,
                'form' => $form,
                'form_id' => $form_id,
                'errors' => array_values(array_unique($errors)),
                'field_errors' => $field_errors,
                'redirect_to' => $redirect_to,
                'values' => $values,
                'privacy_accepted' => $privacy_accepted,
                'captcha' => $captcha_state,
            ];
        }

        $routing       = $this->resolve_form_routing($form, $values, $settings);
        $delivery_form = $form;
        if (($routing['recipient_email'] ?? '') !== '') {
            $delivery_form['recipient_email'] = (string) $routing['recipient_email'];
        }
        $ticket_code = $this->generate_ticket_code();
        $delivery_form = $this->apply_topic_overrides($delivery_form, $values);
        $delivery_form['_ticket_code'] = $ticket_code;

        $notification = $this->mailer->send_notification($delivery_form, $values, $reply_email, $ip_address, $user_agent, $settings, $privacy_accepted);
        if (($routing['details'] ?? '') !== '') {
            $notification['details'] = trim((string) ($notification['details'] ?? '') . ' Routing: ' . (string) $routing['details']);
        }

        $auto_reply_status  = 'nicht_erforderlich';
        $auto_reply_details = 'Es wurde keine Autoantwort versendet, da keine Antwort-E-Mail vorliegt.';
        if ($reply_email !== '') {
            if ($this->repository->is_auto_reply_blocked($reply_email)) {
                $auto_reply_status  = 'gesperrt';
                $auto_reply_details = 'Die Autoantwort wurde fuer diese E-Mail-Adresse durch die Sperrliste deaktiviert.';
            } else {
                $auto_reply         = $this->mailer->send_auto_reply($delivery_form, $values, $reply_email, $settings);
                $auto_reply_status  = (string) ($auto_reply['status'] ?? 'fehler');
                $auto_reply_details = (string) ($auto_reply['details'] ?? '');
            }
        }

        $privacy_version = sanitize_text_field((string) ($settings['privacy_notice_version'] ?? ''));
        $visitor_cookie = $this->get_or_create_visitor_cookie_id();
        $device_type = $this->detect_device_type($user_agent);
        $webhook         = $this->send_webhook($form, $values, $settings, [
            'ticket_code' => $ticket_code,
            'reply_email' => $reply_email,
            'ip_address' => $ip_address,
            'visitor_cookie' => $visitor_cookie,
            'device_type' => $device_type,
            'user_agent' => $user_agent,
            'privacy_accepted' => $privacy_accepted,
            'privacy_version' => $privacy_version,
            'referrer_url' => $referrer,
            'routing_details' => (string) ($routing['details'] ?? ''),
            'is_ajax' => $is_ajax,
        ]);

        $consent_context = [
            'notice_shown' => true,
            'accepted' => $privacy_accepted,
            'accepted_at' => current_time('mysql'),
            'privacy_version' => $privacy_version,
            'privacy_policy_url' => esc_url_raw((string) ($settings['privacy_policy_url'] ?? '')),
            'ip_address' => $ip_address,
            'visitor_cookie' => $visitor_cookie,
            'user_agent' => $user_agent,
            'device_type' => $device_type,
            'referrer_url' => $referrer,
        ];

        $submission_id = $this->repository->insert_submission(
            $form_id,
            $ticket_code,
            $reply_email,
            $ip_address,
            $visitor_cookie,
            $device_type,
            $user_agent,
            $values,
            (string) ($notification['status'] ?? 'fehler'),
            (string) ($notification['details'] ?? ''),
            $auto_reply_status,
            $auto_reply_details,
            (string) ($webhook['status'] ?? 'nicht_konfiguriert'),
            (string) ($webhook['details'] ?? 'Kein Webhook konfiguriert.'),
            $captcha_required,
            $privacy_accepted,
            esc_url_raw((string) ($settings['privacy_policy_url'] ?? '')),
            $privacy_version,
            $referrer,
            $consent_context,
            'new'
        );
        $this->repository->insert_activity_log('ticket_created', 'submission', $submission_id, 'Ticket erstellt: ' . $ticket_code, [
            'form_id' => $form_id,
            'reply_email' => $reply_email,
        ]);

        $notification_sent = ! empty($notification['success']);

        return [
            'success' => true,
            'form' => $form,
            'form_id' => $form_id,
            'message' => $notification_sent
                ? (string) ($settings['default_success_message'] ?? feuer_kontaktform_default_settings()['default_success_message']) . ' Ihre Ticket-ID lautet ' . $ticket_code . '.'
                : 'Ihre Anfrage wurde gespeichert. Die E-Mail-Zustellung konnte aktuell jedoch nicht bestaetigt werden. Ihre Ticket-ID lautet ' . $ticket_code . '.',
            'errors' => [],
            'field_errors' => [],
            'redirect_to' => $redirect_to,
            'values' => [],
            'privacy_accepted' => false,
            'captcha' => [],
            'ticket_code' => $ticket_code,
            'submission_id' => $submission_id,
        ];
    }

    private function send_webhook(array $form, array $values, array $settings, array $context): array
    {
        $url = esc_url_raw((string) ($settings['webhook_url'] ?? ''));
        if ($url === '') {
            return [
                'status' => 'nicht_konfiguriert',
                'details' => 'Kein Webhook konfiguriert.',
            ];
        }

        $response = wp_remote_post($url, [
            'timeout' => max(3, min(30, (int) ($settings['webhook_timeout'] ?? 10))),
            'headers' => ['Content-Type' => 'application/json; charset=UTF-8'],
            'body' => wp_json_encode([
                'form' => [
                    'id' => (int) ($form['id'] ?? 0),
                    'title' => (string) ($form['title'] ?? ''),
                    'slug' => (string) ($form['slug'] ?? ''),
                ],
                'fields' => $values,
                'context' => $context,
                'sent_at' => current_time('mysql'),
            ], JSON_UNESCAPED_UNICODE),
        ]);

        if (is_wp_error($response)) {
            return [
                'status' => 'fehler',
                'details' => implode(' ', array_map('sanitize_text_field', $response->get_error_messages())),
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code >= 200 && $code < 300) {
            return [
                'status' => 'gesendet',
                'details' => 'Webhook bestaetigt mit HTTP ' . $code . '.',
            ];
        }

        return [
            'status' => 'fehler',
            'details' => 'Webhook antwortete mit HTTP ' . $code . '.',
        ];
    }

    private function resolve_form_routing(array $form, array $values, array $settings): array
    {
        $behavior   = feuer_kontaktform_normalize_behavior_settings($form['behavior_settings'] ?? []);
        $recipients = $this->normalize_email_list((string) ($form['recipient_email'] ?? ''));
        $matched    = [];
        $selected_topic = $this->find_selected_topic($behavior, $values);

        if (is_array($selected_topic)) {
            $topic_recipients = $this->normalize_email_list((string) ($selected_topic['recipient_email'] ?? ''));
            if ($topic_recipients !== []) {
                $recipients = $topic_recipients;
            }
            $matched[] = 'Thema: ' . (string) ($selected_topic['label'] ?? '');
        }

        foreach ((array) ($behavior['routing_rules'] ?? []) as $rule) {
            if (! is_array($rule)) {
                continue;
            }

            $field_key       = sanitize_key((string) ($rule['field_key'] ?? ''));
            $value           = trim((string) ($values[$field_key] ?? ''));
            $expected        = trim((string) ($rule['match_value'] ?? ''));
            $rule_recipients = $this->normalize_email_list((string) ($rule['recipient_email'] ?? ''));

            if ($field_key === '' || $value === '' || $expected === '' || $rule_recipients === []) {
                continue;
            }

            if (strtolower($value) !== strtolower($expected)) {
                continue;
            }

            if ((string) ($rule['mode'] ?? 'append') === 'replace') {
                $recipients = $rule_recipients;
            } else {
                $recipients = array_values(array_unique(array_merge($recipients, $rule_recipients)));
            }

            $matched[] = (string) (($rule['label'] ?? '') !== '' ? $rule['label'] : $field_key . '=' . $expected);
        }

        $admin_email = sanitize_email((string) ($settings['admin_notification_email'] ?? ''));
        if ($admin_email !== '') {
            $recipients[] = $admin_email;
        }

        $recipients = array_values(array_unique(array_filter($recipients, static fn (string $email): bool => is_email($email) !== false)));

        return [
            'recipient_email' => implode(', ', $recipients),
            'details' => $matched !== [] ? implode(', ', $matched) : '',
        ];
    }

    private function apply_topic_overrides(array $form, array $values): array
    {
        $behavior = feuer_kontaktform_normalize_behavior_settings($form['behavior_settings'] ?? []);
        $topic = $this->find_selected_topic($behavior, $values);
        if (! is_array($topic)) {
            return $form;
        }

        if ((string) ($topic['auto_reply_subject'] ?? '') !== '') {
            $form['auto_reply_subject'] = (string) $topic['auto_reply_subject'];
        }

        if ((string) ($topic['auto_reply_message'] ?? '') !== '') {
            $form['auto_reply_message'] = (string) $topic['auto_reply_message'];
        }

        return $form;
    }

    private function find_selected_topic(array $behavior, array $values): ?array
    {
        $selected = trim((string) ($values['thema'] ?? $values['topic'] ?? ''));
        if ($selected === '') {
            return null;
        }

        $selected_slug = sanitize_title($selected);
        foreach ((array) ($behavior['topics'] ?? []) as $topic) {
            if (! is_array($topic)) {
                continue;
            }

            $label = trim((string) ($topic['label'] ?? ''));
            $slug = sanitize_title((string) ($topic['slug'] ?? $label));
            if ($selected === $label || ($selected_slug !== '' && $selected_slug === $slug)) {
                return $topic;
            }
        }

        return null;
    }

    private function is_referrer_allowed(string $referrer_url, array $settings): bool
    {
        $raw_hosts = (string) ($settings['allowed_referrer_hosts'] ?? '');
        if (trim($raw_hosts) === '') {
            return true;
        }

        $host = $this->normalize_host((string) wp_parse_url($referrer_url, PHP_URL_HOST));
        if ($host === '') {
            return false;
        }

        $patterns = preg_split('/[\r\n,;]+/', $raw_hosts) ?: [];
        foreach ($patterns as $pattern) {
            $pattern = $this->normalize_host((string) $pattern);
            if ($pattern === '') {
                continue;
            }

            if ($this->host_matches_pattern($host, $pattern)) {
                return true;
            }
        }

        return false;
    }

    private function get_request_referrer(): string
    {
        $raw = $_SERVER['HTTP_REFERER'] ?? '';
        if (is_array($raw)) {
            return '';
        }

        return esc_url_raw((string) wp_unslash($raw));
    }

    private function normalize_host(string $host): string
    {
        return strtolower(trim((string) preg_replace('/^www\./i', '', $host)));
    }

    private function host_matches_pattern(string $host, string $pattern): bool
    {
        if ($pattern === $host) {
            return true;
        }

        if (str_starts_with($pattern, '*.')) {
            $suffix = substr($pattern, 1);
            return $suffix !== '' && str_ends_with($host, $suffix);
        }

        return false;
    }

    private function is_field_visible(array $field, array $values): bool
    {
        $condition_field = sanitize_key((string) ($field['condition_field'] ?? ''));
        $condition_value = trim((string) ($field['condition_value'] ?? ''));

        if ($condition_field === '' || $condition_value === '') {
            return true;
        }

        $actual   = trim((string) ($values[$condition_field] ?? ''));
        $expected = preg_split('/[\r\n,;|]+/', $condition_value) ?: [];
        $actual   = strtolower($actual);

        foreach ($expected as $value) {
            if ($actual === strtolower(trim((string) $value))) {
                return true;
            }
        }

        return false;
    }

    private function get_submission_status_options(): array
    {
        return [
            'new' => 'Neu',
            'in_progress' => 'In Bearbeitung',
            'closed' => 'Abgeschlossen',
            'spam' => 'Spam',
        ];
    }

    private function duplicate_form(int $form_id): void
    {
        $form = $this->resolve_form($this->repository->get_form($form_id));
        if (! is_array($form)) {
            $this->redirect_admin(self::MENU_SLUG);
        }

        $copy = $form;
        unset($copy['id'], $copy['_file_sync']);
        $copy['title'] = $this->build_unique_form_copy_title((string) $form['title']);
        $copy['slug']  = $this->build_unique_slug((string) $form['slug'] . '-kopie');

        $new_id   = $this->repository->save_form($copy, 0);
        $new_form = $this->repository->get_form($new_id);
        if (is_array($new_form)) {
            $this->form_files->write_form($new_form);
            $this->form_files->ensure_form_stylesheet($new_form, $this->build_frontend_design_css($new_form));
        }
        $this->repository->insert_activity_log('form_duplicated', 'form', $new_id, 'Formular dupliziert: ' . (string) $copy['title'], [
            'source_id' => (int) $form['id'],
        ]);

        $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'form_duplicated']);
    }

    private function build_unique_form_copy_title(string $title): string
    {
        $title = trim($title);
        if ($title === '') {
            $title = 'Formular';
        }

        $base  = $title . ' Kopie';
        $count = 2;
        $existing_titles = array_map(static fn (array $form): string => (string) ($form['title'] ?? ''), $this->resolve_forms($this->repository->get_forms()));
        $candidate = $base;
        while (in_array($candidate, $existing_titles, true)) {
            $candidate = $base . ' ' . $count;
            ++$count;
        }

        return $candidate;
    }

    private function build_unique_slug(string $slug, int $exclude_id = 0): string
    {
        $base = sanitize_title($slug);
        if ($base === '') {
            $base = 'formular';
        }

        $candidate = $base;
        $count     = 2;
        while ($this->repository->get_form_by_slug_excluding_id($candidate, $exclude_id) !== null) {
            $candidate = $base . '-' . $count;
            ++$count;
        }

        return $candidate;
    }

    private function export_form_json(int $form_id): void
    {
        $form = $this->resolve_form($this->repository->get_form($form_id));
        if (! is_array($form)) {
            $this->redirect_admin(self::MENU_SLUG);
        }

        $json = $this->form_files->export_form_json($form);
        nocache_headers();
        header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name((string) $form['slug']) . '.json"');
        echo $json;
        exit;
    }

    private function export_submissions_csv(int $form_id): void
    {
        $logs = $this->repository->get_submissions($form_id, 5000);
        $field_labels = [];
        foreach ($logs as $submission) {
            foreach ((array) ($submission['fields'] ?? []) as $label => $value) {
                $field_labels[(string) $label] = (string) $label;
            }
        }

        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="feuer-kontaktform-logs-' . gmdate('Ymd-His') . '.csv"');

        $output = fopen('php://output', 'wb');
        if (! is_resource($output)) {
            exit;
        }

        fwrite($output, "\xEF\xBB\xBF");
        fputcsv($output, array_map([$this, 'escape_csv_cell'], array_merge([
            'ID',
            'Ticket-ID',
            'Datum',
            'Formular',
            'Status',
            'Antwort-E-Mail',
            'Weiterleitung',
            'Autoantwort',
            'Webhook',
            'Datenschutz',
            'Datenschutz-Version',
            'Captcha',
            'IP',
            'Cookie-ID',
            'Geraet',
            'Referrer',
        ], array_values($field_labels))), ';');

        foreach ($logs as $submission) {
            $row = [
                (int) ($submission['id'] ?? 0),
                (string) ($submission['ticket_code'] ?? ''),
                (string) ($submission['created_at'] ?? ''),
                (string) ($submission['form_title'] ?? ''),
                (string) ($submission['status'] ?? 'new'),
                (string) ($submission['reply_email'] ?? ''),
                (string) ($submission['mail_status'] ?? ''),
                (string) ($submission['auto_reply_status'] ?? ''),
                (string) ($submission['webhook_status'] ?? ''),
                ! empty($submission['privacy_accepted']) ? 'Ja' : 'Nein',
                (string) ($submission['privacy_version'] ?? ''),
                ! empty($submission['captcha_required']) ? 'Ja' : 'Nein',
                (string) ($submission['ip_address'] ?? ''),
                (string) ($submission['visitor_cookie'] ?? ''),
                (string) ($submission['device_type'] ?? ''),
                (string) ($submission['referrer_url'] ?? ''),
            ];

            foreach ($field_labels as $label) {
                $row[] = (string) ($submission['fields'][$label] ?? '');
            }

            fputcsv($output, array_map([$this, 'escape_csv_cell'], $row), ';');
        }

        fclose($output);
        exit;
    }

    private function escape_csv_cell($value): string
    {
        $cell = (string) $value;
        if ($cell !== '' && preg_match('/^[=\+\-@\t\r]/', $cell) === 1) {
            return "'" . $cell;
        }

        return $cell;
    }

    private function import_form_json(): void
    {
        check_admin_referer('feuer-kontaktform-import-form-json');

        $raw = trim((string) wp_unslash($_POST['import_json_payload'] ?? ''));
        if ($raw === '') {
            $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'import_invalid']);
        }

        $decoded = json_decode($raw, true);
        $source  = is_array($decoded['form'] ?? null) ? $decoded['form'] : null;
        if (! is_array($source)) {
            $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'import_invalid']);
        }

        $fields = $this->normalize_admin_fields(is_array($source['fields'] ?? null) ? $source['fields'] : []);
        $recipient_email = implode(', ', $this->normalize_email_list((string) ($source['recipient_email'] ?? '')));
        if ($fields === [] || $recipient_email === '') {
            $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'import_invalid']);
        }

        $payload = [
            'title' => $this->build_unique_form_copy_title($this->truncate_input_value(sanitize_text_field((string) ($source['title'] ?? 'Formular')), 190)),
            'slug' => $this->build_unique_slug((string) ($source['slug'] ?? sanitize_title((string) ($source['title'] ?? 'formular')))),
            'design_variant' => sanitize_key((string) ($source['design_variant'] ?? 'design-1')),
            'design_settings' => feuer_kontaktform_normalize_design_settings($source['design_settings'] ?? []),
            'display_settings' => feuer_kontaktform_normalize_display_settings($source['display_settings'] ?? []),
            'behavior_settings' => feuer_kontaktform_normalize_behavior_settings($source['behavior_settings'] ?? []),
            'recipient_email' => $recipient_email,
            'auto_reply_subject' => $this->truncate_input_value(sanitize_text_field((string) ($source['auto_reply_subject'] ?? '')), 190),
            'auto_reply_message' => $this->truncate_input_value(wp_kses_post((string) ($source['auto_reply_message'] ?? '')), 12000),
            'fields' => $fields,
        ];

        $new_id   = $this->repository->save_form($payload, 0);
        $new_form = $this->repository->get_form($new_id);
        if (is_array($new_form)) {
            $this->form_files->write_form($new_form);
            $this->form_files->ensure_form_stylesheet($new_form, $this->build_frontend_design_css($new_form));
        }
        $this->repository->insert_activity_log('form_imported', 'form', $new_id, 'Formular aus JSON importiert: ' . (string) $payload['title']);

        $this->redirect_admin(self::MENU_SLUG, ['feuer-kontaktform-notice' => 'form_imported']);
    }

    private function save_submission_status(): void
    {
        check_admin_referer('feuer-kontaktform-save-submission-status');

        $submission_id = isset($_POST['submission_id']) ? absint(wp_unslash($_POST['submission_id'])) : 0;
        $status        = sanitize_key((string) wp_unslash($_POST['status'] ?? 'new'));
        $form_id       = isset($_POST['return_form_id']) ? absint(wp_unslash($_POST['return_form_id'])) : 0;

        if (! isset($this->get_submission_status_options()[$status])) {
            $status = 'new';
        }

        $this->repository->update_submission_status($submission_id, $status);
        $this->repository->insert_activity_log('ticket_status_changed', 'submission', $submission_id, 'Ticket-Status geaendert: ' . $status);
        $this->redirect_admin('feuer-kontaktform-logs', array_filter([
            'form_id' => $form_id > 0 ? $form_id : null,
            'feuer-kontaktform-notice' => 'status_saved',
        ]));
    }

    private function get_forms_page_path(string $forms_page_url): string
    {
        $page_path = trim((string) wp_parse_url($forms_page_url, PHP_URL_PATH), '/');
        $home_path = trim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');

        if ($page_path === '') {
            return '';
        }

        if ($home_path !== '' && $page_path === $home_path) {
            return '';
        }

        if ($home_path !== '' && str_starts_with($page_path, $home_path . '/')) {
            $page_path = substr($page_path, strlen($home_path) + 1);
        }

        return trim($page_path, '/');
    }

    private function parse_routing_rules_text(string $raw): array
    {
        $rules = [];
        $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }

            $parts = array_map('trim', explode('|', $line));
            if (count($parts) < 3) {
                continue;
            }

            $rules[] = [
                'field_key' => sanitize_key((string) ($parts[0] ?? '')),
                'match_value' => sanitize_text_field((string) ($parts[1] ?? '')),
                'recipient_email' => sanitize_textarea_field((string) ($parts[2] ?? '')),
                'mode' => sanitize_key((string) ($parts[3] ?? 'append')),
                'label' => sanitize_text_field((string) ($parts[4] ?? '')),
            ];
        }

        return $rules;
    }

    private function parse_topics_text(string $raw): array
    {
        $topics = [];
        $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }

            $parts = array_map('trim', explode('|', $line, 5));
            $label = sanitize_text_field((string) ($parts[1] ?? $parts[0] ?? ''));
            if ($label === '') {
                continue;
            }

            $topics[] = [
                'slug' => sanitize_title((string) ($parts[0] ?? $label)),
                'label' => $label,
                'recipient_email' => sanitize_textarea_field((string) ($parts[2] ?? '')),
                'auto_reply_subject' => sanitize_text_field((string) ($parts[3] ?? '')),
                'auto_reply_message' => wp_kses_post((string) ($parts[4] ?? '')),
            ];
        }

        return $topics;
    }
}


