<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Mailer
{
    public function send_notification(array $form, array $values, string $reply_email, string $ip_address, string $user_agent, array $settings, bool $privacy_accepted): array
    {
        $recipients = $this->normalize_recipients((string) $form['recipient_email']);
        if ($recipients === []) {
            return [
                'success' => false,
                'status' => 'fehler',
                'details' => 'Es ist keine gueltige Empfaenger-E-Mail fuer dieses Formular hinterlegt.',
            ];
        }

        $ticket_code = sanitize_text_field((string) ($form['_ticket_code'] ?? ''));
        $subject = sanitize_text_field(($ticket_code !== '' ? '[' . $ticket_code . '] ' : '') . 'Neue Nachricht: ' . (string) $form['title']);
        $body    = [
            'Neue Anfrage ueber Feuer-Kontaktform',
            '',
            'Ticket-ID: ' . ($ticket_code !== '' ? $ticket_code : '-'),
            'Formular / Abteilung: ' . $form['title'],
            '',
            'Uebermittelte Daten:',
            $this->format_field_lines($form['fields'], $values),
            '',
            'Datenschutzhinweis bestaetigt: ' . ($privacy_accepted ? 'Ja' : 'Nein'),
        ];

        $privacy_policy_url = esc_url_raw((string) ($settings['privacy_policy_url'] ?? ''));
        if ($privacy_policy_url !== '') {
            $body[] = 'Datenschutzerklaerung: ' . $privacy_policy_url;
        }

        return $this->deliver_message(
            $recipients,
            $subject,
            implode("\n", $body),
            $this->build_headers((string) $settings['sender_name'], (string) $settings['sender_email'], $reply_email),
            'Weiterleitung',
            $settings
        );
    }

    public function send_auto_reply(array $form, array $values, string $reply_email, array $settings): array
    {
        if (! is_email($reply_email)) {
            return [
                'success' => false,
                'status' => 'fehler',
                'details' => 'Es liegt keine gueltige Antwort-E-Mail fuer die Autoantwort vor.',
            ];
        }

        $ticket_code = sanitize_text_field((string) ($form['_ticket_code'] ?? ''));
        $subject = $form['auto_reply_subject'] !== ''
            ? $form['auto_reply_subject']
            : (string) $settings['default_auto_reply_subject'];
        if ($ticket_code !== '' && ! str_contains($subject, $ticket_code)) {
            $subject = '[' . $ticket_code . '] ' . $subject;
        }
        $subject = sanitize_text_field($subject);

        $message = $form['auto_reply_message'] !== ''
            ? $form['auto_reply_message']
            : (string) $settings['default_auto_reply_message'];

        $brand = feuer_kontaktform_brand_context($settings);
        $logo_markup = $brand['logo_url'] !== ''
            ? sprintf(
                '<img src="%s" alt="%s" style="max-width:%dpx;height:auto;display:block;">',
                esc_url($brand['logo_url']),
                esc_attr($brand['label']),
                (int) $brand['logo_width']
            )
            : '';
        $website_markup = $brand['website_url'] !== ''
            ? sprintf(
                '<a href="%s" target="_blank" rel="noopener">%s</a>',
                esc_url($brand['website_url']),
                esc_html($brand['website_text'])
            )
            : '';

        $message = strtr(
            $message,
            [
                '{{formular}}' => $form['title'],
                '{{vorname}}' => $this->field_value_by_type($form['fields'], $values, 'vorname'),
                '{{nachname}}' => $this->field_value_by_type($form['fields'], $values, 'nachname'),
                '{{name}}' => trim($this->field_value_by_type($form['fields'], $values, 'vorname') . ' ' . $this->field_value_by_type($form['fields'], $values, 'nachname')),
                '{{logo}}' => $logo_markup,
                '{{logo_url}}' => $brand['logo_url'],
                '{{website}}' => $website_markup,
                '{{site_url}}' => $brand['website_url'],
                '{{ticket}}' => $ticket_code,
                '{{ticket_id}}' => $ticket_code,
            ]
        );

        $message = wpautop(
            wp_kses(
                $message,
                [
                    'a' => [
                        'href' => true,
                        'target' => true,
                        'rel' => true,
                    ],
                    'br' => true,
                    'em' => true,
                    'img' => [
                        'src' => true,
                        'alt' => true,
                        'style' => true,
                        'width' => true,
                        'height' => true,
                    ],
                    'p' => true,
                    'span' => [
                        'style' => true,
                    ],
                    'strong' => true,
                ]
            )
        );

        $recipients = $this->normalize_recipients((string) $form['recipient_email']);
        $reply_to   = $recipients[0] ?? '';

        return $this->deliver_message(
            [$reply_email],
            $subject,
            $message,
            $this->build_headers((string) $settings['sender_name'], (string) $settings['sender_email'], $reply_to, 'text/html'),
            'Autoantwort',
            $settings
        );
    }

    public function test_smtp_connection(array $settings): array
    {
        $validation = $this->validate_smtp_settings($settings);
        if (! $validation['success']) {
            return $validation;
        }

        $this->load_phpmailer_classes();
        $mailer = new \PHPMailer\PHPMailer\PHPMailer(true);

        try {
            $this->configure_phpmailer($mailer, $settings);
            $connected = $mailer->smtpConnect();
            $mailer->smtpClose();

            if (! $connected) {
                return [
                    'success' => false,
                    'details' => 'Der SMTP-Server hat die Verbindung abgelehnt.',
                ];
            }

            return [
                'success' => true,
                'details' => 'SMTP-Verbindung zu ' . sanitize_text_field((string) $settings['smtp_host']) . ':' . (int) $settings['smtp_port'] . ' aufgebaut.',
            ];
        } catch (\Throwable $exception) {
            if (method_exists($mailer, 'smtpClose')) {
                $mailer->smtpClose();
            }

            return [
                'success' => false,
                'details' => $this->sanitize_exception_message($exception->getMessage()),
            ];
        }
    }

    public function send_test_email(array $settings, string $recipient): array
    {
        if (! is_email($recipient)) {
            return [
                'success' => false,
                'status' => 'fehler',
                'details' => 'Bitte geben Sie eine gueltige Empfaengeradresse fuer die Test-E-Mail an.',
            ];
        }

        $validation = $this->validate_smtp_settings($settings);
        if (! $validation['success']) {
            return [
                'success' => false,
                'status' => 'fehler',
                'details' => (string) $validation['details'],
            ];
        }

        $test_settings = $settings;
        $test_settings['smtp_enabled'] = true;

        $subject = 'SMTP-Test: Feuer-Kontaktform';
        $message = implode("\n", [
            'Dies ist eine Test-E-Mail von Feuer-Kontaktform.',
            '',
            'Versandzeit: ' . current_time('mysql'),
            'SMTP-Host: ' . sanitize_text_field((string) ($settings['smtp_host'] ?? '')),
            'SMTP-Port: ' . (int) ($settings['smtp_port'] ?? 0),
        ]);

        return $this->deliver_message(
            [$recipient],
            $subject,
            $message,
            $this->build_headers((string) $settings['sender_name'], (string) $settings['sender_email']),
            'Test-E-Mail',
            $test_settings
        );
    }

    private function deliver_message(array $recipients, string $subject, string $message, array $headers, string $label, array $settings): array
    {
        $successful = [];
        $failed     = [];

        foreach ($recipients as $recipient) {
            $result = $this->send_single_mail($recipient, $subject, $message, $headers, $settings);

            if ($result['success']) {
                $successful[] = $recipient;
                continue;
            }

            $failed[] = $recipient . ($result['details'] !== '' ? ' (' . $result['details'] . ')' : '');
        }

        if ($successful !== []) {
            $details = $label . ' gesendet an: ' . implode(', ', $successful) . '.';
            if ($failed !== []) {
                $details .= ' Fehlgeschlagen: ' . implode('; ', $failed) . '.';
            }

            return [
                'success' => true,
                'status' => 'gesendet',
                'details' => $details,
            ];
        }

        return [
            'success' => false,
            'status' => 'fehler',
            'details' => $label . ' konnte nicht zugestellt werden.' . ($failed !== [] ? ' Details: ' . implode('; ', $failed) . '.' : ''),
        ];
    }

    private function send_single_mail(string $recipient, string $subject, string $message, array $headers, array $settings): array
    {
        $attempt = $this->send_with_error_capture($recipient, $subject, $message, $headers, $settings);
        if ($attempt['success']) {
            return $attempt;
        }

        return $this->send_with_error_capture(
            $recipient,
            $subject,
            $this->convert_message_to_plain_text($message),
            $this->replace_content_type($headers, 'text/plain'),
            $settings
        );
    }

    private function send_with_error_capture(string $recipient, string $subject, string $message, array $headers, array $settings): array
    {
        $error_messages = [];
        $capture        = static function ($error) use (&$error_messages): void {
            if ($error instanceof WP_Error) {
                $error_messages = array_merge($error_messages, $error->get_error_messages());
            }
        };

        $transport_error = '';
        add_action('wp_mail_failed', $capture);

        try {
            $sent = $this->execute_with_transport(
                $settings,
                static fn (): bool => wp_mail($recipient, $subject, $message, $headers)
            );
        } catch (\Throwable $exception) {
            $sent = false;
            $transport_error = $this->sanitize_exception_message($exception->getMessage());
        } finally {
            remove_action('wp_mail_failed', $capture);
        }

        if ($sent) {
            return [
                'success' => true,
                'details' => '',
            ];
        }

        if ($transport_error !== '') {
            $error_messages[] = $transport_error;
        }

        $error_messages = array_values(array_unique(array_filter(array_map('sanitize_text_field', $error_messages))));

        return [
            'success' => false,
            'details' => $error_messages !== [] ? implode(' ', $error_messages) : 'wp_mail hat den Versand abgelehnt.',
        ];
    }

    private function execute_with_transport(array $settings, callable $callback): bool
    {
        if (! $this->is_smtp_enabled($settings)) {
            return (bool) $callback();
        }

        $this->load_phpmailer_classes();

        $sender_email = sanitize_email((string) ($settings['sender_email'] ?? ''));
        $sender_name  = sanitize_text_field((string) ($settings['sender_name'] ?? ''));
        $smtp_handler = function ($phpmailer) use ($settings): void {
            if ($phpmailer instanceof \PHPMailer\PHPMailer\PHPMailer) {
                $this->configure_phpmailer($phpmailer, $settings);
            }
        };
        $from_filter = static function (string $email) use ($sender_email): string {
            return is_email($sender_email) ? $sender_email : $email;
        };
        $from_name_filter = static function (string $name) use ($sender_name): string {
            return $sender_name !== '' ? $sender_name : $name;
        };

        add_action('phpmailer_init', $smtp_handler, 100);
        add_filter('wp_mail_from', $from_filter, 100);
        add_filter('wp_mail_from_name', $from_name_filter, 100);

        try {
            return (bool) $callback();
        } finally {
            remove_action('phpmailer_init', $smtp_handler, 100);
            remove_filter('wp_mail_from', $from_filter, 100);
            remove_filter('wp_mail_from_name', $from_name_filter, 100);
        }
    }

    private function is_smtp_enabled(array $settings): bool
    {
        return ! empty($settings['smtp_enabled']) && trim((string) ($settings['smtp_host'] ?? '')) !== '';
    }

    private function validate_smtp_settings(array $settings): array
    {
        $host       = trim((string) ($settings['smtp_host'] ?? ''));
        $port       = (int) ($settings['smtp_port'] ?? 0);
        $encryption = sanitize_key((string) ($settings['smtp_encryption'] ?? ''));
        $auth       = ! empty($settings['smtp_auth']);
        $username   = trim((string) ($settings['smtp_username'] ?? ''));
        $password   = (string) ($settings['smtp_password'] ?? '');
        $sender     = sanitize_email((string) ($settings['sender_email'] ?? ''));

        if ($host === '') {
            return [
                'success' => false,
                'details' => 'Bitte geben Sie einen SMTP-Host an.',
            ];
        }

        if ($port < 1 || $port > 65535) {
            return [
                'success' => false,
                'details' => 'Bitte geben Sie einen gueltigen SMTP-Port an.',
            ];
        }

        if (! in_array($encryption, ['none', 'tls', 'ssl'], true)) {
            return [
                'success' => false,
                'details' => 'Bitte waehlen Sie eine gueltige SMTP-Verschluesselung.',
            ];
        }

        if ($auth && $username === '') {
            return [
                'success' => false,
                'details' => 'Bitte geben Sie einen SMTP-Benutzernamen an.',
            ];
        }

        if ($auth && $password === '') {
            return [
                'success' => false,
                'details' => 'Bitte geben Sie ein SMTP-Passwort an.',
            ];
        }

        if (! is_email($sender)) {
            return [
                'success' => false,
                'details' => 'Bitte hinterlegen Sie eine gueltige Absender-E-Mail.',
            ];
        }

        return [
            'success' => true,
            'details' => '',
        ];
    }

    private function configure_phpmailer(\PHPMailer\PHPMailer\PHPMailer $phpmailer, array $settings): void
    {
        $validation = $this->validate_smtp_settings($settings);
        if (! $validation['success']) {
            throw new RuntimeException((string) $validation['details']);
        }

        $sender_email = sanitize_email((string) ($settings['sender_email'] ?? ''));
        $sender_name  = sanitize_text_field((string) ($settings['sender_name'] ?? ''));
        $encryption   = sanitize_key((string) ($settings['smtp_encryption'] ?? 'tls'));

        if ($sender_name === '') {
            $sender_name = 'Feuer-Kontaktform';
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = trim((string) $settings['smtp_host']);
        $phpmailer->Port = (int) $settings['smtp_port'];
        $phpmailer->Timeout = max(3, min(60, (int) ($settings['smtp_timeout'] ?? 15)));
        $phpmailer->SMTPAuth = ! empty($settings['smtp_auth']);
        $phpmailer->Username = $phpmailer->SMTPAuth ? (string) ($settings['smtp_username'] ?? '') : '';
        $phpmailer->Password = $phpmailer->SMTPAuth ? (string) ($settings['smtp_password'] ?? '') : '';
        $phpmailer->CharSet = 'UTF-8';
        $phpmailer->Sender = $sender_email;
        $phpmailer->SMTPAutoTLS = $encryption !== 'none';

        if ($encryption === 'ssl') {
            $phpmailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($encryption === 'tls') {
            $phpmailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $phpmailer->SMTPSecure = '';
        }

        $phpmailer->setFrom($sender_email, $sender_name, false);
    }

    private function load_phpmailer_classes(): void
    {
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            return;
        }

        require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
        require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
        require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
    }

    private function build_headers(string $sender_name, string $sender_email, string $reply_to = '', string $content_type = 'text/plain'): array
    {
        $sender_name = sanitize_text_field($sender_name);
        $sender_email = sanitize_email($sender_email);
        $headers = ['Content-Type: ' . $content_type . '; charset=UTF-8'];

        if ($sender_name === '') {
            $sender_name = 'Feuer-Kontaktform';
        }

        if ($sender_email !== '' && is_email($sender_email)) {
            $headers[] = 'From: ' . $sender_name . ' <' . $sender_email . '>';
            $headers[] = 'Sender: ' . $sender_email;
        }

        if ($reply_to !== '' && is_email($reply_to)) {
            $headers[] = 'Reply-To: ' . $reply_to;
        }

        return $headers;
    }

    private function replace_content_type(array $headers, string $content_type): array
    {
        $updated = [];
        $replaced = false;

        foreach ($headers as $header) {
            if (stripos($header, 'Content-Type:') === 0) {
                $updated[] = 'Content-Type: ' . $content_type . '; charset=UTF-8';
                $replaced = true;
                continue;
            }

            $updated[] = $header;
        }

        if (! $replaced) {
            $updated[] = 'Content-Type: ' . $content_type . '; charset=UTF-8';
        }

        return $updated;
    }

    private function convert_message_to_plain_text(string $message): string
    {
        $message = preg_replace('/<br\s*\/?>/i', "\n", $message) ?? $message;
        $message = preg_replace('/<\/p>/i', "\n\n", $message) ?? $message;
        $message = html_entity_decode(wp_strip_all_tags($message), ENT_QUOTES, 'UTF-8');
        $message = preg_replace("/\n{3,}/", "\n\n", $message) ?? $message;

        return trim($message);
    }

    private function format_field_lines(array $fields, array $values): string
    {
        $lines = [];

        foreach ($fields as $field) {
            $value   = (string) ($values[$field['key']] ?? '');
            $lines[] = $field['label'] . ': ' . ($value !== '' ? $value : '-');
        }

        return implode("\n", $lines);
    }

    private function field_value_by_type(array $fields, array $values, string $type): string
    {
        foreach ($fields as $field) {
            if ($field['type'] === $type) {
                return trim((string) ($values[$field['key']] ?? ''));
            }
        }

        return '';
    }

    private function normalize_recipients(string $raw): array
    {
        $recipients = preg_split('/[\r\n,;]+/', $raw) ?: [];
        $recipients = array_map('trim', $recipients);
        $recipients = array_filter($recipients, static fn (string $email): bool => is_email($email) !== false);
        $recipients = array_values(array_unique($recipients));

        return array_slice($recipients, 0, 10);
    }

    private function sanitize_exception_message(string $message): string
    {
        $message = sanitize_text_field($message);
        return $message !== '' ? $message : 'Unbekannter SMTP-Fehler.';
    }
}
