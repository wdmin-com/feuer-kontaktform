<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Installer
{
    private const OPTION_SETTINGS = 'feuer-kontaktform-settings';
    private const OPTION_VERSION = 'feuer-kontaktform-version';
    private const FLASH_PREFIX = 'feuer-kontaktform-flash-';

    public static function activate(): void
    {
        $repository = new Feuer_Kontaktform_Repository();
        $repository->create_tables();
        if (class_exists('Feuer_Kontaktform_Form_Files')) {
            $form_files = new Feuer_Kontaktform_Form_Files();
            $form_files->initialize_storage();
            foreach ($repository->get_forms() as $form) {
                $form_files->write_form($form);
            }
        }

        $settings = get_option(self::OPTION_SETTINGS);
        if (! is_array($settings)) {
            add_option(self::OPTION_SETTINGS, feuer_kontaktform_default_settings());
        } else {
            update_option(self::OPTION_SETTINGS, wp_parse_args($settings, feuer_kontaktform_default_settings()));
        }

        update_option(self::OPTION_VERSION, FEUER_KONTAKTFORM_VERSION);
    }

    public static function uninstall(): void
    {
        global $wpdb;

        $repository = new Feuer_Kontaktform_Repository();
        if (class_exists('Feuer_Kontaktform_Form_Files')) {
            $form_files = new Feuer_Kontaktform_Form_Files();
            $form_files->delete_storage();
        }
        $repository->drop_tables();

        delete_option(self::OPTION_SETTINGS);
        delete_option(self::OPTION_VERSION);

        $options_table = $wpdb->options;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$options_table}
                WHERE option_name LIKE %s
                OR option_name LIKE %s",
                '_transient_' . self::FLASH_PREFIX . '%',
                '_transient_timeout_' . self::FLASH_PREFIX . '%'
            )
        );
    }
}


