# Changelog

## 2.5.0 - 2026-04-21

- Plugin-Metadaten auf Walter Faerber und `wdmin.com/plugins/feuer-kontaktform/` aktualisiert.
- Self-hosted Update-Check mit Button in den Einstellungen hinzugefuegt.
- Frontend auf einen einheitlichen Ticket-Wizard mit Datenschutz-Schritt und Ladeanzeige umgestellt.
- Ticket-ID, Cookie-ID, Geraetetyp und Datenschutz-Kontext fuer Anfragen eingefuehrt.
- Themen pro Formular hinzugefuegt; Themen koennen Empfaenger und Autoantwort ueberschreiben.
- Aktivitaetsprotokoll fuer zentrale Plugin-Aktionen hinzugefuegt.
- DB-Schema auf `dbDelta()` umgestellt und neue Spalten fuer Ticket-Protokolle vorbereitet.
- CSV-Export gegen Spreadsheet-Formula-Injection abgesichert.
- Frontend-Designwerte werden jetzt als scoped CSS ausgegeben.
- GitHub-Basisdateien, Update-Metadaten und Praesentationsseite ergaenzt.

## 2.4.0

- Vorherige interne Version mit Formularverwaltung, SMTP, Autoantworten, Webhooks, JSON-Dateien und mehreren Layoutvarianten.
