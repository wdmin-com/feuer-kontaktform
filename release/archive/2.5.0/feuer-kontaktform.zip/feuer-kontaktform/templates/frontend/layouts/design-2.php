<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-2">
    <div class="row g-4 align-items-start">
        <div class="col-lg-4">
            <?php echo $render_partial('frontend/partials/info-card.php', array_merge($layout_vars, [
                'show_info_logo' => true,
                'info_kicker' => (string) ($brand['label'] ?? 'Kontakt'),
            ])); ?>
        </div>
        <div class="col-lg-8">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => false,
            ])); ?>
        </div>
    </div>
</div>
