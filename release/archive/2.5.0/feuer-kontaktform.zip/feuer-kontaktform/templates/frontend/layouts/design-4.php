<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-4">
    <div class="row g-4 align-items-start">
        <div class="col-xl-7">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => false,
            ])); ?>
        </div>
        <div class="col-xl-5">
            <div class="d-grid gap-4">
                <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
                    'intro_kicker' => 'Direktkontakt',
                    'intro_title' => (string) ($form['title'] ?? 'Kontakt'),
                    'intro_text' => $intro_copy,
                ])); ?>

                <?php echo $render_partial('frontend/partials/info-card.php', array_merge($layout_vars, [
                    'show_info_logo' => false,
                    'info_kicker' => 'Abteilung',
                ])); ?>
            </div>
        </div>
    </div>
</div>
