<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-6 d-grid gap-4">
    <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
        'intro_card_class' => 'card border-0 shadow-sm feuer-kontaktform-intro-card feuer-kontaktform-intro-card-hero',
        'intro_kicker' => 'Servicebereich',
    ])); ?>

    <div class="row g-4 align-items-start">
        <div class="col-lg-8">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => false,
            ])); ?>
        </div>
        <div class="col-lg-4">
            <?php echo $render_partial('frontend/partials/info-card.php', array_merge($layout_vars, [
                'show_info_logo' => true,
                'info_kicker' => 'Hinweise',
            ])); ?>
        </div>
    </div>
</div>
