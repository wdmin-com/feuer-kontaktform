<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-5">
    <div class="row g-4 align-items-start">
        <div class="col-lg-5">
            <?php echo $render_partial('frontend/partials/media-card.php', array_merge($layout_vars, [
                'show_media_logo' => true,
                'media_kicker' => 'Kontakt',
            ])); ?>
        </div>
        <div class="col-lg-7">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => true,
            ])); ?>
        </div>
    </div>
</div>
