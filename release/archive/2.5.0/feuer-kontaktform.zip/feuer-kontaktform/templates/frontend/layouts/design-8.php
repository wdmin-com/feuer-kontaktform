<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-8">
    <div class="row g-4 align-items-stretch">
        <div class="col-lg-3">
            <?php echo $render_partial('frontend/partials/media-card.php', array_merge($layout_vars, [
                'show_media_logo' => true,
                'media_kicker' => 'Info',
                'media_title' => (string) ($brand['label'] ?? 'Kontakt'),
                'media_text' => $aside_copy,
            ])); ?>
        </div>
        <div class="col-lg-9">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => false,
            ])); ?>
        </div>
    </div>
</div>
