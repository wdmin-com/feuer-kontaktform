<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-7 d-grid gap-4">
    <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
        'intro_card_class' => 'card border-0 shadow-sm feuer-kontaktform-intro-card feuer-kontaktform-intro-card-compact',
        'intro_kicker' => (string) ($brand['label'] ?? 'Feuer-Kontaktform'),
        'intro_title' => 'Kurzer Kontaktweg',
        'intro_text' => $intro_copy,
    ])); ?>

    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-7">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => true,
            ])); ?>
        </div>
    </div>
</div>
