<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-9 d-grid gap-4">
    <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
        'intro_card_class' => 'card border-0 shadow-sm feuer-kontaktform-intro-card feuer-kontaktform-intro-card-band',
        'intro_kicker' => 'Information',
        'intro_text' => $aside_copy,
    ])); ?>

    <div class="row justify-content-center">
        <div class="col-xl-9">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => false,
            ])); ?>
        </div>
    </div>

    <?php if ($show_contact_info) : ?>
        <div class="row justify-content-end">
            <div class="col-lg-5 col-xl-4">
                <?php echo $render_partial('frontend/partials/info-card.php', array_merge($layout_vars, [
                    'show_info_logo' => false,
                    'info_kicker' => 'Rueckfragen',
                ])); ?>
            </div>
        </div>
    <?php endif; ?>
</div>
