<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-1 d-grid gap-4">
    <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
        'intro_card_class' => 'card border-0 shadow-sm feuer-kontaktform-intro-card feuer-kontaktform-intro-card-centered',
    ])); ?>

    <div class="row justify-content-center">
        <div class="col-xl-8">
            <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                'show_panel_logo' => true,
            ])); ?>
        </div>
    </div>
</div>
