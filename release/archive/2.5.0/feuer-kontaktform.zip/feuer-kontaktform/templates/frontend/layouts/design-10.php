<?php $layout_vars = get_defined_vars(); ?>
<div class="feuer-kontaktform-layout feuer-kontaktform-layout-design-10">
    <div class="row g-4 align-items-start">
        <div class="col-xl-4">
            <div class="d-grid gap-4">
                <?php echo $render_partial('frontend/partials/intro-panel.php', array_merge($layout_vars, [
                    'intro_card_class' => 'card border-0 shadow-sm feuer-kontaktform-intro-card feuer-kontaktform-intro-card-corporate',
                    'intro_kicker' => 'Unternehmenskontakt',
                ])); ?>

                <?php echo $render_partial('frontend/partials/info-card.php', array_merge($layout_vars, [
                    'show_info_logo' => true,
                    'info_kicker' => 'Servicekarte',
                ])); ?>
            </div>
        </div>
        <div class="col-xl-8">
            <div class="d-grid gap-4">
                <?php echo $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
                    'show_panel_logo' => true,
                ])); ?>

                <?php echo $render_partial('frontend/partials/media-card.php', array_merge($layout_vars, [
                    'show_media_logo' => true,
                    'media_kicker' => 'Einblick',
                    'media_text' => $intro_copy,
                ])); ?>
            </div>
        </div>
    </div>
</div>
