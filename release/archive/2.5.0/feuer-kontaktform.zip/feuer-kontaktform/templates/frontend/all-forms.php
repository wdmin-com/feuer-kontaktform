<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <div class="feuer-kontaktform-switcher mx-auto" data-selected-form="<?php echo esc_attr((string) $selected_form_id); ?>">
                <?php if (! isset($show_selector) || ! empty($show_selector)) : ?>
                    <div class="feuer-kontaktform-ticket-shell mb-4">
                        <div class="feuer-kontaktform-ticket-panel">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-10 col-lg-10">
                                    <label class="form-label fw-semibold" for="feuer_kontaktform_selector">An wen moechten Sie sich wenden?</label>
                                    <select id="feuer_kontaktform_selector" class="form-select feuer-kontaktform-selector">
                                        <?php foreach ($forms as $form) : ?>
                                            <option value="<?php echo esc_attr((string) $form['id']); ?>" data-form-query-value="<?php echo esc_attr(sanitize_title((string) ($form['slug'] ?? '')) !== '' ? sanitize_title((string) $form['slug']) : (string) $form['id']); ?>" <?php selected($selected_form_id, $form['id']); ?>><?php echo esc_html($form['title']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php foreach ($blocks as $block) : ?>
                    <?php echo $block; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
