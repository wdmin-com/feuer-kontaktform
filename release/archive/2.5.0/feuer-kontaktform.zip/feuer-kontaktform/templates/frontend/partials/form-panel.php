<?php
$panel_card_class = trim((string) ($panel_card_class ?? 'card border-0 shadow-sm feuer-kontaktform-form-card'));
$panel_body_class = trim((string) ($panel_body_class ?? 'card-body p-4 p-lg-5'));
$panel_kicker = isset($panel_kicker) ? (string) $panel_kicker : 'Feuer-Kontaktform';
$panel_title = isset($panel_title) ? (string) $panel_title : (string) ($form['title'] ?? 'Kontakt');
$panel_note = isset($panel_note) ? (string) $panel_note : 'Bitte fuellen Sie alle benoetigten Angaben aus. Pflichtfelder sind mit einem Stern markiert.';
$show_panel_logo = ! empty($show_panel_logo) && ! empty($brand['logo_url']);
$panel_title_tag = isset($panel_title_tag) ? (string) $panel_title_tag : 'h3';
$panel_title_tag = in_array($panel_title_tag, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], true) ? $panel_title_tag : 'h3';
$panel_vars = get_defined_vars();
?>
<div class="<?php echo esc_attr($panel_card_class); ?>">
    <div class="<?php echo esc_attr($panel_body_class); ?>">
        <?php if ($show_panel_logo || $panel_kicker !== '' || $panel_title !== '' || $panel_note !== '') : ?>
            <div class="feuer-kontaktform-panel-head mb-4">
                <?php if ($show_panel_logo) : ?>
                    <div class="mb-3">
                        <img
                            class="img-fluid feuer-kontaktform-panel-logo"
                            src="<?php echo esc_url((string) $brand['logo_url']); ?>"
                            alt="<?php echo esc_attr((string) $brand['label']); ?>"
                            width="<?php echo esc_attr((string) min((int) $brand['logo_width'], 180)); ?>"
                        >
                    </div>
                <?php endif; ?>

                <?php if ($panel_kicker !== '') : ?>
                    <p class="text-uppercase text-muted small fw-semibold mb-2"><?php echo esc_html($panel_kicker); ?></p>
                <?php endif; ?>

                <<?php echo $panel_title_tag; ?> class="h4 mb-2"><?php echo esc_html($panel_title); ?></<?php echo $panel_title_tag; ?>>

                <?php if ($panel_note !== '') : ?>
                    <p class="text-body-secondary mb-0"><?php echo esc_html($panel_note); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php echo $render_partial('frontend/partials/form-messages.php', $panel_vars); ?>
        <?php echo $render_partial('frontend/partials/form-body.php', $panel_vars); ?>
    </div>
</div>
