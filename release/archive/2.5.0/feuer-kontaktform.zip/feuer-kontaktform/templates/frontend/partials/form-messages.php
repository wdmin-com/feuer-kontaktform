<?php
$errors = is_array($errors ?? null) ? $errors : [];
$success = ! empty($success);
$message = isset($message) ? (string) $message : '';
?>
<?php if ($success && $message !== '') : ?>
    <div class="alert alert-success"><?php echo esc_html($message); ?></div>
<?php endif; ?>

<?php if ($errors !== []) : ?>
    <div class="alert alert-danger" data-form-summary>
        <ul class="mb-0">
            <?php foreach ($errors as $error) : ?>
                <li><?php echo esc_html((string) $error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="alert mt-3 d-none" data-form-message hidden></div>
