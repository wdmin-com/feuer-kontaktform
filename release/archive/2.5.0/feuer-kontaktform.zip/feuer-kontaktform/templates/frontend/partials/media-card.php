<?php
$media_card_class = trim((string) ($media_card_class ?? 'card border-0 shadow-sm overflow-hidden feuer-kontaktform-media-card'));
$media_body_class = trim((string) ($media_body_class ?? 'card-img-overlay d-flex align-items-end feuer-kontaktform-media-overlay'));
$media_kicker = isset($media_kicker) ? (string) $media_kicker : (string) ($brand['label'] ?? 'Feuer-Kontaktform');
$media_title = isset($media_title) ? (string) $media_title : (string) ($form['title'] ?? 'Kontakt');
$media_text = isset($media_text) ? (string) $media_text : (string) ($aside_copy ?? '');
$media_alt = isset($media_alt) ? (string) $media_alt : (string) ($form['title'] ?? 'Kontakt');
$show_media_logo = ! empty($show_media_logo) && ! empty($brand['logo_url']);
?>
<div class="<?php echo esc_attr($media_card_class); ?>">
    <?php if ($media_image_url !== '') : ?>
        <img class="card-img feuer-kontaktform-media-image" src="<?php echo esc_url($media_image_url); ?>" alt="<?php echo esc_attr($media_alt); ?>">
        <div class="<?php echo esc_attr($media_body_class); ?>">
            <div class="feuer-kontaktform-media-copy text-white">
                <?php if ($media_kicker !== '') : ?>
                    <p class="text-uppercase small fw-semibold mb-2 text-white-50"><?php echo esc_html($media_kicker); ?></p>
                <?php endif; ?>
                <h2 class="h4 mb-2"><?php echo esc_html($media_title); ?></h2>
                <?php if ($media_text !== '') : ?>
                    <p class="mb-0"><?php echo esc_html($media_text); ?></p>
                <?php endif; ?>
            </div>
        </div>
    <?php else : ?>
        <div class="card-body p-4 p-lg-5 feuer-kontaktform-media-fallback">
            <?php if ($show_media_logo) : ?>
                <div class="mb-3">
                    <img class="img-fluid" src="<?php echo esc_url((string) $brand['logo_url']); ?>" alt="<?php echo esc_attr((string) $brand['label']); ?>" width="<?php echo esc_attr((string) min((int) $brand['logo_width'], 180)); ?>">
                </div>
            <?php endif; ?>

            <?php if ($media_kicker !== '') : ?>
                <p class="text-uppercase text-muted small fw-semibold mb-2"><?php echo esc_html($media_kicker); ?></p>
            <?php endif; ?>

            <h2 class="h4 mb-2"><?php echo esc_html($media_title); ?></h2>

            <?php if ($media_text !== '') : ?>
                <p class="text-body-secondary mb-0"><?php echo esc_html($media_text); ?></p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
