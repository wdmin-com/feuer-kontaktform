<?php
$info_card_class = trim((string) ($info_card_class ?? 'card border-0 shadow-sm feuer-kontaktform-info-card'));
$info_body_class = trim((string) ($info_body_class ?? 'card-body p-4 p-lg-5'));
$info_kicker = isset($info_kicker) ? (string) $info_kicker : 'Kontakt';
$info_title = isset($info_title) ? (string) $info_title : (string) ($form['title'] ?? 'Kontakt');
$info_text = isset($info_text) ? (string) $info_text : (string) ($aside_copy ?? '');
$show_info_logo = ! empty($show_info_logo) && ! empty($brand['logo_url']);
?>
<div class="<?php echo esc_attr($info_card_class); ?>">
    <div class="<?php echo esc_attr($info_body_class); ?>">
        <?php if ($show_info_logo) : ?>
            <div class="mb-3">
                <img class="img-fluid" src="<?php echo esc_url((string) $brand['logo_url']); ?>" alt="<?php echo esc_attr((string) $brand['label']); ?>" width="<?php echo esc_attr((string) min((int) $brand['logo_width'], 180)); ?>">
            </div>
        <?php endif; ?>

        <div class="d-grid gap-3">
            <div>
                <?php if ($info_kicker !== '') : ?>
                    <p class="text-uppercase text-muted small fw-semibold mb-2"><?php echo esc_html($info_kicker); ?></p>
                <?php endif; ?>

                <h2 class="h4 mb-2"><?php echo esc_html($info_title); ?></h2>

                <?php if ($info_text !== '') : ?>
                    <p class="text-body-secondary mb-0"><?php echo esc_html($info_text); ?></p>
                <?php endif; ?>
            </div>

            <div>
                <div class="small text-uppercase text-muted fw-semibold mb-1"><?php echo esc_html($department_label); ?></div>
                <div><?php echo esc_html((string) $form['title']); ?></div>
            </div>

            <?php if ($website_text !== '') : ?>
                <div>
                    <div class="small text-uppercase text-muted fw-semibold mb-1"><?php echo esc_html($website_label); ?></div>
                    <?php if ($website_url !== '') : ?>
                        <a href="<?php echo esc_url($website_url); ?>" target="_blank" rel="noopener"><?php echo esc_html($website_text); ?></a>
                    <?php else : ?>
                        <span><?php echo esc_html($website_text); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
