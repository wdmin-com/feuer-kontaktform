<?php
$intro_card_class = trim((string) ($intro_card_class ?? 'card border-0 shadow-sm feuer-kontaktform-intro-card'));
$intro_body_class = trim((string) ($intro_body_class ?? 'card-body p-4 p-lg-5'));
$intro_kicker = isset($intro_kicker) ? (string) $intro_kicker : (string) ($brand['label'] ?? 'Feuer-Kontaktform');
$intro_title = isset($intro_title) ? (string) $intro_title : (string) ($form['title'] ?? 'Kontakt');
$intro_text = isset($intro_text) ? (string) $intro_text : (string) ($intro_copy ?? '');
?>
<div class="<?php echo esc_attr($intro_card_class); ?>">
    <div class="<?php echo esc_attr($intro_body_class); ?>">
        <?php if ($intro_kicker !== '') : ?>
            <p class="text-uppercase text-muted small fw-semibold mb-2"><?php echo esc_html($intro_kicker); ?></p>
        <?php endif; ?>

        <?php if ($intro_title !== '') : ?>
            <h2 class="h3 mb-3"><?php echo esc_html($intro_title); ?></h2>
        <?php endif; ?>

        <?php if ($intro_text !== '') : ?>
            <p class="text-body-secondary mb-0"><?php echo esc_html($intro_text); ?></p>
        <?php endif; ?>
    </div>
</div>
