<?php
$footer_note = isset($footer_note) ? (string) $footer_note : 'Felder mit * sind Pflichtfelder.';
$submit_button_label = isset($submit_button_label) ? (string) $submit_button_label : 'Nachricht senden';
$total_steps = count($steps) + 1;
?>
<form
    method="post"
    action="<?php echo esc_url($action_url); ?>"
    class="feuer-kontaktform-submission-form"
    data-form-id="<?php echo esc_attr((string) $form['id']); ?>"
    data-submit-mode="<?php echo esc_attr($submit_mode); ?>"
    data-ajax-url="<?php echo esc_url($ajax_url); ?>"
    data-draft-enabled="<?php echo $draft_enabled ? '1' : '0'; ?>"
    data-draft-key="<?php echo esc_attr('feuer-kontaktform-form-' . (int) $form['id']); ?>"
    data-multi-step="<?php echo $multi_step_enabled ? '1' : '0'; ?>"
    data-progress-enabled="<?php echo $show_progress ? '1' : '0'; ?>"
    novalidate
>
    <?php wp_nonce_field('feuer-kontaktform-send-' . $form['id'], 'feuer-kontaktform-nonce'); ?>
    <input type="hidden" name="action" value="feuer-kontaktform-submit">
    <input type="hidden" name="form_id" value="<?php echo esc_attr((string) $form['id']); ?>">
    <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>">
    <input type="hidden" name="privacy_notice_version" value="<?php echo esc_attr($privacy_notice_version); ?>">
    <input type="hidden" name="feuer_kontaktform_privacy_accepted" value="<?php echo $privacy_accepted ? '1' : ''; ?>" data-privacy-value>

    <div class="feuer-kontaktform-honeypot" aria-hidden="true">
        <label for="feuer_kontaktform_company_website_<?php echo esc_attr((string) $form['id']); ?>">Website</label>
        <input id="feuer_kontaktform_company_website_<?php echo esc_attr((string) $form['id']); ?>" type="text" name="feuer_kontaktform_company_website" value="" tabindex="-1" autocomplete="off">
    </div>

    <?php if ($show_progress) : ?>
        <div class="mb-4">
            <div class="progress" role="progressbar" aria-label="Formularfortschritt">
                <div class="progress-bar" style="width: 0%;" data-step-progress-bar></div>
            </div>
            <div class="small text-muted mt-2" data-step-progress-meta>Schritt 1 von <?php echo esc_html((string) $total_steps); ?></div>
        </div>
    <?php endif; ?>

    <div class="d-grid gap-4">
        <section data-step-panel data-step-number="1" data-privacy-gate>
            <div class="feuer-kontaktform-privacy-step">
                <p class="feuer-kontaktform-ticket-kicker">Datenschutz</p>
                <h3>Einwilligung zur Verarbeitung personenbezogener Daten</h3>
                <p><?php echo esc_html($privacy_notice_text); ?></p>
                <?php if ($privacy_policy_url !== '') : ?>
                    <p><a href="<?php echo esc_url($privacy_policy_url); ?>" target="_blank" rel="noopener">Datenschutzerklaerung oeffnen</a></p>
                <?php endif; ?>
                <div class="feuer-kontaktform-choice-row" data-privacy-wrap>
                    <label class="feuer-kontaktform-choice">
                        <input type="radio" name="feuer_kontaktform_privacy_choice" value="yes" data-privacy-choice <?php checked($privacy_accepted); ?>>
                        <span>Ja, ich bin einverstanden.</span>
                    </label>
                    <label class="feuer-kontaktform-choice">
                        <input type="radio" name="feuer_kontaktform_privacy_choice" value="no" data-privacy-choice>
                        <span>Nein, ich stimme nicht zu.</span>
                    </label>
                </div>
                <div class="invalid-feedback d-block<?php echo ! isset($field_errors['feuer_kontaktform_privacy_accepted']) ? ' d-none' : ''; ?>" data-field-error<?php echo ! isset($field_errors['feuer_kontaktform_privacy_accepted']) ? ' hidden' : ''; ?>>
                    <?php echo esc_html((string) ($field_errors['feuer_kontaktform_privacy_accepted'] ?? '')); ?>
                </div>
                <div class="feuer-kontaktform-privacy-denied alert alert-warning mt-3 d-none" data-privacy-denied hidden>Ohne Einwilligung koennen wir Ihre Anfrage nicht verarbeiten.</div>
            </div>
            <div class="d-flex justify-content-end pt-4">
                <button type="button" class="btn btn-dark" data-step-next>Weiter</button>
            </div>
        </section>

        <?php $step_position = 1; ?>
        <?php foreach ($steps as $step_fields) : ?>
            <?php $step_position++; ?>
            <?php $is_last_step = $step_position === $total_steps; ?>
            <section data-step-panel data-step-number="<?php echo esc_attr((string) $step_position); ?>"<?php echo $step_position > 1 ? ' hidden' : ''; ?>>
                <?php if ($multi_step_enabled) : ?>
                    <div class="border-bottom pb-3 mb-4">
                        <div class="fw-semibold">Schritt <?php echo esc_html((string) $step_position); ?></div>
                        <div class="text-body-secondary small">Bitte erfassen Sie die Angaben fuer diesen Abschnitt.</div>
                    </div>
                <?php endif; ?>

                <div class="row g-3" data-step-fields>
                    <?php foreach ($step_fields as $field) : ?>
                        <?php
                        $field_key = (string) ($field['key'] ?? '');
                        if ($field_key === '') {
                            continue;
                        }
                        $field_type = (string) ($field['type'] ?? 'text');
                        $field_value = isset($values[$field_key]) ? (string) $values[$field_key] : '';
                        $field_error = isset($field_errors[$field_key]) ? (string) $field_errors[$field_key] : '';
                        $is_textarea = in_array($field_type, ['nachricht', 'textarea'], true);
                        $is_select = $field_type === 'select' && ! empty($field['options']);
                        $is_radio = $field_type === 'radio' && ! empty($field['options']);
                        $width_key = isset($width_classes[$field['width'] ?? '']) ? (string) $field['width'] : ($is_textarea || $is_radio ? 'full' : 'medium');
                        $column_class = $width_classes[$width_key];
                        $textarea_rows_value = $textarea_rows[$field['rows'] ?? 'medium'] ?? 5;
                        $condition_field = (string) ($field['condition_field'] ?? '');
                        $condition_value = (string) ($field['condition_value'] ?? '');
                        $field_id = 'feuer_kontaktform_field_' . (string) $form['id'] . '_' . $field_key;
                        $field_label = (string) ($field['label'] ?? 'Feld');
                        ?>
                        <div
                            class="<?php echo esc_attr($column_class); ?>"
                            data-field-wrap
                            data-field-key="<?php echo esc_attr($field_key); ?>"
                            data-condition-field="<?php echo esc_attr($condition_field); ?>"
                            data-condition-value="<?php echo esc_attr($condition_value); ?>"
                        >
                            <label class="form-label" for="<?php echo esc_attr($field_id); ?>">
                                <?php echo esc_html($field_label); ?>
                                <?php if (! empty($field['required'])) : ?><span class="feuer-kontaktform-required">*</span><?php endif; ?>
                            </label>

                            <?php if ($is_textarea) : ?>
                                <textarea
                                    class="form-control<?php echo $field_error !== '' ? ' is-invalid' : ''; ?>"
                                    id="<?php echo esc_attr($field_id); ?>"
                                    name="feuer_kontaktform_fields[<?php echo esc_attr($field_key); ?>]"
                                    rows="<?php echo esc_attr((string) $textarea_rows_value); ?>"
                                    placeholder="<?php echo esc_attr((string) ($field['placeholder'] ?? '')); ?>"
                                    data-required="<?php echo ! empty($field['required']) ? '1' : '0'; ?>"
                                ><?php echo esc_textarea($field_value); ?></textarea>
                            <?php elseif ($is_select) : ?>
                                <select
                                    class="form-select<?php echo $field_error !== '' ? ' is-invalid' : ''; ?>"
                                    id="<?php echo esc_attr($field_id); ?>"
                                    name="feuer_kontaktform_fields[<?php echo esc_attr($field_key); ?>]"
                                    data-required="<?php echo ! empty($field['required']) ? '1' : '0'; ?>"
                                >
                                    <option value="">Bitte auswaehlen</option>
                                    <?php foreach ((array) $field['options'] as $option) : ?>
                                        <option value="<?php echo esc_attr((string) $option); ?>" <?php selected($field_value, (string) $option); ?>><?php echo esc_html((string) $option); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php elseif ($is_radio) : ?>
                                <div class="border rounded p-3<?php echo $field_error !== '' ? ' border-danger' : ''; ?>" data-choice-group>
                                    <?php foreach ((array) $field['options'] as $option_index => $option) : ?>
                                        <?php $choice_id = $field_id . '_' . $option_index; ?>
                                        <div class="form-check">
                                            <input
                                                class="form-check-input<?php echo $field_error !== '' ? ' is-invalid' : ''; ?>"
                                                id="<?php echo esc_attr($choice_id); ?>"
                                                type="radio"
                                                name="feuer_kontaktform_fields[<?php echo esc_attr($field_key); ?>]"
                                                value="<?php echo esc_attr((string) $option); ?>"
                                                data-required="<?php echo ! empty($field['required']) ? '1' : '0'; ?>"
                                                <?php checked($field_value, (string) $option); ?>
                                            >
                                            <label class="form-check-label" for="<?php echo esc_attr($choice_id); ?>"><?php echo esc_html((string) $option); ?></label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else : ?>
                                <input
                                    class="form-control<?php echo $field_error !== '' ? ' is-invalid' : ''; ?>"
                                    id="<?php echo esc_attr($field_id); ?>"
                                    type="<?php echo esc_attr($input_type_resolver($field_type)); ?>"
                                    name="feuer_kontaktform_fields[<?php echo esc_attr($field_key); ?>]"
                                    value="<?php echo esc_attr($field_value); ?>"
                                    placeholder="<?php echo esc_attr((string) ($field['placeholder'] ?? '')); ?>"
                                    data-required="<?php echo ! empty($field['required']) ? '1' : '0'; ?>"
                                >
                            <?php endif; ?>

                            <?php if ((string) ($field['help_text'] ?? '') !== '') : ?>
                                <div class="form-text"><?php echo esc_html((string) $field['help_text']); ?></div>
                            <?php endif; ?>

                            <div class="invalid-feedback d-block<?php echo $field_error === '' ? ' d-none' : ''; ?>" data-field-error<?php echo $field_error === '' ? ' hidden' : ''; ?>>
                                <?php echo esc_html($field_error); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if ($is_last_step && $captcha !== []) : ?>
                        <div class="col-12" data-captcha-container>
                            <div class="border rounded p-3 bg-light" data-captcha-wrap>
                                <label class="form-label" for="feuer_kontaktform_captcha_<?php echo esc_attr((string) $form['id']); ?>"><?php echo esc_html((string) $captcha['question']); ?></label>
                                <input class="form-control<?php echo isset($field_errors['captcha_answer']) ? ' is-invalid' : ''; ?>" id="feuer_kontaktform_captcha_<?php echo esc_attr((string) $form['id']); ?>" type="text" name="captcha_answer" inputmode="numeric">
                                <input type="hidden" name="captcha_token" value="<?php echo esc_attr((string) $captcha['token']); ?>">
                                <div class="invalid-feedback d-block<?php echo ! isset($field_errors['captcha_answer']) ? ' d-none' : ''; ?>" data-field-error<?php echo ! isset($field_errors['captcha_answer']) ? ' hidden' : ''; ?>>
                                    <?php echo esc_html((string) ($field_errors['captcha_answer'] ?? '')); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap pt-4">
                    <div class="small text-body-secondary"><?php echo wp_kses_post(str_replace('*', '<span class="feuer-kontaktform-required">*</span>', esc_html($footer_note))); ?></div>
                    <div class="d-flex gap-2 flex-wrap">
                        <?php if ($step_position > 1) : ?>
                            <button type="button" class="btn btn-outline-secondary" data-step-prev>Zurueck</button>
                        <?php endif; ?>

                        <?php if (! $is_last_step) : ?>
                            <button type="button" class="btn btn-dark" data-step-next>Weiter</button>
                        <?php else : ?>
                            <button type="submit" class="btn btn-dark" data-submit-button<?php echo ! $privacy_accepted ? ' disabled aria-disabled="true"' : ''; ?>><?php echo esc_html($submit_button_label); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
    </div>
    <div class="feuer-kontaktform-submit-overlay" data-submit-overlay hidden>
        <div class="feuer-kontaktform-loader"></div>
        <span>Anfrage wird als Ticket gespeichert...</span>
    </div>
</form>
