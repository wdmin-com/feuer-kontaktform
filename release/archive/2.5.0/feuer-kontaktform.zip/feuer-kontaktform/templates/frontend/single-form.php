<?php
$values  = is_array($state['values'] ?? null) ? $state['values'] : [];
$errors  = is_array($state['errors'] ?? null) ? $state['errors'] : [];
$field_errors = is_array($state['field_errors'] ?? null) ? $state['field_errors'] : [];
$success = ! empty($state['success']);
$message = isset($state['message']) ? (string) $state['message'] : '';
$captcha = is_array($state['captcha'] ?? null) ? $state['captcha'] : [];
$privacy_accepted = ! empty($state['privacy_accepted']);
$privacy_policy_url = isset($privacy_policy_url) ? (string) $privacy_policy_url : '';
$privacy_notice_text = isset($privacy_notice_text) ? (string) $privacy_notice_text : 'Ich habe den Datenschutzhinweis gelesen und akzeptiere die Datenschutzerklaerung.';
$privacy_notice_version = isset($privacy_notice_version) ? (string) $privacy_notice_version : '';
$behavior = is_array($behavior_settings ?? null) ? $behavior_settings : feuer_kontaktform_default_behavior_settings();
$display = is_array($form['display_settings'] ?? null) ? $form['display_settings'] : feuer_kontaktform_default_display_settings();
$design_settings = is_array($form['design_settings'] ?? null) ? feuer_kontaktform_normalize_design_settings($form['design_settings']) : feuer_kontaktform_default_design_settings();
$render_partial = is_callable($render_partial ?? null) ? $render_partial : static fn (string $_template, array $_vars = []): string => '';
$design_variant_key = isset($design_variant_key) ? sanitize_key((string) $design_variant_key) : sanitize_key((string) ($form['design_variant'] ?? 'design-1'));
$design_variant_meta = is_array($design_variant_meta ?? null) ? $design_variant_meta : [];
$width_classes = [
    'small' => 'col-md-4',
    'medium' => 'col-md-6',
    'large' => 'col-md-8',
    'full' => 'col-12',
];
$textarea_rows = [
    'small' => 3,
    'medium' => 5,
    'large' => 8,
];
$custom_website_url = (string) ($display['website_url'] ?? '');
$custom_website_text = (string) ($display['website_text'] ?? '');
$department_label = (string) (($display['department_label'] ?? '') !== '' ? $display['department_label'] : 'Abteilung');
$website_label = (string) (($display['website_label'] ?? '') !== '' ? $display['website_label'] : 'Website');
$website_url = $custom_website_url !== '' ? $custom_website_url : (string) $brand['website_url'];
$website_text = $custom_website_text;
if ($website_text === '') {
    if ($custom_website_url !== '') {
        $website_host = (string) wp_parse_url($custom_website_url, PHP_URL_HOST);
        $website_text = $website_host !== '' ? preg_replace('/^www\./', '', $website_host) : $custom_website_url;
    } else {
        $website_text = (string) $brand['website_text'];
    }
}
$intro_copy = (string) (($display['intro_copy'] ?? '') !== '' ? $display['intro_copy'] : (string) $brand['tagline']);
$aside_copy = (string) (($display['aside_copy'] ?? '') !== '' ? $display['aside_copy'] : $intro_copy);
$steps = [];
$step_numbers = [];
foreach ((array) ($form['fields'] ?? []) as $field) {
    if (! is_array($field)) {
        continue;
    }

    $step = max(1, (int) ($field['step'] ?? 1));
    $steps[$step][] = $field;
    $step_numbers[] = $step;
}
ksort($steps);
$step_numbers = array_values(array_unique(array_map('intval', $step_numbers)));
$multi_step_enabled = ! empty($behavior['multi_step_enabled']) && count($steps) > 1;
if (! $multi_step_enabled) {
    $steps = [1 => is_array($form['fields'] ?? null) ? $form['fields'] : []];
    $step_numbers = [1];
}
$show_progress = ! empty($behavior['progress_enabled']) && (count($steps) + 1) > 1;
$submit_mode = (string) (($behavior['submit_mode'] ?? 'ajax') === 'post' ? 'post' : 'ajax');
$draft_enabled = ! empty($behavior['draft_enabled']);
$show_contact_info = ! empty($brand['logo_url']) || $aside_copy !== '' || $website_text !== '';
$media_image_url = (string) ($design_settings['background_image_url'] ?? '');
$media_has_visual = $media_image_url !== '' || ! empty($brand['logo_url']);
$layout_vars = get_defined_vars();
$layout_output = $render_partial('frontend/partials/form-panel.php', array_merge($layout_vars, [
    'panel_card_class' => 'feuer-kontaktform-ticket-shell',
    'panel_body_class' => 'feuer-kontaktform-ticket-panel',
    'panel_kicker' => 'Ticket Anfrage',
    'panel_title_tag' => 'h2',
    'panel_note' => 'Ihre Anfrage wird als Ticket gespeichert. Nach dem Absenden erhalten Sie eine Ticket-ID fuer die weitere Kommunikation per E-Mail.',
]));
?>
<section
    id="feuer-kontaktform-form-<?php echo esc_attr((string) $form['id']); ?>"
    class="feuer-kontaktform-form-wrap feuer-kontaktform-ticket-wrap feuer-kontaktform-variant-<?php echo esc_attr($design_variant_key !== '' ? $design_variant_key : 'design-1'); ?>"
    data-form-id="<?php echo esc_attr((string) $form['id']); ?>"
    data-form-variant="<?php echo esc_attr($design_variant_key !== '' ? $design_variant_key : 'design-1'); ?>"
    <?php echo $hidden ? 'hidden' : ''; ?>
>
    <?php echo $layout_output; ?>
</section>
