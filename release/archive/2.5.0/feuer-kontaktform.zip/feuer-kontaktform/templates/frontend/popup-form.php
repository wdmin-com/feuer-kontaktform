<div class="feuer-kontaktform-popup-shell" data-feuer-kontaktform-popup-shell data-popup-id="<?php echo esc_attr($modal_id); ?>"<?php echo ! empty($open_on_load) ? ' data-open-on-load="1"' : ''; ?>>
    <button type="button" class="btn btn-dark" data-feuer-kontaktform-popup-open="<?php echo esc_attr($modal_id); ?>">
        <?php echo esc_html($button_label); ?>
    </button>

    <div class="feuer-kontaktform-popup-backdrop" data-feuer-kontaktform-popup-backdrop hidden></div>
    <div class="feuer-kontaktform-popup-dialog" id="<?php echo esc_attr($modal_id); ?>" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($modal_id . '-title'); ?>" hidden>
        <div class="card border-0 shadow-lg">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong id="<?php echo esc_attr($modal_id . '-title'); ?>"><?php echo esc_html((string) ($form['title'] ?? 'Kontakt')); ?></strong>
                <button type="button" class="btn-close" aria-label="Schliessen" data-feuer-kontaktform-popup-close="<?php echo esc_attr($modal_id); ?>"></button>
            </div>
            <div class="card-body">
                <?php echo $content; ?>
            </div>
        </div>
    </div>
</div>
