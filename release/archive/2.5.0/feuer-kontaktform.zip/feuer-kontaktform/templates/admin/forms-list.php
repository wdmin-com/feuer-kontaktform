<div class="wrap feuer-kontaktform-admin-wrap">
    <div class="ka-page-header">
        <div>
            <h1>Feuer-Kontaktform</h1>
            <p>Alle Kontaktformulare nach Abteilung mit Direktzugriff auf Protokolle und Shortcodes.</p>
        </div>
        <a class="button button-primary" href="<?php echo esc_url(add_query_arg(['page' => 'feuer-kontaktform-formular'], admin_url('admin.php'))); ?>">Neues Formular</a>
    </div>

    <?php if (is_array($notice)) : ?>
        <div class="notice notice-<?php echo esc_attr($notice['type']); ?> is-dismissible"><p><?php echo esc_html($notice['message']); ?></p></div>
    <?php endif; ?>

    <div class="ka-admin-panel ka-shortcode-panel">
        <h2>Einbindung</h2>
        <p>Einzelnes Formular: <code>[feuer-kontaktform-formular id="1"]</code> oder <code>[feuer-kontaktform-formular slug="vertrieb"]</code></p>
        <p>Alle Formulare mit Abteilungswahl: <code>[feuer-kontaktform-alle]</code></p>
        <p>Popup-Button fuer ein Formular: <code>[feuer-kontaktform-popup slug="vertrieb"]</code></p>
        <p>Schnelle Ticket-Form: <code>[feuer-kontaktform-schnell slug="wehrfuehrer"]</code></p>
    </div>

    <div class="ka-admin-panel">
        <h2>JSON-Import</h2>
        <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-admin-form">
            <?php wp_nonce_field('feuer-kontaktform-import-form-json'); ?>
            <input type="hidden" name="feuer-kontaktform-action" value="import_form_json">
            <label class="ka-form-group" for="ka_import_json_payload">
                <span class="ka-form-label">Exportiertes Formular als JSON</span>
                <textarea class="ka-admin-input" id="ka_import_json_payload" name="import_json_payload" rows="8" placeholder="{ ... }"></textarea>
                <span class="description">Der Import legt ein neues Formular mit eigener ID und eigenem Slug an.</span>
            </label>
            <p><button type="submit" class="button button-secondary">JSON importieren</button></p>
        </form>
    </div>

    <?php if ($cards === []) : ?>
        <div class="notice notice-info"><p>Noch kein Formular angelegt. Erstellen Sie zuerst eine Abteilung mit Empfaenger-Adresse und Feldern.</p></div>
    <?php else : ?>
        <div class="ka-card-grid">
            <?php foreach ($cards as $card) : ?>
                <section class="ka-admin-panel ka-form-card">
                    <div class="ka-form-card-header">
                        <div>
                            <h2><?php echo esc_html($card['form']['title']); ?></h2>
                            <p class="description">Empfaenger: <strong><?php echo esc_html($card['form']['recipient_email']); ?></strong></p>
                        </div>
                        <div class="ka-action-links">
                            <a class="button" href="<?php echo esc_url($card['edit_url']); ?>">Bearbeiten</a>
                            <a class="button" href="<?php echo esc_url($card['logs_url']); ?>">Protokoll</a>
                            <a class="button" href="<?php echo esc_url($card['duplicate_url']); ?>">Duplizieren</a>
                            <a class="button" href="<?php echo esc_url($card['export_json_url']); ?>">JSON Export</a>
                            <a class="button button-link-delete" href="<?php echo esc_url($card['delete_url']); ?>" onclick="return confirm('Dieses Formular und alle zugehoerigen Nachrichten wirklich loeschen?');">Loeschen</a>
                        </div>
                    </div>

                    <div class="ka-meta-grid">
                        <div><span class="ka-meta-label">Slug</span><code><?php echo esc_html($card['form']['slug']); ?></code></div>
                        <div><span class="ka-meta-label">Design</span><strong><?php echo esc_html($card['design_label']); ?></strong></div>
                        <div><span class="ka-meta-label">Nachrichten</span><strong><?php echo esc_html((string) $card['count']); ?></strong></div>
                        <div><span class="ka-meta-label">Dateiquelle</span><strong><?php echo esc_html((($card['file_state']['source'] ?? 'database') === 'file') ? 'JSON-Datei' : 'Datenbank'); ?></strong></div>
                    </div>

                    <?php if (! empty($card['file_state']['path']) || ! empty($card['file_state']['error'])) : ?>
                        <div class="ka-shortcode-list">
                            <span class="ka-meta-label">Formular-Datei</span>
                            <?php if (! empty($card['file_state']['path'])) : ?>
                                <code><?php echo esc_html((string) $card['file_state']['path']); ?></code>
                            <?php endif; ?>
                            <?php if (! empty($card['file_state']['modified_at'])) : ?>
                                <span class="description">Letzte Datei-Aenderung: <?php echo esc_html((string) $card['file_state']['modified_at']); ?></span>
                            <?php endif; ?>
                            <?php if (! empty($card['file_state']['error'])) : ?>
                                <span class="description ka-inline-error"><?php echo esc_html((string) $card['file_state']['error']); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="ka-shortcode-list">
                        <span class="ka-meta-label">Shortcodes</span>
                        <code>[feuer-kontaktform-formular id="<?php echo esc_html((string) $card['form']['id']); ?>"]</code>
                        <code>[feuer-kontaktform-formular slug="<?php echo esc_html($card['form']['slug']); ?>"]</code>
                        <code>[feuer-kontaktform-schnell slug="<?php echo esc_html($card['form']['slug']); ?>"]</code>
                        <code><?php echo esc_html((string) $card['popup_shortcode']); ?></code>
                    </div>

                    <div class="ka-shortcode-list">
                        <span class="ka-meta-label">Direktlink</span>
                        <code><?php echo esc_html((string) $card['direct_link']['query_code']); ?></code>
                        <?php if (($card['direct_link']['url'] ?? '') !== '') : ?>
                            <a href="<?php echo esc_url((string) $card['direct_link']['url']); ?>" target="_blank" rel="noopener">Direktlink oeffnen</a>
                            <code><?php echo esc_html((string) $card['direct_link']['url']); ?></code>
                            <?php if (($card['direct_link']['pretty_url'] ?? '') !== '') : ?>
                                <code><?php echo esc_html((string) $card['direct_link']['pretty_url']); ?></code>
                            <?php endif; ?>
                        <?php else : ?>
                            <span class="description">Hinterlegen Sie in den Einstellungen die URL der Seite mit <code>[feuer-kontaktform-alle]</code>, um hier den kompletten Link zu sehen.</span>
                        <?php endif; ?>
                    </div>

                    <div class="ka-fields-overview">
                        <span class="ka-meta-label">Felder</span>
                        <ul>
                            <?php foreach ($card['form']['fields'] as $field) : ?>
                                <li><?php echo esc_html($field['label']); ?><?php echo ! empty($field['required']) ? ' *' : ''; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <details class="ka-log-details">
                        <summary>Letzte Nachrichten</summary>
                        <?php if ($card['recent'] === []) : ?>
                            <p class="description">Bisher keine Nachrichten fuer dieses Formular.</p>
                        <?php else : ?>
                            <?php foreach ($card['recent'] as $submission) : ?>
                                <article class="ka-log-entry">
                                    <div class="ka-log-head">
                                        <strong><?php echo esc_html($submission['created_display']); ?></strong>
                                        <span>Ticket: <?php echo esc_html(($submission['ticket_code'] ?? '') !== '' ? $submission['ticket_code'] : '-'); ?></span>
                                        <span>IP: <?php echo esc_html($submission['ip_address']); ?></span>
                                        <span>E-Mail: <?php echo esc_html($submission['reply_email'] !== '' ? $submission['reply_email'] : 'nicht angegeben'); ?></span>
                                    </div>
                                    <div class="ka-log-statuses">
                                        <span>Status: <?php echo esc_html((string) ($submission['status'] ?? 'new')); ?></span>
                                        <span>Weiterleitung: <?php echo esc_html($submission['mail_status']); ?></span>
                                        <span>Autoantwort: <?php echo esc_html($submission['auto_reply_status']); ?></span>
                                        <span>Webhook: <?php echo esc_html((string) ($submission['webhook_status'] ?? '-')); ?></span>
                                        <span>Captcha: <?php echo esc_html($submission['captcha_required'] ? 'ja' : 'nein'); ?></span>
                                        <span>Datenschutz: <?php echo esc_html(! empty($submission['privacy_accepted']) ? 'ja' : 'nein'); ?></span>
                                    </div>
                                    <?php if (($submission['mail_details'] ?? '') !== '') : ?>
                                        <p class="ka-log-note"><strong>Weiterleitung:</strong> <?php echo esc_html($submission['mail_details']); ?></p>
                                    <?php endif; ?>
                                    <?php if (($submission['auto_reply_details'] ?? '') !== '') : ?>
                                        <p class="ka-log-note"><strong>Autoantwort:</strong> <?php echo esc_html($submission['auto_reply_details']); ?></p>
                                    <?php endif; ?>
                                    <ul class="ka-log-values">
                                        <?php foreach ($submission['fields'] as $label => $value) : ?>
                                            <li><strong><?php echo esc_html($label); ?>:</strong> <?php echo esc_html($value !== '' ? $value : '-'); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </article>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </details>
                </section>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>


