<div class="wrap feuer-kontaktform-admin-wrap">
    <h1>Nachrichtenprotokoll</h1>
    <p>Alle gespeicherten Nachrichten mit kompakter Uebersicht. Oeffnen Sie einen Eintrag, um alle Details zu sehen.</p>

    <?php if (is_array($notice)) : ?>
        <div class="notice notice-<?php echo esc_attr($notice['type']); ?> is-dismissible"><p><?php echo esc_html($notice['message']); ?></p></div>
    <?php endif; ?>

    <form method="get" class="ka-inline-filter">
        <input type="hidden" name="page" value="feuer-kontaktform-logs">
        <label for="ka_filter_form"><strong>Formular filtern</strong></label>
        <select id="ka_filter_form" name="form_id">
            <option value="0">Alle Formulare</option>
            <?php foreach ($forms as $form) : ?>
                <option value="<?php echo esc_attr((string) $form['id']); ?>" <?php selected($selected_form_id, $form['id']); ?>><?php echo esc_html($form['title']); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="button">Filtern</button>
        <a class="button" href="<?php echo esc_url($export_csv_url); ?>">CSV Export</a>
    </form>

    <?php if ($logs === []) : ?>
        <div class="notice notice-info"><p>Keine Nachrichten vorhanden.</p></div>
    <?php else : ?>
        <div class="ka-admin-panel">
            <div class="ka-log-list">
                <?php foreach ($logs as $submission) : ?>
                    <details class="ka-log-card">
                        <summary class="ka-log-summary">
                            <div class="ka-log-summary-main">
                                <strong><?php echo esc_html($submission['created_display']); ?></strong>
                                <span><?php echo esc_html($submission['form_title']); ?></span>
                            </div>
                            <div class="ka-log-summary-meta">
                                <span>Ticket: <?php echo esc_html(($submission['ticket_code'] ?? '') !== '' ? $submission['ticket_code'] : '-'); ?></span>
                                <span>E-Mail: <?php echo esc_html($submission['reply_email'] !== '' ? $submission['reply_email'] : 'nicht angegeben'); ?></span>
                                <span>Status: <?php echo esc_html((string) ($status_options[$submission['status']] ?? $submission['status'])); ?></span>
                                <span>Weiterleitung: <?php echo esc_html($submission['mail_status']); ?></span>
                                <span>Autoantwort: <?php echo esc_html($submission['auto_reply_status']); ?></span>
                            </div>
                        </summary>
                        <div class="ka-log-card-body">
                            <div class="ka-meta-grid">
                                <div><span class="ka-meta-label">Ticket-ID</span><strong><?php echo esc_html(($submission['ticket_code'] ?? '') !== '' ? $submission['ticket_code'] : '-'); ?></strong></div>
                                <div><span class="ka-meta-label">IP-Adresse</span><strong><?php echo esc_html($submission['ip_address']); ?></strong></div>
                                <div><span class="ka-meta-label">Cookie-ID</span><strong><?php echo esc_html(($submission['visitor_cookie'] ?? '') !== '' ? $submission['visitor_cookie'] : '-'); ?></strong></div>
                                <div><span class="ka-meta-label">Geraet</span><strong><?php echo esc_html(($submission['device_type'] ?? '') !== '' ? $submission['device_type'] : '-'); ?></strong></div>
                                <div><span class="ka-meta-label">Captcha</span><strong><?php echo esc_html($submission['captcha_required'] ? 'ja' : 'nein'); ?></strong></div>
                                <div><span class="ka-meta-label">Datenschutz</span><strong><?php echo esc_html(! empty($submission['privacy_accepted']) ? 'ja' : 'nein'); ?></strong></div>
                                <div><span class="ka-meta-label">Webhook</span><strong><?php echo esc_html((string) ($submission['webhook_status'] ?? '-')); ?></strong></div>
                                <div><span class="ka-meta-label">Privacy-Version</span><strong><?php echo esc_html((string) ($submission['privacy_version'] ?? '-')); ?></strong></div>
                                <div><span class="ka-meta-label">Referrer</span><strong><?php echo esc_html((string) (($submission['referrer_url'] ?? '') !== '' ? $submission['referrer_url'] : '-')); ?></strong></div>
                            </div>

                            <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-inline-filter">
                                <?php wp_nonce_field('feuer-kontaktform-save-submission-status'); ?>
                                <input type="hidden" name="feuer-kontaktform-action" value="save_submission_status">
                                <input type="hidden" name="submission_id" value="<?php echo esc_attr((string) $submission['id']); ?>">
                                <input type="hidden" name="return_form_id" value="<?php echo esc_attr((string) $selected_form_id); ?>">
                                <label for="ka_status_<?php echo esc_attr((string) $submission['id']); ?>"><strong>Status</strong></label>
                                <select id="ka_status_<?php echo esc_attr((string) $submission['id']); ?>" name="status">
                                    <?php foreach ($status_options as $status_key => $status_label) : ?>
                                        <option value="<?php echo esc_attr((string) $status_key); ?>" <?php selected((string) ($submission['status'] ?? 'new'), (string) $status_key); ?>><?php echo esc_html((string) $status_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="button button-secondary">Status speichern</button>
                            </form>

                            <?php if (($submission['mail_details'] ?? '') !== '') : ?>
                                <p class="ka-log-note"><strong>Weiterleitung:</strong> <?php echo esc_html($submission['mail_details']); ?></p>
                            <?php endif; ?>
                            <?php if (($submission['auto_reply_details'] ?? '') !== '') : ?>
                                <p class="ka-log-note"><strong>Autoantwort:</strong> <?php echo esc_html($submission['auto_reply_details']); ?></p>
                            <?php endif; ?>
                            <?php if (($submission['webhook_details'] ?? '') !== '') : ?>
                                <p class="ka-log-note"><strong>Webhook:</strong> <?php echo esc_html($submission['webhook_details']); ?></p>
                            <?php endif; ?>
                            <?php if (($submission['user_agent'] ?? '') !== '') : ?>
                                <p class="ka-log-note"><strong>User-Agent:</strong> <?php echo esc_html($submission['user_agent']); ?></p>
                            <?php endif; ?>
                            <?php if (! empty($submission['consent_context'])) : ?>
                                <p class="ka-log-note"><strong>Datenschutz-Protokoll:</strong>
                                    Hinweis angezeigt: <?php echo esc_html(! empty($submission['consent_context']['notice_shown']) ? 'ja' : 'nein'); ?>,
                                    Zustimmung: <?php echo esc_html(! empty($submission['consent_context']['accepted']) ? 'ja' : 'nein'); ?>,
                                    Zeitpunkt: <?php echo esc_html((string) ($submission['consent_context']['accepted_at'] ?? '-')); ?>
                                </p>
                            <?php endif; ?>

                            <ul class="ka-log-values">
                                <?php foreach ($submission['fields'] as $label => $value) : ?>
                                    <li><strong><?php echo esc_html($label); ?>:</strong> <?php echo esc_html($value !== '' ? $value : '-'); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </details>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="ka-admin-panel">
        <h2>Plugin-Aktivitaeten</h2>
        <?php if (empty($activity_logs)) : ?>
            <p class="description">Noch keine Aktivitaeten protokolliert.</p>
        <?php else : ?>
            <table class="widefat striped ka-simple-table">
                <thead><tr><th>Zeit</th><th>Ereignis</th><th>Objekt</th><th>Benutzer</th><th>Nachricht</th></tr></thead>
                <tbody>
                    <?php foreach ($activity_logs as $activity) : ?>
                        <tr>
                            <td><?php echo esc_html((string) ($activity['created_at'] ?? '')); ?></td>
                            <td><code><?php echo esc_html((string) ($activity['event_type'] ?? '')); ?></code></td>
                            <td><?php echo esc_html((string) ($activity['object_type'] ?? '-')); ?> #<?php echo esc_html((string) ($activity['object_id'] ?? 0)); ?></td>
                            <td><?php echo esc_html((string) ($activity['actor_id'] ?? 0)); ?></td>
                            <td><?php echo esc_html((string) ($activity['message'] ?? '')); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>


