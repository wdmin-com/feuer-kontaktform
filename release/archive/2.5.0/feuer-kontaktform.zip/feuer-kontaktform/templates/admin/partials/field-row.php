<div class="ka-field-row">
    <div class="ka-field-row-grid">
        <button type="button" class="ka-drag-handle" title="Feld verschieben" aria-label="Feld verschieben">&#8597;</button>

        <label>
            Feldtyp
            <select name="fields[<?php echo esc_attr($index); ?>][type]" class="ka-field-type">
                <?php foreach ($field_types as $value => $label) : ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($field['type'], $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Beschriftung<input type="text" name="fields[<?php echo esc_attr($index); ?>][label]" value="<?php echo esc_attr($field['label']); ?>" class="ka-field-label"></label>
        <label>Feldname<input type="text" name="fields[<?php echo esc_attr($index); ?>][key]" value="<?php echo esc_attr($field['key']); ?>" class="ka-field-key"></label>
        <label>Platzhalter<input type="text" name="fields[<?php echo esc_attr($index); ?>][placeholder]" value="<?php echo esc_attr($field['placeholder']); ?>" class="ka-field-placeholder-input"></label>

        <label>
            Breite
            <select name="fields[<?php echo esc_attr($index); ?>][width]" class="ka-field-width">
                <?php foreach ($width_options as $value => $label) : ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($field['width'] ?? 'medium', $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>
            Hoehe Textfeld
            <select name="fields[<?php echo esc_attr($index); ?>][rows]" class="ka-field-rowsize">
                <?php foreach ($textarea_size_options as $value => $label) : ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($field['rows'] ?? 'medium', $value); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Schritt<input type="number" min="1" step="1" name="fields[<?php echo esc_attr($index); ?>][step]" value="<?php echo esc_attr((string) ($field['step'] ?? 1)); ?>" class="ka-field-step"></label>
        <label>Abhaengiges Feld<input type="text" name="fields[<?php echo esc_attr($index); ?>][condition_field]" value="<?php echo esc_attr((string) ($field['condition_field'] ?? '')); ?>" class="ka-field-condition-field" placeholder="z. B. thema"></label>
        <label>Bedingungswert<input type="text" name="fields[<?php echo esc_attr($index); ?>][condition_value]" value="<?php echo esc_attr((string) ($field['condition_value'] ?? '')); ?>" class="ka-field-condition-value" placeholder="z. B. Rueckruf"></label>
        <label>Hilfetext<input type="text" name="fields[<?php echo esc_attr($index); ?>][help_text]" value="<?php echo esc_attr((string) ($field['help_text'] ?? '')); ?>" class="ka-field-help-text"></label>
        <label class="ka-field-required"><input type="checkbox" name="fields[<?php echo esc_attr($index); ?>][required]" value="1" <?php checked(! empty($field['required'])); ?>> Pflichtfeld</label>
        <button type="button" class="button-link-delete ka-remove-field">Entfernen</button>
    </div>

    <label class="ka-field-options">
        Optionen fuer Auswahl / Radio
        <textarea name="fields[<?php echo esc_attr($index); ?>][options]" rows="3" class="ka-field-options-input" placeholder="Eine Option pro Zeile"><?php echo esc_textarea(implode("\n", is_array($field['options'] ?? null) ? $field['options'] : [])); ?></textarea>
    </label>
</div>
