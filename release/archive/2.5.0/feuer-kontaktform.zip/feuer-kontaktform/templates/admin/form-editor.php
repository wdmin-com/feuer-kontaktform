<?php
$brand = is_array($brand ?? null) ? $brand : feuer_kontaktform_brand_context(feuer_kontaktform_default_settings());
$configuration_checks = is_array($configuration_checks ?? null) ? $configuration_checks : [];
$variant = isset($data['design_variant']) ? (string) $data['design_variant'] : 'design-1';
$display_settings = is_array($data['display_settings'] ?? null) ? $data['display_settings'] : feuer_kontaktform_default_display_settings();
$behavior_settings = is_array($data['behavior_settings'] ?? null) ? $data['behavior_settings'] : feuer_kontaktform_default_behavior_settings();
$routing_lines = [];
foreach ((array) ($behavior_settings['routing_rules'] ?? []) as $rule) {
    if (! is_array($rule)) {
        continue;
    }
    $routing_lines[] = implode('|', [
        (string) ($rule['field_key'] ?? ''),
        (string) ($rule['match_value'] ?? ''),
        (string) ($rule['recipient_email'] ?? ''),
        (string) ($rule['mode'] ?? 'append'),
        (string) ($rule['label'] ?? ''),
    ]);
}
$has_brand_logo = ! empty($brand['logo_url']);
$show_preview_aside = ! in_array($variant, ['design-1', 'design-7'], true);
$show_preview_intro = in_array($variant, ['design-1', 'design-2', 'design-6', 'design-7', 'design-10'], true);
$show_preview_panel_logo = $has_brand_logo && in_array($variant, ['design-1', 'design-5', 'design-7', 'design-10'], true);
$preview_intro_copy = $display_settings['intro_copy'] !== '' ? (string) $display_settings['intro_copy'] : (string) $brand['tagline'];
$preview_aside_copy = $display_settings['aside_copy'] !== '' ? (string) $display_settings['aside_copy'] : (string) $brand['tagline'];
$preview_website_label = (string) ($display_settings['website_label'] !== '' ? $display_settings['website_label'] : 'Website');
$preview_website_text = (string) ($display_settings['website_text'] ?? '');
if ($preview_website_text === '') {
    if ($display_settings['website_url'] !== '') {
        $preview_website_host = (string) wp_parse_url($display_settings['website_url'], PHP_URL_HOST);
        $preview_website_text = $preview_website_host !== '' ? preg_replace('/^www\./', '', $preview_website_host) : $display_settings['website_url'];
    } else {
        $preview_website_text = (string) $brand['website_text'];
    }
}
?>
<div class="wrap feuer-kontaktform-admin-wrap">
    <h1><?php echo esc_html($form_id > 0 ? 'Formular bearbeiten' : 'Neues Formular'); ?></h1>
    <p>Jedes Formular entspricht einer Abteilung mit eigener Empfaenger-Adresse, eigenen Feldern und eigenem Autoantwort-Text.</p>

    <?php if (is_array($notice)) : ?>
        <div class="notice notice-<?php echo esc_attr($notice['type']); ?> is-dismissible"><p><?php echo esc_html($notice['message']); ?></p></div>
    <?php endif; ?>

    <?php if ($errors !== []) : ?>
        <div class="notice notice-error">
            <p><strong>Bitte korrigieren Sie die folgenden Punkte:</strong></p>
            <ul>
                <?php foreach ($errors as $error) : ?>
                    <li><?php echo esc_html($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-form-wizard">
        <?php wp_nonce_field('feuer-kontaktform-save-form'); ?>
        <input type="hidden" name="feuer-kontaktform-action" value="save_form">
        <input type="hidden" name="form_id" value="<?php echo esc_attr((string) $form_id); ?>">

        <div class="ka-admin-layout ka-admin-layout-stack">
            <section class="ka-admin-panel">
                <h2>Hauptinformationen</h2>
                <div class="ka-admin-form">
                    <label class="ka-form-group" for="ka_title">
                        <span class="ka-form-label">Abteilung / Formularname</span>
                        <input class="ka-admin-input" id="ka_title" type="text" name="title" value="<?php echo esc_attr((string) $data['title']); ?>" required>
                        <span class="description">Beispiel: Vertrieb, Kindergarten, Verwaltung.</span>
                    </label>

                    <label class="ka-form-group" for="ka_slug">
                        <span class="ka-form-label">Slug</span>
                        <input class="ka-admin-input" id="ka_slug" type="text" name="slug" value="<?php echo esc_attr((string) $data['slug']); ?>">
                        <span class="description">Leer lassen, damit automatisch ein Slug erzeugt wird.</span>
                    </label>

                    <label class="ka-form-group" for="ka_recipient">
                        <span class="ka-form-label">Empfaenger-E-Mail</span>
                        <textarea class="ka-admin-input" id="ka_recipient" name="recipient_email" rows="3" required><?php echo esc_textarea((string) $data['recipient_email']); ?></textarea>
                        <span class="description">Mehrere Adressen koennen mit Komma oder Zeilenumbruch getrennt werden. Diese Adresse erhaelt die Formularnachricht.</span>
                    </label>

                    <label class="ka-form-group" for="ka_behavior_topics">
                        <span class="ka-form-label">Themen der Anfrage</span>
                        <textarea class="ka-admin-input" id="ka_behavior_topics" name="behavior_settings[topics_text]" rows="6" placeholder="mitglied-werden|Mitglied werden|wehrfuehrer@example.de|Ihre Anfrage zum Mitmachen|Guten Tag {{name}}, wir haben Ihre Anfrage unter {{ticket_id}} erhalten."><?php echo esc_textarea(implode("\n", is_array($topic_lines ?? null) ? $topic_lines : [])); ?></textarea>
                        <span class="description">Eine Zeile pro Thema. Format: <code>slug|Beschriftung|Empfaenger optional|Autoantwort Betreff optional|Autoantwort Text optional</code>. Felder koennen ueber <code>Abhaengiges Feld = thema</code> und <code>Bedingungswert = Beschriftung</code> an einzelne Themen gebunden werden.</span>
                    </label>

                    <div class="ka-form-group">
                        <span class="ka-form-label">Direktzugriff</span>
                        <?php if ($form_id > 0 && is_array($direct_link ?? null)) : ?>
                            <code><?php echo esc_html((string) $direct_link['query_code']); ?></code>
                            <?php if (($direct_link['url'] ?? '') !== '') : ?>
                                <a href="<?php echo esc_url((string) $direct_link['url']); ?>" target="_blank" rel="noopener">Direktlink oeffnen</a>
                                <code><?php echo esc_html((string) $direct_link['url']); ?></code>
                                <?php if (($direct_link['pretty_url'] ?? '') !== '') : ?>
                                    <code><?php echo esc_html((string) $direct_link['pretty_url']); ?></code>
                                <?php endif; ?>
                            <?php else : ?>
                                <span class="description">Speichern Sie in den <a href="<?php echo esc_url((string) $settings_url); ?>">Einstellungen</a> die URL der Kontaktseite mit <code>[feuer-kontaktform-alle]</code>, damit hier der komplette Link erscheint.</span>
                            <?php endif; ?>
                        <?php else : ?>
                            <span class="description">Nach dem ersten Speichern wird hier der Direktlink-Code angezeigt.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="ka-admin-panel">
                <h2>Pflicht und Versand</h2>
                <p class="ka-panel-lead">Diese Punkte muessen fuer eine funktionierende Kontaktform erfuellt sein. Beim Speichern wird dieselbe Pruefung serverseitig erzwungen.</p>

                <ul class="ka-checklist">
                    <?php foreach ($configuration_checks as $check) : ?>
                        <li class="<?php echo ! empty($check['ok']) ? 'is-complete' : 'is-missing'; ?>">
                            <strong><?php echo ! empty($check['ok']) ? 'OK' : 'Fehlt'; ?></strong>
                            <span><?php echo esc_html((string) ($check['label'] ?? '')); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <div class="ka-admin-form">
                    <label class="ka-form-group" for="ka_auto_subject">
                        <span class="ka-form-label">Autoantwort Betreff</span>
                        <input class="ka-admin-input" id="ka_auto_subject" type="text" name="auto_reply_subject" value="<?php echo esc_attr((string) $data['auto_reply_subject']); ?>">
                        <span class="description">Leer lassen, um den Standardwert aus den Einstellungen zu verwenden.</span>
                    </label>

                    <label class="ka-form-group" for="ka_auto_message">
                        <span class="ka-form-label">Autoantwort Text</span>
                        <textarea class="ka-admin-input" id="ka_auto_message" name="auto_reply_message" rows="8"><?php echo esc_textarea((string) $data['auto_reply_message']); ?></textarea>
                        <span class="description">Verfuegbare Makros: <code>{{formular}}</code>, <code>{{vorname}}</code>, <code>{{nachname}}</code>, <code>{{name}}</code>, <code>{{ticket_id}}</code>, <code>{{logo}}</code>, <code>{{logo_url}}</code>, <code>{{website}}</code>, <code>{{site_url}}</code>.</span>
                    </label>

                    <div class="ka-form-group">
                        <span class="ka-form-label">Formular-Datei</span>
                        <?php if (! empty($file_state['available']) && ! empty($file_state['path'])) : ?>
                            <code><?php echo esc_html((string) $file_state['path']); ?></code>
                            <span class="description">
                                Quelle:
                                <strong><?php echo esc_html(($file_state['source'] ?? 'database') === 'file' ? 'JSON-Datei' : 'Datenbank'); ?></strong>
                                <?php if (! empty($file_state['modified_at'])) : ?>
                                    | Letzte Datei-Aenderung: <?php echo esc_html((string) $file_state['modified_at']); ?>
                                <?php endif; ?>
                            </span>
                            <span class="description">Diese JSON-Datei kann manuell bearbeitet werden. Der Inhalt wird beim Oeffnen und Ausgeben des Formulars erneut eingelesen.</span>
                        <?php else : ?>
                            <span class="description">Die Formular-Datei wird nach dem ersten Speichern automatisch im Upload-Verzeichnis angelegt.</span>
                        <?php endif; ?>

                        <?php if (! empty($file_state['error'])) : ?>
                            <span class="description ka-inline-error"><?php echo esc_html((string) $file_state['error']); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="ka-admin-panel">
                <h2>Verhalten</h2>
                <div class="ka-admin-form">
                    <label class="ka-form-group" for="ka_behavior_template_key">
                        <span class="ka-form-label">Vorlagen-Schluessel</span>
                        <input class="ka-admin-input" id="ka_behavior_template_key" type="text" name="behavior_settings[template_key]" value="<?php echo esc_attr((string) ($behavior_settings['template_key'] ?? '')); ?>" placeholder="z. B. service, callback, bewerbung">
                        <span class="description">Dient zur internen Gruppierung und fuer wiederkehrende Formularvarianten.</span>
                    </label>

                    <label class="ka-form-group" for="ka_behavior_submit_mode">
                        <span class="ka-form-label">Versandmodus</span>
                        <select class="ka-admin-input" id="ka_behavior_submit_mode" name="behavior_settings[submit_mode]">
                            <option value="ajax" <?php selected($behavior_settings['submit_mode'] ?? 'ajax', 'ajax'); ?>>AJAX ohne Reload</option>
                            <option value="post" <?php selected($behavior_settings['submit_mode'] ?? 'ajax', 'post'); ?>>Klassischer POST</option>
                        </select>
                        <span class="description">AJAX zeigt Erfolg und Fehler direkt ohne Seitenwechsel. Klassischer POST verarbeitet die Anfrage auf derselben Seite und zeigt die Rueckmeldung anschliessend inline an.</span>
                    </label>

                    <label class="ka-form-group" for="ka_behavior_popup_trigger_label">
                        <span class="ka-form-label">Popup-Button Text</span>
                        <input class="ka-admin-input" id="ka_behavior_popup_trigger_label" type="text" name="behavior_settings[popup_trigger_label]" value="<?php echo esc_attr((string) ($behavior_settings['popup_trigger_label'] ?? 'Kontakt aufnehmen')); ?>">
                    </label>

                    <div class="ka-checkbox-grid">
                        <label><input type="checkbox" name="behavior_settings[draft_enabled]" value="1" <?php checked(! empty($behavior_settings['draft_enabled'])); ?>> Browser-Draft speichern</label>
                        <label><input type="checkbox" name="behavior_settings[multi_step_enabled]" value="1" <?php checked(! empty($behavior_settings['multi_step_enabled'])); ?>> Mehrstufige Form aktivieren</label>
                        <label><input type="checkbox" name="behavior_settings[progress_enabled]" value="1" <?php checked(! empty($behavior_settings['progress_enabled'])); ?>> Fortschrittsanzeige zeigen</label>
                        <label><input type="checkbox" name="behavior_settings[popup_enabled]" value="1" <?php checked(! empty($behavior_settings['popup_enabled'])); ?>> Fuer Popup-Shortcode vorgesehen</label>
                    </div>

                    <label class="ka-form-group" for="ka_behavior_routing_rules">
                        <span class="ka-form-label">Routing-Regeln</span>
                        <textarea class="ka-admin-input" id="ka_behavior_routing_rules" name="behavior_settings[routing_rules_text]" rows="6" placeholder="feld_key|match_value|team@example.de|append|Label"><?php echo esc_textarea(implode("\n", $routing_lines)); ?></textarea>
                        <span class="description">Eine Regel pro Zeile. Format: <code>feld_key|vergleichswert|empfaenger@example.de|append|Label</code>. Modus <code>replace</code> ersetzt die Standard-Empfaengerliste.</span>
                    </label>
                </div>
            </section>

            <section class="ka-admin-panel">
                <h2>Zusatzinformationen</h2>
                <div class="ka-admin-form">
                    <label class="ka-form-group" for="ka_display_intro_copy">
                        <span class="ka-form-label">Einleitungstext</span>
                        <textarea class="ka-admin-input ka-display-control" id="ka_display_intro_copy" name="display_settings[intro_copy]" rows="4"><?php echo esc_textarea((string) ($display_settings['intro_copy'] ?? '')); ?></textarea>
                        <span class="description">Optionaler Text fuer die obere Einleitung. Leer lassen, um den Standardtext der Vorlage zu verwenden.</span>
                    </label>

                    <label class="ka-form-group" for="ka_display_aside_copy">
                        <span class="ka-form-label">Text im Infobereich</span>
                        <textarea class="ka-admin-input ka-display-control" id="ka_display_aside_copy" name="display_settings[aside_copy]" rows="4"><?php echo esc_textarea((string) ($display_settings['aside_copy'] ?? '')); ?></textarea>
                        <span class="description">Dieser Text erscheint in der rechten oder linken Informationsspalte der Form.</span>
                    </label>

                    <label class="ka-form-group" for="ka_display_department_label">
                        <span class="ka-form-label">Bezeichnung fuer Abteilung</span>
                        <input class="ka-admin-input ka-display-control" id="ka_display_department_label" type="text" name="display_settings[department_label]" value="<?php echo esc_attr((string) ($display_settings['department_label'] ?? 'Abteilung')); ?>">
                    </label>

                    <label class="ka-form-group" for="ka_display_website_label">
                        <span class="ka-form-label">Bezeichnung fuer Website</span>
                        <input class="ka-admin-input ka-display-control" id="ka_display_website_label" type="text" name="display_settings[website_label]" value="<?php echo esc_attr((string) ($display_settings['website_label'] ?? 'Website')); ?>">
                    </label>

                    <label class="ka-form-group" for="ka_display_website_url">
                        <span class="ka-form-label">Website-URL</span>
                        <input class="ka-admin-input ka-display-control" id="ka_display_website_url" type="url" name="display_settings[website_url]" value="<?php echo esc_attr((string) ($display_settings['website_url'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $brand['website_url']); ?>">
                        <span class="description">Leer lassen, um die Website aus den allgemeinen Einstellungen zu verwenden.</span>
                    </label>

                    <label class="ka-form-group" for="ka_display_website_text">
                        <span class="ka-form-label">Website-Anzeigetext</span>
                        <input class="ka-admin-input ka-display-control" id="ka_display_website_text" type="text" name="display_settings[website_text]" value="<?php echo esc_attr((string) ($display_settings['website_text'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $brand['website_text']); ?>">
                    </label>

                </div>
            </section>

            <section class="ka-admin-panel">
                <h2>Design auswaehlen</h2>
                <p>Jede Vorlage nutzt jetzt ein eigenes Frontend-Layout. Die HTML-Struktur liegt getrennt in <code>templates/frontend/layouts</code> und <code>templates/frontend/partials</code>, damit das Design leichter bearbeitet werden kann.</p>
                <div class="ka-design-grid">
                    <?php foreach ($design_variants as $design_key => $design) : ?>
                        <label class="ka-design-card">
                            <input type="radio" name="design_variant" value="<?php echo esc_attr($design_key); ?>" <?php checked($data['design_variant'] ?? 'design-1', $design_key); ?>>
                            <span class="ka-design-preview ka-preview-<?php echo esc_attr($design_key); ?>"></span>
                            <strong><?php echo esc_html($design['label']); ?></strong>
                            <small><?php echo esc_html($design['description']); ?></small>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="ka-design-stage" data-design-stage>
                    <div class="ka-design-stage-preview-shell ka-preview-<?php echo esc_attr((string) ($data['design_variant'] ?? 'design-1')); ?>" data-design-preview-shell>
                        <div class="ka-design-stage-preview-intro">
                            <span class="ka-design-stage-kicker" data-design-preview-kicker>Vorlagenansicht</span>
                            <strong data-design-preview-heading>Kontaktbereich</strong>
                            <span>Vereinfachte Vorschau der ausgewaehlten Frontend-Struktur.</span>
                        </div>
                        <div class="ka-design-stage-preview-frame ka-preview-<?php echo esc_attr((string) ($data['design_variant'] ?? 'design-1')); ?>" data-design-preview>
                            <div class="ka-design-stage-preview-aside" data-design-preview-aside>
                                <span class="ka-design-stage-kicker" data-design-preview-kicker>Kontakt</span>
                                <strong data-design-preview-title data-design-preview-heading><?php echo esc_html((string) ($data['title'] !== '' ? $data['title'] : 'Abteilung')); ?></strong>
                                <span>Klare Informationsspalte ohne Social-Links.</span>
                            </div>
                            <div class="ka-design-stage-preview-panel" data-design-preview-panel>
                                <span class="ka-design-stage-panel-title" data-design-preview-heading>Formularvorschau</span>
                                <span class="ka-design-stage-preview-input" data-design-preview-input></span>
                                <span class="ka-design-stage-preview-input is-wide" data-design-preview-input></span>
                                <span class="ka-design-stage-preview-input is-tall" data-design-preview-input></span>
                                <span class="ka-design-stage-preview-button" data-design-preview-button>Nachricht senden</span>
                            </div>
                        </div>
                    </div>
                    <div class="ka-design-stage-copy">
                        <strong data-design-label></strong>
                        <p class="description" data-design-description></p>
                        <p class="description">Texte, Bild und Feldanordnung greifen direkt in das ausgewaehlte Layout ein. Leere Zusatzfelder verwenden die Standardinhalte der jeweiligen Vorlage.</p>
                    </div>
                </div>

                <div
                    class="ka-live-preview"
                    data-live-preview-root
                    data-brand-label="<?php echo esc_attr((string) $brand['label']); ?>"
                    data-brand-tagline="<?php echo esc_attr((string) $brand['tagline']); ?>"
                    data-brand-website-text="<?php echo esc_attr((string) $brand['website_text']); ?>"
                >
                    <div class="ka-fields-header">
                        <div>
                            <h3>Live-Vorschau</h3>
                            <p class="description">Aenderungen an Titel, Feldern, Groessen und Design werden hier sofort dargestellt.</p>
                        </div>
                    </div>

                    <div class="ka-live-preview-stage">
                        <div class="ka-live-preview-intro<?php echo $show_preview_intro ? '' : ' is-hidden'; ?>" data-live-preview-intro<?php echo $show_preview_intro ? '' : ' hidden'; ?>>
                            <span class="ka-live-preview-kicker" data-live-preview-kicker data-live-preview-intro-kicker><?php echo esc_html((string) $brand['label']); ?></span>
                            <h3 class="ka-live-preview-intro-title" data-live-preview-title data-live-preview-intro-title><?php echo esc_html((string) ($data['title'] !== '' ? $data['title'] : 'Abteilung')); ?></h3>
                            <p class="ka-live-preview-intro-copy" data-live-preview-intro-copy><?php echo esc_html($preview_intro_copy); ?></p>
                        </div>

                        <div class="ka-live-preview-shell ka-preview-<?php echo esc_attr($variant); ?>" data-live-preview-shell>
                            <div class="ka-live-preview-frame ka-preview-<?php echo esc_attr($variant); ?>" data-live-preview-frame>
                                <aside class="ka-live-preview-aside<?php echo $show_preview_aside ? '' : ' is-hidden'; ?>" data-live-preview-aside<?php echo $show_preview_aside ? '' : ' hidden'; ?>>
                                    <div class="ka-live-preview-aside-inner">
                                        <?php if ($has_brand_logo) : ?>
                                            <div class="ka-live-preview-logo-wrap">
                                                <img class="ka-live-preview-logo" data-live-preview-logo src="<?php echo esc_url((string) $brand['logo_url']); ?>" alt="<?php echo esc_attr((string) $brand['label']); ?>" width="<?php echo esc_attr((string) $brand['logo_width']); ?>">
                                            </div>
                                        <?php endif; ?>

                                        <div class="ka-live-preview-aside-copy">
                                            <span class="ka-live-preview-kicker" data-live-preview-kicker data-live-preview-aside-kicker>Service</span>
                                            <h3 class="ka-live-preview-aside-title" data-live-preview-title data-live-preview-aside-title><?php echo esc_html((string) ($data['title'] !== '' ? $data['title'] : 'Abteilung')); ?></h3>
                                            <p class="ka-live-preview-aside-text" data-live-preview-aside-copy><?php echo esc_html($preview_aside_copy); ?></p>
                                        </div>

                                        <div class="ka-live-preview-aside-list">
                                            <div class="ka-live-preview-aside-item">
                                                <span class="ka-live-preview-aside-label" data-live-preview-department-label><?php echo esc_html((string) ($display_settings['department_label'] ?? 'Abteilung')); ?></span>
                                                <span data-live-preview-department><?php echo esc_html((string) ($data['title'] !== '' ? $data['title'] : 'Abteilung')); ?></span>
                                            </div>
                                            <div class="ka-live-preview-aside-item<?php echo $preview_website_text !== '' ? '' : ' is-hidden'; ?>" data-live-preview-website-row<?php echo $preview_website_text !== '' ? '' : ' hidden'; ?>>
                                                <span class="ka-live-preview-aside-label" data-live-preview-website-label><?php echo esc_html($preview_website_label); ?></span>
                                                <span data-live-preview-website-value><?php echo esc_html($preview_website_text); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </aside>

                                <section class="ka-live-preview-panel" data-live-preview-panel>
                                    <div class="ka-live-preview-panel-header">
                                        <?php if ($has_brand_logo) : ?>
                                            <img class="ka-live-preview-panel-logo" data-live-preview-panel-logo src="<?php echo esc_url((string) $brand['logo_url']); ?>" alt="<?php echo esc_attr((string) $brand['label']); ?>" width="<?php echo esc_attr((string) min((int) $brand['logo_width'], 180)); ?>"<?php echo $show_preview_panel_logo ? '' : ' hidden'; ?>>
                                        <?php endif; ?>

                                        <div class="ka-live-preview-panel-copy">
                                            <span class="ka-live-preview-kicker" data-live-preview-kicker data-live-preview-panel-kicker>Kontaktformular</span>
                                            <h3 class="ka-live-preview-panel-title" data-live-preview-title data-live-preview-panel-title><?php echo esc_html((string) ($data['title'] !== '' ? $data['title'] : 'Abteilung')); ?></h3>
                                            <p class="ka-live-preview-panel-note" data-live-preview-panel-note>Bitte fuellen Sie alle benoetigten Angaben aus. Pflichtfelder sind mit einem Stern markiert.</p>
                                        </div>
                                    </div>

                                    <div class="ka-live-preview-fields" data-live-preview-fields></div>

                                    <div class="ka-live-preview-footer">
                                        <small>Felder mit <span class="feuer-kontaktform-required">*</span> sind Pflichtfelder.</small>
                                        <span class="ka-live-preview-button" data-live-preview-button>Nachricht senden</span>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ka-design-customizer">
                    <div class="ka-fields-header">
                        <div>
                            <h3>Design anpassen</h3>
                            <p class="description">Farben, Bild und Oberflaeche koennen pro Formular frei angepasst werden.</p>
                        </div>
                        <div class="ka-action-links">
                            <button type="button" class="button" data-design-reset>Designwerte leeren</button>
                        </div>
                    </div>

                    <div class="ka-design-customizer-grid">
                        <label class="ka-form-group ka-color-control" for="ka_design_shell_background_color">
                            <span class="ka-form-label">Layout-Hintergrund</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['shell_background_color'] ?? '') !== '' ? $data['design_settings']['shell_background_color'] : $design_palette['shell_background_color'])); ?>" data-color-target="ka_design_shell_background_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_shell_background_color" type="text" name="design_settings[shell_background_color]" value="<?php echo esc_attr((string) ($data['design_settings']['shell_background_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['shell_background_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['shell_background_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_panel_background_color">
                            <span class="ka-form-label">Formular-Hintergrund</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['panel_background_color'] ?? '') !== '' ? $data['design_settings']['panel_background_color'] : $design_palette['panel_background_color'])); ?>" data-color-target="ka_design_panel_background_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_panel_background_color" type="text" name="design_settings[panel_background_color]" value="<?php echo esc_attr((string) ($data['design_settings']['panel_background_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['panel_background_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['panel_background_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_panel_text_color">
                            <span class="ka-form-label">Textfarbe Formular</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['panel_text_color'] ?? '') !== '' ? $data['design_settings']['panel_text_color'] : $design_palette['panel_text_color'])); ?>" data-color-target="ka_design_panel_text_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_panel_text_color" type="text" name="design_settings[panel_text_color]" value="<?php echo esc_attr((string) ($data['design_settings']['panel_text_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['panel_text_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['panel_text_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_title_color">
                            <span class="ka-form-label">Titel-Farbe</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['title_color'] ?? '') !== '' ? $data['design_settings']['title_color'] : $design_palette['title_color'])); ?>" data-color-target="ka_design_title_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_title_color" type="text" name="design_settings[title_color]" value="<?php echo esc_attr((string) ($data['design_settings']['title_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['title_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['title_color']); ?>">
                            </span>
                            <span class="description">Gilt fuer die grossen Ueberschriften wie <code>feuer-kontaktform-title</code>, Panel-Titel und Intro-Titel.</span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_aside_background_color">
                            <span class="ka-form-label">Info-Bereich Hintergrund</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['aside_background_color'] ?? '') !== '' ? $data['design_settings']['aside_background_color'] : $design_palette['aside_background_color'])); ?>" data-color-target="ka_design_aside_background_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_aside_background_color" type="text" name="design_settings[aside_background_color]" value="<?php echo esc_attr((string) ($data['design_settings']['aside_background_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['aside_background_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['aside_background_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_aside_text_color">
                            <span class="ka-form-label">Textfarbe Info-Bereich</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['aside_text_color'] ?? '') !== '' ? $data['design_settings']['aside_text_color'] : $design_palette['aside_text_color'])); ?>" data-color-target="ka_design_aside_text_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_aside_text_color" type="text" name="design_settings[aside_text_color]" value="<?php echo esc_attr((string) ($data['design_settings']['aside_text_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['aside_text_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['aside_text_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_accent_color">
                            <span class="ka-form-label">Akzentfarbe</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['accent_color'] ?? '') !== '' ? $data['design_settings']['accent_color'] : $design_palette['accent_color'])); ?>" data-color-target="ka_design_accent_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_accent_color" type="text" name="design_settings[accent_color]" value="<?php echo esc_attr((string) ($data['design_settings']['accent_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['accent_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['accent_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_button_background_color">
                            <span class="ka-form-label">Button-Hintergrund</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['button_background_color'] ?? '') !== '' ? $data['design_settings']['button_background_color'] : $design_palette['button_background_color'])); ?>" data-color-target="ka_design_button_background_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_button_background_color" type="text" name="design_settings[button_background_color]" value="<?php echo esc_attr((string) ($data['design_settings']['button_background_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['button_background_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['button_background_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_button_text_color">
                            <span class="ka-form-label">Button-Textfarbe</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['button_text_color'] ?? '') !== '' ? $data['design_settings']['button_text_color'] : $design_palette['button_text_color'])); ?>" data-color-target="ka_design_button_text_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_button_text_color" type="text" name="design_settings[button_text_color]" value="<?php echo esc_attr((string) ($data['design_settings']['button_text_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['button_text_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['button_text_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_input_background_color">
                            <span class="ka-form-label">Eingabefeld Hintergrund</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['input_background_color'] ?? '') !== '' ? $data['design_settings']['input_background_color'] : $design_palette['input_background_color'])); ?>" data-color-target="ka_design_input_background_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_input_background_color" type="text" name="design_settings[input_background_color]" value="<?php echo esc_attr((string) ($data['design_settings']['input_background_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['input_background_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['input_background_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_input_text_color">
                            <span class="ka-form-label">Eingabefeld Textfarbe</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['input_text_color'] ?? '') !== '' ? $data['design_settings']['input_text_color'] : $design_palette['input_text_color'])); ?>" data-color-target="ka_design_input_text_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_input_text_color" type="text" name="design_settings[input_text_color]" value="<?php echo esc_attr((string) ($data['design_settings']['input_text_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['input_text_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['input_text_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_input_border_color">
                            <span class="ka-form-label">Eingabefeld Rahmen</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['input_border_color'] ?? '') !== '' ? $data['design_settings']['input_border_color'] : $design_palette['input_border_color'])); ?>" data-color-target="ka_design_input_border_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_input_border_color" type="text" name="design_settings[input_border_color]" value="<?php echo esc_attr((string) ($data['design_settings']['input_border_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['input_border_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['input_border_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group ka-color-control" for="ka_design_overlay_color">
                            <span class="ka-form-label">Bild-Overlay Farbe</span>
                            <span class="ka-color-pair">
                                <input type="color" class="ka-color-swatch" value="<?php echo esc_attr((string) (($data['design_settings']['overlay_color'] ?? '') !== '' ? $data['design_settings']['overlay_color'] : $design_palette['overlay_color'])); ?>" data-color-target="ka_design_overlay_color">
                                <input class="ka-admin-input ka-design-control ka-color-value" id="ka_design_overlay_color" type="text" name="design_settings[overlay_color]" value="<?php echo esc_attr((string) ($data['design_settings']['overlay_color'] ?? '')); ?>" placeholder="<?php echo esc_attr((string) $design_palette['overlay_color']); ?>" data-default-color="<?php echo esc_attr((string) $design_palette['overlay_color']); ?>">
                            </span>
                        </label>

                        <label class="ka-form-group" for="ka_design_overlay_opacity">
                            <span class="ka-form-label">Bild-Overlay Deckkraft</span>
                            <input class="ka-admin-input ka-design-control" id="ka_design_overlay_opacity" type="number" min="0" max="100" step="1" name="design_settings[overlay_opacity]" value="<?php echo esc_attr((string) ($data['design_settings']['overlay_opacity'] ?? $design_palette['overlay_opacity'])); ?>">
                            <span class="description">Wert von 0 bis 100. Wirkt nur, wenn eine Overlay-Farbe gesetzt ist.</span>
                        </label>

                        <label class="ka-form-group ka-design-span-2" for="ka_design_background_image_url">
                            <span class="ka-form-label">Hintergrundbild</span>
                            <div class="ka-media-control">
                                <input class="ka-admin-input ka-design-control" id="ka_design_background_image_url" type="url" name="design_settings[background_image_url]" value="<?php echo esc_attr((string) ($data['design_settings']['background_image_url'] ?? '')); ?>" placeholder="/wp-content/uploads/formular-hintergrund.jpg">
                                <div class="ka-action-links">
                                    <button type="button" class="button ka-media-pick">Bild waehlen</button>
                                    <button type="button" class="button-link-delete ka-media-clear">Bild entfernen</button>
                                </div>
                            </div>
                            <span class="description">Bitte nur lokale Dateien aus der WordPress-Mediathek oder vom selben Host verwenden. Externe Bild-URLs werden nicht gespeichert.</span>
                        </label>

                        <label class="ka-form-group" for="ka_design_background_image_target">
                            <span class="ka-form-label">Bildbereich</span>
                            <select class="ka-admin-input ka-design-control" id="ka_design_background_image_target" name="design_settings[background_image_target]">
                                <?php foreach ($design_image_targets as $value => $label) : ?>
                                    <option value="<?php echo esc_attr((string) $value); ?>" <?php selected($data['design_settings']['background_image_target'] ?? 'aside', $value); ?>><?php echo esc_html((string) $label); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="description">Steuert, wo das Bild in der Form angezeigt wird.</span>
                        </label>
                    </div>
                </div>
            </section>

            <section class="ka-admin-panel">
                <div class="ka-fields-header">
                    <div>
                        <h2>Formularfelder</h2>
                        <p>Ziehen Sie die Feldkarten im visuellen Aufbau an die gewuenschte Stelle. Darunter bearbeiten Sie die Details jedes Feldes.</p>
                    </div>
                    <div class="ka-field-tools">
                        <select class="ka-new-field-type">
                            <option value="vorname">Vorname</option>
                            <option value="nachname">Nachname</option>
                            <option value="email">E-Mail</option>
                            <option value="telefon">Telefon</option>
                            <option value="nachricht">Nachricht</option>
                            <option value="kind_name">Name des Kindes</option>
                            <option value="kind_alter">Alter des Kindes</option>
                            <option value="text">Freies Textfeld</option>
                            <option value="textarea">Freies Textfeld (mehrzeilig)</option>
                            <option value="select">Auswahl</option>
                            <option value="radio">Radio-Auswahl</option>
                            <option value="date">Datum</option>
                            <option value="time">Uhrzeit</option>
                        </select>
                        <button type="button" class="button button-secondary ka-add-field">Feld hinzufuegen</button>
                    </div>
                </div>
                <div class="ka-field-builder" data-next-index="<?php echo esc_attr((string) count($data['fields'])); ?>">
                    <div class="ka-layout-canvas-wrap">
                        <p class="description">Visueller Aufbau: Ziehen Sie die Feldkarten in die gewuenschte Reihenfolge. Nachrichtenfelder werden automatisch als breite Elemente dargestellt.</p>
                        <div class="ka-layout-canvas" data-layout-canvas></div>
                    </div>
                    <div class="ka-field-rows ka-sortable-fields"><?php echo $field_rows; ?></div>
                    <script type="text/template" id="ka-field-template"><?php echo $field_template; ?></script>
                </div>
            </section>
        </div>

        <p class="submit">
            <button type="submit" class="button button-primary">Formular speichern</button>
            <a class="button" href="<?php echo esc_url($overview_url); ?>">Zur Uebersicht</a>
        </p>
    </form>
</div>


