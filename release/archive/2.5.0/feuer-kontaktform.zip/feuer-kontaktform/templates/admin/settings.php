<div class="wrap feuer-kontaktform-admin-wrap">
    <h1>Einstellungen</h1>
    <p>Globale Versanddaten, Branding, Standardtexte sowie Sperrlisten fuer IP-Adressen und Autoantwort-E-Mails.</p>

    <?php if (is_array($notice)) : ?>
        <div class="notice notice-<?php echo esc_attr($notice['type']); ?> is-dismissible"><p><?php echo esc_html($notice['message']); ?></p></div>
    <?php endif; ?>

    <div class="ka-admin-layout ka-admin-layout-stack">
        <section class="ka-admin-panel">
            <h2>Allgemein</h2>
            <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-admin-form">
                <?php wp_nonce_field('feuer-kontaktform-save-settings'); ?>
                <input type="hidden" name="feuer-kontaktform-action" value="save_settings">

                <label class="ka-form-group" for="ka_sender_name">
                    <span class="ka-form-label">Absendername</span>
                    <input class="ka-admin-input" id="ka_sender_name" type="text" name="sender_name" value="<?php echo esc_attr((string) $settings['sender_name']); ?>" required>
                </label>

                <label class="ka-form-group" for="ka_sender_email">
                    <span class="ka-form-label">Absender-E-Mail</span>
                    <input class="ka-admin-input" id="ka_sender_email" type="email" name="sender_email" value="<?php echo esc_attr((string) $settings['sender_email']); ?>" required>
                    <span class="description">Verwenden Sie hier die offizielle, bestaetigte Domain-Adresse fuer den Versand. Benutzeradressen werden nur als Reply-To genutzt. Fuer gute Zustellung sollten SMTP sowie SPF, DKIM und DMARC korrekt eingerichtet sein.</span>
                </label>

                <div class="ka-form-group">
                    <span class="ka-form-label">SMTP-Server</span>
                    <span class="description">Wenn SMTP aktiviert ist, versendet Feuer-Kontaktform Benachrichtigungen und Autoantworten direkt ueber Ihren Mailserver. Die Testfunktionen verwenden immer die aktuell eingegebenen SMTP-Daten, auch wenn diese noch nicht gespeichert wurden.</span>
                </div>

                <div class="ka-checkbox-grid">
                    <label><input type="checkbox" name="smtp_enabled" value="1" <?php checked(! empty($settings['smtp_enabled'])); ?>> SMTP fuer den Versand aktivieren</label>
                    <label><input type="checkbox" name="smtp_auth" value="1" <?php checked(! empty($settings['smtp_auth'])); ?>> SMTP-Authentifizierung verwenden</label>
                </div>

                <label class="ka-form-group" for="ka_smtp_host">
                    <span class="ka-form-label">SMTP-Host</span>
                    <input class="ka-admin-input" id="ka_smtp_host" type="text" name="smtp_host" value="<?php echo esc_attr((string) ($settings['smtp_host'] ?? '')); ?>" placeholder="mail.example.com">
                </label>

                <div class="ka-checkbox-grid">
                    <label class="ka-form-group" for="ka_smtp_port">
                        <span class="ka-form-label">SMTP-Port</span>
                        <input class="ka-admin-input" id="ka_smtp_port" type="number" name="smtp_port" min="1" max="65535" step="1" value="<?php echo esc_attr((string) ($settings['smtp_port'] ?? '587')); ?>">
                    </label>

                    <label class="ka-form-group" for="ka_smtp_encryption">
                        <span class="ka-form-label">Verschluesselung</span>
                        <select class="ka-admin-input" id="ka_smtp_encryption" name="smtp_encryption">
                            <option value="none" <?php selected((string) ($settings['smtp_encryption'] ?? 'tls'), 'none'); ?>>Keine</option>
                            <option value="tls" <?php selected((string) ($settings['smtp_encryption'] ?? 'tls'), 'tls'); ?>>TLS / STARTTLS</option>
                            <option value="ssl" <?php selected((string) ($settings['smtp_encryption'] ?? 'tls'), 'ssl'); ?>>SSL</option>
                        </select>
                    </label>

                    <label class="ka-form-group" for="ka_smtp_timeout">
                        <span class="ka-form-label">Timeout in Sekunden</span>
                        <input class="ka-admin-input" id="ka_smtp_timeout" type="number" name="smtp_timeout" min="3" max="60" step="1" value="<?php echo esc_attr((string) ($settings['smtp_timeout'] ?? '15')); ?>">
                    </label>
                </div>

                <label class="ka-form-group" for="ka_smtp_username">
                    <span class="ka-form-label">SMTP-Benutzername</span>
                    <input class="ka-admin-input" id="ka_smtp_username" type="text" name="smtp_username" value="<?php echo esc_attr((string) ($settings['smtp_username'] ?? '')); ?>" autocomplete="off">
                </label>

                <label class="ka-form-group" for="ka_smtp_password">
                    <span class="ka-form-label">SMTP-Passwort</span>
                    <input class="ka-admin-input" id="ka_smtp_password" type="password" name="smtp_password" value="" autocomplete="new-password">
                    <span class="description">Leer lassen, um das bereits gespeicherte Passwort beizubehalten.</span>
                </label>

                <label class="ka-form-group" for="ka_smtp_test_recipient">
                    <span class="ka-form-label">Empfaenger fuer Test-E-Mail</span>
                    <input class="ka-admin-input" id="ka_smtp_test_recipient" type="email" name="smtp_test_recipient" value="<?php echo esc_attr((string) ($smtp_test_recipient ?? '')); ?>" placeholder="<?php echo esc_attr((string) $settings['sender_email']); ?>">
                </label>

                <div class="ka-checkbox-grid">
                    <button type="submit" class="button button-secondary" name="feuer-kontaktform-action" value="test_smtp_connection">SMTP-Verbindung pruefen</button>
                    <button type="submit" class="button button-secondary" name="feuer-kontaktform-action" value="send_test_email">Test-E-Mail senden</button>
                </div>

                <div class="ka-update-box">
                    <div>
                        <span class="ka-form-label">Plugin-Updates</span>
                        <p class="description">
                            Update-Quelle:
                            <a href="<?php echo esc_url((string) ($update_status['base_url'] ?? 'https://wdmin.com/plugins/feuer-kontaktform/')); ?>" target="_blank" rel="noopener">wdmin.com/plugins/feuer-kontaktform/</a>
                        </p>
                        <p class="description">
                            Installiert: <strong><?php echo esc_html((string) ($update_status['current_version'] ?? '')); ?></strong>
                            <?php if (($update_status['remote_version'] ?? '') !== '') : ?>
                                | Server: <strong><?php echo esc_html((string) $update_status['remote_version']); ?></strong>
                            <?php endif; ?>
                            <?php if (($update_status['checked_at'] ?? '') !== '') : ?>
                                | Letzte Pruefung: <?php echo esc_html((string) $update_status['checked_at']); ?>
                            <?php endif; ?>
                        </p>
                        <?php if (! empty($update_status['update_available'])) : ?>
                            <p class="ka-inline-success">Eine neue Version ist verfuegbar.</p>
                        <?php elseif (($update_status['error'] ?? '') !== '') : ?>
                            <p class="ka-inline-error"><?php echo esc_html((string) $update_status['error']); ?></p>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="button button-secondary" name="feuer-kontaktform-action" value="check_plugin_update">Update pruefen</button>
                </div>

                <label class="ka-form-group" for="ka_success_message">
                    <span class="ka-form-label">Erfolgsmeldung</span>
                    <textarea class="ka-admin-input" id="ka_success_message" name="default_success_message" rows="3"><?php echo esc_textarea((string) $settings['default_success_message']); ?></textarea>
                </label>

                <div class="ka-form-group">
                    <span class="ka-form-label">Logo</span>
                    <div class="ka-media-control">
                        <input class="ka-admin-input" id="ka_brand_logo_url" type="url" name="brand_logo_url" value="<?php echo esc_attr((string) $settings['brand_logo_url']); ?>" placeholder="/wp-content/uploads/logo.svg">
                        <div class="ka-action-links">
                            <button type="button" class="button ka-media-pick">Logo waehlen</button>
                            <button type="button" class="button-link-delete ka-media-clear">Logo entfernen</button>
                        </div>
                    </div>
                    <span class="description">Bitte nur Dateien aus der eigenen WordPress-Mediathek oder vom selben Host verwenden. Externe Logo-URLs werden beim Speichern verworfen.</span>
                </div>

                <label class="ka-form-group" for="ka_brand_logo_width">
                    <span class="ka-form-label">Logo-Breite in px</span>
                    <input class="ka-admin-input" id="ka_brand_logo_width" type="number" name="brand_logo_width" min="60" max="320" step="1" value="<?php echo esc_attr((string) $settings['brand_logo_width']); ?>">
                </label>

                <label class="ka-form-group" for="ka_brand_label">
                    <span class="ka-form-label">Markenbezeichnung</span>
                    <input class="ka-admin-input" id="ka_brand_label" type="text" name="brand_label" value="<?php echo esc_attr((string) $settings['brand_label']); ?>">
                </label>

                <label class="ka-form-group" for="ka_brand_tagline">
                    <span class="ka-form-label">Unterzeile / Signatur</span>
                    <textarea class="ka-admin-input" id="ka_brand_tagline" name="brand_tagline" rows="3"><?php echo esc_textarea((string) $settings['brand_tagline']); ?></textarea>
                </label>

                <label class="ka-form-group" for="ka_brand_website_url">
                    <span class="ka-form-label">Website-URL</span>
                    <input class="ka-admin-input" id="ka_brand_website_url" type="url" name="brand_website_url" value="<?php echo esc_attr((string) $settings['brand_website_url']); ?>">
                </label>

                <label class="ka-form-group" for="ka_brand_website_text">
                    <span class="ka-form-label">Website-Beschriftung</span>
                    <input class="ka-admin-input" id="ka_brand_website_text" type="text" name="brand_website_text" value="<?php echo esc_attr((string) $settings['brand_website_text']); ?>">
                </label>

                <label class="ka-form-group" for="feuer-kontaktform-forms_page_url">
                    <span class="ka-form-label">URL der Kontaktseite</span>
                    <input class="ka-admin-input" id="feuer-kontaktform-forms_page_url" type="url" name="forms_page_url" value="<?php echo esc_attr((string) ($settings['forms_page_url'] ?? '')); ?>" placeholder="https://example.com/kontakt/">
                    <span class="description">Seite, auf der <code>[feuer-kontaktform-alle]</code> eingebunden ist. Daraus erzeugt Feuer-Kontaktform Direktlinks zu einzelnen Formularen.</span>
                </label>

                <label class="ka-form-group" for="ka_privacy_policy_url">
                    <span class="ka-form-label">URL zur Datenschutzerklaerung</span>
                    <input class="ka-admin-input" id="ka_privacy_policy_url" type="url" name="privacy_policy_url" value="<?php echo esc_attr((string) ($settings['privacy_policy_url'] ?? '')); ?>">
                    <span class="description">Diese URL wird im verpflichtenden Datenschutzhinweis der Formulare angezeigt und zusammen mit dem Versand protokolliert.</span>
                </label>

                <label class="ka-form-group" for="ka_privacy_notice_text">
                    <span class="ka-form-label">Text fuer Datenschutzhinweis</span>
                    <textarea class="ka-admin-input" id="ka_privacy_notice_text" name="privacy_notice_text" rows="3"><?php echo esc_textarea((string) ($settings['privacy_notice_text'] ?? '')); ?></textarea>
                </label>

                <label class="ka-form-group" for="ka_privacy_notice_version">
                    <span class="ka-form-label">Version Datenschutzhinweis</span>
                    <input class="ka-admin-input" id="ka_privacy_notice_version" type="text" name="privacy_notice_version" value="<?php echo esc_attr((string) ($settings['privacy_notice_version'] ?? '1')); ?>">
                </label>

                <label class="ka-form-group" for="ka_allowed_referrer_hosts">
                    <span class="ka-form-label">Erlaubte Referrer-Hosts</span>
                    <textarea class="ka-admin-input" id="ka_allowed_referrer_hosts" name="allowed_referrer_hosts" rows="4" placeholder="example.com&#10;*.example.com"><?php echo esc_textarea((string) ($settings['allowed_referrer_hosts'] ?? '')); ?></textarea>
                    <span class="description">Optional. Wenn gesetzt, duerfen Formulare nur von diesen Hostnamen abgesendet werden.</span>
                </label>

                <label class="ka-form-group" for="ka_log_retention_days">
                    <span class="ka-form-label">Log-Aufbewahrung in Tagen</span>
                    <input class="ka-admin-input" id="ka_log_retention_days" type="number" min="0" step="1" name="log_retention_days" value="<?php echo esc_attr((string) ($settings['log_retention_days'] ?? '0')); ?>">
                    <span class="description">0 deaktiviert die automatische Anonymisierung alter Eintraege.</span>
                </label>

                <label class="ka-form-group" for="ka_webhook_url">
                    <span class="ka-form-label">Webhook-URL</span>
                    <input class="ka-admin-input" id="ka_webhook_url" type="url" name="webhook_url" value="<?php echo esc_attr((string) ($settings['webhook_url'] ?? '')); ?>">
                </label>

                <label class="ka-form-group" for="ka_webhook_timeout">
                    <span class="ka-form-label">Webhook-Timeout in Sekunden</span>
                    <input class="ka-admin-input" id="ka_webhook_timeout" type="number" min="3" max="30" step="1" name="webhook_timeout" value="<?php echo esc_attr((string) ($settings['webhook_timeout'] ?? '10')); ?>">
                </label>

                <label class="ka-form-group" for="ka_admin_notification_email">
                    <span class="ka-form-label">Zusaetzliche Admin-Benachrichtigung</span>
                    <input class="ka-admin-input" id="ka_admin_notification_email" type="email" name="admin_notification_email" value="<?php echo esc_attr((string) ($settings['admin_notification_email'] ?? '')); ?>">
                    <span class="description">Diese Adresse wird zusaetzlich in die Empfaengerliste aufgenommen.</span>
                </label>

                <div class="ka-checkbox-grid">
                    <label><input type="checkbox" name="rewrite_enabled" value="1" <?php checked(! empty($settings['rewrite_enabled'])); ?>> Pretty URLs fuer Formulare aktivieren</label>
                </div>

                <label class="ka-form-group" for="ka_popup_button_label">
                    <span class="ka-form-label">Standard Popup-Button</span>
                    <input class="ka-admin-input" id="ka_popup_button_label" type="text" name="popup_button_label" value="<?php echo esc_attr((string) ($settings['popup_button_label'] ?? 'Kontakt aufnehmen')); ?>">
                </label>

                <label class="ka-form-group" for="ka_default_subject">
                    <span class="ka-form-label">Standard-Autoantwort Betreff</span>
                    <input class="ka-admin-input" id="ka_default_subject" type="text" name="default_auto_reply_subject" value="<?php echo esc_attr((string) $settings['default_auto_reply_subject']); ?>" required>
                </label>

                <label class="ka-form-group" for="ka_default_message">
                    <span class="ka-form-label">Standard-Autoantwort Text</span>
                    <textarea class="ka-admin-input" id="ka_default_message" name="default_auto_reply_message" rows="10"><?php echo esc_textarea((string) $settings['default_auto_reply_message']); ?></textarea>
                    <span class="description">Verfuegbare Makros: <code>{{formular}}</code>, <code>{{vorname}}</code>, <code>{{nachname}}</code>, <code>{{name}}</code>, <code>{{ticket_id}}</code>, <code>{{logo}}</code>, <code>{{logo_url}}</code>, <code>{{website}}</code>, <code>{{site_url}}</code>.</span>
                    <span class="description">Autoantworten werden als HTML versendet. Sie koennen daher auch einfache HTML-Tags verwenden.</span>
                </label>

                <p class="submit"><button type="submit" class="button button-primary" name="feuer-kontaktform-action" value="save_settings">Einstellungen speichern</button></p>
            </form>
        </section>

        <section class="ka-admin-panel">
            <h2>Direktlinks zu Formularen</h2>
            <p>Mit dem Query-Parameter <code>?feuer-kontaktform-form=slug</code> laesst sich eine bestimmte Abteilung direkt im Browser oeffnen.</p>

            <?php if ($form_links === []) : ?>
                <p class="description">Es sind noch keine Formulare vorhanden.</p>
            <?php else : ?>
                <div class="ka-shortcode-list">
                    <?php foreach ($form_links as $form_link) : ?>
                        <div class="ka-direct-link-item">
                            <strong><?php echo esc_html((string) $form_link['title']); ?></strong>
                            <code><?php echo esc_html((string) $form_link['link']['query_code']); ?></code>
                            <?php if (($form_link['link']['url'] ?? '') !== '') : ?>
                                <a href="<?php echo esc_url((string) $form_link['link']['url']); ?>" target="_blank" rel="noopener">Direktlink oeffnen</a>
                                <code><?php echo esc_html((string) $form_link['link']['url']); ?></code>
                                <?php if (($form_link['link']['pretty_url'] ?? '') !== '') : ?>
                                    <code><?php echo esc_html((string) $form_link['link']['pretty_url']); ?></code>
                                <?php endif; ?>
                            <?php else : ?>
                                <span class="description">Hinterlegen Sie oben die URL der Kontaktseite, um den kompletten Link zu generieren.</span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="ka-admin-panel">
            <h2>IP-Sperrliste</h2>
            <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-stacked-form">
                <?php wp_nonce_field('feuer-kontaktform-add-blocked-ip'); ?>
                <input type="hidden" name="feuer-kontaktform-action" value="add_blocked_ip">
                <label>IP-Adresse<input type="text" name="ip_address" placeholder="203.0.113.5" required></label>
                <label>Begruendung<input type="text" name="reason" placeholder="z. B. Spam"></label>
                <button type="submit" class="button button-secondary">IP-Adresse sperren</button>
            </form>

            <?php if ($blocked_ips === []) : ?>
                <p class="description">Keine gesperrten IP-Adressen vorhanden.</p>
            <?php else : ?>
                <table class="widefat striped ka-simple-table">
                    <thead><tr><th>IP-Adresse</th><th>Begruendung</th><th>Seit</th><th></th></tr></thead>
                    <tbody>
                        <?php foreach ($blocked_ips as $item) : ?>
                            <tr>
                                <td><code><?php echo esc_html($item['ip_address']); ?></code></td>
                                <td><?php echo esc_html($item['reason'] !== '' ? $item['reason'] : '-'); ?></td>
                                <td><?php echo esc_html($item['created_display']); ?></td>
                                <td><a class="button button-link-delete" href="<?php echo esc_url($item['delete_url']); ?>">Entfernen</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>

        <section class="ka-admin-panel">
            <h2>Autoantwort-Sperrliste</h2>
            <form method="post" action="<?php echo esc_url($action_url); ?>" class="ka-stacked-form">
                <?php wp_nonce_field('feuer-kontaktform-add-blocked-email'); ?>
                <input type="hidden" name="feuer-kontaktform-action" value="add_blocked_email">
                <label>E-Mail-Adresse<input type="email" name="email" placeholder="name@beispiel.de" required></label>
                <label>Begruendung<input type="text" name="reason" placeholder="z. B. keine Autoantwort erwuenscht"></label>
                <button type="submit" class="button button-secondary">E-Mail sperren</button>
            </form>
            <p class="description">Gesperrte E-Mail-Adressen duerfen weiterhin Nachrichten absenden. Es wird lediglich keine automatische Antwort mehr verschickt.</p>

            <?php if ($blocked_emails === []) : ?>
                <p class="description">Keine gesperrten E-Mail-Adressen vorhanden.</p>
            <?php else : ?>
                <table class="widefat striped ka-simple-table">
                    <thead><tr><th>E-Mail-Adresse</th><th>Begruendung</th><th>Seit</th><th></th></tr></thead>
                    <tbody>
                        <?php foreach ($blocked_emails as $item) : ?>
                            <tr>
                                <td><code><?php echo esc_html($item['email']); ?></code></td>
                                <td><?php echo esc_html($item['reason'] !== '' ? $item['reason'] : '-'); ?></td>
                                <td><?php echo esc_html($item['created_display']); ?></td>
                                <td><a class="button button-link-delete" href="<?php echo esc_url($item['delete_url']); ?>">Entfernen</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </div>
</div>


