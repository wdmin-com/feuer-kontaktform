document.addEventListener('DOMContentLoaded', function () {
  function qsa(root, selector) {
    return Array.prototype.slice.call(root.querySelectorAll(selector));
  }

  function escapeSelectorValue(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') {
      return window.CSS.escape(value);
    }

    return String(value).replace(/(["\\\]])/g, '\\$1');
  }

  function setHidden(element, hidden) {
    if (!element) {
      return;
    }

    element.hidden = hidden;
    element.classList.toggle('d-none', hidden);
  }

  function updateVisibleForm(select, switcher) {
    var value = select.value;

    qsa(switcher, '.feuer-kontaktform-form-wrap').forEach(function (formWrap) {
      setHidden(formWrap, formWrap.getAttribute('data-form-id') !== value);
    });
  }

  function updateBrowserUrl(select, force) {
    var option;
    var queryValue;
    var url;
    var hasFlash;
    var hasFormQuery;

    if (!window.history || typeof window.history.replaceState !== 'function') {
      return;
    }

    option = select.options[select.selectedIndex];
    queryValue = option ? option.getAttribute('data-form-query-value') || select.value : select.value;

    try {
      url = new URL(window.location.href);
      hasFlash = url.searchParams.has('feuer-kontaktform-flash');
      hasFormQuery = url.searchParams.has('feuer-kontaktform-form');

      if (!force && !hasFlash && !hasFormQuery) {
        return;
      }

      url.searchParams.delete('feuer-kontaktform-flash');
      url.searchParams.set('feuer-kontaktform-form', queryValue);
      window.history.replaceState({}, '', url.toString());
    } catch (error) {
      // Ignore invalid browser URL states.
    }
  }

  qsa(document, '.feuer-kontaktform-switcher').forEach(function (switcher) {
    var select = switcher.querySelector('.feuer-kontaktform-selector');

    if (!select) {
      return;
    }

    select.addEventListener('change', function () {
      updateVisibleForm(select, switcher);
      updateBrowserUrl(select, true);
    });

    updateVisibleForm(select, switcher);
    updateBrowserUrl(select, false);
  });

  function showMessage(form, kind, message) {
    var box = form.querySelector('[data-form-message]');

    if (!box) {
      return;
    }

    box.className = 'alert mt-3';
    box.classList.add(kind === 'success' ? 'alert-success' : 'alert-danger');
    box.textContent = message || '';
    setHidden(box, !message);
  }

  function clearMessage(form) {
    showMessage(form, 'error', '');
  }

  function setFieldError(form, fieldKey, message) {
    var fieldWrap = form.querySelector('[data-field-key="' + fieldKey + '"]');
    var errorBox;
    var privacyWrap;
    var privacyInput;

    if (!fieldWrap) {
      if (fieldKey === 'feuer_kontaktform_privacy_accepted') {
        privacyWrap = form.querySelector('[data-privacy-wrap]');
        privacyInput = form.querySelector('input[name="feuer_kontaktform_privacy_accepted"]');
        errorBox = privacyWrap ? privacyWrap.querySelector('[data-field-error]') : null;

        if (privacyWrap) {
          privacyWrap.classList.toggle('border-danger', !!message);
        }

        if (privacyInput) {
          privacyInput.classList.toggle('is-invalid', !!message);
        }

        if (errorBox) {
          errorBox.textContent = message || '';
          setHidden(errorBox, !message);
        }
      }

      return;
    }

    errorBox = fieldWrap.querySelector('[data-field-error]');
    if (errorBox) {
      errorBox.textContent = message || '';
      setHidden(errorBox, !message);
    }

    qsa(fieldWrap, 'input, select, textarea').forEach(function (input) {
      input.classList.toggle('is-invalid', !!message);
    });

    qsa(fieldWrap, '[data-choice-group]').forEach(function (group) {
      group.classList.toggle('border-danger', !!message);
    });
  }

  function clearFieldErrors(form) {
    qsa(form, '[data-field-error]').forEach(function (box) {
      box.textContent = '';
      setHidden(box, true);
    });

    qsa(form, '.is-invalid').forEach(function (element) {
      element.classList.remove('is-invalid');
    });

    qsa(form, '.border-danger').forEach(function (element) {
      element.classList.remove('border-danger');
    });
  }

  function getFieldValue(form, fieldKey) {
    var fields = qsa(form, '[name="feuer_kontaktform_fields[' + fieldKey + ']"]');
    var checked;

    if (!fields.length) {
      return '';
    }

    if (fields[0].type === 'radio') {
      checked = fields.find(function (field) {
        return field.checked;
      });

      return checked ? checked.value : '';
    }

    return fields[0].value || '';
  }

  function toggleFieldDisabled(fieldWrap, disabled) {
    qsa(fieldWrap, 'input, select, textarea').forEach(function (input) {
      if (input.name === 'feuer-kontaktform-nonce' || input.name === 'form_id' || input.name === 'redirect_to' || input.name === 'action' || input.name === 'privacy_notice_version') {
        return;
      }

      input.disabled = disabled;
    });
  }

  function applyConditionalVisibility(form) {
    qsa(form, '[data-field-wrap]').forEach(function (fieldWrap) {
      var conditionField = fieldWrap.getAttribute('data-condition-field') || '';
      var conditionValue = fieldWrap.getAttribute('data-condition-value') || '';
      var actualValue;
      var expectedValues;
      var visible = true;

      if (conditionField && conditionValue) {
        actualValue = (getFieldValue(form, conditionField) || '').toLowerCase();
        expectedValues = conditionValue.split(/[\n,;|]+/).map(function (value) {
          return value.trim().toLowerCase();
        }).filter(Boolean);
        visible = expectedValues.indexOf(actualValue) !== -1;
      }

      setHidden(fieldWrap, !visible);
      toggleFieldDisabled(fieldWrap, !visible);
    });
  }

  function getPanels(form) {
    return qsa(form, '[data-step-panel]');
  }

  function updateProgress(form) {
    var panels = getPanels(form);
    var current = parseInt(form.getAttribute('data-current-step') || '1', 10);
    var bar = form.querySelector('[data-step-progress-bar]');
    var meta = form.querySelector('[data-step-progress-meta]');
    var percent;

    if (!panels.length) {
      return;
    }

    percent = Math.max(1, Math.round((current / panels.length) * 100));

    if (bar) {
      bar.style.width = percent + '%';
    }

    if (meta) {
      meta.textContent = 'Schritt ' + current + ' von ' + panels.length;
    }
  }

  function showStep(form, stepNumber) {
    var panels = getPanels(form);

    if (!panels.length) {
      return;
    }

    panels.forEach(function (panel, index) {
      var active = index + 1 === stepNumber;
      setHidden(panel, !active);
      panel.classList.toggle('is-active', active);
    });

    form.setAttribute('data-current-step', String(stepNumber));
    updateProgress(form);
  }

  function validateFieldWrap(fieldWrap, form) {
    var controls = qsa(fieldWrap, 'input, select, textarea');
    var first = controls[0];
    var required = controls.some(function (control) {
      return control.getAttribute('data-required') === '1';
    });
    var fieldKey = fieldWrap.getAttribute('data-field-key') || '';
    var value = '';
    var message = '';
    var checked;

    if (fieldWrap.hidden) {
      return true;
    }

    if (!controls.length) {
      return true;
    }

    if (controls[0].type === 'radio') {
      checked = controls.find(function (control) {
        return control.checked;
      });
      value = checked ? checked.value : '';
    } else {
      value = first.value || '';
    }

    if (required && !value) {
      message = 'Bitte fuellen Sie dieses Feld aus.';
    } else if (first.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      message = 'Bitte geben Sie eine gueltige E-Mail-Adresse an.';
    }

    setFieldError(form, fieldKey, message);

    return !message;
  }

  function validateCurrentStep(form) {
    var current = parseInt(form.getAttribute('data-current-step') || '1', 10);
    var panel = getPanels(form)[current - 1];
    var valid = true;

    if (!panel) {
      return true;
    }

    if (panel.hasAttribute('data-privacy-gate')) {
      return validatePrivacyGate(form, panel);
    }

    qsa(panel, '[data-field-wrap]').forEach(function (fieldWrap) {
      if (!validateFieldWrap(fieldWrap, form)) {
        valid = false;
      }
    });

    return valid;
  }

  function getPrivacyChoice(form) {
    var checked = form.querySelector('input[name="feuer_kontaktform_privacy_choice"]:checked');
    return checked ? checked.value : '';
  }

  function syncPrivacyValue(form) {
    var hidden = form.querySelector('[data-privacy-value]');
    var accepted = getPrivacyChoice(form) === 'yes';

    if (hidden) {
      hidden.value = accepted ? '1' : '';
    }

    return accepted;
  }

  function validatePrivacyGate(form, panel) {
    var choice = getPrivacyChoice(form);
    var denied = form.querySelector('[data-privacy-denied]');
    var errorBox = panel ? panel.querySelector('[data-field-error]') : null;
    var message = '';

    syncPrivacyValue(form);

    if (choice === 'no') {
      message = 'Ohne Einwilligung koennen wir Ihre Anfrage nicht verarbeiten.';
      setHidden(denied, false);
    } else {
      setHidden(denied, true);
    }

    if (choice === '') {
      message = 'Bitte treffen Sie eine Auswahl zum Datenschutz.';
    }

    if (errorBox) {
      errorBox.textContent = message;
      setHidden(errorBox, !message);
    }

    return choice === 'yes';
  }

  function validateWholeForm(form) {
    var valid = true;
    var privacyPanel = form.querySelector('[data-privacy-gate]');

    qsa(form, '[data-field-wrap]').forEach(function (fieldWrap) {
      if (!validateFieldWrap(fieldWrap, form)) {
        valid = false;
      }
    });

    if (privacyPanel && !validatePrivacyGate(form, privacyPanel)) {
      setFieldError(form, 'feuer_kontaktform_privacy_accepted', 'Bitte bestaetigen Sie den Datenschutzhinweis.');
      valid = false;
    } else {
      setFieldError(form, 'feuer_kontaktform_privacy_accepted', '');
    }

    return valid;
  }

  function saveDraft(form) {
    var key = form.getAttribute('data-draft-key');
    var enabled = form.getAttribute('data-draft-enabled') === '1';
    var payload = {};

    if (!enabled || !key || !window.localStorage) {
      return;
    }

    qsa(form, '[name^="feuer_kontaktform_fields["], input[name="feuer_kontaktform_privacy_accepted"]').forEach(function (input) {
      if (!input.name || input.disabled) {
        return;
      }

      if (input.type === 'radio') {
        if (input.checked) {
          payload[input.name] = input.value;
        } else if (!(input.name in payload)) {
          payload[input.name] = '';
        }

        return;
      }

      if (input.type === 'checkbox') {
        payload[input.name] = input.checked ? '1' : '';
        return;
      }

      payload[input.name] = input.value || '';
    });

    try {
      window.localStorage.setItem(key, JSON.stringify(payload));
    } catch (error) {
      // Ignore storage failures.
    }
  }

  function restoreDraft(form) {
    var key = form.getAttribute('data-draft-key');
    var enabled = form.getAttribute('data-draft-enabled') === '1';
    var raw;
    var payload;

    if (!enabled || !key || !window.localStorage) {
      return;
    }

    try {
      raw = window.localStorage.getItem(key);
      payload = raw ? JSON.parse(raw) : null;
    } catch (error) {
      payload = null;
    }

    if (!payload || typeof payload !== 'object') {
      return;
    }

    Object.keys(payload).forEach(function (name) {
      var inputs = qsa(form, '[name="' + escapeSelectorValue(name) + '"]');

      if (!inputs.length) {
        return;
      }

      if (inputs[0].type === 'radio') {
        inputs.forEach(function (input) {
          input.checked = input.value === payload[name];
        });
        return;
      }

      if (inputs[0].type === 'checkbox') {
        inputs[0].checked = payload[name] === '1';
        return;
      }

      inputs[0].value = payload[name];
    });
  }

  function clearDraft(form) {
    var key = form.getAttribute('data-draft-key');

    if (!key || !window.localStorage) {
      return;
    }

    try {
      window.localStorage.removeItem(key);
    } catch (error) {
      // Ignore storage failures.
    }
  }

  function syncSubmitState(form) {
    var submitButton = form.querySelector('[data-submit-button]');
    var submitting = form.getAttribute('data-is-submitting') === '1';
    var canSubmit = !form.querySelector('[data-privacy-gate]') || syncPrivacyValue(form);

    if (!submitButton) {
      return;
    }

    submitButton.disabled = submitting || !canSubmit;
    submitButton.setAttribute('aria-disabled', submitButton.disabled ? 'true' : 'false');
  }

  function clearCaptcha(form) {
    qsa(form, '[data-captcha-container][data-generated="1"]').forEach(function (wrapper) {
      wrapper.remove();
    });
  }

  function renderCaptcha(form, captcha) {
    var existingToken = form.querySelector('input[name="captcha_token"]');
    var existingWrap = form.querySelector('[data-captcha-wrap]');
    var lastPanel = getPanels(form).slice(-1)[0];
    var fieldsRow;
    var beforeNode;
    var wrapper;
    var inputId;
    var label;

    if (!captcha || !captcha.question || !captcha.token || !lastPanel) {
      return;
    }

    if (existingToken && existingWrap) {
      existingToken.value = captcha.token;
      label = existingWrap.querySelector('label');

      if (label) {
        label.textContent = captcha.question;
      }

      setHidden(existingWrap.closest('[data-captcha-container]'), false);
      return;
    }

    fieldsRow = lastPanel.querySelector('[data-step-fields]');
    if (!fieldsRow) {
      return;
    }

    beforeNode = fieldsRow.querySelector('[data-privacy-container]');
    wrapper = document.createElement('div');
    inputId = 'feuer_kontaktform_ajax_captcha_' + form.getAttribute('data-form-id');
    wrapper.className = 'col-12';
    wrapper.setAttribute('data-captcha-container', '1');
    wrapper.setAttribute('data-generated', '1');
    wrapper.innerHTML =
      '<div class="border rounded p-3 bg-light" data-captcha-wrap>' +
        '<label class="form-label" for="' + inputId + '">' + captcha.question + '</label>' +
        '<input class="form-control" id="' + inputId + '" type="text" name="captcha_answer" inputmode="numeric">' +
        '<input type="hidden" name="captcha_token" value="' + captcha.token + '">' +
        '<div class="invalid-feedback d-block d-none" data-field-error></div>' +
      '</div>';

    if (beforeNode) {
      fieldsRow.insertBefore(wrapper, beforeNode);
    } else {
      fieldsRow.appendChild(wrapper);
    }
  }

  function applyServerErrors(form, payload) {
    clearFieldErrors(form);

    if (payload && payload.fieldErrors) {
      Object.keys(payload.fieldErrors).forEach(function (fieldKey) {
        setFieldError(form, fieldKey, payload.fieldErrors[fieldKey]);
      });
    }

    if (payload && payload.errors && payload.errors.length) {
      showMessage(form, 'error', payload.errors[0]);
    } else {
      clearMessage(form);
    }

    if (payload && payload.captcha && payload.captcha.question) {
      renderCaptcha(form, payload.captcha);
    }
  }

  function submitAsync(form) {
    var data = new window.FormData(form);
    var overlay = form.querySelector('[data-submit-overlay]');

    data.set('action', 'feuer-kontaktform-submit-async');

    clearMessage(form);
    form.setAttribute('data-is-submitting', '1');
    setHidden(overlay, false);
    syncSubmitState(form);

    window.fetch(form.getAttribute('data-ajax-url'), {
      method: 'POST',
      credentials: 'same-origin',
      body: data
    }).then(function (response) {
      return response.json();
    }).then(function (json) {
      var payload = json && json.data ? json.data : {};

      if (json && json.success) {
        clearFieldErrors(form);
        showMessage(form, 'success', payload.message || 'Ihre Anfrage wurde versendet.');
        form.reset();
        clearCaptcha(form);
        clearDraft(form);
        applyConditionalVisibility(form);
        showStep(form, 1);
        syncSubmitState(form);
        return;
      }

      applyServerErrors(form, payload);
    }).catch(function () {
      showMessage(form, 'error', 'Die Anfrage konnte nicht versendet werden. Bitte versuchen Sie es erneut.');
    }).finally(function () {
      form.setAttribute('data-is-submitting', '0');
      setHidden(overlay, true);
      syncSubmitState(form);
    });
  }

  function initForm(form) {
    restoreDraft(form);
    applyConditionalVisibility(form);
    showStep(form, 1);
    form.setAttribute('data-is-submitting', '0');
    syncSubmitState(form);

    form.addEventListener('input', function () {
      syncPrivacyValue(form);
      applyConditionalVisibility(form);
      saveDraft(form);
      syncSubmitState(form);
    });

    form.addEventListener('change', function () {
      syncPrivacyValue(form);
      applyConditionalVisibility(form);
      saveDraft(form);
      syncSubmitState(form);
    });

    qsa(form, '[data-step-next]').forEach(function (button) {
      button.addEventListener('click', function () {
        var current = parseInt(form.getAttribute('data-current-step') || '1', 10);
        clearMessage(form);

        if (!validateCurrentStep(form)) {
          showMessage(form, 'error', 'Bitte korrigieren Sie die markierten Felder.');
          return;
        }

        showStep(form, current + 1);
      });
    });

    qsa(form, '[data-step-prev]').forEach(function (button) {
      button.addEventListener('click', function () {
        var current = parseInt(form.getAttribute('data-current-step') || '1', 10);
        clearMessage(form);
        showStep(form, Math.max(1, current - 1));
      });
    });

    form.addEventListener('submit', function (event) {
      clearFieldErrors(form);
      clearMessage(form);

      if (!validateWholeForm(form)) {
        event.preventDefault();
        showMessage(form, 'error', 'Bitte korrigieren Sie die markierten Felder.');
        syncSubmitState(form);
        return;
      }

      if (form.getAttribute('data-submit-mode') !== 'ajax') {
        form.setAttribute('data-is-submitting', '1');
        setHidden(form.querySelector('[data-submit-overlay]'), false);
        syncSubmitState(form);
        return;
      }

      event.preventDefault();
      submitAsync(form);
    });
  }

  qsa(document, '.feuer-kontaktform-submission-form').forEach(initForm);

  function openPopup(shell) {
    var dialog = shell.querySelector('.feuer-kontaktform-popup-dialog');
    var backdrop = shell.querySelector('.feuer-kontaktform-popup-backdrop');

    if (!dialog || !backdrop) {
      return;
    }

    setHidden(dialog, false);
    setHidden(backdrop, false);
    shell.classList.add('is-open');
    document.documentElement.classList.add('feuer-kontaktform-popup-open');
  }

  function closePopup(shell) {
    var dialog = shell.querySelector('.feuer-kontaktform-popup-dialog');
    var backdrop = shell.querySelector('.feuer-kontaktform-popup-backdrop');

    if (!dialog || !backdrop) {
      return;
    }

    setHidden(dialog, true);
    setHidden(backdrop, true);
    shell.classList.remove('is-open');

    if (!document.querySelector('.feuer-kontaktform-popup-shell.is-open')) {
      document.documentElement.classList.remove('feuer-kontaktform-popup-open');
    }
  }

  qsa(document, '[data-feuer-kontaktform-popup-shell]').forEach(function (shell) {
    var openButton = shell.querySelector('[data-feuer-kontaktform-popup-open]');
    var closeButton = shell.querySelector('[data-feuer-kontaktform-popup-close]');
    var backdrop = shell.querySelector('[data-feuer-kontaktform-popup-backdrop]');

    if (openButton) {
      openButton.addEventListener('click', function () {
        openPopup(shell);
      });
    }

    if (closeButton) {
      closeButton.addEventListener('click', function () {
        closePopup(shell);
      });
    }

    if (backdrop) {
      backdrop.addEventListener('click', function () {
        closePopup(shell);
      });
    }

    if (shell.getAttribute('data-open-on-load') === '1') {
      openPopup(shell);
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') {
      return;
    }

    qsa(document, '.feuer-kontaktform-popup-shell.is-open').forEach(closePopup);
  });
});
