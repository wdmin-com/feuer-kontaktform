(function (blocks, element, components, i18n, blockEditor) {
  var el = element.createElement;
  var InspectorControls = blockEditor.InspectorControls;
  var PanelBody = components.PanelBody;
  var SelectControl = components.SelectControl;
  var ToggleControl = components.ToggleControl;
  var forms = (window.FeuerKontaktformBlock && window.FeuerKontaktformBlock.forms) || [];

  blocks.registerBlockType('feuer-kontaktform/form', {
    title: 'Feuer-Kontaktform',
    icon: 'email-alt2',
    category: 'widgets',
    attributes: {
      formId: { type: 'number', default: 0 },
      slug: { type: 'string', default: '' },
      showAll: { type: 'boolean', default: false }
    },
    edit: function (props) {
      var options = [{ label: 'Alle Formulare', value: '0' }].concat(forms.map(function (form) {
        return {
          label: form.title + ' (' + form.slug + ')',
          value: String(form.id)
        };
      }));

      return el(
        element.Fragment,
        {},
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: 'Feuer-Kontaktform', initialOpen: true },
            el(ToggleControl, {
              label: 'Alle Formulare anzeigen',
              checked: !!props.attributes.showAll,
              onChange: function (value) {
                props.setAttributes({ showAll: !!value });
              }
            }),
            !props.attributes.showAll && el(SelectControl, {
              label: 'Formular',
              value: String(props.attributes.formId || 0),
              options: options,
              onChange: function (value) {
                var selected = forms.find(function (form) {
                  return String(form.id) === String(value);
                });
                props.setAttributes({
                  formId: parseInt(value, 10) || 0,
                  slug: selected ? selected.slug : ''
                });
              }
            })
          )
        ),
        el(
          'div',
          { className: 'components-placeholder' },
          el('strong', {}, 'Feuer-Kontaktform'),
          el(
            'p',
            {},
            props.attributes.showAll
              ? 'Block zeigt alle Formulare mit Umschalter an.'
              : 'Block zeigt Formular: ' + ((forms.find(function (form) {
                  return form.id === props.attributes.formId;
                }) || {}).title || 'nicht ausgewaehlt')
          )
        )
      );
    },
    save: function () {
      return null;
    }
  });
})(window.wp.blocks, window.wp.element, window.wp.components, window.wp.i18n, window.wp.blockEditor || window.wp.editor);

