document.addEventListener('DOMContentLoaded', function () {
  var builder = document.querySelector('.ka-field-builder');
  var rowsContainer = builder ? builder.querySelector('.ka-field-rows') : null;
  var layoutCanvas = builder ? builder.querySelector('[data-layout-canvas]') : null;
  var addButton = document.querySelector('.ka-add-field');
  var fieldTypeSelector = document.querySelector('.ka-new-field-type');
  var fieldTemplate = document.getElementById('ka-field-template');
  var defaults = (window.FeuerKontaktformAdmin && window.FeuerKontaktformAdmin.fieldDefaults) || {};
  var designVariants = (window.FeuerKontaktformAdmin && window.FeuerKontaktformAdmin.designVariants) || {};
  var designFallbacks = (window.FeuerKontaktformAdmin && window.FeuerKontaktformAdmin.designFallbacks) || {};
  var designPreviewShell = document.querySelector('[data-design-preview-shell]');
  var designPreview = document.querySelector('[data-design-preview]');
  var designLabel = document.querySelector('[data-design-label]');
  var designDescription = document.querySelector('[data-design-description]');
  var designPreviewAside = document.querySelector('[data-design-preview-aside]');
  var designPreviewPanel = document.querySelector('[data-design-preview-panel]');
  var designPreviewButton = document.querySelector('[data-design-preview-button]');
  var designPreviewTitle = document.querySelector('[data-design-preview-title]');
  var designPreviewInputs = document.querySelectorAll('[data-design-preview-input]');
  var designPreviewHeadings = document.querySelectorAll('[data-design-preview-heading]');
  var designPreviewKickers = document.querySelectorAll('[data-design-preview-kicker]');
  var livePreviewRoot = document.querySelector('[data-live-preview-root]');
  var livePreviewShell = document.querySelector('[data-live-preview-shell]');
  var livePreviewFrame = document.querySelector('[data-live-preview-frame]');
  var livePreviewIntro = document.querySelector('[data-live-preview-intro]');
  var livePreviewIntroKicker = document.querySelector('[data-live-preview-intro-kicker]');
  var livePreviewIntroTitle = document.querySelector('[data-live-preview-intro-title]');
  var livePreviewIntroCopy = document.querySelector('[data-live-preview-intro-copy]');
  var livePreviewAside = document.querySelector('[data-live-preview-aside]');
  var livePreviewAsideKicker = document.querySelector('[data-live-preview-aside-kicker]');
  var livePreviewAsideTitle = document.querySelector('[data-live-preview-aside-title]');
  var livePreviewAsideCopy = document.querySelector('[data-live-preview-aside-copy]');
  var livePreviewDepartmentLabel = document.querySelector('[data-live-preview-department-label]');
  var livePreviewDepartment = document.querySelector('[data-live-preview-department]');
  var livePreviewWebsiteRow = document.querySelector('[data-live-preview-website-row]');
  var livePreviewWebsiteLabel = document.querySelector('[data-live-preview-website-label]');
  var livePreviewWebsiteValue = document.querySelector('[data-live-preview-website-value]');
  var livePreviewPanel = document.querySelector('[data-live-preview-panel]');
  var livePreviewPanelLogo = document.querySelector('[data-live-preview-panel-logo]');
  var livePreviewPanelKicker = document.querySelector('[data-live-preview-panel-kicker]');
  var livePreviewPanelTitle = document.querySelector('[data-live-preview-panel-title]');
  var livePreviewPanelNote = document.querySelector('[data-live-preview-panel-note]');
  var livePreviewFields = document.querySelector('[data-live-preview-fields]');
  var livePreviewButton = document.querySelector('[data-live-preview-button]');
  var livePreviewLogo = document.querySelector('[data-live-preview-logo]');
  var widthLabels = {
    small: 'Klein',
    medium: 'Mittel',
    large: 'Breit',
    full: 'Voll'
  };
  var rowLabels = {
    small: 'Klein',
    medium: 'Mittel',
    large: 'Gross'
  };
  var uniqueId = 0;

  function nextIndex() {
    if (!builder) {
      return 0;
    }

    var current = parseInt(builder.getAttribute('data-next-index') || '0', 10);
    builder.setAttribute('data-next-index', String(current + 1));
    return current;
  }

  function nextBuilderId() {
    uniqueId += 1;
    return 'ka-field-' + Date.now() + '-' + uniqueId;
  }

  function buildFieldRowLocally(type) {
    var index;
    var html;
    var row;
    var typeSelect;

    if (!rowsContainer || !fieldTemplate) {
      return null;
    }

    index = nextIndex();
    html = fieldTemplate.innerHTML.replace(/__INDEX__/g, String(index));
    rowsContainer.insertAdjacentHTML('beforeend', html);
    row = rowsContainer.querySelector('.ka-field-row:last-child');

    if (!row) {
      return null;
    }

    row.dataset.builderId = nextBuilderId();
    typeSelect = row.querySelector('.ka-field-type');
    if (typeSelect) {
      typeSelect.value = type || 'text';
      updateFieldDefaults(typeSelect);
    }

    syncRowControlState(row);

    return row;
  }

  function ensureRowIds() {
    rowsContainer.querySelectorAll('.ka-field-row').forEach(function (row) {
      if (!row.dataset.builderId) {
        row.dataset.builderId = nextBuilderId();
      }
    });
  }

  function reindexRows() {
    rowsContainer.querySelectorAll('.ka-field-row').forEach(function (row, index) {
      row.querySelectorAll('[name]').forEach(function (input) {
        input.name = input.name.replace(/fields\[[^\]]+\]/, 'fields[' + index + ']');
      });
    });
  }

  function getFieldLabel(row) {
    var input = row.querySelector('.ka-field-label');
    return input && input.value.trim() !== '' ? input.value.trim() : 'Feld';
  }

  function getFieldType(row) {
    var select = row.querySelector('.ka-field-type');
    return select ? select.value : 'text';
  }

  function getFieldTypeLabel(row) {
    var select = row.querySelector('.ka-field-type');

    if (!select) {
      return 'Textfeld';
    }

    var option = select.options[select.selectedIndex];
    return option ? option.text : 'Textfeld';
  }

  function getFieldWidth(row) {
    var select = row.querySelector('.ka-field-width');
    return select ? select.value : 'medium';
  }

  function getTextareaSize(row) {
    var select = row.querySelector('.ka-field-rowsize');
    return select ? select.value : 'medium';
  }

  function getFieldPlaceholder(row) {
    var input = row.querySelector('.ka-field-placeholder-input');
    return input ? input.value.trim() : '';
  }

  function getFormTitleValue() {
    var formTitleInput = document.getElementById('ka_title');
    return formTitleInput && formTitleInput.value.trim() !== '' ? formTitleInput.value.trim() : 'Abteilung';
  }

  function getDisplayControl(name) {
    return document.querySelector('[name="display_settings[' + name + ']"]');
  }

  function getDisplayValue(name) {
    var input = getDisplayControl(name);
    return input ? input.value.trim() : '';
  }

  function getPreviewWebsiteText() {
    var customText = getDisplayValue('website_text');
    var customUrl = getDisplayValue('website_url');
    var fallbackText = livePreviewRoot ? (livePreviewRoot.dataset.brandWebsiteText || '') : '';

    if (customText !== '') {
      return customText;
    }

    if (customUrl !== '') {
      try {
        return new window.URL(customUrl).host.replace(/^www\./, '');
      } catch (error) {
        return customUrl;
      }
    }

    return fallbackText;
  }

  function setHidden(element, hidden) {
    if (!element) {
      return;
    }

    element.hidden = hidden;
    element.classList.toggle('is-hidden', hidden);
  }

  function getPreviewVariantValue() {
    var checked = document.querySelector('.ka-design-card input[type="radio"]:checked');
    return checked ? checked.value : 'design-1';
  }

  function getPreviewVariantState(variant, formTitle) {
    var brandLabel = livePreviewRoot ? (livePreviewRoot.dataset.brandLabel || 'Feuer-Kontaktform') : 'Feuer-Kontaktform';
    var brandTagline = livePreviewRoot
      ? (livePreviewRoot.dataset.brandTagline || 'Bitte schildern Sie Ihr Anliegen so konkret wie moeglich.')
      : 'Bitte schildern Sie Ihr Anliegen so konkret wie moeglich.';
    var description = designVariants[variant] && designVariants[variant].description ? designVariants[variant].description : brandTagline;
    var hasLogo = !!(livePreviewLogo && livePreviewLogo.getAttribute('src'));

    var introCopy = getDisplayValue('intro_copy');
    var asideCopy = getDisplayValue('aside_copy');

    return {
      showIntro: ['design-1', 'design-2', 'design-6', 'design-7', 'design-10'].indexOf(variant) !== -1,
      showAside: ['design-1', 'design-7'].indexOf(variant) === -1,
      showPanelLogo: hasLogo && ['design-1', 'design-5', 'design-7', 'design-10'].indexOf(variant) !== -1,
      introKicker: ({
        'design-2': 'Kontakt',
        'design-6': 'Servicebereich',
        'design-10': 'Unternehmenskontakt'
      }[variant]) || brandLabel,
      introTitle: ({
        'design-2': 'Nehmen Sie Kontakt mit uns auf',
        'design-6': 'Direkte Anfrage an die zustaendige Stelle',
        'design-7': 'Kurzes Kontaktformular',
        'design-10': 'Verbindliche Kontaktaufnahme'
      }[variant]) || formTitle,
      introCopy: introCopy || ({
        'design-2': 'Nutzen Sie das Formular fuer eine direkte Rueckmeldung. Ihre Anfrage wird intern an die richtige Abteilung weitergeleitet.',
        'design-6': 'Bitte senden Sie Ihre Nachricht ueber das folgende Formular. Wir bearbeiten Ihr Anliegen schnell und strukturiert.',
        'design-10': 'Diese Vorschau zeigt eine sachliche Unternehmensform mit klarer Informationshierarchie.'
      }[variant]) || brandTagline,
      asideKicker: ({
        'design-5': 'Kontakt',
        'design-6': 'Kontaktkanal',
        'design-9': 'Information'
      }[variant]) || 'Service',
      asideTitle: ({
        'design-2': 'Kontaktinformationen',
        'design-3': 'Direkter Servicekontakt',
        'design-4': 'Persoenliche Rueckmeldung',
        'design-5': brandLabel,
        'design-6': 'Servicehinweise',
        'design-8': 'Kontaktstelle',
        'design-9': 'Rueckfragen und Hinweise',
        'design-10': 'Unternehmensservice'
      }[variant]) || 'Direkter Kontakt',
      asideCopy: asideCopy || ({
        'design-2': 'Alle Informationen auf einen Blick. Social-Media-Elemente wurden bewusst entfernt.',
        'design-3': 'Die Gestaltung trennt Information und Formular klar in zwei Bereiche.',
        'design-4': 'Reduziertes Zwei-Spalten-Layout mit Formular links und Textspalte rechts.',
        'design-5': brandTagline,
        'design-6': 'Oben eine sachliche Hinweiszone, darunter das eigentliche Kontaktformular.',
        'design-8': 'Schmale Infospalte links, kompaktes Formular rechts.',
        'design-9': 'Geradlinige Form mit deutlichem Rahmen und nuechterner Aufteilung.',
        'design-10': 'Kompakte Corporate-Darstellung ohne dekorative Zusatzelemente.'
      }[variant]) || description,
      panelTitle: formTitle,
      panelNote: 'Bitte fuellen Sie alle benoetigten Angaben aus. Pflichtfelder sind mit einem Stern markiert.'
    };
  }

  function isFieldRequired(row) {
    var checkbox = row.querySelector('.ka-field-required input[type="checkbox"]');
    return !!checkbox && checkbox.checked;
  }

  function isTextareaType(row) {
    var type = getFieldType(row);
    return type === 'nachricht' || type === 'textarea';
  }

  function syncRowControlState(row) {
    var rowsInput = row.querySelector('.ka-field-rowsize');
    var optionsInput = row.querySelector('.ka-field-options-input');
    var type = getFieldType(row);

    if (!rowsInput) {
      return;
    }

    rowsInput.disabled = !isTextareaType(row);
    if (optionsInput) {
      optionsInput.disabled = !(type === 'select' || type === 'radio');
    }
  }

  function createChip(label, value, currentValue, className, dataName) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'ka-layout-chip ' + className + (value === currentValue ? ' is-active' : '');
    button.dataset[dataName] = value;
    button.textContent = label;
    return button;
  }

  function buildPreviewCard(row) {
    var card = document.createElement('article');
    var top = document.createElement('div');
    var handle = document.createElement('button');
    var copy = document.createElement('div');
    var title = document.createElement('strong');
    var meta = document.createElement('span');
    var preview = document.createElement('div');
    var previewLine = document.createElement('div');
    var sizeTools = document.createElement('div');
    var widthGroup = document.createElement('div');
    var widthLabel = document.createElement('span');
    var actions = document.createElement('div');
    var editButton = document.createElement('button');
    var removeButton = document.createElement('button');
    var currentWidth = getFieldWidth(row);
    var currentRows = getTextareaSize(row);
    var textareaType = isTextareaType(row);

    card.className = 'ka-layout-card' + (currentWidth === 'full' ? ' is-full' : '');
    card.dataset.builderId = row.dataset.builderId;

    top.className = 'ka-layout-card-top';

    handle.className = 'ka-layout-handle';
    handle.type = 'button';
    handle.setAttribute('aria-label', 'Block verschieben');
    handle.innerHTML = '&#8597;';

    copy.className = 'ka-layout-card-copy';

    title.textContent = getFieldLabel(row) + (isFieldRequired(row) ? ' *' : '');
    meta.textContent = getFieldTypeLabel(row) + ' - ' + (widthLabels[currentWidth] || 'Mittel');
    if (textareaType) {
      meta.textContent += ' - ' + (rowLabels[currentRows] || 'Mittel');
    }

    preview.className = 'ka-layout-card-preview';
    previewLine.className = 'ka-layout-card-preview-line';
    if (currentWidth === 'small') {
      previewLine.classList.add('is-small');
    }
    if (currentWidth === 'large') {
      previewLine.classList.add('is-wide');
    }
    if (currentWidth === 'full') {
      previewLine.classList.add('is-full');
    }
    if (textareaType) {
      previewLine.classList.add('is-large');
      if (currentRows === 'small') {
        previewLine.classList.remove('is-large');
      }
      if (currentRows === 'large') {
        previewLine.classList.add('is-tall');
      }
    }

    sizeTools.className = 'ka-layout-size-tools';

    widthGroup.className = 'ka-layout-chip-group';
    widthLabel.className = 'ka-layout-chip-label';
    widthLabel.textContent = 'Breite';
    widthGroup.appendChild(widthLabel);
    widthGroup.appendChild(createChip('K', 'small', currentWidth, 'ka-layout-width-chip', 'widthValue'));
    widthGroup.appendChild(createChip('M', 'medium', currentWidth, 'ka-layout-width-chip', 'widthValue'));
    widthGroup.appendChild(createChip('B', 'large', currentWidth, 'ka-layout-width-chip', 'widthValue'));
    widthGroup.appendChild(createChip('V', 'full', currentWidth, 'ka-layout-width-chip', 'widthValue'));
    sizeTools.appendChild(widthGroup);

    if (textareaType) {
      var heightGroup = document.createElement('div');
      var heightLabel = document.createElement('span');

      heightGroup.className = 'ka-layout-chip-group';
      heightLabel.className = 'ka-layout-chip-label';
      heightLabel.textContent = 'Hoehe';
      heightGroup.appendChild(heightLabel);
      heightGroup.appendChild(createChip('S', 'small', currentRows, 'ka-layout-rows-chip', 'rowsValue'));
      heightGroup.appendChild(createChip('M', 'medium', currentRows, 'ka-layout-rows-chip', 'rowsValue'));
      heightGroup.appendChild(createChip('L', 'large', currentRows, 'ka-layout-rows-chip', 'rowsValue'));
      sizeTools.appendChild(heightGroup);
    }

    actions.className = 'ka-layout-card-actions';

    editButton.className = 'button button-secondary button-small ka-layout-edit';
    editButton.type = 'button';
    editButton.textContent = 'Bearbeiten';

    removeButton.className = 'button-link-delete ka-layout-remove';
    removeButton.type = 'button';
    removeButton.textContent = 'Entfernen';

    preview.appendChild(previewLine);
    copy.appendChild(title);
    copy.appendChild(meta);
    top.appendChild(handle);
    top.appendChild(copy);
    actions.appendChild(editButton);
    actions.appendChild(removeButton);
    card.appendChild(top);
    card.appendChild(preview);
    card.appendChild(sizeTools);
    card.appendChild(actions);

    return card;
  }

  function buildLivePreviewField(row) {
    var field = document.createElement('div');
    var label = document.createElement('label');
    var control = document.createElement('div');
    var placeholder = document.createElement('span');
    var width = getFieldWidth(row);
    var rows = getTextareaSize(row);
    var text = getFieldPlaceholder(row) || getFieldLabel(row);

    field.className = 'ka-live-preview-field is-width-' + width;

    label.className = 'ka-live-preview-field-label';
    label.textContent = getFieldLabel(row) + (isFieldRequired(row) ? ' *' : '');

    control.className = 'ka-live-preview-control';
    if (isTextareaType(row)) {
      control.classList.add('is-textarea', 'is-rows-' + rows);
    }

    placeholder.textContent = text !== '' ? text : 'Eingabe';

    control.appendChild(placeholder);
    field.appendChild(label);
    field.appendChild(control);

    return field;
  }

  function renderLivePreviewFields() {
    var rows;

    if (!livePreviewFields || !rowsContainer) {
      return;
    }

    livePreviewFields.innerHTML = '';
    rows = rowsContainer.querySelectorAll('.ka-field-row');

    if (!rows.length) {
      var empty = document.createElement('div');
      empty.className = 'ka-layout-empty';
      empty.textContent = 'Noch keine Felder vorhanden.';
      livePreviewFields.appendChild(empty);
      return;
    }

    rows.forEach(function (row) {
      livePreviewFields.appendChild(buildLivePreviewField(row));
    });
  }

  function renderLayoutCanvas() {
    if (!layoutCanvas) {
      return;
    }

    ensureRowIds();
    layoutCanvas.innerHTML = '';

    var rows = rowsContainer.querySelectorAll('.ka-field-row');

    if (rows.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ka-layout-empty';
      empty.textContent = 'Noch keine Felder vorhanden. Fuegen Sie ein Feld hinzu und ordnen Sie es dann hier visuell an.';
      layoutCanvas.appendChild(empty);
      return;
    }

    rows.forEach(function (row) {
      layoutCanvas.appendChild(buildPreviewCard(row));
    });
  }

  function syncRowsFromCanvas() {
    if (!layoutCanvas) {
      return;
    }

    var fragment = document.createDocumentFragment();

    layoutCanvas.querySelectorAll('.ka-layout-card').forEach(function (card) {
      var row = rowsContainer.querySelector('.ka-field-row[data-builder-id="' + card.dataset.builderId + '"]');

      if (row) {
        fragment.appendChild(row);
      }
    });

    rowsContainer.appendChild(fragment);
    reindexRows();
    renderLayoutCanvas();
    renderLivePreviewFields();
  }

  function syncBuilderState() {
    ensureRowIds();
    rowsContainer.querySelectorAll('.ka-field-row').forEach(syncRowControlState);
    reindexRows();
    renderLayoutCanvas();
    renderLivePreviewFields();
  }

  function updateFieldDefaults(select) {
    var row = select.closest('.ka-field-row');

    if (!row) {
      return;
    }

    var config = defaults[select.value];

    if (!config) {
      return;
    }

    var labelInput = row.querySelector('.ka-field-label');
    var keyInput = row.querySelector('.ka-field-key');
    var placeholderInput = row.querySelector('input[name*="[placeholder]"]');
    var requiredInput = row.querySelector('.ka-field-required input[type="checkbox"]');
    var widthInput = row.querySelector('.ka-field-width');
    var rowsInput = row.querySelector('.ka-field-rowsize');
    var optionsInput = row.querySelector('.ka-field-options-input');

    if (labelInput && labelInput.value.trim() === '') {
      labelInput.value = config.label || '';
    }

    if (keyInput && keyInput.value.trim() === '') {
      keyInput.value = config.key || '';
    }

    if (placeholderInput && placeholderInput.value.trim() === '') {
      placeholderInput.value = config.placeholder || '';
    }

    if (widthInput) {
      widthInput.value = config.width || 'medium';
    }

    if (rowsInput) {
      rowsInput.value = config.rows || 'medium';
    }

    if (optionsInput && optionsInput.value.trim() === '' && Array.isArray(config.options)) {
      optionsInput.value = config.options.join('\n');
    }

    if (requiredInput && (select.value === 'email' || select.value === 'nachricht' || select.value === 'textarea')) {
      requiredInput.checked = true;
    }
  }

  function syncDesignPreview() {
    var checked = document.querySelector('.ka-design-card input[type="radio"]:checked');
    var previewClassPrefix = 'ka-preview-';

    document.querySelectorAll('.ka-design-card').forEach(function (card) {
      var radio = card.querySelector('input[type="radio"]');
      card.classList.toggle('is-selected', !!radio && radio.checked);
    });

    if (!checked) {
      return;
    }

    [designPreviewShell, designPreview, livePreviewShell, livePreviewFrame].forEach(function (element) {
      if (!element) {
        return;
      }

      Array.from(element.classList).forEach(function (className) {
        if (className.indexOf(previewClassPrefix) === 0) {
          element.classList.remove(className);
        }
      });

      element.classList.add(previewClassPrefix + checked.value);
    });

    if (designLabel && designVariants[checked.value]) {
      designLabel.textContent = designVariants[checked.value].label || '';
    }

    if (designDescription && designVariants[checked.value]) {
      designDescription.textContent = designVariants[checked.value].description || '';
    }

    applyDesignPreviewStyles();
    syncLivePreviewMeta();
    applyLivePreviewStyles();
  }

  function syncLivePreviewMeta() {
    var variant;
    var title;
    var state;
    var departmentLabel;
    var websiteLabel;
    var websiteText;
    var fallbackWebsiteText;

    if (!livePreviewRoot) {
      return;
    }

    variant = getPreviewVariantValue();
    title = getFormTitleValue();
    state = getPreviewVariantState(variant, title);
    departmentLabel = getDisplayValue('department_label') || 'Abteilung';
    websiteLabel = getDisplayValue('website_label') || 'Website';
    fallbackWebsiteText = livePreviewRoot.dataset.brandWebsiteText || '';
    websiteText = getPreviewWebsiteText() || fallbackWebsiteText;

    setHidden(livePreviewIntro, !state.showIntro);
    setHidden(livePreviewAside, !state.showAside);
    setHidden(livePreviewPanelLogo, !state.showPanelLogo);

    if (livePreviewIntroKicker) {
      livePreviewIntroKicker.textContent = state.introKicker;
    }

    if (livePreviewIntroTitle) {
      livePreviewIntroTitle.textContent = state.introTitle;
    }

    if (livePreviewIntroCopy) {
      livePreviewIntroCopy.textContent = state.introCopy;
    }

    if (livePreviewAsideTitle) {
      livePreviewAsideTitle.textContent = state.asideTitle;
    }

    if (livePreviewAsideKicker) {
      livePreviewAsideKicker.textContent = state.asideKicker;
    }

    if (livePreviewAsideCopy) {
      livePreviewAsideCopy.textContent = state.asideCopy;
    }

    if (livePreviewDepartmentLabel) {
      livePreviewDepartmentLabel.textContent = departmentLabel;
    }

    if (livePreviewDepartment) {
      livePreviewDepartment.textContent = title;
    }

    setHidden(livePreviewWebsiteRow, websiteText === '');
    if (livePreviewWebsiteLabel) {
      livePreviewWebsiteLabel.textContent = websiteLabel;
    }
    if (livePreviewWebsiteValue) {
      livePreviewWebsiteValue.textContent = websiteText;
    }

    if (livePreviewPanelTitle) {
      livePreviewPanelTitle.textContent = state.panelTitle;
    }

    if (livePreviewPanelKicker) {
      livePreviewPanelKicker.textContent = 'Kontaktformular';
    }

    if (livePreviewPanelNote) {
      livePreviewPanelNote.textContent = state.panelNote;
    }

    if (livePreviewLogo) {
      setHidden(livePreviewLogo, !livePreviewLogo.getAttribute('src'));
    }
  }

  function getDesignControl(name) {
    return document.querySelector('[name="design_settings[' + name + ']"]');
  }

  function getDesignValue(name) {
    var input = getDesignControl(name);
    return input ? input.value.trim() : '';
  }

  function isHexColor(value) {
    return /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value);
  }

  function hexToRgba(hex, alpha) {
    if (!isHexColor(hex)) {
      return 'rgba(0, 0, 0, ' + alpha + ')';
    }

    var normalized = hex.slice(1);
    if (normalized.length === 3) {
      normalized = normalized.split('').map(function (char) {
        return char + char;
      }).join('');
    }

    var red = parseInt(normalized.slice(0, 2), 16);
    var green = parseInt(normalized.slice(2, 4), 16);
    var blue = parseInt(normalized.slice(4, 6), 16);

    return 'rgba(' + red + ', ' + green + ', ' + blue + ', ' + alpha + ')';
  }

  function isLocalAssetUrl(url) {
    var normalizedHost;
    var currentHost;

    if (!url) {
      return false;
    }

    if (/^\//.test(url)) {
      return true;
    }

    try {
      normalizedHost = new window.URL(url, window.location.origin).host.replace(/^www\./, '').toLowerCase();
      currentHost = window.location.host.replace(/^www\./, '').toLowerCase();
      return normalizedHost === currentHost;
    } catch (error) {
      return false;
    }
  }

  function setPreviewAreaImage(element, url) {
    if (!element) {
      return;
    }

    if (url !== '' && isLocalAssetUrl(url)) {
      element.style.backgroundImage = 'url("' + url.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '")';
      element.style.backgroundPosition = 'center';
      element.style.backgroundRepeat = 'no-repeat';
      element.style.backgroundSize = 'cover';
      return;
    }

    element.style.backgroundImage = '';
    element.style.backgroundPosition = '';
    element.style.backgroundRepeat = '';
    element.style.backgroundSize = '';
  }

  function clearPreviewOverrides() {
    if (designPreviewShell) {
      designPreviewShell.style.background = '';
    }

    if (designPreview) {
      designPreview.style.background = '';
    }

    if (designPreviewAside) {
      designPreviewAside.style.background = '';
      designPreviewAside.style.backgroundColor = '';
      designPreviewAside.style.color = '';
      designPreviewAside.style.removeProperty('--ka-preview-overlay-color');
      designPreviewAside.style.removeProperty('--ka-preview-overlay-opacity');
      setPreviewAreaImage(designPreviewAside, '');
    }

    if (designPreviewPanel) {
      designPreviewPanel.style.background = '';
      designPreviewPanel.style.backgroundColor = '';
      designPreviewPanel.style.color = '';
      setPreviewAreaImage(designPreviewPanel, '');
    }

    if (designPreviewButton) {
      designPreviewButton.style.background = '';
      designPreviewButton.style.color = '';
      designPreviewButton.style.boxShadow = '';
    }

    designPreviewHeadings.forEach(function (heading) {
      heading.style.color = '';
    });

    designPreviewKickers.forEach(function (kicker) {
      kicker.style.color = '';
    });

    designPreviewInputs.forEach(function (input) {
      input.style.background = '';
      input.style.borderColor = '';
      input.style.color = '';
    });
  }

  function clearLivePreviewStyles() {
    var variables = [
      '--ka-live-shell-bg',
      '--ka-live-panel-bg',
      '--ka-live-panel-text',
      '--ka-live-panel-muted',
      '--ka-live-aside-bg',
      '--ka-live-aside-text',
      '--ka-live-aside-muted',
      '--ka-live-title-color',
      '--ka-live-kicker-color',
      '--ka-live-button-bg',
      '--ka-live-button-text',
      '--ka-live-input-bg',
      '--ka-live-input-text',
      '--ka-live-input-placeholder',
      '--ka-live-input-border',
      '--ka-live-overlay-color',
      '--ka-live-overlay-opacity'
    ];

    if (!livePreviewRoot) {
      return;
    }

    variables.forEach(function (name) {
      livePreviewRoot.style.removeProperty(name);
    });

    setPreviewAreaImage(livePreviewAside, '');
    setPreviewAreaImage(livePreviewPanel, '');
  }

  function applyDesignPreviewStyles() {
    var imageUrl = getDesignValue('background_image_url');
    var imageTarget = getDesignValue('background_image_target') || 'aside';
    var overlayOpacity = parseInt(getDesignValue('overlay_opacity') || String(designFallbacks.overlay_opacity || 72), 10);
    var shellBackground = getDesignValue('shell_background_color');
    var panelBackground = getDesignValue('panel_background_color');
    var panelText = getDesignValue('panel_text_color');
    var titleColor = getDesignValue('title_color');
    var asideBackground = getDesignValue('aside_background_color');
    var asideText = getDesignValue('aside_text_color');
    var accentColor = getDesignValue('accent_color');
    var buttonBackground = getDesignValue('button_background_color');
    var buttonText = getDesignValue('button_text_color');
    var inputBackground = getDesignValue('input_background_color');
    var inputText = getDesignValue('input_text_color');
    var inputBorder = getDesignValue('input_border_color');
    var overlayColor = getDesignValue('overlay_color');

    clearPreviewOverrides();

    if (designPreviewTitle) {
      designPreviewTitle.textContent = getFormTitleValue();
    }

    if (designPreviewShell && shellBackground !== '') {
      designPreviewShell.style.background = shellBackground;
    }

    if (designPreviewPanel && panelBackground !== '') {
      designPreviewPanel.style.background = panelBackground;
    }

    if (designPreviewPanel && panelText !== '') {
      designPreviewPanel.style.color = panelText;
    }

    if (designPreviewAside && asideBackground !== '') {
      designPreviewAside.style.background = asideBackground;
    }

    if (designPreviewAside && asideText !== '') {
      designPreviewAside.style.color = asideText;
    }

    if (titleColor !== '') {
      designPreviewHeadings.forEach(function (heading) {
        heading.style.color = titleColor;
      });
    }

    if (accentColor !== '') {
      designPreviewKickers.forEach(function (kicker) {
        kicker.style.color = accentColor;
      });
    }

    if (designPreviewAside && overlayColor !== '') {
      designPreviewAside.style.setProperty('--ka-preview-overlay-color', overlayColor);
      designPreviewAside.style.setProperty('--ka-preview-overlay-opacity', String(Math.max(0, Math.min(100, overlayOpacity)) / 100));
    } else if (
      designPreviewAside &&
      (asideBackground !== '' || (imageUrl !== '' && (imageTarget === 'aside' || imageTarget === 'both')))
    ) {
      designPreviewAside.style.setProperty('--ka-preview-overlay-color', 'transparent');
      designPreviewAside.style.setProperty('--ka-preview-overlay-opacity', '0');
    }

    if (designPreviewButton && buttonBackground !== '') {
      designPreviewButton.style.background = buttonBackground;
      designPreviewButton.style.boxShadow = '0 12px 28px ' + hexToRgba(buttonBackground, 0.24);
    }

    if (designPreviewButton && buttonText !== '') {
      designPreviewButton.style.color = buttonText;
    }

    designPreviewInputs.forEach(function (input) {
      if (inputBackground !== '') {
        input.style.background = inputBackground;
      }

      if (inputBorder !== '') {
        input.style.borderColor = inputBorder;
      }

      if (inputText !== '') {
        input.style.color = inputText;
      }
    });

    if (imageUrl !== '') {
      if (imageTarget === 'aside' || imageTarget === 'both') {
        setPreviewAreaImage(designPreviewAside, imageUrl);
      }

      if (imageTarget === 'panel' || imageTarget === 'both') {
        setPreviewAreaImage(designPreviewPanel, imageUrl);
      }
    }
  }

  function applyLivePreviewStyles() {
    var imageUrl = getDesignValue('background_image_url');
    var imageTarget = getDesignValue('background_image_target') || 'aside';
    var overlayOpacity = parseInt(getDesignValue('overlay_opacity') || String(designFallbacks.overlay_opacity || 72), 10);
    var shellBackground = getDesignValue('shell_background_color');
    var panelBackground = getDesignValue('panel_background_color');
    var panelText = getDesignValue('panel_text_color');
    var titleColor = getDesignValue('title_color');
    var asideBackground = getDesignValue('aside_background_color');
    var asideText = getDesignValue('aside_text_color');
    var accentColor = getDesignValue('accent_color');
    var buttonBackground = getDesignValue('button_background_color');
    var buttonText = getDesignValue('button_text_color');
    var inputBackground = getDesignValue('input_background_color');
    var inputText = getDesignValue('input_text_color');
    var inputBorder = getDesignValue('input_border_color');
    var overlayColor = getDesignValue('overlay_color');

    clearLivePreviewStyles();

    if (!livePreviewRoot) {
      return;
    }

    if (shellBackground !== '') {
      livePreviewRoot.style.setProperty('--ka-live-shell-bg', shellBackground);
    }

    if (panelBackground !== '') {
      livePreviewRoot.style.setProperty('--ka-live-panel-bg', panelBackground);
    }

    if (panelText !== '') {
      livePreviewRoot.style.setProperty('--ka-live-panel-text', panelText);
      livePreviewRoot.style.setProperty('--ka-live-panel-muted', hexToRgba(panelText, 0.72));
    }

    if (titleColor !== '') {
      livePreviewRoot.style.setProperty('--ka-live-title-color', titleColor);
    }

    if (asideBackground !== '') {
      livePreviewRoot.style.setProperty('--ka-live-aside-bg', asideBackground);
    }

    if (asideText !== '') {
      livePreviewRoot.style.setProperty('--ka-live-aside-text', asideText);
      livePreviewRoot.style.setProperty('--ka-live-aside-muted', hexToRgba(asideText, 0.72));
    }

    if (accentColor !== '') {
      livePreviewRoot.style.setProperty('--ka-live-kicker-color', accentColor);
    }

    if (buttonBackground !== '') {
      livePreviewRoot.style.setProperty('--ka-live-button-bg', buttonBackground);
    }

    if (buttonText !== '') {
      livePreviewRoot.style.setProperty('--ka-live-button-text', buttonText);
    }

    if (inputBackground !== '') {
      livePreviewRoot.style.setProperty('--ka-live-input-bg', inputBackground);
    }

    if (inputText !== '') {
      livePreviewRoot.style.setProperty('--ka-live-input-text', inputText);
      livePreviewRoot.style.setProperty('--ka-live-input-placeholder', hexToRgba(inputText, 0.62));
    }

    if (inputBorder !== '') {
      livePreviewRoot.style.setProperty('--ka-live-input-border', inputBorder);
    }

    if (overlayColor !== '') {
      livePreviewRoot.style.setProperty('--ka-live-overlay-color', overlayColor);
      livePreviewRoot.style.setProperty('--ka-live-overlay-opacity', String(Math.max(0, Math.min(100, overlayOpacity)) / 100));
    } else if (
      asideBackground !== '' ||
      (imageUrl !== '' && (imageTarget === 'aside' || imageTarget === 'both'))
    ) {
      livePreviewRoot.style.setProperty('--ka-live-overlay-color', 'transparent');
      livePreviewRoot.style.setProperty('--ka-live-overlay-opacity', '0');
    }

    if (imageUrl !== '') {
      if (imageTarget === 'aside' || imageTarget === 'both') {
        setPreviewAreaImage(livePreviewAside, imageUrl);
      }

      if (imageTarget === 'panel' || imageTarget === 'both') {
        setPreviewAreaImage(livePreviewPanel, imageUrl);
      }
    }
  }

  function syncColorSwatchFromField(field) {
    var swatch;
    var value;
    var fallback;

    if (!field || !field.id) {
      return;
    }

    swatch = document.querySelector('.ka-color-swatch[data-color-target="' + field.id + '"]');
    if (!swatch) {
      return;
    }

    value = field.value.trim();
    fallback = field.dataset.defaultColor || swatch.value;
    swatch.value = isHexColor(value) ? value : fallback;
  }

  function resetDesignCustomizer() {
    document.querySelectorAll('.ka-color-value').forEach(function (field) {
      field.value = '';
      syncColorSwatchFromField(field);
    });

    document.querySelectorAll('.ka-design-control[type="url"]').forEach(function (field) {
      field.value = '';
    });

    var opacityField = getDesignControl('overlay_opacity');
    if (opacityField) {
      opacityField.value = String(designFallbacks.overlay_opacity || 72);
    }

    var targetField = getDesignControl('background_image_target');
    if (targetField) {
      targetField.value = 'aside';
    }

    syncDesignPreview();
  }

  function focusRow(builderId) {
    var row = rowsContainer.querySelector('.ka-field-row[data-builder-id="' + builderId + '"]');

    if (!row) {
      return;
    }

    row.classList.add('is-focused');
    row.scrollIntoView({ behavior: 'smooth', block: 'center' });

    window.setTimeout(function () {
      row.classList.remove('is-focused');
    }, 1400);
  }

  function setRowOption(builderId, selector, value) {
    var row = rowsContainer.querySelector('.ka-field-row[data-builder-id="' + builderId + '"]');

    if (!row) {
      return;
    }

    var input = row.querySelector(selector);
    if (!input) {
      return;
    }

    input.value = value;
    syncBuilderState();
  }

  function getDragAfterElement(container, itemSelector, clientY, draggedItem) {
    var items = Array.from(container.querySelectorAll(itemSelector)).filter(function (item) {
      return item !== draggedItem;
    });
    var closest = {
      offset: Number.NEGATIVE_INFINITY,
      element: null
    };

    items.forEach(function (item) {
      var box = item.getBoundingClientRect();
      var offset = clientY - box.top - (box.height / 2);

      if (offset < 0 && offset > closest.offset) {
        closest = {
          offset: offset,
          element: item
        };
      }
    });

    return closest.element;
  }

  function enableLocalSorting(container, itemSelector, handleSelector, updateCallback) {
    var draggedItem = null;

    if (!container) {
      return;
    }

    container.addEventListener('mousedown', function (event) {
      var handle = event.target.closest(handleSelector);
      var item = handle ? handle.closest(itemSelector) : null;

      if (!handle || !item || !container.contains(item)) {
        return;
      }

      item.dataset.dragHandleActive = '1';
      item.setAttribute('draggable', 'true');
    });

    container.addEventListener('dragstart', function (event) {
      var item = event.target.closest(itemSelector);

      if (!item || item.dataset.dragHandleActive !== '1') {
        event.preventDefault();
        return;
      }

      draggedItem = item;
      item.classList.add('is-dragging');

      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', item.dataset.builderId || item.textContent || 'item');
      }
    });

    container.addEventListener('dragover', function (event) {
      var afterElement;

      if (!draggedItem) {
        return;
      }

      event.preventDefault();
      afterElement = getDragAfterElement(container, itemSelector, event.clientY, draggedItem);

      if (afterElement) {
        container.insertBefore(draggedItem, afterElement);
        return;
      }

      container.appendChild(draggedItem);
    });

    container.addEventListener('drop', function (event) {
      if (draggedItem) {
        event.preventDefault();
      }
    });

    container.addEventListener('dragend', function (event) {
      var item = event.target.closest(itemSelector);

      if (!item) {
        return;
      }

      item.classList.remove('is-dragging');
      item.removeAttribute('draggable');
      delete item.dataset.dragHandleActive;
      draggedItem = null;
      updateCallback();
    });

    document.addEventListener('mouseup', function () {
      container.querySelectorAll(itemSelector + '[draggable="true"]').forEach(function (item) {
        if (!item.classList.contains('is-dragging')) {
          item.removeAttribute('draggable');
          delete item.dataset.dragHandleActive;
        }
      });
    });
  }

  enableLocalSorting(rowsContainer, '.ka-field-row', '.ka-drag-handle', syncBuilderState);
  enableLocalSorting(layoutCanvas, '.ka-layout-card', '.ka-layout-card-top', syncRowsFromCanvas);

  if (addButton && rowsContainer) {
    addButton.addEventListener('click', function () {
      addButton.disabled = true;
      addButton.classList.add('is-loading');
      try {
        var newRow = buildFieldRowLocally(fieldTypeSelector ? fieldTypeSelector.value : 'text');

        syncBuilderState();

        if (newRow) {
          var lastRow = newRow.querySelector('.ka-field-label');

          if (lastRow) {
            lastRow.focus();
          }
        }
      } finally {
        addButton.disabled = false;
        addButton.classList.remove('is-loading');
      }
    });
  }

  document.addEventListener('click', function (event) {
    if (event.target.classList.contains('ka-remove-field')) {
      var row = event.target.closest('.ka-field-row');

      if (row) {
        row.remove();
        syncBuilderState();
      }

      return;
    }

    if (event.target.classList.contains('ka-layout-edit')) {
      var editCard = event.target.closest('.ka-layout-card');

      if (editCard) {
        focusRow(editCard.dataset.builderId);
      }

      return;
    }

    if (event.target.classList.contains('ka-layout-remove')) {
      var removeCard = event.target.closest('.ka-layout-card');

      if (removeCard) {
        var targetRow = rowsContainer.querySelector('.ka-field-row[data-builder-id="' + removeCard.dataset.builderId + '"]');

        if (targetRow) {
          targetRow.remove();
          syncBuilderState();
        }
      }

      return;
    }

    if (event.target.classList.contains('ka-layout-width-chip')) {
      var widthCard = event.target.closest('.ka-layout-card');

      if (widthCard) {
        setRowOption(widthCard.dataset.builderId, '.ka-field-width', event.target.dataset.widthValue);
      }

      return;
    }

    if (event.target.classList.contains('ka-layout-rows-chip')) {
      var rowsCard = event.target.closest('.ka-layout-card');

      if (rowsCard) {
        setRowOption(rowsCard.dataset.builderId, '.ka-field-rowsize', event.target.dataset.rowsValue);
      }

      return;
    }

    if (event.target.classList.contains('ka-media-pick')) {
      var mediaContainer = event.target.closest('.ka-media-control');
      var mediaInput = mediaContainer ? mediaContainer.querySelector('input[type="url"]') : null;

      if (!mediaInput || !window.wp || !window.wp.media) {
        return;
      }

      var frame = window.wp.media({
        title: 'Bild auswaehlen',
        button: {
          text: 'Dieses Bild verwenden'
        },
        multiple: false
      });

      frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        mediaInput.value = attachment && attachment.url ? attachment.url : '';
        syncDesignPreview();
      });

      frame.open();

      return;
    }

    if (event.target.classList.contains('ka-media-clear')) {
      var clearContainer = event.target.closest('.ka-media-control');
      var clearInput = clearContainer ? clearContainer.querySelector('input[type="url"]') : null;

      if (clearInput) {
        clearInput.value = '';
        syncDesignPreview();
      }

      return;
    }

    if (event.target.hasAttribute('data-design-reset')) {
      resetDesignCustomizer();
    }
  });

  document.addEventListener('change', function (event) {
    if (event.target.classList.contains('ka-field-type')) {
      updateFieldDefaults(event.target);
      syncBuilderState();
    }

    if (event.target.classList.contains('ka-field-width') || event.target.classList.contains('ka-field-rowsize')) {
      syncBuilderState();
    }

    if (event.target.matches('.ka-design-card input[type="radio"]')) {
      syncDesignPreview();
    }

    if (event.target.classList.contains('ka-design-control')) {
      syncDesignPreview();
    }

    if (event.target.classList.contains('ka-display-control') || event.target.id === 'ka_recipient') {
      syncLivePreviewMeta();
    }

    if (
      event.target.classList.contains('ka-field-label') ||
      event.target.classList.contains('ka-field-key') ||
      event.target.classList.contains('ka-field-placeholder-input') ||
      event.target.matches('.ka-field-required input[type="checkbox"]')
    ) {
      syncBuilderState();
    }
  });

  document.addEventListener('input', function (event) {
    if (event.target.id === 'ka_title') {
      applyDesignPreviewStyles();
      syncLivePreviewMeta();
      applyLivePreviewStyles();
    }

    if (event.target.classList.contains('ka-display-control') || event.target.id === 'ka_recipient') {
      syncLivePreviewMeta();
    }

    if (event.target.classList.contains('ka-field-label') || event.target.classList.contains('ka-field-key')) {
      renderLayoutCanvas();
      renderLivePreviewFields();
    }

    if (event.target.classList.contains('ka-field-placeholder-input')) {
      renderLivePreviewFields();
    }

    if (event.target.classList.contains('ka-color-swatch')) {
      var targetField = document.getElementById(event.target.dataset.colorTarget);

      if (targetField) {
        targetField.value = event.target.value;
        syncDesignPreview();
      }
    }

    if (event.target.classList.contains('ka-color-value')) {
      syncColorSwatchFromField(event.target);
      syncDesignPreview();
    }

    if (event.target.classList.contains('ka-design-control') && !event.target.classList.contains('ka-color-value')) {
      syncDesignPreview();
    }
  });

  document.querySelectorAll('.ka-color-value').forEach(syncColorSwatchFromField);
  if (builder) {
    syncBuilderState();
  }
  syncDesignPreview();

  document.querySelectorAll('.ka-form-wizard').forEach(function (wizard) {
    var panels = Array.from(wizard.querySelectorAll(':scope > .ka-admin-layout > .ka-admin-panel'));
    var submitRow = wizard.querySelector(':scope > .submit');
    var current = 0;
    var nav = document.createElement('div');
    var controls = document.createElement('div');
    var prev = document.createElement('button');
    var next = document.createElement('button');

    if (panels.length < 2 || wizard.dataset.wizardReady === '1') {
      return;
    }

    wizard.dataset.wizardReady = '1';
    nav.className = 'ka-wizard-nav';
    controls.className = 'ka-wizard-controls';

    panels.forEach(function (panel, index) {
      var button = document.createElement('button');
      var title = panel.querySelector('h2');

      panel.dataset.wizardPanel = String(index);
      button.type = 'button';
      button.className = 'ka-wizard-step';
      button.textContent = String(index + 1) + '. ' + (title ? title.textContent : 'Schritt');
      button.addEventListener('click', function () {
        showWizardStep(index);
      });
      nav.appendChild(button);
    });

    prev.type = 'button';
    prev.className = 'button button-secondary';
    prev.textContent = 'Zurueck';
    prev.addEventListener('click', function () {
      showWizardStep(Math.max(0, current - 1));
    });

    next.type = 'button';
    next.className = 'button button-primary';
    next.textContent = 'Weiter';
    next.addEventListener('click', function () {
      showWizardStep(Math.min(panels.length - 1, current + 1));
    });

    controls.appendChild(prev);
    controls.appendChild(next);
    wizard.insertBefore(nav, wizard.firstElementChild);
    if (submitRow) {
      wizard.insertBefore(controls, submitRow);
    }

    function showWizardStep(index) {
      current = index;
      panels.forEach(function (panel, panelIndex) {
        var active = panelIndex === current;
        panel.hidden = !active;
        panel.classList.toggle('is-active', active);
      });

      Array.from(nav.querySelectorAll('.ka-wizard-step')).forEach(function (button, buttonIndex) {
        button.classList.toggle('is-active', buttonIndex === current);
        button.classList.toggle('is-complete', buttonIndex < current);
      });

      prev.disabled = current === 0;
      next.hidden = current === panels.length - 1;
      if (submitRow) {
        submitRow.hidden = current !== panels.length - 1;
      }
    }

    showWizardStep(0);
  });
});

