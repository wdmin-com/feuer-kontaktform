<?php

declare(strict_types=1);

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once __DIR__ . '/config/defaults.php';
require_once __DIR__ . '/includes/class-feuer-kontaktform-repository.php';
require_once __DIR__ . '/includes/class-feuer-kontaktform-form-files.php';
require_once __DIR__ . '/includes/class-feuer-kontaktform-installer.php';

Feuer_Kontaktform_Installer::uninstall();

