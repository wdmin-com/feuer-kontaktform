# Feuer-Kontaktform

## Zweck

`Feuer-Kontaktform` erstellt deutsche Kontaktformulare pro Abteilung mit:

- eigener Empfaenger-E-Mail je Formular
- frei konfigurierbaren Formularfeldern
- Drag-and-drop Feldeditor im Backend
- mehreren Bootstrap-Layouts pro Formular
- Nachrichtenprotokoll mit Zustellstatus und Detailhinweisen
- Autoantworten
- IP-Sperrliste
- E-Mail-Sperrliste nur fuer Autoantworten
- lokaler Rechen-Captcha bei wiederholten Anfragen innerhalb von 30 Minuten

## Shortcodes

- Einzelnes Formular per ID: `[feuer-kontaktform-formular id="1"]`
- Einzelnes Formular per Slug: `[feuer-kontaktform-formular slug="vertrieb"]`
- Alle Formulare mit Abteilungswahl: `[feuer-kontaktform-alle]`

## Backend

### Formulare

Unter `Feuer-Kontaktform -> Formulare` sehen Sie:

- alle angelegten Formulare
- das ausgewaehlte Design
- Shortcodes je Formular
- Anzahl der Nachrichten
- letzte Nachrichten direkt unter dem Formular
- Versandstatus der Weiterleitung und der Autoantwort

### Neues Formular

Unter `Feuer-Kontaktform -> Neues Formular` koennen Sie:

- den Namen der Abteilung festlegen
- die Empfaenger-E-Mail setzen
- den Autoantwort-Betreff und Text anpassen
- Formularfelder per Drag-and-drop sortieren
- neue Felder direkt im Browser ohne Admin-AJAX einfuegen
- gespeicherte Vorlagenwerte aus Kompatibilitaetsgruenden verwalten
- Texte und Website pro Formular pflegen

### Nachrichtenprotokoll

Unter `Feuer-Kontaktform -> Nachrichtenprotokoll` sehen Sie:

- Datum und Uhrzeit
- IP-Adresse
- Antwort-E-Mail
- Status der Weiterleitung
- Status der Autoantwort
- Detailhinweise zur E-Mail-Zustellung
- uebermittelte Formulardaten

### Einstellungen

Unter `Feuer-Kontaktform -> Einstellungen` koennen Sie:

- globale Absenderdaten pflegen
- einen SMTP-Server fuer Benachrichtigungen und Autoantworten hinterlegen
- die SMTP-Verbindung direkt in den Einstellungen pruefen
- eine Test-E-Mail ueber den eingetragenen Mailserver senden
- Standard-Erfolgsmeldung und Standard-Autoantwort definieren
- IP-Adressen sperren
- E-Mail-Adressen fuer Autoantworten sperren

### SMTP-Versand

Wenn `SMTP fuer den Versand aktivieren` eingeschaltet ist, versendet Feuer-Kontaktform Benachrichtigungen und Autoantworten ueber den eingetragenen Mailserver.

Fuer die Einrichtung werden normalerweise benoetigt:

- SMTP-Host
- SMTP-Port
- Verschluesselung `TLS`, `SSL` oder `Keine`
- SMTP-Benutzername
- SMTP-Passwort

Die Buttons `SMTP-Verbindung pruefen` und `Test-E-Mail senden` verwenden die aktuell im Formular eingetragenen Werte. Das ist auch dann moeglich, wenn die Einstellungen noch nicht gespeichert wurden.

## Frontend

Die Formulare werden ueber getrennte Layout-Dateien in `templates/frontend/layouts` und gemeinsame Bausteine in `templates/frontend/partials` ausgegeben. Das Plugin bindet selbst kein zusaetzliches Bootstrap von externen Quellen ein.

Verfuegbar sind unterschiedliche Layouttypen wie:

- kompakte Einzelkarte
- Form mit seitlichem Textblock
- Form mit seitlicher Bildkarte
- Hero-Layout mit Einleitung oben
- gestaffelte Corporate-Ansicht

Frontend-JavaScript wurde auf ein Minimum reduziert. Die Abteilungsumschaltung wird direkt im Formular-Template ausgegeben, ohne zusaetzliche externe Requests.

Im Backend laufen Feldaufbau und Sortierung lokal im Plugin. Es werden dafuer keine separaten Admin-AJAX-Requests mehr benoetigt.

Logos und Hintergrundbilder sollten aus der eigenen WordPress-Mediathek oder vom selben Host stammen. Externe Asset-URLs werden beim Speichern verworfen.

Die Captcha-Funktion arbeitet ebenfalls lokal und ohne Drittanbieter.

## Entfernung des Plugins

Beim Loeschen des Plugins ueber WordPress wird `uninstall.php` ausgefuehrt. Dabei werden:

- alle Plugin-Tabellen geloescht
- die Plugin-Optionen entfernt
- temporaere Flash-Transients bereinigt

