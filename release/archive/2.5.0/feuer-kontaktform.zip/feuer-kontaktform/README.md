# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin fuer Kontaktformulare auf Websites freiwilliger Feuerwehren. Es verbindet klassische Kontaktformulare mit einem einfachen Ticket-Protokoll, SMTP-Versand, Autoantworten, Datenschutznachweis und Abteilungsrouting.

## Funktionen

- Mehrstufige Kontaktform mit Datenschutz-Schritt.
- Abteilungs- und Themenrouting pro Formular.
- Frei konfigurierbare Pflichtfelder je Thema ueber bedingte Felder.
- Ticket-ID fuer jede Anfrage.
- Nachrichtenprotokoll mit IP-Adresse, Cookie-ID, Geraetetyp, Browser/User-Agent, Datenschutzstatus, Captcha-Status, Mailstatus, Autoantwort und Webhookstatus.
- SMTP-Test, Test-E-Mail, Logo, Website-URL, Datenschutzhinweis, Sperrlisten und Shortcode-Uebersicht.
- CSV-Export mit Schutz gegen Spreadsheet-Formula-Injection.
- Self-hosted Updates ueber `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## Shortcodes

```text
[feuer-kontaktform-formular slug="wehrfuehrer"]
[feuer-kontaktform-formular id="1"]
[feuer-kontaktform-alle]
[feuer-kontaktform-schnell slug="wehrfuehrer"]
[feuer-kontaktform-popup slug="wehrfuehrer"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket enthaelt nur die Plugin-Dateien ohne `.git`, lokale Archive, Dokumentationsreste oder Entwicklungsordner. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
