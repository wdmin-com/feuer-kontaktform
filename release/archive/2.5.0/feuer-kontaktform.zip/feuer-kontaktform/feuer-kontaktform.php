<?php
/**
 * Plugin Name: Feuer-Kontaktform
 * Plugin URI: https://wdmin.com/plugins/feuer-kontaktform/
 * Description: Deutsche Kontaktformulare mit Abteilungswahl, Protokollen, E-Mail-Weiterleitung, Autoresponder und lokaler Wiederholungs-Captcha.
 * Version: 2.5.0
 * Author: Walter Faerber
 * Author URI: https://wdmin.com/
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

define('FEUER_KONTAKTFORM_VERSION', '2.5.0');
define('FEUER_KONTAKTFORM_FILE', __FILE__);
define('FEUER_KONTAKTFORM_PATH', plugin_dir_path(__FILE__));
define('FEUER_KONTAKTFORM_URL', plugin_dir_url(__FILE__));

require_once FEUER_KONTAKTFORM_PATH . 'config/defaults.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-view.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-repository.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-form-files.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-mailer.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-installer.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-updater.php';
require_once FEUER_KONTAKTFORM_PATH . 'includes/class-feuer-kontaktform-plugin.php';

register_activation_hook(__FILE__, ['Feuer_Kontaktform_Installer', 'activate']);

function feuer_kontaktform_plugin(): Feuer_Kontaktform_Plugin
{
    static $plugin = null;

    if (! $plugin instanceof Feuer_Kontaktform_Plugin) {
        $repository = new Feuer_Kontaktform_Repository();
        $view       = new Feuer_Kontaktform_View(FEUER_KONTAKTFORM_PATH . 'templates');
        $form_files = new Feuer_Kontaktform_Form_Files();
        $mailer     = new Feuer_Kontaktform_Mailer();
        $plugin     = new Feuer_Kontaktform_Plugin($repository, $view, $mailer, $form_files);
    }

    return $plugin;
}

feuer_kontaktform_plugin();

