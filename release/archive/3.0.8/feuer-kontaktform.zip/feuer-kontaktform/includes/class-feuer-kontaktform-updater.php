<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Updater
{
    private const UPDATE_BASE_URL = 'https://wdmin.com/plugins/feuer-kontaktform/';
    private const UPDATE_META_URL = 'https://wdmin.com/plugins/feuer-kontaktform/update.json';
    private const CACHE_KEY = 'feuer-kontaktform-update-info';
    private const LAST_CHECK_OPTION = 'feuer-kontaktform-update-last-check';

    public function register(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [$this, 'inject_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_action('upgrader_process_complete', [$this, 'clear_cache']);
    }

    public function check_now(): array
    {
        delete_site_transient(self::CACHE_KEY);
        $info = $this->fetch_update_info(true);
        update_option(self::LAST_CHECK_OPTION, [
            'checked_at' => current_time('mysql'),
            'remote_version' => (string) ($info['version'] ?? ''),
            'update_available' => ! empty($info['update_available']),
            'error' => (string) ($info['error'] ?? ''),
        ], false);

        return $info;
    }

    public function get_status(): array
    {
        $last = get_option(self::LAST_CHECK_OPTION, []);
        $info = $this->fetch_update_info(false);

        return [
            'base_url' => self::UPDATE_BASE_URL,
            'meta_url' => self::UPDATE_META_URL,
            'current_version' => defined('FEUER_KONTAKTFORM_VERSION') ? (string) FEUER_KONTAKTFORM_VERSION : '',
            'remote_version' => (string) ($info['version'] ?? ($last['remote_version'] ?? '')),
            'update_available' => ! empty($info['update_available']),
            'download_url' => (string) ($info['download_url'] ?? ''),
            'checked_at' => is_array($last) ? (string) ($last['checked_at'] ?? '') : '',
            'error' => (string) ($info['error'] ?? (is_array($last) ? ($last['error'] ?? '') : '')),
        ];
    }

    public function inject_update($transient)
    {
        if (! is_object($transient)) {
            return $transient;
        }

        $info = $this->fetch_update_info(false);
        $plugin_file = plugin_basename(FEUER_KONTAKTFORM_FILE);
        if (! isset($transient->response) || ! is_array($transient->response)) {
            $transient->response = [];
        }
        if (! isset($transient->no_update) || ! is_array($transient->no_update)) {
            $transient->no_update = [];
        }
        if (empty($info['update_available'])) {
            unset($transient->response[$plugin_file]);
            $transient->no_update[$plugin_file] = (object) [
                'id' => 'feuer-kontaktform',
                'slug' => 'feuer-kontaktform',
                'plugin' => $plugin_file,
                'new_version' => FEUER_KONTAKTFORM_VERSION,
                'url' => self::UPDATE_BASE_URL,
                'package' => '',
                'tested' => (string) ($info['tested'] ?? ''),
                'requires' => (string) ($info['requires'] ?? '6.0'),
                'requires_php' => (string) ($info['requires_php'] ?? '8.0'),
            ];
            return $transient;
        }

        $transient->response[$plugin_file] = (object) [
            'id' => 'feuer-kontaktform',
            'slug' => 'feuer-kontaktform',
            'plugin' => $plugin_file,
            'new_version' => (string) $info['version'],
            'url' => self::UPDATE_BASE_URL,
            'package' => (string) $info['download_url'],
            'tested' => (string) ($info['tested'] ?? ''),
            'requires' => (string) ($info['requires'] ?? '6.0'),
            'requires_php' => (string) ($info['requires_php'] ?? '8.0'),
        ];

        return $transient;
    }

    public function plugin_info($result, string $action, object $args)
    {
        if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'feuer-kontaktform') {
            return $result;
        }

        $info = $this->fetch_update_info(false);
        if (($info['error'] ?? '') !== '') {
            return $result;
        }

        return (object) [
            'name' => 'Feuer-Kontaktform',
            'slug' => 'feuer-kontaktform',
            'version' => (string) ($info['version'] ?? FEUER_KONTAKTFORM_VERSION),
            'author' => '<a href="https://wdmin.com/">Walter Faerber</a>',
            'homepage' => self::UPDATE_BASE_URL,
            'requires' => (string) ($info['requires'] ?? '6.0'),
            'requires_php' => (string) ($info['requires_php'] ?? '8.0'),
            'tested' => (string) ($info['tested'] ?? ''),
            'download_link' => (string) ($info['download_url'] ?? ''),
            'last_updated' => (string) ($info['last_updated'] ?? ''),
            'sections' => [
                'description' => (string) ($info['description'] ?? 'Kontaktformular- und Ticket-Plugin fuer freiwillige Feuerwehren.'),
                'changelog' => (string) ($info['changelog'] ?? ''),
            ],
        ];
    }

    private function fetch_update_info(bool $force): array
    {
        if (! $force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $this->with_current_version($cached);
            }
        }

        $response = wp_remote_get(self::UPDATE_META_URL, [
            'timeout' => 12,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return $this->cache_result([
                'error' => implode(' ', array_map('sanitize_text_field', $response->get_error_messages())),
                'update_available' => false,
            ]);
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        if ($code < 200 || $code >= 300 || trim($body) === '') {
            return $this->cache_result([
                'error' => 'Update-Server antwortete mit HTTP ' . $code . '.',
                'update_available' => false,
            ]);
        }

        $decoded = json_decode($body, true);
        if (! is_array($decoded)) {
            return $this->cache_result([
                'error' => 'Update-Informationen enthalten kein gueltiges JSON.',
                'update_available' => false,
            ]);
        }

        $version = sanitize_text_field((string) ($decoded['version'] ?? ''));
        $download_url = esc_url_raw((string) ($decoded['download_url'] ?? self::UPDATE_BASE_URL . 'release/latest/feuer-kontaktform.zip'));
        $result = [
            'version' => $version,
            'download_url' => $download_url,
            'requires' => sanitize_text_field((string) ($decoded['requires'] ?? '6.0')),
            'requires_php' => sanitize_text_field((string) ($decoded['requires_php'] ?? '8.0')),
            'tested' => sanitize_text_field((string) ($decoded['tested'] ?? '')),
            'last_updated' => sanitize_text_field((string) ($decoded['last_updated'] ?? '')),
            'description' => wp_kses_post((string) ($decoded['description'] ?? '')),
            'changelog' => wp_kses_post((string) ($decoded['changelog'] ?? '')),
            'update_available' => $version !== '' && version_compare($version, FEUER_KONTAKTFORM_VERSION, '>'),
            'error' => '',
        ];

        if ($download_url === '' || ! str_starts_with($download_url, self::UPDATE_BASE_URL)) {
            $result['download_url'] = '';
            $result['update_available'] = false;
            $result['error'] = 'Download-URL ist nicht im freigegebenen Plugin-Verzeichnis.';
        }

        return $this->cache_result($this->with_current_version($result));
    }

    private function cache_result(array $result): array
    {
        set_site_transient(self::CACHE_KEY, $result, HOUR_IN_SECONDS);
        return $result;
    }

    public function clear_cache($upgrader = null): void
    {
        delete_site_transient(self::CACHE_KEY);
    }

    private function with_current_version(array $result): array
    {
        $version = sanitize_text_field((string) ($result['version'] ?? ''));
        $current = defined('FEUER_KONTAKTFORM_VERSION') ? (string) FEUER_KONTAKTFORM_VERSION : '';
        $result['update_available'] = $version !== '' && $current !== '' && version_compare($version, $current, '>');
        return $result;
    }
}
