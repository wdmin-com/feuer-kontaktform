# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin fuer Support- und Ticket-Kommunikation auf Websites freiwilliger Feuerwehren. Jede Anfrage wird ueber einen AJAX-Wizard erfasst, bekommt eine 8-stellige Ticket-ID und wird per E-Mail an die passende Abteilung oder das passende Thema weitergeleitet.

## Funktionen

- Mehrstufiger AJAX-Wizard mit Datenschutz, Abteilung, Thema, dynamischen Feldern, Captcha und Abschlussmeldung.
- Abteilungen mit Name, Kurzname und Empfaenger-E-Mail.
- Themen je Abteilung mit optional eigener E-Mail, Autoantwort und eigenen Pflichtfeldern.
- Autoantworten pro Thema als Plain-Text und HTML-Vorlage mit Logo, Website-Name, Ticket-ID und Makros.
- 8-stellige zufaellige Ticket-ID fuer jede Anfrage.
- Ticketprotokoll mit IP-Adresse, Cookie-ID, Geraetetyp, Browser/User-Agent, Datenschutzstatus und Captcha-Status.
- Admin-Protokoll fuer Einstellungen, Abteilungen, Themen, Testmails, Updates und Ticket-Erstellung.
- E-Mail-Test ueber den konfigurierten WordPress-Mailweg.
- Self-hosted Updates ueber `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## Shortcodes

```text
[feuer-kontaktform]
[feuer-kontaktform department="wehrfuehrung"]
[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]
[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket wird mit `tools/build-release.ps1` erzeugt. Der Builder schreibt keine Ordner-Eintraege in das ZIP, setzt `ExternalAttributes` auf `0`, schreibt keine ZIP extra fields und vermeidet dadurch Windows-Owner/ACL-Metadaten. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
