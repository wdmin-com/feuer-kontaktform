<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Admin
{
    private const MENU_SLUG = 'feuer-kontaktform';

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer,
        private Feuer_Kontaktform_Updater $updater
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'handle_actions']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function assets(string $hook): void
    {
        if (! str_contains($hook, 'feuer-kontaktform')) {
            return;
        }

        wp_enqueue_style('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/css/support-admin.css', [], FEUER_KONTAKTFORM_VERSION);
        wp_enqueue_script('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/js/support-admin.js', [], FEUER_KONTAKTFORM_VERSION, true);
    }

    public function menu(): void
    {
        add_menu_page('Feuer-Kontaktform', 'Feuer-Kontaktform', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page'], 'dashicons-sos', 56);
        add_submenu_page(self::MENU_SLUG, 'Tickets', 'Tickets', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page']);
        add_submenu_page(self::MENU_SLUG, 'Abteilungen & Themen', 'Abteilungen & Themen', 'manage_options', 'feuer-kontaktform-departments', [$this, 'departments_page']);
        add_submenu_page(self::MENU_SLUG, 'Einstellungen', 'Einstellungen', 'manage_options', 'feuer-kontaktform-settings', [$this, 'settings_page']);
        add_submenu_page(self::MENU_SLUG, 'Protokolle', 'Protokolle', 'manage_options', 'feuer-kontaktform-logs', [$this, 'logs_page']);
    }

    public function handle_actions(): void
    {
        if (! current_user_can('manage_options') || empty($_POST['feuer_support_action'])) {
            return;
        }

        check_admin_referer('feuer_support_admin');
        $action = sanitize_key((string) wp_unslash($_POST['feuer_support_action']));

        switch ($action) {
            case 'save_settings':
                $settings = $this->sanitize_settings($_POST);
                $this->db->update_settings($settings);
                $this->db->log('settings_saved', 'settings', 0, []);
                $this->redirect('feuer-kontaktform-settings', 'settings_saved');
                break;

            case 'send_test_mail':
                $settings = $this->db->get_settings();
                $target = sanitize_email((string) wp_unslash($_POST['test_email'] ?? get_option('admin_email')));
                $ok = $this->mailer->send_test($settings, $target);
                $this->db->log('test_mail_sent', 'settings', 0, ['target' => $target, 'success' => $ok]);
                $this->redirect('feuer-kontaktform-settings', $ok ? 'test_mail_sent' : 'test_mail_failed');
                break;

            case 'check_updates':
                $status = $this->updater->check_now();
                $this->db->log('update_checked', 'update', 0, $status);
                $this->redirect('feuer-kontaktform-settings', empty($status['error']) ? 'update_checked' : 'update_failed');
                break;

            case 'save_department':
                $id = $this->db->save_department([
                    'id' => absint($_POST['department_id'] ?? 0),
                    'name' => wp_unslash($_POST['department_name'] ?? ''),
                    'slug' => wp_unslash($_POST['department_slug'] ?? ''),
                    'email' => wp_unslash($_POST['department_email'] ?? ''),
                    'description' => wp_unslash($_POST['department_description'] ?? ''),
                    'sort_order' => absint($_POST['department_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['department_is_active']),
                ]);
                $this->redirect('feuer-kontaktform-departments', $id > 0 ? 'department_saved' : 'department_failed');
                break;

            case 'delete_department':
                $this->db->deactivate_department(absint($_POST['department_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'department_deleted');
                break;

            case 'save_topic':
                $id = $this->db->save_topic([
                    'id' => absint($_POST['topic_id'] ?? 0),
                    'department_id' => absint($_POST['department_id'] ?? 0),
                    'title' => wp_unslash($_POST['topic_title'] ?? ''),
                    'slug' => wp_unslash($_POST['topic_slug'] ?? ''),
                    'email_override' => wp_unslash($_POST['topic_email_override'] ?? ''),
                    'auto_subject' => wp_unslash($_POST['topic_auto_subject'] ?? ''),
                    'auto_body' => wp_unslash($_POST['topic_auto_body'] ?? ''),
                    'auto_html' => wp_unslash($_POST['topic_auto_html'] ?? ''),
                    'sort_order' => absint($_POST['topic_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['topic_is_active']),
                    'fields' => $this->collect_fields(),
                ]);
                $this->redirect('feuer-kontaktform-departments', $id > 0 ? 'topic_saved' : 'topic_failed');
                break;

            case 'delete_topic':
                $this->db->deactivate_topic(absint($_POST['topic_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'topic_deleted');
                break;
        }
    }

    public function tickets_page(): void
    {
        $tickets = $this->db->get_tickets(200);
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Feuer-Kontaktform Tickets</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-card">
                <h2>Letzte Anfragen</h2>
                <table class="widefat striped">
                    <thead><tr><th>Ticket</th><th>Status</th><th>Abteilung</th><th>Thema</th><th>Absender</th><th>Datenschutz</th><th>IP / Geraet</th><th>Datum</th></tr></thead>
                    <tbody>
                    <?php if ($tickets === []) : ?>
                        <tr><td colspan="8">Noch keine Tickets vorhanden.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($tickets as $ticket) : ?>
                        <tr>
                            <td><strong><?php echo esc_html((string) $ticket['ticket_code']); ?></strong></td>
                            <td><?php echo esc_html((string) $ticket['status']); ?></td>
                            <td><?php echo esc_html((string) ($ticket['department_name'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) ($ticket['topic_title'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) $ticket['sender_name']); ?><br><a href="mailto:<?php echo esc_attr((string) $ticket['sender_email']); ?>"><?php echo esc_html((string) $ticket['sender_email']); ?></a></td>
                            <td><?php echo ! empty($ticket['privacy_accepted']) ? 'ja' : 'nein'; ?><br><small><?php echo esc_html((string) $ticket['privacy_version']); ?></small></td>
                            <td><?php echo esc_html((string) $ticket['ip_address']); ?><br><small><?php echo esc_html((string) $ticket['device_type']); ?></small></td>
                            <td><?php echo esc_html((string) $ticket['created_at']); ?></td>
                        </tr>
                        <tr class="feuer-ticket-details">
                            <td colspan="8">
                                <strong>Nachricht:</strong> <?php echo esc_html((string) $ticket['message']); ?>
                                <?php if (! empty($ticket['fields'])) : ?>
                                    <div class="feuer-field-dump">
                                        <?php foreach ((array) $ticket['fields'] as $key => $value) : ?>
                                            <span><b><?php echo esc_html((string) $key); ?>:</b> <?php echo esc_html(is_array($value) ? implode(', ', $value) : (string) $value); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function departments_page(): void
    {
        $departments = $this->db->get_departments();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Abteilungen & Themen</h1>
            <?php $this->notice(); ?>
            <p class="description">Hier entstehen die Support-Routen: Abteilung, Themen, Empfaenger, Autoantwort und individuelle Felder pro Thema.</p>

            <div class="feuer-admin-card">
                <h2>Neue Abteilung</h2>
                <?php $this->department_form(); ?>
            </div>

            <?php foreach ($departments as $department) : ?>
                <div class="feuer-admin-card">
                    <details open>
                        <summary><strong><?php echo esc_html((string) $department['name']); ?></strong> <code><?php echo esc_html((string) $department['slug']); ?></code></summary>
                        <?php $this->department_form($department); ?>
                        <h3>Themen</h3>
                        <?php foreach ($this->db->get_topics((int) $department['id']) as $topic) : ?>
                            <?php $this->topic_form($department, $topic); ?>
                        <?php endforeach; ?>
                        <h3>Neues Thema</h3>
                        <?php $this->topic_form($department); ?>
                    </details>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    public function settings_page(): void
    {
        $settings = $this->db->get_settings();
        $update = $this->updater->get_status();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Einstellungen</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-grid">
                <form method="post" class="feuer-admin-card">
                    <?php wp_nonce_field('feuer_support_admin'); ?>
                    <input type="hidden" name="feuer_support_action" value="save_settings">
                    <h2>Basis & E-Mail</h2>
                    <?php $this->input('site_name', 'Name der Website', $settings['site_name']); ?>
                    <?php $this->input('logo_url', 'Logo URL', $settings['logo_url'], 'url'); ?>
                    <?php $this->input('base_email', 'Basis E-Mail', $settings['base_email'], 'email'); ?>
                    <?php $this->input('from_email', 'Absender E-Mail', $settings['from_email'], 'email'); ?>
                    <?php $this->input('from_name', 'Absender Name', $settings['from_name']); ?>
                    <?php $this->input('privacy_url', 'URL zur Datenschutzerklaerung', $settings['privacy_url'], 'url'); ?>
                    <label>Text fuer Datenschutzhinweis<textarea name="privacy_text" rows="4" class="large-text"><?php echo esc_textarea((string) $settings['privacy_text']); ?></textarea></label>
                    <?php $this->input('privacy_version', 'Datenschutz-Version', $settings['privacy_version']); ?>
                    <label>Text nach erfolgreichem Versand<textarea name="ticket_success_text" rows="3" class="large-text"><?php echo esc_textarea((string) $settings['ticket_success_text']); ?></textarea></label>
                    <?php $this->input('rate_limit_minutes', 'Captcha nach Wiederholung innerhalb Minuten', $settings['rate_limit_minutes'], 'number'); ?>
                    <p><button class="button button-primary">Speichern</button></p>
                </form>

                <div class="feuer-admin-card">
                    <h2>E-Mail Verbindung pruefen</h2>
                    <form method="post">
                        <?php wp_nonce_field('feuer_support_admin'); ?>
                        <input type="hidden" name="feuer_support_action" value="send_test_mail">
                        <?php $this->input('test_email', 'Test Empfaenger', get_option('admin_email'), 'email'); ?>
                        <p><button class="button">Testmail senden</button></p>
                    </form>
                    <p class="description">Die Pruefung nutzt den aktuell konfigurierten WordPress-Mailweg. SMTP-Zugangsdaten sollten serverseitig oder ueber eine sichere SMTP-Konfiguration verwaltet werden.</p>
                </div>

                <div class="feuer-admin-card">
                    <h2>Plugin Update</h2>
                    <p>Entwickler-URL: <code><?php echo esc_html((string) $update['base_url']); ?></code></p>
                    <p>Installiert: <strong><?php echo esc_html((string) $update['current_version']); ?></strong></p>
                    <p>Server: <strong><?php echo esc_html((string) $update['remote_version']); ?></strong></p>
                    <?php if (! empty($update['error'])) : ?><p class="notice notice-error inline"><?php echo esc_html((string) $update['error']); ?></p><?php endif; ?>
                    <form method="post">
                        <?php wp_nonce_field('feuer_support_admin'); ?>
                        <input type="hidden" name="feuer_support_action" value="check_updates">
                        <button class="button button-primary">Update pruefen</button>
                    </form>
                </div>

                <div class="feuer-admin-card">
                    <h2>Shortcodes</h2>
                    <p><code>[feuer-kontaktform]</code> kompletter Wizard.</p>
                    <p><code>[feuer-kontaktform department="wehrfuehrung"]</code> direkt zu einer Abteilung.</p>
                    <p><code>[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]</code> direkt zu einem Thema.</p>
                    <p><code>[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]</code> schnelle klassische Form.</p>
                </div>
            </div>
        </div>
        <?php
    }

    public function logs_page(): void
    {
        $logs = $this->db->get_logs();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Protokolle</h1>
            <div class="feuer-admin-card">
                <table class="widefat striped">
                    <thead><tr><th>Datum</th><th>Aktion</th><th>Objekt</th><th>Admin</th><th>IP</th><th>Kontext</th></tr></thead>
                    <tbody>
                    <?php foreach ($logs as $log) : ?>
                        <tr>
                            <td><?php echo esc_html((string) $log['created_at']); ?></td>
                            <td><code><?php echo esc_html((string) $log['action']); ?></code></td>
                            <td><?php echo esc_html((string) $log['object_type']); ?> #<?php echo esc_html((string) $log['object_id']); ?></td>
                            <td><?php echo esc_html((string) $log['actor_id']); ?></td>
                            <td><?php echo esc_html((string) $log['ip_address']); ?></td>
                            <td><small><?php echo esc_html((string) $log['context_json']); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    private function department_form(?array $department = null): void
    {
        $department = $department ?? ['id' => 0, 'name' => '', 'slug' => '', 'email' => '', 'description' => '', 'sort_order' => 0, 'is_active' => true];
        ?>
        <form method="post" class="feuer-inline-form">
            <?php wp_nonce_field('feuer_support_admin'); ?>
            <input type="hidden" name="feuer_support_action" value="save_department">
            <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
            <div class="feuer-form-grid">
                <?php $this->input('department_name', 'Name', $department['name']); ?>
                <?php $this->input('department_slug', 'Kurzname / Slug', $department['slug']); ?>
                <?php $this->input('department_email', 'E-Mail Empfaenger', $department['email'], 'email'); ?>
                <?php $this->input('department_sort_order', 'Sortierung', $department['sort_order'], 'number'); ?>
            </div>
            <label>Beschreibung<textarea class="large-text" name="department_description" rows="2"><?php echo esc_textarea((string) $department['description']); ?></textarea></label>
            <label><input type="checkbox" name="department_is_active" value="1" <?php checked(! empty($department['is_active'])); ?>> aktiv</label>
            <p><button class="button button-primary">Abteilung speichern</button></p>
        </form>
        <?php if ((int) $department['id'] > 0) : ?>
            <form method="post">
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="delete_department">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <button class="button button-link-delete">Abteilung deaktivieren</button>
            </form>
        <?php endif; ?>
        <?php
    }

    private function topic_form(array $department, ?array $topic = null): void
    {
        $topic = $topic ?? [
            'id' => 0,
            'department_id' => (int) $department['id'],
            'title' => '',
            'slug' => '',
            'email_override' => '',
            'auto_subject' => Feuer_Kontaktform_Support_DB::default_auto_subject(),
            'auto_body' => Feuer_Kontaktform_Support_DB::default_auto_body(),
            'auto_html' => Feuer_Kontaktform_Support_DB::default_auto_html_body(),
            'sort_order' => 0,
            'is_active' => true,
            'fields' => Feuer_Kontaktform_Support_DB::default_fields(),
        ];
        ?>
        <details class="feuer-topic-box" <?php echo (int) $topic['id'] === 0 ? 'open' : ''; ?>>
            <summary><?php echo (int) $topic['id'] > 0 ? esc_html((string) $topic['title']) : 'Neues Thema konfigurieren'; ?></summary>
            <form method="post" data-topic-form>
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="save_topic">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                <div class="feuer-form-grid">
                    <?php $this->input('topic_title', 'Thema', $topic['title']); ?>
                    <?php $this->input('topic_slug', 'Kurzname / Slug', $topic['slug']); ?>
                    <?php $this->input('topic_email_override', 'E-Mail falls abweichend', $topic['email_override'], 'email'); ?>
                    <?php $this->input('topic_sort_order', 'Sortierung', $topic['sort_order'], 'number'); ?>
                </div>
                <?php $this->input('topic_auto_subject', 'Autoantwort Betreff', $topic['auto_subject']); ?>
                <div class="feuer-auto-reply-grid">
                    <label>
                        Autoantwort Text
                        <span class="description">Plain-Text Fallback fuer einfache Mailprogramme.</span>
                        <textarea class="large-text code" name="topic_auto_body" rows="11"><?php echo esc_textarea((string) $topic['auto_body']); ?></textarea>
                    </label>
                    <label>
                        Autoantwort HTML
                        <span class="description">Formatierte E-Mail mit Logo, Website-Name, Ticket-ID und Datenschutzlink.</span>
                        <textarea class="large-text code" name="topic_auto_html" rows="16"><?php echo esc_textarea((string) ($topic['auto_html'] ?? Feuer_Kontaktform_Support_DB::default_auto_html_body())); ?></textarea>
                    </label>
                </div>
                <?php $this->auto_reply_macro_help(); ?>
                <label><input type="checkbox" name="topic_is_active" value="1" <?php checked(! empty($topic['is_active'])); ?>> aktiv</label>
                <h4>Felder fuer dieses Thema</h4>
                <div data-fields-list>
                    <?php foreach ((array) $topic['fields'] as $field) : ?>
                        <?php $this->field_row($field); ?>
                    <?php endforeach; ?>
                </div>
                <p><button type="button" class="button" data-add-field>Feld hinzufuegen</button></p>
                <p><button class="button button-primary">Thema speichern</button></p>
            </form>
            <?php if ((int) $topic['id'] > 0) : ?>
                <form method="post">
                    <?php wp_nonce_field('feuer_support_admin'); ?>
                    <input type="hidden" name="feuer_support_action" value="delete_topic">
                    <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                    <button class="button button-link-delete">Thema deaktivieren</button>
                </form>
            <?php endif; ?>
        </details>
        <?php
    }

    private function field_row(array $field): void
    {
        ?>
        <div class="feuer-field-row" data-field-row>
            <input name="topic_fields[key][]" value="<?php echo esc_attr((string) ($field['key'] ?? '')); ?>" placeholder="key">
            <input name="topic_fields[label][]" value="<?php echo esc_attr((string) ($field['label'] ?? '')); ?>" placeholder="Label">
            <select name="topic_fields[type][]">
                <?php foreach (['text', 'email', 'tel', 'textarea', 'select', 'file'] as $type) : ?>
                    <option value="<?php echo esc_attr($type); ?>" <?php selected((string) ($field['type'] ?? 'text'), $type); ?>><?php echo esc_html($type); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="topic_fields[width][]">
                <?php foreach (['full', 'half', 'third'] as $width) : ?>
                    <option value="<?php echo esc_attr($width); ?>" <?php selected((string) ($field['width'] ?? 'full'), $width); ?>><?php echo esc_html($width); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="topic_fields[required][]" value="<?php echo ! empty($field['required']) ? '1' : '0'; ?>" data-required-hidden>
            <label><input type="checkbox" value="1" data-required-checkbox <?php checked(! empty($field['required'])); ?>> Pflicht</label>
            <input name="topic_fields[options][]" value="<?php echo esc_attr(implode(', ', (array) ($field['options'] ?? []))); ?>" placeholder="Optionen bei select">
            <button type="button" class="button" data-remove-field>Entfernen</button>
        </div>
        <?php
    }

    private function auto_reply_macro_help(): void
    {
        ?>
        <div class="feuer-macro-help">
            <h4>Shortcodes fuer Autoantworten</h4>
            <p class="description">Diese Platzhalter koennen im Betreff, im Text und in der HTML-Vorlage verwendet werden.</p>
            <div class="feuer-macro-grid">
                <?php foreach (Feuer_Kontaktform_Support_DB::auto_reply_macros() as $macro => $description) : ?>
                    <div><code><?php echo esc_html($macro); ?></code><span><?php echo esc_html($description); ?></span></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private function collect_fields(): array
    {
        $input = isset($_POST['topic_fields']) && is_array($_POST['topic_fields']) ? wp_unslash($_POST['topic_fields']) : [];
        $labels = is_array($input['label'] ?? null) ? $input['label'] : [];
        $fields = [];

        foreach ($labels as $index => $label) {
            $fields[] = [
                'key' => (string) (($input['key'][$index] ?? '') ?: $label),
                'label' => (string) $label,
                'type' => (string) ($input['type'][$index] ?? 'text'),
                'width' => (string) ($input['width'][$index] ?? 'full'),
                'required' => ! empty($input['required'][$index]),
                'options' => (string) ($input['options'][$index] ?? ''),
                'sort_order' => $index,
            ];
        }

        return $fields;
    }

    private function sanitize_settings(array $source): array
    {
        $defaults = Feuer_Kontaktform_Support_DB::default_settings();
        return [
            'site_name' => sanitize_text_field((string) wp_unslash($source['site_name'] ?? $defaults['site_name'])),
            'logo_url' => esc_url_raw((string) wp_unslash($source['logo_url'] ?? '')),
            'base_email' => sanitize_email((string) wp_unslash($source['base_email'] ?? $defaults['base_email'])),
            'from_email' => sanitize_email((string) wp_unslash($source['from_email'] ?? $defaults['from_email'])),
            'from_name' => sanitize_text_field((string) wp_unslash($source['from_name'] ?? $defaults['from_name'])),
            'privacy_url' => esc_url_raw((string) wp_unslash($source['privacy_url'] ?? '')),
            'privacy_text' => sanitize_textarea_field((string) wp_unslash($source['privacy_text'] ?? $defaults['privacy_text'])),
            'privacy_version' => sanitize_text_field((string) wp_unslash($source['privacy_version'] ?? $defaults['privacy_version'])),
            'ticket_success_text' => sanitize_textarea_field((string) wp_unslash($source['ticket_success_text'] ?? $defaults['ticket_success_text'])),
            'rate_limit_minutes' => max(1, absint($source['rate_limit_minutes'] ?? $defaults['rate_limit_minutes'])),
        ];
    }

    private function input(string $name, string $label, $value, string $type = 'text'): void
    {
        ?>
        <label><?php echo esc_html($label); ?><input class="regular-text" type="<?php echo esc_attr($type); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) $value); ?>"></label>
        <?php
    }

    private function redirect(string $page, string $message): void
    {
        wp_safe_redirect(add_query_arg(['page' => $page, 'feuer-message' => $message], admin_url('admin.php')));
        exit;
    }

    private function notice(): void
    {
        $message = sanitize_key((string) ($_GET['feuer-message'] ?? ''));
        if ($message === '') {
            return;
        }

        $labels = [
            'settings_saved' => 'Einstellungen gespeichert.',
            'test_mail_sent' => 'Testmail wurde gesendet.',
            'test_mail_failed' => 'Testmail konnte nicht gesendet werden.',
            'update_checked' => 'Update-Pruefung wurde ausgefuehrt.',
            'update_failed' => 'Update-Pruefung fehlgeschlagen.',
            'department_saved' => 'Abteilung gespeichert.',
            'department_failed' => 'Abteilung konnte nicht gespeichert werden.',
            'department_deleted' => 'Abteilung wurde deaktiviert.',
            'topic_saved' => 'Thema gespeichert.',
            'topic_failed' => 'Thema konnte nicht gespeichert werden.',
            'topic_deleted' => 'Thema wurde deaktiviert.',
        ];

        if (! isset($labels[$message])) {
            return;
        }

        $type = str_contains($message, 'failed') ? 'error' : 'success';
        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($labels[$message]) . '</p></div>';
    }
}
