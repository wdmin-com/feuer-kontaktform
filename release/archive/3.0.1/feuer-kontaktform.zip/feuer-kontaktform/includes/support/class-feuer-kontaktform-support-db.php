<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_DB
{
    public const OPTION_SETTINGS = 'feuer_kontaktform_support_settings';
    public const OPTION_VERSION = 'feuer_kontaktform_support_version';

    private string $departments_table;
    private string $topics_table;
    private string $tickets_table;
    private string $messages_table;
    private string $logs_table;

    public function __construct()
    {
        global $wpdb;

        $this->departments_table = $wpdb->prefix . 'feuer_kontaktform_departments';
        $this->topics_table      = $wpdb->prefix . 'feuer_kontaktform_topics';
        $this->tickets_table     = $wpdb->prefix . 'feuer_kontaktform_tickets';
        $this->messages_table    = $wpdb->prefix . 'feuer_kontaktform_ticket_messages';
        $this->logs_table        = $wpdb->prefix . 'feuer_kontaktform_logs';
    }

    public static function default_settings(): array
    {
        return [
            'site_name' => get_bloginfo('name'),
            'logo_url' => '',
            'base_email' => get_option('admin_email'),
            'from_email' => get_option('admin_email'),
            'from_name' => get_bloginfo('name'),
            'privacy_url' => function_exists('get_privacy_policy_url') ? (string) get_privacy_policy_url() : '',
            'privacy_text' => 'Ich stimme zu, dass meine Angaben zur Bearbeitung meiner Anfrage verarbeitet werden. Es gilt die Datenschutzerklaerung.',
            'privacy_version' => '1',
            'ticket_success_text' => 'Vielen Dank. Ihre Anfrage wurde gespeichert und per E-Mail weitergeleitet.',
            'rate_limit_minutes' => 10,
        ];
    }

    public static function default_fields(): array
    {
        return [
            ['key' => 'vorname', 'label' => 'Vorname', 'type' => 'text', 'width' => 'half', 'required' => true],
            ['key' => 'nachname', 'label' => 'Nachname', 'type' => 'text', 'width' => 'half', 'required' => true],
            ['key' => 'titel', 'label' => 'Titel / Betreff', 'type' => 'text', 'width' => 'full', 'required' => false],
            ['key' => 'telefon', 'label' => 'Telefonnummer', 'type' => 'tel', 'width' => 'half', 'required' => false],
            ['key' => 'email', 'label' => 'E-Mail Adresse', 'type' => 'email', 'width' => 'half', 'required' => true],
            ['key' => 'nachricht', 'label' => 'Nachricht', 'type' => 'textarea', 'width' => 'full', 'required' => true],
        ];
    }

    public static function default_auto_subject(): string
    {
        return 'Ihre Anfrage {{ticket_id}} wurde empfangen';
    }

    public static function default_auto_body(): string
    {
        return "Hallo {{vorname}} {{nachname}},\n\nvielen Dank fuer Ihre Anfrage an {{site_name}}.\n\nWir haben Ihre Nachricht zum Thema \"{{topic}}\" erhalten und unter der Ticket-ID {{ticket_id}} gespeichert. Ihre Anfrage wird geprueft und schnellstmoeglich beantwortet.\n\nBitte geben Sie bei Rueckfragen immer die Ticket-ID {{ticket_id}} an, damit wir Ihre Anfrage eindeutig zuordnen koennen.\n\nMit freundlichen Gruessen\n{{site_name}}";
    }

    public static function default_auto_html_body(): string
    {
        return '<div style="margin:0;padding:0;background:#f3f5f7;font-family:Arial,Helvetica,sans-serif;color:#20242a;">'
            . '<div style="max-width:680px;margin:0 auto;padding:28px 18px;">'
            . '<div style="background:#ffffff;border:1px solid #dde2e8;border-radius:10px;overflow:hidden;">'
            . '<div style="padding:24px 28px;border-bottom:4px solid #b3192b;background:#ffffff;">'
            . '{{logo_html}}'
            . '<div style="font-size:13px;letter-spacing:.02em;text-transform:uppercase;color:#b3192b;font-weight:700;">Ticket {{ticket_id}}</div>'
            . '<h1 style="margin:8px 0 0;font-size:24px;line-height:1.25;color:#20242a;">Ihre Anfrage wurde empfangen</h1>'
            . '</div>'
            . '<div style="padding:28px;">'
            . '<p style="margin:0 0 16px;font-size:16px;line-height:1.55;">Hallo {{vorname}} {{nachname}},</p>'
            . '<p style="margin:0 0 16px;font-size:16px;line-height:1.55;">vielen Dank fuer Ihre Anfrage an <strong>{{site_name}}</strong>.</p>'
            . '<p style="margin:0 0 16px;font-size:16px;line-height:1.55;">Wir haben Ihre Nachricht zum Thema <strong>{{topic}}</strong> erhalten und unter der Ticket-ID <strong>{{ticket_id}}</strong> gespeichert. Ihre Anfrage wird geprueft und schnellstmoeglich beantwortet.</p>'
            . '<div style="margin:22px 0;padding:16px 18px;border-radius:8px;background:#f6f7f9;border:1px solid #e1e5ea;">'
            . '<div style="font-size:13px;color:#606a76;">Ihre Ticket-ID</div>'
            . '<div style="font-size:28px;line-height:1.2;font-weight:700;letter-spacing:.06em;color:#20242a;">{{ticket_id}}</div>'
            . '</div>'
            . '<p style="margin:0 0 18px;font-size:15px;line-height:1.55;color:#47515f;">Bitte geben Sie bei Rueckfragen immer diese Ticket-ID an, damit wir Ihre Anfrage eindeutig zuordnen koennen.</p>'
            . '<p style="margin:0;font-size:16px;line-height:1.55;">Mit freundlichen Gruessen<br><strong>{{site_name}}</strong></p>'
            . '</div>'
            . '<div style="padding:18px 28px;background:#f8f9fb;border-top:1px solid #e6e9ee;font-size:12px;line-height:1.45;color:#687281;">'
            . 'Diese E-Mail wurde automatisch erstellt. Datenschutzerklaerung: <a href="{{privacy_url}}" style="color:#b3192b;">{{privacy_url}}</a>'
            . '</div>'
            . '</div>'
            . '</div>'
            . '</div>';
    }

    public static function auto_reply_macros(): array
    {
        return [
            '{{ticket_id}}' => '8-stellige Ticket-ID der Anfrage',
            '{{ticket}}' => 'Alias fuer die Ticket-ID',
            '{{site_name}}' => 'Name der Website aus den Einstellungen',
            '{{logo_html}}' => 'Fertiger HTML-Block fuer das Logo, wenn eine Logo-URL gesetzt ist',
            '{{logo_url}}' => 'Logo-URL aus den Einstellungen',
            '{{privacy_url}}' => 'URL zur Datenschutzerklaerung',
            '{{department}}' => 'Name der ausgewaehlten Abteilung',
            '{{topic}}' => 'Name des ausgewaehlten Themas',
            '{{name}}' => 'Vollstaendiger Name des Absenders',
            '{{vorname}}' => 'Vorname des Absenders',
            '{{nachname}}' => 'Nachname des Absenders',
            '{{email}}' => 'E-Mail-Adresse des Absenders',
            '{{telefon}}' => 'Telefonnummer des Absenders',
        ];
    }

    public function create_tables(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE {$this->departments_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(190) NOT NULL,
            slug varchar(120) NOT NULL,
            email varchar(255) NOT NULL,
            description text NULL,
            sort_order int(11) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY is_active (is_active),
            KEY sort_order (sort_order)
        ) $charset;");

        dbDelta("CREATE TABLE {$this->topics_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            department_id bigint(20) unsigned NOT NULL,
            title varchar(190) NOT NULL,
            slug varchar(120) NOT NULL,
            email_override varchar(255) NOT NULL DEFAULT '',
            auto_subject varchar(255) NOT NULL DEFAULT '',
            auto_body longtext NULL,
            auto_html longtext NULL,
            fields_json longtext NULL,
            sort_order int(11) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY department_slug (department_id, slug),
            KEY department_id (department_id),
            KEY is_active (is_active),
            KEY sort_order (sort_order)
        ) $charset;");

        dbDelta("CREATE TABLE {$this->tickets_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_code varchar(8) NOT NULL,
            department_id bigint(20) unsigned NOT NULL,
            topic_id bigint(20) unsigned NOT NULL,
            subject varchar(255) NOT NULL DEFAULT '',
            sender_name varchar(255) NOT NULL DEFAULT '',
            sender_email varchar(255) NOT NULL DEFAULT '',
            sender_phone varchar(100) NOT NULL DEFAULT '',
            message longtext NULL,
            fields_json longtext NULL,
            status varchar(40) NOT NULL DEFAULT 'open',
            privacy_accepted tinyint(1) NOT NULL DEFAULT 0,
            privacy_version varchar(80) NOT NULL DEFAULT '',
            privacy_url text NULL,
            consent_text text NULL,
            ip_address varchar(100) NOT NULL DEFAULT '',
            visitor_cookie varchar(120) NOT NULL DEFAULT '',
            browser text NULL,
            device_type varchar(80) NOT NULL DEFAULT '',
            user_agent text NULL,
            captcha_required tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ticket_code (ticket_code),
            KEY department_id (department_id),
            KEY topic_id (topic_id),
            KEY sender_email (sender_email),
            KEY ip_address (ip_address),
            KEY created_at (created_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$this->messages_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) unsigned NOT NULL,
            direction varchar(20) NOT NULL DEFAULT 'inbound',
            from_email varchar(255) NOT NULL DEFAULT '',
            to_email varchar(255) NOT NULL DEFAULT '',
            body longtext NULL,
            raw_json longtext NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_id (ticket_id),
            KEY direction (direction),
            KEY created_at (created_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$this->logs_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
            action varchar(120) NOT NULL,
            object_type varchar(80) NOT NULL DEFAULT '',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            ip_address varchar(100) NOT NULL DEFAULT '',
            user_agent text NULL,
            context_json longtext NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY actor_id (actor_id),
            KEY action (action),
            KEY object_type (object_type),
            KEY created_at (created_at)
        ) $charset;");

        if (! is_array(get_option(self::OPTION_SETTINGS))) {
            add_option(self::OPTION_SETTINGS, self::default_settings(), '', false);
        }

        update_option(self::OPTION_VERSION, FEUER_KONTAKTFORM_VERSION);
        $this->seed_defaults();
    }

    public function uninstall(): void
    {
        global $wpdb;

        $wpdb->query("DROP TABLE IF EXISTS {$this->messages_table}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->tickets_table}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->topics_table}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->departments_table}");
        $wpdb->query("DROP TABLE IF EXISTS {$this->logs_table}");

        delete_option(self::OPTION_SETTINGS);
        delete_option(self::OPTION_VERSION);
    }

    public function get_settings(): array
    {
        $settings = get_option(self::OPTION_SETTINGS);
        return wp_parse_args(is_array($settings) ? $settings : [], self::default_settings());
    }

    public function update_settings(array $settings): void
    {
        update_option(self::OPTION_SETTINGS, wp_parse_args($settings, self::default_settings()), false);
    }

    public function get_departments(bool $active_only = false): array
    {
        global $wpdb;

        $where = $active_only ? 'WHERE is_active = 1' : '';
        $rows = $wpdb->get_results("SELECT * FROM {$this->departments_table} {$where} ORDER BY sort_order ASC, name ASC", ARRAY_A);
        return is_array($rows) ? array_map([$this, 'hydrate_department'], $rows) : [];
    }

    public function get_department(int $id): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->departments_table} WHERE id = %d", $id), ARRAY_A);
        return is_array($row) ? $this->hydrate_department($row) : null;
    }

    public function get_department_by_slug(string $slug): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->departments_table} WHERE slug = %s AND is_active = 1", $slug), ARRAY_A);
        return is_array($row) ? $this->hydrate_department($row) : null;
    }

    public function save_department(array $data): int
    {
        global $wpdb;

        $id = absint($data['id'] ?? 0);
        $now = current_time('mysql');
        $name = sanitize_text_field((string) ($data['name'] ?? ''));
        $slug = sanitize_title((string) ($data['slug'] ?? $name));
        $email = sanitize_email((string) ($data['email'] ?? ''));

        if ($name === '' || $slug === '' || $email === '') {
            return 0;
        }

        $record = [
            'name' => $name,
            'slug' => $slug,
            'email' => $email,
            'description' => sanitize_textarea_field((string) ($data['description'] ?? '')),
            'sort_order' => (int) ($data['sort_order'] ?? 0),
            'is_active' => empty($data['is_active']) ? 0 : 1,
            'updated_at' => $now,
        ];

        if ($id > 0) {
            $wpdb->update($this->departments_table, $record, ['id' => $id]);
            $this->log('department_updated', 'department', $id, $record);
            return $id;
        }

        $record['created_at'] = $now;
        $wpdb->insert($this->departments_table, $record);
        $new_id = (int) $wpdb->insert_id;
        $this->log('department_created', 'department', $new_id, $record);
        return $new_id;
    }

    public function deactivate_department(int $id): void
    {
        global $wpdb;

        $wpdb->update($this->departments_table, ['is_active' => 0, 'updated_at' => current_time('mysql')], ['id' => $id]);
        $this->log('department_deleted', 'department', $id, []);
    }

    public function get_topics(int $department_id = 0, bool $active_only = false): array
    {
        global $wpdb;

        $where = [];
        $args = [];

        if ($department_id > 0) {
            $where[] = 'department_id = %d';
            $args[] = $department_id;
        }

        if ($active_only) {
            $where[] = 'is_active = 1';
        }

        $sql = "SELECT * FROM {$this->topics_table}";
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY sort_order ASC, title ASC';

        if ($args !== []) {
            $sql = $wpdb->prepare($sql, $args);
        }

        $rows = $wpdb->get_results($sql, ARRAY_A);
        return is_array($rows) ? array_map([$this, 'hydrate_topic'], $rows) : [];
    }

    public function get_topic(int $id): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->topics_table} WHERE id = %d", $id), ARRAY_A);
        return is_array($row) ? $this->hydrate_topic($row) : null;
    }

    public function get_topic_by_slug(int $department_id, string $slug): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->topics_table} WHERE department_id = %d AND slug = %s AND is_active = 1", $department_id, $slug),
            ARRAY_A
        );

        return is_array($row) ? $this->hydrate_topic($row) : null;
    }

    public function save_topic(array $data): int
    {
        global $wpdb;

        $id = absint($data['id'] ?? 0);
        $department_id = absint($data['department_id'] ?? 0);
        $title = sanitize_text_field((string) ($data['title'] ?? ''));
        $slug = sanitize_title((string) ($data['slug'] ?? $title));

        if ($department_id <= 0 || $title === '' || $slug === '') {
            return 0;
        }

        $now = current_time('mysql');
        $fields = $this->normalize_fields(is_array($data['fields'] ?? null) ? $data['fields'] : self::default_fields());
        $record = [
            'department_id' => $department_id,
            'title' => $title,
            'slug' => $slug,
            'email_override' => sanitize_email((string) ($data['email_override'] ?? '')),
            'auto_subject' => sanitize_text_field((string) ($data['auto_subject'] ?? self::default_auto_subject())),
            'auto_body' => sanitize_textarea_field((string) ($data['auto_body'] ?? self::default_auto_body())),
            'auto_html' => wp_kses_post((string) ($data['auto_html'] ?? self::default_auto_html_body())),
            'fields_json' => wp_json_encode($fields),
            'sort_order' => (int) ($data['sort_order'] ?? 0),
            'is_active' => empty($data['is_active']) ? 0 : 1,
            'updated_at' => $now,
        ];

        if ($id > 0) {
            $wpdb->update($this->topics_table, $record, ['id' => $id]);
            $this->log('topic_updated', 'topic', $id, ['department_id' => $department_id, 'title' => $title]);
            return $id;
        }

        $record['created_at'] = $now;
        $wpdb->insert($this->topics_table, $record);
        $new_id = (int) $wpdb->insert_id;
        $this->log('topic_created', 'topic', $new_id, ['department_id' => $department_id, 'title' => $title]);
        return $new_id;
    }

    public function deactivate_topic(int $id): void
    {
        global $wpdb;

        $wpdb->update($this->topics_table, ['is_active' => 0, 'updated_at' => current_time('mysql')], ['id' => $id]);
        $this->log('topic_deleted', 'topic', $id, []);
    }

    public function public_config(?string $department_slug = null, ?string $topic_slug = null): array
    {
        $departments = [];

        foreach ($this->get_departments(true) as $department) {
            if ($department_slug !== null && $department['slug'] !== $department_slug) {
                continue;
            }

            $topics = [];
            foreach ($this->get_topics((int) $department['id'], true) as $topic) {
                if ($topic_slug !== null && $topic['slug'] !== $topic_slug) {
                    continue;
                }

                $topics[] = [
                    'id' => (int) $topic['id'],
                    'title' => $topic['title'],
                    'slug' => $topic['slug'],
                    'fields' => $topic['fields'],
                ];
            }

            if ($topics === []) {
                continue;
            }

            $departments[] = [
                'id' => (int) $department['id'],
                'name' => $department['name'],
                'slug' => $department['slug'],
                'description' => $department['description'],
                'topics' => $topics,
            ];
        }

        return $departments;
    }

    public function generate_ticket_code(): string
    {
        global $wpdb;

        for ($i = 0; $i < 20; $i++) {
            $code = (string) random_int(10000000, 99999999);
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tickets_table} WHERE ticket_code = %s LIMIT 1", $code));
            if ($exists === null) {
                return $code;
            }
        }

        return (string) time();
    }

    public function create_ticket(array $data): int
    {
        global $wpdb;

        $now = current_time('mysql');
        $record = [
            'ticket_code' => sanitize_text_field((string) $data['ticket_code']),
            'department_id' => absint($data['department_id']),
            'topic_id' => absint($data['topic_id']),
            'subject' => sanitize_text_field((string) ($data['subject'] ?? '')),
            'sender_name' => sanitize_text_field((string) ($data['sender_name'] ?? '')),
            'sender_email' => sanitize_email((string) ($data['sender_email'] ?? '')),
            'sender_phone' => sanitize_text_field((string) ($data['sender_phone'] ?? '')),
            'message' => sanitize_textarea_field((string) ($data['message'] ?? '')),
            'fields_json' => wp_json_encode($data['fields'] ?? []),
            'status' => 'open',
            'privacy_accepted' => empty($data['privacy_accepted']) ? 0 : 1,
            'privacy_version' => sanitize_text_field((string) ($data['privacy_version'] ?? '')),
            'privacy_url' => esc_url_raw((string) ($data['privacy_url'] ?? '')),
            'consent_text' => sanitize_textarea_field((string) ($data['consent_text'] ?? '')),
            'ip_address' => sanitize_text_field((string) ($data['ip_address'] ?? '')),
            'visitor_cookie' => sanitize_text_field((string) ($data['visitor_cookie'] ?? '')),
            'browser' => sanitize_text_field((string) ($data['browser'] ?? '')),
            'device_type' => sanitize_text_field((string) ($data['device_type'] ?? '')),
            'user_agent' => sanitize_textarea_field((string) ($data['user_agent'] ?? '')),
            'captcha_required' => empty($data['captcha_required']) ? 0 : 1,
            'created_at' => $now,
            'updated_at' => $now,
        ];

        $wpdb->insert($this->tickets_table, $record);
        $ticket_id = (int) $wpdb->insert_id;

        $this->add_message($ticket_id, 'inbound', $record['sender_email'], (string) ($data['recipient_email'] ?? ''), $record['message'], $data);
        $this->log('ticket_created', 'ticket', $ticket_id, ['ticket_code' => $record['ticket_code']]);

        return $ticket_id;
    }

    public function add_message(int $ticket_id, string $direction, string $from, string $to, string $body, array $raw = []): void
    {
        global $wpdb;

        $wpdb->insert($this->messages_table, [
            'ticket_id' => $ticket_id,
            'direction' => sanitize_key($direction),
            'from_email' => sanitize_email($from),
            'to_email' => sanitize_email($to),
            'body' => sanitize_textarea_field($body),
            'raw_json' => wp_json_encode($raw),
            'created_at' => current_time('mysql'),
        ]);
    }

    public function get_tickets(int $limit = 100): array
    {
        global $wpdb;

        $sql = "SELECT t.*, d.name AS department_name, p.title AS topic_title
            FROM {$this->tickets_table} t
            LEFT JOIN {$this->departments_table} d ON d.id = t.department_id
            LEFT JOIN {$this->topics_table} p ON p.id = t.topic_id
            ORDER BY t.created_at DESC
            LIMIT %d";

        $rows = $wpdb->get_results($wpdb->prepare($sql, max(1, min(500, $limit))), ARRAY_A);
        return is_array($rows) ? array_map([$this, 'hydrate_ticket'], $rows) : [];
    }

    public function has_recent_ticket(string $ip_address, string $email, int $minutes): bool
    {
        global $wpdb;

        $threshold = gmdate('Y-m-d H:i:s', time() - max(1, $minutes) * MINUTE_IN_SECONDS);
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tickets_table} WHERE created_at >= %s AND (ip_address = %s OR sender_email = %s)",
                $threshold,
                $ip_address,
                $email
            )
        );

        return (int) $count > 0;
    }

    public function get_logs(int $limit = 150): array
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->logs_table} ORDER BY created_at DESC LIMIT %d", max(1, min(500, $limit))),
            ARRAY_A
        );

        return is_array($rows) ? $rows : [];
    }

    public function log(string $action, string $object_type, int $object_id, array $context = []): void
    {
        global $wpdb;

        $wpdb->insert($this->logs_table, [
            'actor_id' => get_current_user_id(),
            'action' => sanitize_key($action),
            'object_type' => sanitize_key($object_type),
            'object_id' => $object_id,
            'ip_address' => $this->current_ip(),
            'user_agent' => sanitize_textarea_field((string) ($_SERVER['HTTP_USER_AGENT'] ?? '')),
            'context_json' => wp_json_encode($context),
            'created_at' => current_time('mysql'),
        ]);
    }

    private function seed_defaults(): void
    {
        if ($this->get_departments() !== []) {
            return;
        }

        $settings = $this->get_settings();
        $department_id = $this->save_department([
            'name' => 'Wehrfuehrung',
            'slug' => 'wehrfuehrung',
            'email' => (string) $settings['base_email'],
            'description' => 'Allgemeine Kontaktstelle der Feuerwehr.',
            'is_active' => 1,
        ]);

        if ($department_id > 0) {
            foreach (['Mitglied werden', 'Veranstaltungen', 'Allgemein'] as $index => $title) {
                $this->save_topic([
                    'department_id' => $department_id,
                    'title' => $title,
                    'slug' => sanitize_title($title),
                    'sort_order' => $index,
                    'is_active' => 1,
                    'fields' => self::default_fields(),
                ]);
            }
        }
    }

    private function normalize_fields(array $fields): array
    {
        $normalized = [];

        foreach ($fields as $index => $field) {
            if (! is_array($field)) {
                continue;
            }

            $label = sanitize_text_field((string) ($field['label'] ?? ''));
            $key = sanitize_key((string) ($field['key'] ?? $label));
            if ($label === '' || $key === '') {
                continue;
            }

            $type = sanitize_key((string) ($field['type'] ?? 'text'));
            if (! in_array($type, ['text', 'email', 'tel', 'textarea', 'select', 'file'], true)) {
                $type = 'text';
            }

            $width = sanitize_key((string) ($field['width'] ?? 'full'));
            if (! in_array($width, ['full', 'half', 'third'], true)) {
                $width = 'full';
            }

            $options = [];
            if (isset($field['options'])) {
                $raw_options = is_array($field['options']) ? $field['options'] : preg_split('/[\r\n,;]+/', (string) $field['options']);
                foreach ((array) $raw_options as $option) {
                    $option = sanitize_text_field((string) $option);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            }

            $normalized[] = [
                'key' => $key,
                'label' => $label,
                'type' => $type,
                'width' => $width,
                'required' => ! empty($field['required']),
                'options' => $options,
                'sort_order' => (int) ($field['sort_order'] ?? $index),
            ];
        }

        usort($normalized, static fn(array $a, array $b): int => ($a['sort_order'] <=> $b['sort_order']));

        return $normalized !== [] ? $normalized : self::default_fields();
    }

    private function hydrate_department(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['sort_order'] = (int) $row['sort_order'];
        $row['is_active'] = ! empty($row['is_active']);
        return $row;
    }

    private function hydrate_topic(array $row): array
    {
        $decoded = json_decode((string) ($row['fields_json'] ?? ''), true);
        $row['id'] = (int) $row['id'];
        $row['department_id'] = (int) $row['department_id'];
        $row['sort_order'] = (int) $row['sort_order'];
        $row['is_active'] = ! empty($row['is_active']);
        $row['auto_subject'] = (string) ($row['auto_subject'] ?: self::default_auto_subject());
        $row['auto_body'] = (string) ($row['auto_body'] ?: self::default_auto_body());
        $row['auto_html'] = (string) (($row['auto_html'] ?? '') ?: self::default_auto_html_body());
        $row['fields'] = $this->normalize_fields(is_array($decoded) ? $decoded : self::default_fields());
        return $row;
    }

    private function hydrate_ticket(array $row): array
    {
        $decoded = json_decode((string) ($row['fields_json'] ?? ''), true);
        $row['id'] = (int) $row['id'];
        $row['department_id'] = (int) $row['department_id'];
        $row['topic_id'] = (int) $row['topic_id'];
        $row['privacy_accepted'] = ! empty($row['privacy_accepted']);
        $row['captcha_required'] = ! empty($row['captcha_required']);
        $row['fields'] = is_array($decoded) ? $decoded : [];
        return $row;
    }

    private function current_ip(): string
    {
        $candidates = [
            (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''),
            (string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''),
            (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
        ];

        foreach ($candidates as $candidate) {
            $ip = trim(explode(',', $candidate)[0]);
            if ($ip !== '') {
                return sanitize_text_field($ip);
            }
        }

        return '';
    }
}
