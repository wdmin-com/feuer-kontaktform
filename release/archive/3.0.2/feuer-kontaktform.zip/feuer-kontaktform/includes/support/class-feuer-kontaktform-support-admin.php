<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Admin
{
    private const MENU_SLUG = 'feuer-kontaktform';

    public function __construct(
        private Feuer_Kontaktform_Support_DB $db,
        private Feuer_Kontaktform_Support_Mailer $mailer,
        private Feuer_Kontaktform_Updater $updater
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'handle_actions']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function assets(string $hook): void
    {
        if (! str_contains($hook, 'feuer-kontaktform')) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/css/support-admin.css', [], FEUER_KONTAKTFORM_VERSION);
        wp_enqueue_script('feuer-kontaktform-support-admin', FEUER_KONTAKTFORM_URL . 'assets/js/support-admin.js', [], FEUER_KONTAKTFORM_VERSION, true);
    }

    public function menu(): void
    {
        add_menu_page('Feuer-Kontaktform', 'Feuer-Kontaktform', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page'], 'dashicons-sos', 56);
        add_submenu_page(self::MENU_SLUG, 'Anfragen', 'Anfragen', 'manage_options', self::MENU_SLUG, [$this, 'tickets_page']);
        add_submenu_page(self::MENU_SLUG, 'Abteilungen & Themen', 'Abteilungen & Themen', 'manage_options', 'feuer-kontaktform-departments', [$this, 'departments_page']);
        add_submenu_page(self::MENU_SLUG, 'Einstellungen', 'Einstellungen', 'manage_options', 'feuer-kontaktform-settings', [$this, 'settings_page']);
        add_submenu_page(self::MENU_SLUG, 'Protokolle', 'Protokolle', 'manage_options', 'feuer-kontaktform-logs', [$this, 'logs_page']);
    }

    public function handle_actions(): void
    {
        if (! current_user_can('manage_options') || empty($_POST['feuer_support_action'])) {
            return;
        }

        check_admin_referer('feuer_support_admin');
        $action = sanitize_key((string) wp_unslash($_POST['feuer_support_action']));

        switch ($action) {
            case 'save_settings':
                $settings = $this->sanitize_settings($_POST);
                $this->db->update_settings($settings);
                $this->db->log('settings_saved', 'settings', 0, []);
                $this->redirect('feuer-kontaktform-settings', 'settings_saved');
                break;

            case 'send_test_mail':
                $settings = $this->db->get_settings();
                $target = sanitize_email((string) wp_unslash($_POST['test_email'] ?? get_option('admin_email')));
                $ok = $this->mailer->send_test($settings, $target);
                $this->db->log('test_mail_sent', 'settings', 0, ['target' => $target, 'success' => $ok]);
                $this->redirect('feuer-kontaktform-settings', $ok ? 'test_mail_sent' : 'test_mail_failed');
                break;

            case 'check_updates':
                $status = $this->updater->check_now();
                $this->db->log('update_checked', 'update', 0, $status);
                $this->redirect('feuer-kontaktform-settings', empty($status['error']) ? 'update_checked' : 'update_failed');
                break;

            case 'save_department':
                $id = $this->db->save_department([
                    'id' => absint($_POST['department_id'] ?? 0),
                    'name' => wp_unslash($_POST['department_name'] ?? ''),
                    'slug' => wp_unslash($_POST['department_slug'] ?? ''),
                    'email' => wp_unslash($_POST['department_email'] ?? ''),
                    'description' => wp_unslash($_POST['department_description'] ?? ''),
                    'sort_order' => absint($_POST['department_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['department_is_active']),
                ]);
                $this->redirect('feuer-kontaktform-departments', $id > 0 ? 'department_saved' : 'department_failed');
                break;

            case 'delete_department':
                $this->db->deactivate_department(absint($_POST['department_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'department_deleted');
                break;

            case 'save_topic':
                $id = $this->db->save_topic([
                    'id' => absint($_POST['topic_id'] ?? 0),
                    'department_id' => absint($_POST['department_id'] ?? 0),
                    'title' => wp_unslash($_POST['topic_title'] ?? ''),
                    'slug' => wp_unslash($_POST['topic_slug'] ?? ''),
                    'email_override' => wp_unslash($_POST['topic_email_override'] ?? ''),
                    'auto_reply_enabled' => ! empty($_POST['topic_auto_reply_enabled']),
                    'auto_reply_format' => wp_unslash($_POST['topic_auto_reply_format'] ?? 'html'),
                    'auto_subject' => wp_unslash($_POST['topic_auto_subject'] ?? ''),
                    'auto_body' => wp_unslash($_POST['topic_auto_body'] ?? ''),
                    'auto_html' => wp_unslash($_POST['topic_auto_html'] ?? ''),
                    'sort_order' => absint($_POST['topic_sort_order'] ?? 0),
                    'is_active' => ! empty($_POST['topic_is_active']),
                    'fields' => $this->collect_fields(),
                ]);
                $this->redirect('feuer-kontaktform-departments', $id > 0 ? 'topic_saved' : 'topic_failed');
                break;

            case 'delete_topic':
                $this->db->deactivate_topic(absint($_POST['topic_id'] ?? 0));
                $this->redirect('feuer-kontaktform-departments', 'topic_deleted');
                break;
        }
    }

    public function tickets_page(): void
    {
        $tickets = $this->db->get_tickets(200);
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Feuer-Kontaktform Anfragen</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-card">
                <h2>Letzte Anfragen</h2>
                <p class="description">Die <strong>Anfrage Nr.</strong> gehoert in den Betreff jeder E-Mail-Antwort, damit der Dialog eindeutig zugeordnet werden kann.</p>
                <table class="widefat striped">
                    <thead><tr><th>Anfrage Nr.</th><th>Status</th><th>Abteilung</th><th>Thema</th><th>Absender</th><th>Datenschutz</th><th>IP / Geraet</th><th>Datum</th></tr></thead>
                    <tbody>
                    <?php if ($tickets === []) : ?>
                        <tr><td colspan="8">Noch keine Anfragen vorhanden.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($tickets as $ticket) : ?>
                        <tr>
                            <td><strong><?php echo esc_html((string) $ticket['ticket_code']); ?></strong></td>
                            <td><?php echo esc_html((string) $ticket['status']); ?></td>
                            <td><?php echo esc_html((string) ($ticket['department_name'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) ($ticket['topic_title'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) $ticket['sender_name']); ?><br><a href="mailto:<?php echo esc_attr((string) $ticket['sender_email']); ?>"><?php echo esc_html((string) $ticket['sender_email']); ?></a></td>
                            <td><?php echo ! empty($ticket['privacy_accepted']) ? 'ja' : 'nein'; ?><br><small><?php echo esc_html((string) $ticket['privacy_version']); ?></small></td>
                            <td><?php echo esc_html((string) $ticket['ip_address']); ?><br><small><?php echo esc_html((string) $ticket['device_type']); ?></small></td>
                            <td><?php echo esc_html((string) $ticket['created_at']); ?></td>
                        </tr>
                        <tr class="feuer-ticket-details">
                            <td colspan="8">
                                <strong>Nachricht:</strong> <?php echo esc_html((string) $ticket['message']); ?>
                                <?php if (! empty($ticket['fields'])) : ?>
                                    <div class="feuer-field-dump">
                                        <?php foreach ((array) $ticket['fields'] as $key => $value) : ?>
                                            <span><b><?php echo esc_html((string) $key); ?>:</b> <?php echo esc_html(is_array($value) ? implode(', ', $value) : (string) $value); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function departments_page(): void
    {
        $departments = $this->db->get_departments();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Abteilungen & Themen</h1>
            <?php $this->notice(); ?>
            <p class="description">Jede Abteilung ist eine eigene Support-Route. In den Tabs bearbeiten Sie zuerst Name und E-Mail, danach die einzelnen Themen mit Autoantwort und Feldern.</p>

            <div class="feuer-admin-card">
                <h2>Neue Abteilung</h2>
                <?php $this->department_form(); ?>
            </div>

            <?php foreach ($departments as $department) : ?>
                <div class="feuer-admin-card">
                    <?php $topics = $this->db->get_topics((int) $department['id']); ?>
                    <?php $tab_prefix = 'department-' . (int) $department['id']; ?>
                    <div class="feuer-department-head">
                        <div>
                            <h2><?php echo esc_html((string) $department['name']); ?></h2>
                            <p><code><?php echo esc_html((string) $department['slug']); ?></code> - <?php echo esc_html((string) $department['email']); ?></p>
                        </div>
                        <strong><?php echo esc_html((string) count($topics)); ?> Themen</strong>
                    </div>
                    <div class="feuer-tabs" data-feuer-tabs>
                        <div class="feuer-tab-nav" role="tablist">
                            <button type="button" class="is-active" data-tab-target="<?php echo esc_attr($tab_prefix . '-base'); ?>">Abteilung</button>
                            <?php foreach ($topics as $topic) : ?>
                                <button type="button" data-tab-target="<?php echo esc_attr($tab_prefix . '-topic-' . (int) $topic['id']); ?>"><?php echo esc_html((string) $topic['title']); ?></button>
                            <?php endforeach; ?>
                            <button type="button" data-tab-target="<?php echo esc_attr($tab_prefix . '-new-topic'); ?>">+ Thema</button>
                        </div>
                        <div class="feuer-tab-panel is-active" data-tab-panel="<?php echo esc_attr($tab_prefix . '-base'); ?>">
                            <h3>Abteilung</h3>
                            <p class="description"><strong>Name und E-Mail der Abteilung</strong>. Diese E-Mail wird verwendet, wenn ein Thema keine eigene E-Mail-Adresse hat.</p>
                            <?php $this->department_form($department); ?>
                        </div>
                        <?php foreach ($topics as $topic) : ?>
                            <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix . '-topic-' . (int) $topic['id']); ?>">
                                <?php $this->topic_form($department, $topic); ?>
                            </div>
                        <?php endforeach; ?>
                        <div class="feuer-tab-panel" data-tab-panel="<?php echo esc_attr($tab_prefix . '-new-topic'); ?>">
                            <h3>Neues Thema</h3>
                            <p class="description">Neue Themen starten mit einer Standard-Autoantwort und den Standardfeldern.</p>
                            <?php $this->topic_form($department); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    public function settings_page(): void
    {
        $settings = $this->db->get_settings();
        $update = $this->updater->get_status();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Einstellungen</h1>
            <?php $this->notice(); ?>
            <div class="feuer-admin-card">
                <div class="feuer-tabs" data-feuer-tabs>
                    <div class="feuer-tab-nav" role="tablist">
                        <button type="button" class="is-active" data-tab-target="settings-brand">Website & Logo</button>
                        <button type="button" data-tab-target="settings-mail">E-Mail</button>
                        <button type="button" data-tab-target="settings-privacy">Datenschutz</button>
                        <button type="button" data-tab-target="settings-system">System</button>
                        <button type="button" data-tab-target="settings-shortcodes">Shortcodes</button>
                    </div>

                    <div class="feuer-tab-panel is-active" data-tab-panel="settings-brand">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>Website & Logo</h2>
                            <?php $this->input('site_name', 'Name der Website', $settings['site_name']); ?>
                            <label>
                                Logo
                                <div class="feuer-media-picker">
                                    <input class="regular-text" type="url" name="logo_url" value="<?php echo esc_attr((string) $settings['logo_url']); ?>" data-media-url>
                                    <button type="button" class="button" data-media-select>Bild aus Mediathek waehlen</button>
                                    <button type="button" class="button" data-media-clear>Entfernen</button>
                                </div>
                                <span class="description">Das Logo wird in der Kontaktstrecke und in HTML-Autoantworten verwendet.</span>
                                <img class="feuer-logo-preview" src="<?php echo esc_url((string) $settings['logo_url']); ?>" alt="" data-media-preview<?php echo (string) $settings['logo_url'] === '' ? ' hidden' : ''; ?>>
                            </label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-mail">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>E-Mail</h2>
                            <div class="feuer-form-grid">
                                <?php $this->input('base_email', 'Basis E-Mail', $settings['base_email'], 'email'); ?>
                                <?php $this->input('from_email', 'Absender E-Mail', $settings['from_email'], 'email'); ?>
                                <?php $this->input('from_name', 'Absender Name', $settings['from_name']); ?>
                            </div>
                            <p class="description">Der Versand nutzt den WordPress-Mailweg. SMTP-Zugangsdaten sollten ueber eine sichere Server- oder SMTP-Konfiguration verwaltet werden.</p>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                        <form method="post" class="feuer-subform">
                            <h3>E-Mail Verbindung pruefen</h3>
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="send_test_mail">
                            <?php $this->input('test_email', 'Test Empfaenger', get_option('admin_email'), 'email'); ?>
                            <p><button class="button">Testmail senden</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-privacy">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>Datenschutz</h2>
                            <?php $this->input('privacy_url', 'URL zur Datenschutzerklaerung', $settings['privacy_url'], 'url'); ?>
                            <label>Text fuer Datenschutzhinweis<textarea name="privacy_text" rows="5" class="large-text"><?php echo esc_textarea((string) $settings['privacy_text']); ?></textarea></label>
                            <?php $this->input('privacy_version', 'Datenschutz-Version', $settings['privacy_version']); ?>
                            <label>Text nach erfolgreichem Versand<textarea name="ticket_success_text" rows="4" class="large-text"><?php echo esc_textarea((string) $settings['ticket_success_text']); ?></textarea></label>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-system">
                        <form method="post">
                            <?php wp_nonce_field('feuer_support_admin'); ?>
                            <input type="hidden" name="feuer_support_action" value="save_settings">
                            <h2>System</h2>
                            <?php $this->input('rate_limit_minutes', 'Captcha nach Wiederholung innerhalb Minuten', $settings['rate_limit_minutes'], 'number'); ?>
                            <p><button class="button button-primary">Speichern</button></p>
                        </form>
                        <div class="feuer-subform">
                            <h3>Plugin Update</h3>
                            <p>Entwickler-URL: <code><?php echo esc_html((string) $update['base_url']); ?></code></p>
                            <p>Installiert: <strong><?php echo esc_html((string) $update['current_version']); ?></strong></p>
                            <p>Server: <strong><?php echo esc_html((string) $update['remote_version']); ?></strong></p>
                            <?php if (! empty($update['error'])) : ?><p class="notice notice-error inline"><?php echo esc_html((string) $update['error']); ?></p><?php endif; ?>
                            <form method="post">
                                <?php wp_nonce_field('feuer_support_admin'); ?>
                                <input type="hidden" name="feuer_support_action" value="check_updates">
                                <button class="button button-primary">Update pruefen</button>
                            </form>
                        </div>
                    </div>

                    <div class="feuer-tab-panel" data-tab-panel="settings-shortcodes">
                        <h2>Shortcodes</h2>
                        <p><code>[feuer-kontaktform]</code> kompletter Wizard.</p>
                        <p><code>[feuer-kontaktform department="wehrfuehrung"]</code> direkt zu einer Abteilung.</p>
                        <p><code>[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]</code> direkt zu einem Thema.</p>
                        <p><code>[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]</code> schnelle klassische Form.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function logs_page(): void
    {
        $logs = $this->db->get_logs();
        ?>
        <div class="wrap feuer-support-admin">
            <h1>Protokolle</h1>
            <div class="feuer-admin-card">
                <h2>Aktivitaeten im Plugin</h2>
                <p class="description">Hier steht in normaler Sprache, was im Plugin passiert ist: Einstellungen, Abteilungen, Themen, Update-Pruefungen und neue Anfragen.</p>
                <div class="feuer-log-list">
                    <?php if ($logs === []) : ?>
                        <p>Noch keine Protokolle vorhanden.</p>
                    <?php endif; ?>
                    <?php foreach ($logs as $log) : ?>
                        <?php $user = ! empty($log['actor_id']) ? get_user_by('id', (int) $log['actor_id']) : null; ?>
                        <article class="feuer-log-item">
                            <div class="feuer-log-main">
                                <strong><?php echo esc_html($this->log_action_label((string) $log['action'])); ?></strong>
                                <span><?php echo esc_html($this->object_type_label((string) $log['object_type'])); ?><?php echo ! empty($log['object_id']) ? ' #' . esc_html((string) $log['object_id']) : ''; ?></span>
                            </div>
                            <div class="feuer-log-meta">
                                <span><?php echo esc_html((string) $log['created_at']); ?></span>
                                <span>Admin: <?php echo esc_html($user ? $user->user_login : ((int) $log['actor_id'] > 0 ? '#' . (string) $log['actor_id'] : 'System')); ?></span>
                                <span>IP: <?php echo esc_html((string) $log['ip_address']); ?></span>
                            </div>
                            <?php $context = $this->format_context((string) ($log['context_json'] ?? '')); ?>
                            <?php if ($context !== '') : ?><p class="feuer-log-context"><?php echo esc_html($context); ?></p><?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    private function log_action_label(string $action): string
    {
        $labels = [
            'settings_saved' => 'Einstellungen gespeichert',
            'test_mail_sent' => 'Testmail gesendet',
            'update_checked' => 'Update geprueft',
            'department_created' => 'Abteilung erstellt',
            'department_updated' => 'Abteilung bearbeitet',
            'department_deleted' => 'Abteilung deaktiviert',
            'default_department_created' => 'Standard-Abteilung angelegt',
            'topic_created' => 'Thema erstellt',
            'topic_updated' => 'Thema bearbeitet',
            'topic_deleted' => 'Thema deaktiviert',
            'ticket_created' => 'Neue Anfrage gespeichert',
        ];

        return $labels[$action] ?? $action;
    }

    private function object_type_label(string $type): string
    {
        $labels = [
            'settings' => 'Einstellungen',
            'update' => 'Update',
            'department' => 'Abteilung',
            'topic' => 'Thema',
            'ticket' => 'Anfrage',
        ];

        return $labels[$type] ?? ($type !== '' ? $type : 'Plugin');
    }

    private function format_context(string $json): string
    {
        $decoded = json_decode($json, true);
        if (! is_array($decoded) || $decoded === []) {
            return '';
        }

        $parts = [];
        foreach ($decoded as $key => $value) {
            if (is_array($value)) {
                $value = wp_json_encode($value);
            } elseif (is_bool($value)) {
                $value = $value ? 'ja' : 'nein';
            }

            $parts[] = (string) $key . ': ' . (string) $value;
        }

        return implode(' | ', $parts);
    }

    private function department_form(?array $department = null): void
    {
        $department = $department ?? ['id' => 0, 'name' => '', 'slug' => '', 'email' => '', 'description' => '', 'sort_order' => 0, 'is_active' => true];
        ?>
        <form method="post" class="feuer-inline-form">
            <?php wp_nonce_field('feuer_support_admin'); ?>
            <input type="hidden" name="feuer_support_action" value="save_department">
            <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
            <div class="feuer-form-grid">
                <?php $this->input('department_name', 'Name', $department['name']); ?>
                <?php $this->input('department_slug', 'Kurzname / Slug', $department['slug']); ?>
                <?php $this->input('department_email', 'E-Mail Empfaenger', $department['email'], 'email'); ?>
                <?php $this->input('department_sort_order', 'Sortierung', $department['sort_order'], 'number'); ?>
            </div>
            <label>Beschreibung<textarea class="large-text" name="department_description" rows="2"><?php echo esc_textarea((string) $department['description']); ?></textarea></label>
            <label><input type="checkbox" name="department_is_active" value="1" <?php checked(! empty($department['is_active'])); ?>> aktiv</label>
            <p><button class="button button-primary">Abteilung speichern</button></p>
        </form>
        <?php if ((int) $department['id'] > 0) : ?>
            <form method="post">
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="delete_department">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <button class="button button-link-delete">Abteilung deaktivieren</button>
            </form>
        <?php endif; ?>
        <?php
    }

    private function topic_form(array $department, ?array $topic = null): void
    {
        $topic = $topic ?? [
            'id' => 0,
            'department_id' => (int) $department['id'],
            'title' => '',
            'slug' => '',
            'email_override' => '',
            'auto_reply_enabled' => true,
            'auto_reply_format' => 'html',
            'auto_subject' => Feuer_Kontaktform_Support_DB::default_auto_subject(),
            'auto_body' => Feuer_Kontaktform_Support_DB::default_auto_body(),
            'auto_html' => Feuer_Kontaktform_Support_DB::default_auto_html_body(),
            'sort_order' => 0,
            'is_active' => true,
            'fields' => Feuer_Kontaktform_Support_DB::default_fields(),
        ];
        ?>
        <div class="feuer-topic-box">
            <h3><?php echo (int) $topic['id'] > 0 ? esc_html((string) $topic['title']) : 'Neues Thema konfigurieren'; ?></h3>
            <form method="post" data-topic-form>
                <?php wp_nonce_field('feuer_support_admin'); ?>
                <input type="hidden" name="feuer_support_action" value="save_topic">
                <input type="hidden" name="department_id" value="<?php echo esc_attr((string) $department['id']); ?>">
                <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                <div class="feuer-form-grid">
                    <?php $this->input('topic_title', 'Thema', $topic['title']); ?>
                    <?php $this->input('topic_slug', 'Kurzname / Slug', $topic['slug']); ?>
                    <?php $this->input('topic_email_override', 'E-Mail falls abweichend', $topic['email_override'], 'email'); ?>
                    <?php $this->input('topic_sort_order', 'Sortierung', $topic['sort_order'], 'number'); ?>
                </div>
                <div class="feuer-topic-auto-controls">
                    <label class="feuer-check-label"><input type="checkbox" name="topic_auto_reply_enabled" value="1" <?php checked(! empty($topic['auto_reply_enabled'])); ?>> Autoantwort fuer dieses Thema senden</label>
                    <div class="feuer-radio-row">
                        <span>Antwortformat</span>
                        <label><input type="radio" name="topic_auto_reply_format" value="text" <?php checked((string) ($topic['auto_reply_format'] ?? 'html'), 'text'); ?>> Text</label>
                        <label><input type="radio" name="topic_auto_reply_format" value="html" <?php checked((string) ($topic['auto_reply_format'] ?? 'html'), 'html'); ?>> HTML</label>
                    </div>
                </div>
                <?php $this->input('topic_auto_subject', 'Autoantwort Betreff', $topic['auto_subject']); ?>
                <div class="feuer-auto-reply-grid">
                    <label>
                        Autoantwort Text
                        <span class="description">Plain-Text Fallback fuer einfache Mailprogramme.</span>
                        <textarea class="large-text code" name="topic_auto_body" rows="11"><?php echo esc_textarea((string) $topic['auto_body']); ?></textarea>
                    </label>
                    <label>
                        Autoantwort HTML
                        <span class="description">Formatierte E-Mail mit Logo, Website-Name, Anfrage Nr. und Datenschutzlink.</span>
                        <textarea class="large-text code" name="topic_auto_html" rows="16"><?php echo esc_textarea((string) ($topic['auto_html'] ?? Feuer_Kontaktform_Support_DB::default_auto_html_body())); ?></textarea>
                    </label>
                </div>
                <?php $this->auto_reply_macro_help(); ?>
                <label><input type="checkbox" name="topic_is_active" value="1" <?php checked(! empty($topic['is_active'])); ?>> aktiv</label>
                <h4>Felder fuer dieses Thema</h4>
                <div data-fields-list>
                    <?php foreach ((array) $topic['fields'] as $field) : ?>
                        <?php $this->field_row($field); ?>
                    <?php endforeach; ?>
                </div>
                <p><button type="button" class="button" data-add-field>Feld hinzufuegen</button></p>
                <p><button class="button button-primary">Thema speichern</button></p>
            </form>
            <?php if ((int) $topic['id'] > 0) : ?>
                <form method="post">
                    <?php wp_nonce_field('feuer_support_admin'); ?>
                    <input type="hidden" name="feuer_support_action" value="delete_topic">
                    <input type="hidden" name="topic_id" value="<?php echo esc_attr((string) $topic['id']); ?>">
                    <button class="button button-link-delete">Thema deaktivieren</button>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    private function field_row(array $field): void
    {
        ?>
        <div class="feuer-field-row" data-field-row>
            <input name="topic_fields[key][]" value="<?php echo esc_attr((string) ($field['key'] ?? '')); ?>" placeholder="key">
            <input name="topic_fields[label][]" value="<?php echo esc_attr((string) ($field['label'] ?? '')); ?>" placeholder="Label">
            <select name="topic_fields[type][]">
                <?php foreach (['text', 'email', 'tel', 'textarea', 'select', 'file'] as $type) : ?>
                    <option value="<?php echo esc_attr($type); ?>" <?php selected((string) ($field['type'] ?? 'text'), $type); ?>><?php echo esc_html($type); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="topic_fields[width][]">
                <?php foreach (['full', 'half', 'third'] as $width) : ?>
                    <option value="<?php echo esc_attr($width); ?>" <?php selected((string) ($field['width'] ?? 'full'), $width); ?>><?php echo esc_html($width); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="topic_fields[required][]" value="<?php echo ! empty($field['required']) ? '1' : '0'; ?>" data-required-hidden>
            <label><input type="checkbox" value="1" data-required-checkbox <?php checked(! empty($field['required'])); ?>> Pflicht</label>
            <input name="topic_fields[options][]" value="<?php echo esc_attr(implode(', ', (array) ($field['options'] ?? []))); ?>" placeholder="Optionen bei select">
            <button type="button" class="button" data-remove-field>Entfernen</button>
        </div>
        <?php
    }

    private function auto_reply_macro_help(): void
    {
        ?>
        <div class="feuer-macro-help">
            <h4>Shortcodes fuer Autoantworten</h4>
            <p class="description">Diese Platzhalter koennen im Betreff, im Text und in der HTML-Vorlage verwendet werden.</p>
            <div class="feuer-macro-grid">
                <?php foreach (Feuer_Kontaktform_Support_DB::auto_reply_macros() as $macro => $description) : ?>
                    <div><code><?php echo esc_html($macro); ?></code><span><?php echo esc_html($description); ?></span></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private function collect_fields(): array
    {
        $input = isset($_POST['topic_fields']) && is_array($_POST['topic_fields']) ? wp_unslash($_POST['topic_fields']) : [];
        $labels = is_array($input['label'] ?? null) ? $input['label'] : [];
        $fields = [];

        foreach ($labels as $index => $label) {
            $fields[] = [
                'key' => (string) (($input['key'][$index] ?? '') ?: $label),
                'label' => (string) $label,
                'type' => (string) ($input['type'][$index] ?? 'text'),
                'width' => (string) ($input['width'][$index] ?? 'full'),
                'required' => ! empty($input['required'][$index]),
                'options' => (string) ($input['options'][$index] ?? ''),
                'sort_order' => $index,
            ];
        }

        return $fields;
    }

    private function sanitize_settings(array $source): array
    {
        $defaults = $this->db->get_settings();
        return [
            'site_name' => sanitize_text_field((string) wp_unslash($source['site_name'] ?? $defaults['site_name'])),
            'logo_url' => esc_url_raw((string) wp_unslash($source['logo_url'] ?? '')),
            'base_email' => sanitize_email((string) wp_unslash($source['base_email'] ?? $defaults['base_email'])),
            'from_email' => sanitize_email((string) wp_unslash($source['from_email'] ?? $defaults['from_email'])),
            'from_name' => sanitize_text_field((string) wp_unslash($source['from_name'] ?? $defaults['from_name'])),
            'privacy_url' => esc_url_raw((string) wp_unslash($source['privacy_url'] ?? '')),
            'privacy_text' => sanitize_textarea_field((string) wp_unslash($source['privacy_text'] ?? $defaults['privacy_text'])),
            'privacy_version' => sanitize_text_field((string) wp_unslash($source['privacy_version'] ?? $defaults['privacy_version'])),
            'ticket_success_text' => sanitize_textarea_field((string) wp_unslash($source['ticket_success_text'] ?? $defaults['ticket_success_text'])),
            'rate_limit_minutes' => max(1, absint($source['rate_limit_minutes'] ?? $defaults['rate_limit_minutes'])),
        ];
    }

    private function input(string $name, string $label, $value, string $type = 'text'): void
    {
        ?>
        <label><?php echo esc_html($label); ?><input class="regular-text" type="<?php echo esc_attr($type); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) $value); ?>"></label>
        <?php
    }

    private function redirect(string $page, string $message): void
    {
        wp_safe_redirect(add_query_arg(['page' => $page, 'feuer-message' => $message], admin_url('admin.php')));
        exit;
    }

    private function notice(): void
    {
        $message = sanitize_key((string) ($_GET['feuer-message'] ?? ''));
        if ($message === '') {
            return;
        }

        $labels = [
            'settings_saved' => 'Einstellungen gespeichert.',
            'test_mail_sent' => 'Testmail wurde gesendet.',
            'test_mail_failed' => 'Testmail konnte nicht gesendet werden.',
            'update_checked' => 'Update-Pruefung wurde ausgefuehrt.',
            'update_failed' => 'Update-Pruefung fehlgeschlagen.',
            'department_saved' => 'Abteilung gespeichert.',
            'department_failed' => 'Abteilung konnte nicht gespeichert werden.',
            'department_deleted' => 'Abteilung wurde deaktiviert.',
            'topic_saved' => 'Thema gespeichert.',
            'topic_failed' => 'Thema konnte nicht gespeichert werden.',
            'topic_deleted' => 'Thema wurde deaktiviert.',
        ];

        if (! isset($labels[$message])) {
            return;
        }

        $type = str_contains($message, 'failed') ? 'error' : 'success';
        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($labels[$message]) . '</p></div>';
    }
}
