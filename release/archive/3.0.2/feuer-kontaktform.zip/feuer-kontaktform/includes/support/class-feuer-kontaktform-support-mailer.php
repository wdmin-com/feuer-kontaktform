<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

final class Feuer_Kontaktform_Support_Mailer
{
    public function __construct(private Feuer_Kontaktform_Support_DB $db)
    {
    }

    public function send_ticket(array $ticket, array $department, array $topic, array $settings): array
    {
        $recipient = sanitize_email((string) ($topic['email_override'] ?: $department['email']));
        if ($recipient === '') {
            return ['success' => false, 'message' => 'Kein Empfaenger fuer diese Abteilung konfiguriert.'];
        }

        $headers = $this->headers($settings, (string) ($ticket['sender_email'] ?? ''));
        $subject = '[Anfrage Nr. ' . (string) $ticket['ticket_code'] . '] ' . (string) ($topic['title'] ?? 'Kontaktanfrage');
        $body = $this->notification_body($ticket, $department, $topic, $settings);

        $sent = wp_mail($recipient, $subject, $body, $headers);
        if (! $sent) {
            return ['success' => false, 'message' => 'Die Benachrichtigung konnte nicht gesendet werden.'];
        }

        $reply_email = sanitize_email((string) ($ticket['sender_email'] ?? ''));
        if ($reply_email !== '' && ! empty($topic['auto_reply_enabled'])) {
            $auto_subject = $this->replace_macros((string) ($topic['auto_subject'] ?: Feuer_Kontaktform_Support_DB::default_auto_subject()), $ticket, $department, $topic, $settings, false);
            $auto_body = $this->replace_macros((string) ($topic['auto_body'] ?: Feuer_Kontaktform_Support_DB::default_auto_body()), $ticket, $department, $topic, $settings, false);
            $auto_html = trim((string) ($topic['auto_html'] ?? ''));
            $format = (string) ($topic['auto_reply_format'] ?? 'html');

            if ($format === 'html' && $auto_html !== '') {
                $auto_html = $this->replace_macros($auto_html, $ticket, $department, $topic, $settings, true);
                wp_mail($reply_email, $auto_subject, $auto_html, $this->headers($settings, '', true));
            } else {
                wp_mail($reply_email, $auto_subject, $auto_body, $this->headers($settings));
            }
        }

        return ['success' => true, 'message' => 'E-Mail wurde gesendet.', 'recipient' => $recipient];
    }

    public function send_test(array $settings, string $target_email): bool
    {
        $target = sanitize_email($target_email);
        if ($target === '') {
            return false;
        }

        $subject = 'Feuer-Kontaktform Testmail';
        $body = "Diese Testmail wurde ueber WordPress wp_mail() gesendet.\n\nWenn diese Nachricht ankommt, ist der konfigurierte Versandweg grundsaetzlich erreichbar.";
        return wp_mail($target, $subject, $body, $this->headers($settings));
    }

    private function notification_body(array $ticket, array $department, array $topic, array $settings): string
    {
        $lines = [
            'Neue Anfrage ueber Feuer-Kontaktform',
            '',
            'Anfrage Nr.: ' . (string) $ticket['ticket_code'],
            'Abteilung: ' . (string) ($department['name'] ?? ''),
            'Thema: ' . (string) ($topic['title'] ?? ''),
            'Name: ' . (string) ($ticket['sender_name'] ?? ''),
            'E-Mail: ' . (string) ($ticket['sender_email'] ?? ''),
            'Telefon: ' . (string) ($ticket['sender_phone'] ?? ''),
            '',
            'Nachricht:',
            (string) ($ticket['message'] ?? ''),
            '',
            'Zusatzfelder:',
        ];

        foreach ((array) ($ticket['fields'] ?? []) as $key => $value) {
            if (is_array($value)) {
                $value = implode(', ', array_map('strval', $value));
            }

            $lines[] = (string) $key . ': ' . (string) $value;
        }

        $lines[] = '';
        $lines[] = 'Datenschutz bestaetigt: ' . (! empty($ticket['privacy_accepted']) ? 'Ja' : 'Nein');
        $lines[] = 'Datenschutz-Version: ' . (string) ($ticket['privacy_version'] ?? '');
        $lines[] = 'Datenschutzerklaerung: ' . (string) ($settings['privacy_url'] ?? '');
        $lines[] = 'IP-Adresse: ' . (string) ($ticket['ip_address'] ?? '');
        $lines[] = 'Cookie-ID: ' . (string) ($ticket['visitor_cookie'] ?? '');
        $lines[] = 'Geraet: ' . (string) ($ticket['device_type'] ?? '');
        $lines[] = 'Browser: ' . (string) ($ticket['browser'] ?? '');
        $lines[] = 'User-Agent: ' . (string) ($ticket['user_agent'] ?? '');

        return implode("\n", $lines);
    }

    private function replace_macros(string $text, array $ticket, array $department, array $topic, array $settings, bool $html): string
    {
        $fields = is_array($ticket['fields'] ?? null) ? $ticket['fields'] : [];
        $site_name = (string) ($settings['site_name'] ?? get_bloginfo('name'));
        $logo_url = esc_url_raw((string) ($settings['logo_url'] ?? ''));
        $privacy_url = esc_url_raw((string) ($settings['privacy_url'] ?? ''));
        $logo_html = $logo_url !== ''
            ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($site_name) . '" style="max-width:150px;max-height:72px;margin:0 0 14px 0;display:block;">'
            : '';
        $macros = [
            '{{ticket}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{ticket_id}}' => (string) ($ticket['ticket_code'] ?? ''),
            '{{site_name}}' => $site_name,
            '{{logo_url}}' => $logo_url,
            '{{logo_html}}' => $logo_html,
            '{{privacy_url}}' => $privacy_url,
            '{{department}}' => (string) ($department['name'] ?? ''),
            '{{topic}}' => (string) ($topic['title'] ?? ''),
            '{{name}}' => (string) ($ticket['sender_name'] ?? ''),
            '{{email}}' => (string) ($ticket['sender_email'] ?? ''),
            '{{vorname}}' => (string) ($fields['vorname'] ?? ''),
            '{{nachname}}' => (string) ($fields['nachname'] ?? ''),
            '{{telefon}}' => (string) ($fields['telefon'] ?? ''),
        ];

        if (! $html) {
            $macros['{{logo_html}}'] = $logo_url;
            return strtr($text, $macros);
        }

        $safe = [];
        foreach ($macros as $macro => $value) {
            $safe[$macro] = $macro === '{{logo_html}}' ? $value : esc_html($value);
        }

        return wp_kses_post(strtr($text, $safe));
    }

    private function headers(array $settings, string $reply_to = '', bool $html = false): array
    {
        $from_email = sanitize_email((string) ($settings['from_email'] ?? get_option('admin_email')));
        $from_name = sanitize_text_field((string) ($settings['from_name'] ?? get_bloginfo('name')));
        $headers = [
            'Content-Type: ' . ($html ? 'text/html' : 'text/plain') . '; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];

        $reply = sanitize_email($reply_to);
        if ($reply !== '') {
            $headers[] = 'Reply-To: ' . $reply;
        }

        return $headers;
    }
}
