# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin fР“Сr Support- und Anfrage-Kommunikation auf Websites freiwilliger Feuerwehren. Jede Anfrage wird Р“Сber einen AJAX-Wizard erfasst, bekommt eine 8-stellige Anfrage Nr. und wird per E-Mail an die passende Abteilung oder das passende Thema weitergeleitet.

Mindestanforderung: WordPress 6.9 und PHP 8.0.

Status: Version 3.0.15 ist die erste finale stabile Version des neuen Plugins. Version 3.0.39 ist die aktuelle stabile Version. Abteilungen kР“В¶nnen Anfragen Р“Сber einen geschР“Сtzten Link Р“В¶ffnen, den Verlauf ansehen und direkt antworten. Ein optionales Ticket-Postfach wie `anfrage@domain.de` importiert Antworten per IMAP und kann neue, direkt an dieses Postfach gesendete E-Mails automatisch als Anfrage erfassen.

## Funktionen

- Mehrstufiger AJAX-Wizard mit Datenschutz, Abteilung, Thema, dynamischen Feldern, Captcha und Abschlussmeldung.
- Datenschutz-Schritt kann in den Einstellungen aktiviert oder deaktiviert werden.
- Abteilungen mit Name, Kurzname und EmpfР“В¤nger-E-Mail.
- Themen je Abteilung mit optional eigener E-Mail, Autoantwort und eigenen Pflichtfeldern.
- Shortcodes werden allgemein in den Einstellungen und direkt je Abteilung angezeigt.
- Autoantworten pro Thema als Plain-Text und HTML-Vorlage mit Logo, Website-Name, Anfrage Nr. und Makros.
- Mehrere Frontend-Designvarianten und Feldstile fР“Сr die Kontaktstrecke.
- Zustellbarkeits-Einstellungen fР“Сr SPF/DMARC/DKIM-Hinweise, Reply-To-Strategien, SMTP-Versand und Autoantwort-Header.
- 8-stellige zufР“В¤llige Anfrage Nr. fР“Сr jede Anfrage.
- Anfrageprotokoll mit aufklappbarer Detailansicht, Verlauf und Antwortfunktion per E-Mail.
- WordPress Privacy Export/Erase fР“Сr personenbezogene Anfrage-Daten.
- Konfigurierbare Dateiformate und Upload-GrР“В¶Р“Сџen fР“Сr Datei-Felder.
- Admin-Protokoll fР“Сr Einstellungen, Abteilungen, Themen, Testmails, Updates und Anfrage-Erstellung.
- E-Mail-Test Р“Сber den konfigurierten WordPress-Mailweg oder den SMTP-Zugang des Plugins.
- EmpfangsbestР“В¤tigung fР“Сr Abteilungs-E-Mails mit signiertem Link, Versandstatus und Wiederholungsfunktion.
- GeschР“Сtzte Anfrageansicht fР“Сr die Abteilung mit Feldern, Verlauf, EmpfangsbestР“В¤tigung und Antwortformular.
- Bidirektionales Ticket-Postfach Р“Сber IMAP fР“Сr Antworten von Besuchern und Abteilungen.
- Direkte E-Mail-Anfragen ohne bestehende Anfrage Nr. mit automatischer Nummer, Verlauf und Weiterleitung an einen Standard-EmpfР“В¤nger.
- GeschР“Сtzter Browserdialog und E-Mail-Antwortweg auch fР“Сr direkt eingegangene E-Mails.
- Kurze nicht erratbare Zugriffscodes mit Cookie-Sitzung fР“Сr den geschР“Сtzten Browserdialog.
- ZuverlР“В¤ssige WP-Cron-Planung und Statusanzeige fР“Сr die automatische PostfachprР“Сfung.
- Sichere Plus-Adressen pro Anfrage zur PrР“Сfung des eingehenden E-Mail-Dialogs.
- Detaillierte Fehlerprotokolle fР“Сr Testmails, Abteilungs-E-Mails, Autoantworten und Antworten aus dem Plugin.
- JSON-Sicherung und Wiederherstellung fР“Сr Einstellungen, EmpfР“В¤nger-E-Mails, Abteilungen, Themen, Anfragen, Nachrichten und Protokolle.
- Self-hosted Updates Р“Сber `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## E-Mail-Zustellbarkeit

Der Plugin-Absender sollte eine Adresse der eigenen Domain sein, zum Beispiel `kontakt@wdmin.com`. FР“Сr diese Domain sollten SPF, DKIM und DMARC beim DNS-Anbieter gesetzt sein. Im WordPress-Backend zeigt der Tab `Zustellbarkeit`, welche Punkte konfiguriert sind und welche noch offen sind.

Autoantworten enthalten optional technische Header gegen automatische Antwortschleifen. Bei aktivem Ticket-Postfach wird `Reply-To` automatisch auf die sichere Anfrage-Adresse gesetzt. Ohne Ticket-Postfach gelten weiterhin die konfigurierten Reply-To-Regeln fР“Сr Abteilung oder Basisadresse.

## Ticket-Postfach

FР“Сr einen vollstР“В¤ndigen E-Mail-Dialog kann ein eigenes Postfach wie `anfrage@domain.de` eingerichtet werden. Das Plugin verwendet SMTP fР“Сr ausgehende Nachrichten und IMAP fР“Сr eingehende Antworten. Der Mailanbieter muss Plus-Adressierung oder Catch-all unterstР“Сtzen, damit sichere Adressen wie `anfrage+fkt-12345678-securecode@domain.de` im selben Postfach ankommen. Auf dem Webserver muss die PHP-Erweiterung `imap` aktiviert sein.

Optional kР“В¶nnen neue E-Mails ohne Anfrage Nr., die direkt an `anfrage@domain.de` gesendet werden, automatisch als neue Anfrage angelegt werden. Unter `Einstellungen РІвЂ вЂ™ Ticket-Postfach` wird dafР“Сr ein Standard-EmpfР“В¤nger festgelegt. Dieser erhР“В¤lt die weitergeleitete Nachricht und einen zeitlich begrenzten Browserlink. Ticket-Postfach und Standard-EmpfР“В¤nger mР“Сssen unterschiedliche E-Mail-Adressen sein.

Der lesbare Textinhalt direkter E-Mails wird Р“Сbernommen. E-Mail-AnhР“В¤nge werden in Version 3.0.34 noch nicht in den Anfrageverlauf importiert.

Die automatische PostfachprР“Сfung lР“В¤uft Р“Сber WordPress-Cron alle fР“Сnf Minuten. Wenn `DISABLE_WP_CRON` auf dem Server aktiv ist, muss der Server-Cron regelmР“В¤Р“Сџig `wp-cron.php` aufrufen.

## Shortcodes

```text
[feuer-kontaktform]
[feuer-kontaktform department="wehrfuehrung"]
[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]
[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket wird mit `tools/build-release.ps1` erzeugt. Der Builder schreibt keine Ordner-EintrР“В¤ge in das ZIP, setzt `ExternalAttributes` auf `0`, schreibt keine ZIP extra fields und vermeidet dadurch Windows-Owner/ACL-Metadaten. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
