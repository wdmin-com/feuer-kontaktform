﻿# Feuer-Kontaktform

Feuer-Kontaktform ist ein WordPress-Plugin fГјr Support- und Anfrage-Kommunikation auf Websites freiwilliger Feuerwehren. Jede Anfrage wird Гјber einen AJAX-Wizard erfasst, bekommt eine 8-stellige Anfrage Nr. und wird per E-Mail an die passende Abteilung oder das passende Thema weitergeleitet.

Mindestanforderung: WordPress 6.9 und PHP 8.0.

Status: Version 3.0.15 ist die erste finale stabile Version des neuen Plugins. Version 3.0.37 ist die aktuelle stabile Version. Abteilungen kГ¶nnen Anfragen Гјber einen geschГјtzten Link Г¶ffnen, den Verlauf ansehen und direkt antworten. Ein optionales Ticket-Postfach wie `anfrage@domain.de` importiert Antworten per IMAP und kann neue, direkt an dieses Postfach gesendete E-Mails automatisch als Anfrage erfassen.

## Funktionen

- Mehrstufiger AJAX-Wizard mit Datenschutz, Abteilung, Thema, dynamischen Feldern, Captcha und Abschlussmeldung.
- Datenschutz-Schritt kann in den Einstellungen aktiviert oder deaktiviert werden.
- Abteilungen mit Name, Kurzname und EmpfГ¤nger-E-Mail.
- Themen je Abteilung mit optional eigener E-Mail, Autoantwort und eigenen Pflichtfeldern.
- Shortcodes werden allgemein in den Einstellungen und direkt je Abteilung angezeigt.
- Autoantworten pro Thema als Plain-Text und HTML-Vorlage mit Logo, Website-Name, Anfrage Nr. und Makros.
- Mehrere Frontend-Designvarianten und Feldstile fГјr die Kontaktstrecke.
- Zustellbarkeits-Einstellungen fГјr SPF/DMARC/DKIM-Hinweise, Reply-To-Strategien, SMTP-Versand und Autoantwort-Header.
- 8-stellige zufГ¤llige Anfrage Nr. fГјr jede Anfrage.
- Anfrageprotokoll mit aufklappbarer Detailansicht, Verlauf und Antwortfunktion per E-Mail.
- WordPress Privacy Export/Erase fГјr personenbezogene Anfrage-Daten.
- Konfigurierbare Dateiformate und Upload-GrГ¶Гџen fГјr Datei-Felder.
- Admin-Protokoll fГјr Einstellungen, Abteilungen, Themen, Testmails, Updates und Anfrage-Erstellung.
- E-Mail-Test Гјber den konfigurierten WordPress-Mailweg oder den SMTP-Zugang des Plugins.
- EmpfangsbestГ¤tigung fГјr Abteilungs-E-Mails mit signiertem Link, Versandstatus und Wiederholungsfunktion.
- GeschГјtzte Anfrageansicht fГјr die Abteilung mit Feldern, Verlauf, EmpfangsbestГ¤tigung und Antwortformular.
- Bidirektionales Ticket-Postfach Гјber IMAP fГјr Antworten von Besuchern und Abteilungen.
- Direkte E-Mail-Anfragen ohne bestehende Anfrage Nr. mit automatischer Nummer, Verlauf und Weiterleitung an einen Standard-EmpfГ¤nger.
- GeschГјtzter Browserdialog und E-Mail-Antwortweg auch fГјr direkt eingegangene E-Mails.
- Kurze nicht erratbare Zugriffscodes mit Cookie-Sitzung fГјr den geschГјtzten Browserdialog.
- ZuverlГ¤ssige WP-Cron-Planung und Statusanzeige fГјr die automatische PostfachprГјfung.
- Sichere Plus-Adressen pro Anfrage zur PrГјfung des eingehenden E-Mail-Dialogs.
- Detaillierte Fehlerprotokolle fГјr Testmails, Abteilungs-E-Mails, Autoantworten und Antworten aus dem Plugin.
- JSON-Sicherung und Wiederherstellung fГјr Einstellungen, EmpfГ¤nger-E-Mails, Abteilungen, Themen, Anfragen, Nachrichten und Protokolle.
- Self-hosted Updates Гјber `https://wdmin.com/plugins/feuer-kontaktform/update.json`.

## E-Mail-Zustellbarkeit

Der Plugin-Absender sollte eine Adresse der eigenen Domain sein, zum Beispiel `kontakt@wdmin.com`. FГјr diese Domain sollten SPF, DKIM und DMARC beim DNS-Anbieter gesetzt sein. Im WordPress-Backend zeigt der Tab `Zustellbarkeit`, welche Punkte konfiguriert sind und welche noch offen sind.

Autoantworten enthalten optional technische Header gegen automatische Antwortschleifen. Bei aktivem Ticket-Postfach wird `Reply-To` automatisch auf die sichere Anfrage-Adresse gesetzt. Ohne Ticket-Postfach gelten weiterhin die konfigurierten Reply-To-Regeln fГјr Abteilung oder Basisadresse.

## Ticket-Postfach

FГјr einen vollstГ¤ndigen E-Mail-Dialog kann ein eigenes Postfach wie `anfrage@domain.de` eingerichtet werden. Das Plugin verwendet SMTP fГјr ausgehende Nachrichten und IMAP fГјr eingehende Antworten. Der Mailanbieter muss Plus-Adressierung oder Catch-all unterstГјtzen, damit sichere Adressen wie `anfrage+fkt-12345678-securecode@domain.de` im selben Postfach ankommen. Auf dem Webserver muss die PHP-Erweiterung `imap` aktiviert sein.

Optional kГ¶nnen neue E-Mails ohne Anfrage Nr., die direkt an `anfrage@domain.de` gesendet werden, automatisch als neue Anfrage angelegt werden. Unter `Einstellungen в†’ Ticket-Postfach` wird dafГјr ein Standard-EmpfГ¤nger festgelegt. Dieser erhГ¤lt die weitergeleitete Nachricht und einen zeitlich begrenzten Browserlink. Ticket-Postfach und Standard-EmpfГ¤nger mГјssen unterschiedliche E-Mail-Adressen sein.

Der lesbare Textinhalt direkter E-Mails wird Гјbernommen. E-Mail-AnhГ¤nge werden in Version 3.0.34 noch nicht in den Anfrageverlauf importiert.

Die automatische PostfachprГјfung lГ¤uft Гјber WordPress-Cron alle fГјnf Minuten. Wenn `DISABLE_WP_CRON` auf dem Server aktiv ist, muss der Server-Cron regelmГ¤Гџig `wp-cron.php` aufrufen.

## Shortcodes

```text
[feuer-kontaktform]
[feuer-kontaktform department="wehrfuehrung"]
[feuer-kontaktform department="wehrfuehrung" topic="mitglied-werden"]
[feuer-kontaktform-schnell department="wehrfuehrung" topic="allgemein"]
```

## Update-Server

Das Plugin erwartet die Update-Metadaten unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/update.json
```

Das neueste ZIP liegt unter:

```text
https://wdmin.com/plugins/feuer-kontaktform/release/latest/feuer-kontaktform.zip
```

## Release

Ein Release-Paket wird mit `tools/build-release.ps1` erzeugt. Der Builder schreibt keine Ordner-EintrГ¤ge in das ZIP, setzt `ExternalAttributes` auf `0`, schreibt keine ZIP extra fields und vermeidet dadurch Windows-Owner/ACL-Metadaten. Die aktuelle Version wird in `release/<version>/` und `release/latest/` abgelegt.
